#!/bin/bash
#/**
# * Starts NodeJS to test build
# *
# */


nodejs server.js build

