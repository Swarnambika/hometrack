#TimeBase LawOne

##Installation

### Clone the GIT repository

`git clone git@bitbucket.org:timebase/tb-lawone.git`

### Install NodeJS (https://nodejs.org/)

If NodeJS was previously installed ensure that your npm is up-to-date by running `npm update -g npm`

### Install the NPM dependencies
Install the dependencies in the local node_modules folder.

`npm install`

### Install Bower (http://bower.io/)

`npm install -g bower`

### Install Grunt (http://gruntjs.com/)

`npm install -g grunt-cli`

### Install dependencies listed in bower.json 

`bower install`

##Release Build
To build the application ready for release run grunt without any options.

`grunt`