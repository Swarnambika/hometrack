var https = require("https"),
    url = require("url"),
    path = require("path"),
    fs = require("fs"),
    httpProxy = require('http-proxy');

var cwd = process.argv[2] || "",
    port = process.argv[3] || 8888;
 

var apiHost = 'ps-dev.timebase.com.au',
    apiPort = 80,
    apiLatency = 1;

//read in the SLL certificate and key
var options = {
  key: fs.readFileSync('localhost.key'),
  cert: fs.readFileSync('localhost.crt')
};


//set the current working directory. ie the root dirrectory
if (cwd) {
  try {
    process.chdir(cwd);
    console.log('Set working directory: ' + process.cwd());
  }
  catch (err) {
    console.log('chdir: ' + err);
  }
}

// 
// Create a proxy server to the API
// 
var proxy = httpProxy.createProxyServer({
  target: {
    host: apiHost,
    port: apiPort
  }
});


// Modify the proxy connection before data is sent
proxy.on('proxyReq', function(proxyReq, request, res, options) {
  proxyReq.setHeader('Host', apiHost);
});

 
// Listen for the `error` event on `proxy`. 
proxy.on('error', function (err, req, res) {
  res.writeHead(500, {
    'Content-Type': 'text/plain'
  });
 
  res.end('Something went wrong. Proxing the request the API.');
});


//create the NodeJD webserver
https.createServer(options, function (request, response) {
  //get the path for the current request
  var uri = url.parse(request.url).pathname,
    filename = path.join(process.cwd(), uri);

   fs.exists(filename, function(exists) {
    
    //direct any requests to /api to the proxy
    if (/^\/api/.exec(request.url)) {
       setTimeout(function () {
          proxy.web(request, response);
        }, apiLatency);
    }
    else
    {
      //if the file doesn't exist or it is directory then
      //rewrite the request to index.html
      if(!exists || fs.statSync(filename).isDirectory()) {
        filename = process.cwd() + '/index.html';
      }
      
      //read and write the file
      fs.readFile(filename, "binary", function(err, file) {
        if(err) {        
          response.writeHead(500, {"Content-Type": "text/plain"});
          response.write(err + "\n");
          response.end();
          return;
        }
   
        response.writeHead(200);
        response.write(file, "binary");
        response.end();
      });
    }
  });

}).listen(port);


 
console.log("Static file server running at\n  => https://localhost:" + port + "/\nCTRL + C to shutdown");
