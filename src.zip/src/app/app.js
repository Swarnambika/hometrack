angular.module( 'tbLawOne', [
  'sly',
  //'pasvaz.bindonce',
  'ui.router',
  //'oc.lazyLoad',
  'restangular',
  'ui.utils',
  'templates-app',
  'templates-common',
  'ngSanitize',
  'tbLawOne.directives',
  'tbLawOne.services',
  'tbLawOne.login',
  'tbLawOne.navigation',
  'tbLawOne.home',
  'tbLawOne.about',
  'tbLawOne.trail',
  'tbLawOne.user',
  'tbLawOne.departments',
  'ui.calendar',
  'tbLawOne.calendar',
  'tbLawOne.browse',
  'tbLawOne.search',
  'tbLawOne.legislation',
  'tbLawOne.lawtracker',
  'tbLawOne.commencements',
  'tbLawOne.error',
  'tbLawOne.print',
  'tbLawOne.sandbox',
  'ui.scroll',
  'ngStorage',
  'oauth',
  'angular-loading-bar',
  'mgcrea.ngStrap.helpers.dimensions',
  'mgcrea.ngStrap.helpers.parseOptions',
  'mgcrea.ngStrap.helpers.raf',
  'mgcrea.ngStrap.tooltip',
  'mgcrea.ngStrap.popover'
])

.config( function myAppConfig (
    $stateProvider,
    $urlRouterProvider,
    $httpProvider,
    $locationProvider,
    //$ocLazyLoadProvider,
    RestangularProvider,
    cfpLoadingBarProvider
) {
    $httpProvider.defaults.useXDomain = true;
    delete $httpProvider.defaults.headers.common['X-Requested-With'];
    //ABSTRACT STATE redirects, because we do not have default child state functionality
    $urlRouterProvider.when('/lawtracker/alerts/admin','/lawtracker/alerts/admin/profiles');
    $urlRouterProvider.when('/lawtracker/alerts','/lawtracker/alerts/display');
    $urlRouterProvider.when('/lawtracker/custom','/lawtracker/custom/form');
    $urlRouterProvider.when('/lawtracker/alerts/profile/:id','/lawtracker/alerts/profile/:id/subjects');
    ////$urlRouterProvider.when('/api/0.1/*path', '/about');
    $urlRouterProvider.when('/legislation/content/:id', function($match, $injector){
        var $state = $injector.get('$state');
        var $location = $injector.get('$location');
        var TbApi = $injector.get('TbApi');
        var AccessToken = $injector.get('AccessToken');
        var tbAuthService = $injector.get('tbAuthService');

        //now we see what to do about it
        if(AccessToken.get() && !AccessToken.expired()){
          //$scope.$emit('oauth:authorized', AccessToken.get());
          console.log("loading up we have a token which hasn't expired");
          TbApi.setDefaultHeaders({ 'Authorization' : 'Bearer ' + AccessToken.get().access_token });
        }else{
          console.log('Lack of access token when browse to legislation/content');
          tbAuthService.loginAuthServiceRaw($location.url());
        }
        
        console.log('LEGISLATION CONTENT ROUTING CHECK',$match, $location.search());
        var params = $location.search();

        if($.isNumeric($match['id'])){
            var singleId = $match['id'];
            console.log('WHEN SINGLEID', singleId);
            params['contId'] = singleId;

            TbApi.one('content/'+ singleId + '.json').get().then(function(ret){
                console.log('CONTENT FORWARDING REQUEST IF', ret);
                var leg = ret['data']['legislation'];

                if(leg['content-id']){
                   params['legId'] = leg['legislation-id'];
                   params['contId'] = leg['content-id'];

                    //window.location.replace($state.href('legislation', params, {absolute: true}));
                    $state.go('legislation', params,{ location: 'replace' });
                }else{
                    //window.location.replace($state.href('legdisplay', {id: $stateParams['legId']}, {absolute: true}));
                    $state.go('legdisplay', {id: leg['legislation-id']},{location: 'replace'});
                }
            });

            //$state.go('legsingle',params,{location: 'replace', inherit: true});
        }else{
            var legId = $match['id'].split('_')[0];
            var contId = $match['id'];
            TbApi.one('legislation/'+ legId + '.json').get().then(function(ret){
                console.log('CONTENT FORWARDING REQUEST ELSE', ret);
                var leg = ret['data']['legislation'];

                params['legId'] = leg['legislation-id'];
                params['contId'] = contId;
                console.log('WHEN LEGID', params['legId']);
                console.log('WHEN CONTID', params['contId']);
                $state.go('legislation', params, {location: 'replace', inherit: true});
            });
        }
    });
    $urlRouterProvider.otherwise( '/home' );

    //THIS ALLOWS FOR URL CHANGES WITHOUT A STATE RELOAD
    //DO NOT MOVE THIS
    $urlRouterProvider.deferIntercept();

    //configure base url for back end access
    RestangularProvider.setBaseUrl('assets/api');
    RestangularProvider.setDefaultHttpFields({cache: false});

    //html5mode - NECESSARY FOR OAUTH TO WORK!!!
    $locationProvider.html5Mode(true).hashPrefix('!');

    //loading bar global
    cfpLoadingBarProvider.includeSpinner = false;
})

.run([
    '$rootScope', '$state', '$stateParams',
    function ($rootScope,   $state,   $stateParams) {
        // It's very handy to add references to $state and $stateParams to the $rootScope
        // so that you can access them from any scope within your applications.For example,
        // <li ng-class="{ active: $state.includes('contacts.list') }"> will set the <li>
        // to active whenever 'contacts.list' or one of its decendents is active.
        $rootScope.$state = $state;
        $rootScope.$stateParams = $stateParams;
    }
])

.controller( 'AppCtrl', function AppCtrl (
    $scope,
    $rootScope,
    $urlRouter,
    $location,
    $state,
    $stateParams,
    $q,
    $http,
    tbSearchServiceAlt,
    AccessToken,
    TbApi,
    TbDrmApi,
    TbNewApi,
    TbTestingApi,
    tbUserService,
    tbSavedSearchService,
    tbFavouritesService,
    tbAuthService,
    tbTrailService,
    $modal,
    $window,
    $modalStack,
    $localStorage,
    $timeout
){
    console.log('APP INIT WINDOW LOCATION DUMP',window.location);
    //define the searchForm object with which the search function will work
    console.log('APP INIT $LOCATION.SEARCH() DUMP',$location.search());
    console.log('APP INIT PATHNAME DUMP',$location.path());

    $rootScope.locationSpoof = function(url){
        console.log('locationSpoof: ', url);
        $timeout(function(){
            $rootScope.blockSync = true;
            $location.path(url).replace();
        },0);
    };

    //URL REPLACER - FOUL SORCERY
    //THIS MUST BE DECLARED BEFORE THE DEFAULT $urlRouter.listen() CALL!
    $rootScope.$on('$locationChangeSuccess', function(event, newUrl, oldUrl){
        console.log('locationChangeSuccess: ', newUrl, oldUrl);
        if($rootScope.blockSync){
            console.log('locationChangeSuccess: preventDefault');
            event.preventDefault();
            $rootScope.blockSync = false;
        }
    });

    // //THIS MUST BE DECLARED AFTER $rootScope.on('$locationChangeSuccess')!
    $urlRouter.listen();

    //init authentication stuff
    //this sets the access token if one is actually present
    tbAuthService.initAuthService($scope);

    //now we see what to do about it
    if(AccessToken.get() && !AccessToken.expired()){
        //$scope.$emit('oauth:authorized', AccessToken.get());
        console.log("loading up we have a token which hasn't expired");
        TbApi.setDefaultHeaders({ 'Authorization' : 'Bearer ' + AccessToken.get().access_token });
        TbDrmApi.setDefaultHeaders({ 'Authorization' : 'Bearer ' + AccessToken.get().access_token });
        TbTestingApi.setDefaultHeaders({ 'Authorization' : 'Bearer ' + AccessToken.get().access_token });
        TbNewApi.setDefaultHeaders({ 'Authorization' : 'Bearer ' + AccessToken.get().access_token });
        //now that we have a token, let's go get a user
        // if(!tbUserService.getUserObject()['user']){
        //     console.log('since we have a token, lets get a user');
        //     tbUserService.loadUserObject();
        // }
    }

    if($location.path().indexOf('search') > -1 || $location.path().indexOf('legislation') > -1){
        tbSearchServiceAlt.setObjectFromUrl($location.search());
    }else{
        tbSearchServiceAlt.newSearchObject();
    }

    window.Intercom("boot", {
      app_id: "fekub4it"
    });
  
    //end init
    TbApi.setErrorInterceptor(function(response, deferred, responseHandler){
        console.log("Restangular Error Interceptor:",JSON.stringify(response));
        if(response.status){
            if(response.status == 401){
                tbAuthService.loginAuthServiceRaw($location.url());
                //window.location.reload();
                //$state.go('error', {code: response.status},{location: 'replace', inherit: false});
            }else if(response.status == 403){
                if(response.data && response.data.data && response.data.data.reason){
                    switch(response.data.data.reason){
                        case "No subscription":
                            window.location.replace('https://login.timebase.com.au/Authorisation/NoSubscription');
                            break;
                        case "IP address isn't valid":
                            window.location.replace('https://login.timebase.com.au/Authorisation/NoRoaming');
                            break;
                        case 'No available subscription':
                            if(response.data.data.subscriptions && response.data.data.subscriptions[0] && response.data.data.subscriptions[0].state){
                                switch(response.data.data.subscriptions[0].state){
                                    case 'Subscription uncommenced':
                                        window.location.replace('https://login.timebase.com.au/Authorisation/Uncommenced');
                                        break;
                                    case 'Maximum concurrent user limit exceeded':
                                        window.location.replace('https://login.timebase.com.au/Authorisation/MaxConcurrentUsers');
                                        break;
                                    case 'Subscription expired':
                                        window.location.replace('https://login.timebase.com.au/Authorisation/Expired');
                                        break;
                                    default:
                                        console.log( 'Unknown availble 403 state property under subscription error', response.data );
                                        window.location.replace('https://login.timebase.com.au/Authorisation/NoSubscription');
                                }
                            }
                            else {
                                console.log( 'No availble 403 subscription state property under subscription error', response.data );
                                window.location.replace('https://login.timebase.com.au/Authorisation/NoSubscription');
                            }
                            break;
                        default:
                            $scope.$broadcast('RestErrorThrown', response);
                    }
                }
                else {
                    $scope.$broadcast('RestErrorThrown', response);
                }
            }else{
                $scope.$broadcast('RestErrorThrown', response);
            }
        }
    });

    $scope.$on('refineSearch', function(event, value){
        console.log('refine search event received', value);
        $scope.$broadcast('refineSearchParams', value);
    });

    $scope.$on('$stateChangeError', function(event, toState, toParams, fromState, fromParams){
        console.log('$stateChangeError');
        console.log(event);
        console.log(toState);
        console.log(toParams);
        console.log(fromState);
        console.log(fromParams);
    });

    $scope.searchKeyFired = function(e){
        e.preventDefault();
        console.log("testing S key");
        console.log(e);
    };

    var expiryHandled = false;

    //fires upon a successful login
    $scope.$on('oauth:login', function(event, token) {
        console.log('ROOT EVENT oauth:login - Authorized third party app with token', token.access_token);
        //TbApi.setDefaultHeaders({ 'Authorization' : 'Bearer ' + AccessToken.get().access_token });
        //console.log('Token!', TbApi);
        expiryHandled = false;
        
    });

    //fires upon load and sequentially after a successful login
    $scope.$on('oauth:authorized', function(event, token) {
        console.log('ROOT EVENT oauth:authorized - Non expired token in local/session storage', token.access_token);
        //set the token to TBAPI for purposes of API hits
        TbApi.setDefaultHeaders({ 'Authorization' : 'Bearer ' + AccessToken.get().access_token });
        //now that we have a token, let's go get a user object

        if(!tbUserService.getUserObject()['user']){
            console.log('user not detected');
            tbUserService.loadUserObject();
        }
mixpanel.track('user',tbUserService.getUserObject()['user']);
        expiryHandled = false;
    });

    $scope.$on('oauth:logout', function(event) {
        console.log('EVENT oauth:logout - The user is not logged in');
        tbUserService.clearUserObject();
        AccessToken.destroy();
        window.Intercom("shutdown");
        mixpanel.track("Log Out");
        window.location.replace('http://www.timebase.com.au');
        //$state.go('login');
        expiryHandled = false;
    });

    $scope.$on('oauth:denied', function(event) {
      console.log('EVENT oauth:denied - The user did not authorize the third party app');
    });

    $scope.$on('oauth:expired', function(event) {
        if(!expiryHandled){
            console.log('EVENT oauth:expired - The access token is expired. Please refresh.', event);
            console.log('expiry check STATE', $state);
            tbUserService.clearUserObject();
            AccessToken.destroy();
            window.Intercom("shutdown");
            mixpanel.track("Log Out");
            console.log('path', $location);
            //tbAuthService.loginAuthService($state.current.name, $stateParams);
            tbAuthService.loginAuthServiceRaw($location.url());
            //window.location.replace('http://www.timebase.com.au');
            //console.log('expiry',$state,event);
            expiryHandled = true;
        }
    });

    var stateChangeInterceptor = function(event, toState, toParams, fromState, fromParams){
        //console.log('State Change Start interception filter function called');

        if(fromState.name == 'lawtracker.alerts.profile' || fromState.parent == 'lawtracker.alerts.profile'){
            //console.log('Substate Changed?',fromState.data.subStateChanged);
            if(fromState.data.subStateChanged){
                event.preventDefault();

                var modalInstance = $modal.open({
                   templateUrl: 'lawtracker/transitionalert.tpl.html',
                   controller:  'AlertsTransitionModalCtrl',
                   windowClass: 'alert-create-modal'
                });

                modalInstance.result.then(function(ret){
                    if(ret){
                        switch(ret){
                            case 'dismiss':
                                fromState.data.subStateChanged = false;
                                $state.go(toState, toParams);
                                break;
                            case 'save':
                                fromState.data.subStateChanged = false;
                                var stateInfo = {
                                    'toState': toState,
                                    'toParams': toParams
                                };

                                $scope.$broadcast('profileOmniSubmit', stateInfo);
                                break;
                        }
                    }
                });
            }
        }
        //handling search/legislation and search object stuff
        else{
            //first let's check if we need to do anything at all
            //if we aren't entering a state that cares, we don't care
            if((toState['name'] == 'search' || toState['name'] == 'legislation') && !tbSearchServiceAlt.isPassthrough()) {
                //first, look for passthrough, have we already processed this?
                console.log('Interceptor: Search has no passthrough, doing stuff');
                console.log('Interceptor: toParams', toParams);

                //no we haven't got passthrough, time to do stuff
                var inherit = true;
                var restartStateChange = false;

                //set the passthrough so we don't need to do this again
                tbSearchServiceAlt.setPassthrough();

                //transition from browse shouldn't inherit because browse uses the same params as search
                if(fromState['name'] === 'browse.form'){
                    inherit = false;
                }

                //if search object IS empty and the to-params HAS a term
                if(tbSearchServiceAlt.isSearchEmpty() && toParams['term']){
                    //console.log('Object is empty');
                    tbSearchServiceAlt.setObjectFromUrl(toParams);
                    restartStateChange = true;
                }

                //if search object IS empty and the to-params HAS a term
                if(tbSearchServiceAlt.isSearchEmpty() && toParams['term']){
                    //console.log('Object is not empty');
                    tbSearchServiceAlt.setObjectFromUrl(toParams);
                    //restartStateChange = true;
                }

                //if search object is NOT empty and the to-param has NO term
                if(!tbSearchServiceAlt.isSearchEmpty() && !toParams['term']){
                    //add the search object params to the toParams
                    //console.log('Interceptor: Search is NOT empty and toParams has NO term');
                    var params = tbSearchServiceAlt.getStateParams();

                    for(var key in params){
                        if(params[key] != 'page' && (params[key] != toParams[key])) {
                            toParams[key] = params[key];
                            restartStateChange = true;
                        }
                    }
                    //the toParams have been change so restart the state change
                }

                //if search object is NOT empty and the to-params HAS a term and the search object is NOT matching the toParams
                if(!tbSearchServiceAlt.isSearchEmpty() && toParams['term'] && !_.isEqual(tbSearchServiceAlt.searchObject, tbSearchServiceAlt.parseUrlToObject(toParams))){
                    //console.log('special breadcrumb exception caught');
                    tbSearchServiceAlt.setObjectFromUrl(toParams);
                }

                if (restartStateChange) {
                    //stop the transition
                    event.preventDefault();

                    if(toState['name'] == 'search'){
                      $state.go(toState,toParams,{inherit:inherit, reload:true});
                    }else{
                      $state.go(toState,toParams,{inherit:inherit});
                    }
                }
            }//end processing, we aren't looking at toStates we care about
        }
    };

  
    //for updating Intercom, is called from $stateChangeStart event handler.
    var updateIntercom = function(){
      var user = tbUserService.getUserObject().user;
      if(user){
        var company_id = user['_links']['organisation']['href'].split('/')[4].split('.json')[0];

        var params = {
          name: user.firstname + " " + user.surname, // Full name
          email: user.email, // Email address
          created_at: (new Date(user['added-date']).getTime() / 1000), // Signup date as a Unix timestamp
          company: {
              id: company_id,
              name: user.organisation,
              ////created_at: (new Date().getTime() / 1000)
          },
          user_id : user.id,
          "LawOne Account Type": user.type,
          "LawOne Account Roles": user.roles.join(',')
        };

        if(user.type !== "shared"){
            var alertCountPromise = TbApi.all('profiles.json').getList();
            var savedCountPromise = tbSavedSearchService.getSavedSearches();
            var favesCountPromise = tbFavouritesService.getFavourites();

            $q.all([alertCountPromise, savedCountPromise, favesCountPromise]).then(function(data){
                console.log('PROMISE SET TEST', data);
                if(data[0]){ params['LawOne Alert Profiles'] = data[0][2].length; }
                if(data[1]){ params['LawOne Saved Searches'] = data[1]['data']['searches'].length; }
                if(data[2]){ params['LawOne Favourites'] = data[2]['data']['favourites'].length; }

                window.Intercom("update", params);
                
            });
        }else{
            window.Intercom("update", params);
            
        }
      }
    };

 

    $scope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams){
        //$scope.stateshift = true;
        console.log('stateChangeStart: ', event, toState, toParams, fromState, fromParams);

        //check for token, if not present kick user to login
        if(!AccessToken.get()){
            switch(toState['name']){
                case 'login':
                mixpanel.time_event("Log Out");
                    break;
                default:
                    console.log('caught lack of access token');
                    event.preventDefault();
                    console.log('firing transition',toState, toParams);
                    console.log('pre-auth redirect check', $location.url());
                    tbAuthService.loginAuthServiceRaw($location.url());
                    //tbAuthService.loginAuthService(toState['name'], toParams);
                    //$state.go('login');
            }
        }
        //do state interception stuff right here
        else{
            //is user object empty?
            if(!tbUserService.getUserObject()['user']){
                //gate this behind a promise
                tbUserService.loadUserPromise().then(function(ret){
                    console.log('USER FIX TEST',ret);
                    if(ret && ret['data']){
                        tbUserService.setUserObject(ret['data']);
                        console.log('USER INDIVIDUALITY', tbUserService.isUserIndividual());

                        updateIntercom();
                        mixpanel.time_event("Log Out");
                        if(!tbUserService.isUserIndividual() && (toState['name'].indexOf('lawtracker.alerts') > -1 || toState['name'].indexOf('user.account') > -1 || toState['name'].indexOf('user.favourites') > -1 || toState['name'].indexOf('user.searches') > -1 || toState['name'].indexOf('user.admin') > -1)){
                            console.log('USER IS NOT AN INDIVIDUAL');
                            event.preventDefault();
                            $state.go('userblock');
                        }else{
                            stateChangeInterceptor(event, toState, toParams, fromState, fromParams);
                        }
                    }else{
                        alert('ERROR: User details inaccessible!');
                    }
                });
            }else{
                if(!tbUserService.isUserIndividual() && (toState['name'].indexOf('lawtracker.alerts') > -1 || toState['name'].indexOf('user.account') > -1 || toState['name'].indexOf('user.favourites') > -1 || toState['name'].indexOf('user.searches') > -1 || toState['name'].indexOf('user.admin') > -1)){
                    console.log('USER IS NOT AN INDIVIDUAL');
                    event.preventDefault();
                    $state.go('userblock');
                }else{
                    stateChangeInterceptor(event, toState, toParams, fromState, fromParams);
                }
            }

            // //if(tbUserService.getUserRoles() && tbUserService.getUserRoles().indexOf('share') > -1){
            // if(tbUserService.getUserObject && !tbUserService.isUserIndividual()){
            //     if(toState['name'].indexOf('lawtracker.alerts') > -1 || toState['name'].indexOf('user.account') > -1 || toState['name'].indexOf('user.favourites') > -1 || toState['name'].indexOf('user.searches') > -1 || toState['name'].indexOf('user.admin') > -1){
            //         event.preventDefault();
            //         $state.go('userblock');
            //     }else{
            //         stateChangeInterceptor(event, toState, toParams, fromState, fromParams);
            //     }
            // }else{
            //     stateChangeInterceptor(event, toState, toParams, fromState, fromParams);
            // }
        }
    });

    $scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams){
        console.log("StateChangeSuccess", $location.url(), toState);
        tbSearchServiceAlt.clearPassthrough();

        if($location.url() && ((toState.name !== 'legforward') && (toState.name !== 'legislation') && (toState.parent !== 'legsummary'))){
            tbTrailService.addTrailItem({title: toState.data.pageTitle, url: $location.url()});
        }

        if ( angular.isDefined( toState.data.pageTitle ) ) {
            $scope.pageTitle = toState.data.pageTitle + ' | LawOne' ;
        }else{
            $scope.pageTitle = "LawOne";
        }

        window.Intercom("update");
     
        //console.log('testing GA', $window.ga);
        $modalStack.dismissAll('dismiss all open modals');
        if($localStorage.errorMessList){ $localStorage.errorMessList = null; }
        tbAuthService.pingAuthService();
    });

    $scope.$on('PageTitleChanged', function(event, title){
        event.preventDefault();
        event.stopPropagation();

        console.log('page title changed', title);

        if (title) {
            $scope.pageTitle = title + ' | LawOne' ;
        }
    });

    window.onerror = function(msg, url, line){
        console.log('Error: ' + msg + '\n Line No: ' + line);
    };
})

;
