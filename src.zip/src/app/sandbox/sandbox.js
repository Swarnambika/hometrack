angular.module( 'tbLawOne.sandbox', [
  'ui.router',
  'ui.bootstrap',
  'tbLawOne.services'
])

.config(function config( $stateProvider ) {
    $stateProvider
        //test
        .state( 'sandboxmaster', {
            abstract: true,
            views: {
                "main" : {
                    controller: 'SandboxCtrl',
                    templateUrl: 'sandbox/sandbox.tpl.html'
                },
                "col1@sandboxmaster" : {
                    controller: 'SandboxPanelCtrl',
                    templateUrl: 'sandbox/sandboxpanel.tpl.html'
                },
                "col2@sandboxmaster" : {
                    controller: 'SandboxMainCtrl',
                    template: '<div ui-view="content"></div>'
                }
            },
            data:{ pageTitle: 'SANDBOX TESTING' }
        })
        .state( 'sandbox', {
            url: '/test',
            parent: 'sandboxmaster',
            views: {
                "content" : {
                    controller: 'SandboxContentCtrl',
                    templateUrl: 'sandbox/sandboxcontent.tpl.html'
                }
            },
            data:{ pageTitle: 'SANDBOX CONTENT TESTING' }
        })
    ;//end stateProvider
})

.controller( 'SandboxCtrl', function SandboxController(
    $scope,
    $stateParams,
    TbApi
){

})

.controller( 'SandboxMainCtrl', function SandboxController(
    $scope,
    $stateParams,
    TbApi
){

})

.controller( 'SandboxPanelCtrl', function SandboxController(
    $scope,
    $stateParams,
    TbApi
){

})

.controller( 'SandboxContentCtrl', function SandboxController(
    $scope,
    $stateParams,
    TbApi
){

})

;//end module
