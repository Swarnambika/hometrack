angular.module( 'tbLawOne.search', [
  'ui.router',
  'ui.bootstrap',
  'restangular',
  'tbLawOne.services',
  'ngSanitize'
])

.config(function config( $stateProvider ) {
    $stateProvider
        .state( 'searchmaster', {
            abstract: true,
            views: {
                "main" : {
                    controller: 'SearchCtrl',
                    templateUrl: 'search/search.tpl.html'
                },
                "col1@searchmaster" : {
                    controller: 'SearchPanelCtrl',
                    templateUrl: 'search/panel.tpl.html'
                },
                "col2@searchmaster" : {
                    controller: 'SearchHoldCtrl',
                    template: '<div ui-view="content"></div>'
                }
            }
        })
        .state( 'search', {
            url: '/search?term?modifier?scope?juris?doc-type?status?subject?start?sort?page?open?department?within?principal?expand',
            parent: 'searchmaster',
            views: {
                "content" : {
                    controller: 'SearchResultsCtrl',
                    templateUrl: 'search/results.tpl.html'
                }
            },
            data:{ pageTitle: 'Search' },
            onEnter: function($stateParams, trdoctypeFilter, trstatusFilter){
                console.log('ONENTER SEARCH EVENT FIRED', $stateParams);
                var title = "Search";
                if($stateParams['term'] && $stateParams['term'] !== ""){
                    title += (" - \"" + $stateParams['term'] + "\"");
                }
                if($stateParams['scope'] && $stateParams['scope'] !== ""){
                    title += (" | " + $stateParams['scope']);
                }

                var temp = "";
                var i = 0;
                var arr = [];

                if($stateParams['juris'] && $stateParams['juris'] !== ""){
                    if($stateParams['juris'] == 'all' || $stateParams['juris'] == 'All'){
                        title += (" | All");
                    }else{
                        arr = $stateParams['juris'].split(',');
                        for(i = 0;i<arr.length;i++){
                            temp = temp += arr[i] + ", ";
                        }
                        temp = temp.slice(0,-2);
                        title += (" | " + temp);
                        temp = "";
                    }

                }

                if($stateParams['doc-type'] && $stateParams['doc-type'] !== ""){
                    if($stateParams['doc-type'] == 'all' || $stateParams['doc-type'] == 'All'){
                        title += (" | All");
                    }else{
                        arr = $stateParams['doc-type'].split(',');
                        for(i = 0;i<arr.length;i++){
                            temp = temp += trdoctypeFilter(arr[i]) + ", ";
                        }
                        temp = temp.slice(0,-2);
                        title += (" | type: " + temp);
                        temp = "";
                    }
                }

                if($stateParams['status'] && $stateParams['status'] !== ""){
                    if($stateParams['status'] == 'all' || $stateParams['status'] == 'All'){
                        title += (" | All");
                    }else{
                        arr = $stateParams['status'].split(',');
                        for(i = 0;i<arr.length;i++){
                            temp = temp += trstatusFilter(arr[i]) + ", ";
                        }
                        temp = temp.slice(0,-2);
                        title += (" | " + temp);
                        temp = "";
                    }
                }

                if($stateParams['year'] && $stateParams['year'] !== ""){
                    title += (" | year: " + $stateParams['year']);
                }

                if($stateParams['principal']){
                    if($stateParams['principal'] == 'true'){
                        title += (" | " + "Principal");
                    }else if($stateParams['principal'] == 'false'){
                        title += (" | " + "Amending");
                    }
                }

                if($stateParams['subject'] && $stateParams['subject'] !== ""){
                    title += (" | subjects: " + $stateParams['subject'].split(',').length);
                }
                if($stateParams['department'] && $stateParams['department'] !== ""){
                    title += (" | depts: " + $stateParams['department'].split(',').length);
                }

                if($stateParams['within'] && $stateParams['department'] !== ""){
                    title += (" | within specific legislation");
                }
                this.data.pageTitle = title;
            }
        })
    ;//end stateProvider declarations
})

.controller('SearchHoldCtrl', function SearchHoldController($scope){

})

.controller( 'SearchCtrl', function SearchController( $scope, $location, $stateParams, $state, $modal, TbApi, $timeout, tbSearchServiceAlt, tbSavedSearchService, tbFavouritesService, tbUserService) {
    console.log('SEARCH MASTER CONTROLLER FIRED');
    $scope.panelVisible = {};
    $scope.childLoaded = false;

    $scope.data = {
        selected: []
    };

    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            if(user['user'] && user.isIndividual()){
                $scope.showUserButtons = true;
            }
        },
        true
    );

    $scope.openAdvSearch = function(){
        console.log("refineSearch event emitted");
        if(tbSearchServiceAlt.searchObject.searchwithin.id){
            TbApi.one('/legislation/' + tbSearchServiceAlt.searchObject.searchwithin.id + ".json").get().then(function(ret){
                $scope.$emit('refineSearch', {
                    'searchwithin':{
                        title: ret['data']['legislation']['title'],
                        id: tbSearchServiceAlt.searchObject.searchwithin.id
                    }
                });
            });
        }else{
            $scope.$emit('refineSearch');
        }
    };

    $scope.xvalue = 0;
    $scope.yvalue = 0;
    $scope.databox = {};
    $scope.databox.numHits = -1;

    $scope.$on('SearchResultLoaded', function(e, v){
        e.stopPropagation();
        console.log('SearchCtrl: SearchResultLoaded', e, v);
        if(v){
            $scope.childLoaded = true;
            $scope.$broadcast('refreshFacets');
        }

        console.log('SearchResultLoaded getting the search object',tbSearchServiceAlt.searchObject);
    });

    $scope.getSelectedItems = function(){
        return $scope.data.selected;
    };

    $scope.modalProfileOpen = function(){
        console.log('Modal add to profile called');
        var modalInstance = $modal.open({
            templateUrl: 'search/modalSearchProfile.html',
            controller: 'ModalSearchProfileCtrl',
            resolve: {
                selected: function(){
                    return $scope.data.selected;
                }
            }
        });
    };

    $scope.modalFavouritesOpen = function(){
        if(tbUserService.getUserObject() && !tbUserService.isUserIndividual()){
            tbUserService.showShareBlockModal();
        }else{
            console.log('Modal add to favourites called');
            var modalInstance = $modal.open({
                templateUrl: 'search/modalSearchFavourites.html',
                controller: 'ModalSearchFavouritesCtrl',
                resolve: {
                    selected: function(){
                        return $scope.data.selected;
                    }
                }
            });

            modalInstance.result.then(function(){
                if($scope.data.selected && $scope.data.selected.length > 0){
                    console.log('SELECTED FAVES',$scope.data.selected);
                    tbFavouritesService.addMultipleFavourites($scope.data.selected.map(function(item){
                        return item['doc-id'];
                    }));
                }
            });
        }
    };

    //modal functions
    $scope.modalSaveOpen = function(){
        if(tbUserService.getUserObject() && !tbUserService.isUserIndividual()){
            tbUserService.showShareBlockModal();
        }else{
            console.log('Modal save called', $state.current.data.pageTitle);

            var currentSearch = _.clone(tbSearchServiceAlt.searchObject);

            var modalInstance = $modal.open({
                templateUrl: 'search/modalSaveSearch.html',
                controller: 'ModalSaveSearchCtrl',
                resolve: {
                    searchObject: function(){
                        return $state.current.data.pageTitle;
                    }
                }
            });

            modalInstance.result.then(function(ret){
                if(ret){
                    tbSavedSearchService.addSavedSearch({
                        date: new Date().toISOString(),
                        string: $state.current.data.pageTitle,
                        search: currentSearch
                    });
                }
            });
          }
    };

    $scope.modalPrintOpen = function(){
        console.log('Modal print called');
        var modalInstance = $modal.open({
            templateUrl: 'search/modalSearchPrint.html',
            controller: 'ModalSearchPrintCtrl',
            resolve: {
                searchItems: function(){
                    return $scope.getSelectedItems();
                }
            }
        });

        modalInstance.result.then(function(ret){
            console.log('Print modal dismissed!',ret);
            var params = {};
            switch(ret){
                case 'sections':
                    params.sections = true;
                    break;
                case 'selected':
                    var ids = $scope.data.selected.map(function(item){
                        return item['legislation-id'];
                    });

                    params.selected = ids.join(',');
                    break;
                case 'results':
                    break;
            }
            var sparams = tbSearchServiceAlt.getStateParams();
            sparams.sections = params.sections;
            sparams.selected = params.selected;
            delete sparams.page;
            // if(!sparams['sort']){
            //     sparams['sort'] = 'rel';
            // }

            console.log('SPARAMS',sparams);
            var url = $state.href('searchprint',sparams);
            window.open(url, '_blank');
            //$state.go('searchprint',params);
        });
    };

    $scope.modalDownloadOpen = function(){
        console.log('Modal download called');
        var modalInstance = $modal.open({
            templateUrl: 'search/modalSearchDownload.html',
            controller: 'ModalSearchDownloadCtrl',
            resolve: {
                searchItems: function(){
                    return $scope.getSelectedItems();
                }
            }
        });

        modalInstance.result.then(function(){
            //$log.info('Print modal dismissed!');
        });
    };

    $scope.modalShareOpen = function(){
        console.log('modal share called');
        var modalInstance = $modal.open({
            templateUrl: 'search/modalSearchShare.html',
            controller: 'ModalSearchShareCtrl',
            resolve: {
                searchItems: function(){
                    return $scope.getSelectedItems();
                }
            }
        });

        modalInstance.result.then(function(){
            //$log.info('Share modal dismissed!');
        });
    };
})

.controller( 'SearchPanelCtrl', function SearchPanelController(
    $scope,
    $state,
    $stateParams,
    tbSearchServiceAlt,
    TbApi,
    ENV,
    trjurisFilter,
    trjurisrevFilter,
    trdoctypeFilter,
    trdoctyperevFilter,
    trstatusFilter,
    trstatusrevFilter,
    $location,
    listsubjects
){
    console.log("FACETS: Search filter controller fired!");

    var initFacets = function(){
        //get search params from currently active search object
        $scope.initialParams = tbSearchServiceAlt.getSearchParams();

        console.log('FACETS PARAMS JURIS',$scope.initialParams['jurisdiction']);

        $scope.showLoader = true;
        $scope.loadCounter = 0;
        $scope.hasFacets = false;
        $scope.showFacets = false;
    };

    initFacets();

    $scope.$watch('loadCounter', function(newValue, oldValue){
        if(newValue >= 6){
            $scope.showLoader = false;
        }
    });

    $scope.facetsParams = function(facet){
        var finalParams = {
            'term': $scope.initialParams['term'],
            'jurisdiction': $scope.initialParams['jurisdiction'],
            'doc-type': $scope.initialParams['doc-type'],
            'status': $scope.initialParams['status'],
            'principal': $scope.initialParams['principal'],
            'subject': $scope.initialParams['subject'],
            'department': $scope.initialParams['department'],
            'scope' : $scope.initialParams['scope']
        };

        return finalParams;
    };

    var buildFacetLinks = function(type, name, search){
        //this builds the prefix required
        var base = ENV.apiPath + "search/facets/";
        var actual = ""; //this is a placeholder for the string of the current facet, it will be removed

        switch(type){
            case 'juris':
                base += "jurisdiction.json";
                actual = trjurisrevFilter(name);
                break;
            case 'doctype':
                base += "document-type.json";
                actual = trdoctyperevFilter(name);
                break;
            case 'status':
                base += "legislative-status.json";
                actual = trstatusrevFilter(name);
                break;
            case 'subject':
                base += "subject.json";
                actual = name;
                break;
        }

        var urlSearchString = window.location.search;
        var splitString = urlSearchString.split(/&(.+)?/);
        var modString = splitString[1].replace(actual + ",", "").replace(actual, "");
        var clearString = splitString[0] + "&" + modString;

        //get which ones we care about
        var links = {
            clear: {
                href: base + clearString //remove NAME from the TYPE
            },
            drilldown: {
                href: base + "" //do nothing else, we don't use this at all
            },
            parallel: {
                href: base + urlSearchString //send exactly what we got, do nothing else
            }
        };
        return links;
    };

    var addMissingFacets = function(inArray, type){
        console.log('ADD MISSING FACETS CALLED', inArray, type);

        var locationSearchParams = [];
        var stringList = [];

        switch(type){
            case 'juris':
                if($location.search()['juris']){
                    locationSearchParams = $location.search()['juris'];
                    stringList = locationSearchParams.split(',').map(
                        function(item){
                            return trjurisFilter(item);
                        }
                    );
                }
                break;
            case 'doctype':
                if($location.search()['doc-type']){
                    locationSearchParams = $location.search()['doc-type'];
                    stringList = locationSearchParams.split(',').map(
                        function(item){
                            return trdoctypeFilter(item);
                        }
                    );
                }
                break;
            case 'status':
                if($location.search()['status']){
                    locationSearchParams = $location.search()['status'];
                    stringList = locationSearchParams.split(',').map(
                        function(item){
                            return trstatusFilter(item);
                        }
                    );
                }
                break;
        }

        _.each(stringList, function(item){
            if(!_.find(inArray, function(v){
                return v.name == item;
            })){
                console.log('MISSING', type);
                inArray.push({
                    'name': item,
                    'hits': 0,
                    'filtered': true, //is this present in the search, if so, set true?
                    '_links' : buildFacetLinks(type, item, $scope.initialParams) //push this through to the cruncher to produce a valid links object
                });
            }else{
                console.log('PRESENT', type);
            }
        });

        return inArray;
    };

    var getFacets = function(){
        TbApi.one('search/facets/jurisdiction.json').get($scope.facetsParams('jurisdiction'))
        .then(function(ret){
            $scope.fjuris = ret['data'];
            addMissingFacets(ret['data']['filters'], 'juris');
            $scope.loadCounter++;
            if(ret['data'].length > 0){ $scope.hasFacets = true; }
        });

        TbApi.one('search/facets/document-type.json').get($scope.facetsParams('doc-type'))
        .then(function(ret){
            var tmpfdoctype = {};
            tmpfdoctype['name'] = ret['data']['name'];
            if(ret['data']['filters']){
                console.log('Remove Aged Care Principle', ret['data']['filters']);
                tmpfdoctype['filters'] = ret['data']['filters'].filter(function(item){
                    return item.name !== 'Aged Care Principle';
                });
            }
            $scope.fdoctype = tmpfdoctype;
            addMissingFacets(ret['data']['filters'], 'doctype');
            $scope.loadCounter++;
            if(ret['data'].length > 0){ $scope.hasFacets = true; }
        });

        TbApi.one('search/facets/legislative-status.json').get($scope.facetsParams('status'))
        .then(function(ret){
            $scope.fstatus = ret['data'];
            addMissingFacets(ret['data']['filters'], 'status');
            $scope.loadCounter++;
            if(ret['data'].length > 0){ $scope.hasFacets = true; }
        });

        TbApi.one('search/facets/principal.json').get($scope.facetsParams('principal'))
        .then(function(ret){
            console.log('FACETS:  facets loaded');
            $scope.fprincipal = ret['data'];
            $scope.loadCounter++;
            if(ret['data'].length > 0){ $scope.hasFacets = true; }
        });

        TbApi.one('search/facets/subject.json').get($scope.facetsParams('subject'))
        .then(function(ret){
            console.log('FACETS: SUBJECT facets loaded', ret['data']);

            $scope.loadCounter++;
            if(ret['data'] && ret['data']['filters'].length > 0){
                $scope.hasFacets = true;

                var tfinal = ret['data'];

                var tempsub = ret['data']['filters'].slice(0, 10);
                var temprest = ret['data']['filters'].slice(11);
                var tempext = _.filter(temprest, function(item){
                    if(item['filtered']){return item;}
                });
                console.log('tempext', tempext);
                tfinal['filters'] = tempsub.concat(tempext);
                $scope.fsubject = tfinal;

                //the URL has subjects, so we need to care about this
                if($location.search()['subject']){

                    //get the subject IDs from the URL by splitting on the subject sparam
                    var subjectsInUrl = $location.search()['subject'].split(',');
                    console.log('SUBJECTS IN URL', subjectsInUrl);

                    //holding array for stuff where we have something in the url but not in the return
                    var subjectsInUrlAndFacets = [];

                    //go through the facets' hrefs and see if there is a case of the above
                    for(var i = 0; i < subjectsInUrl.length; i++){ //for each item in the url
                        for(var j = 0; j < tfinal['filters'].length; j++){ //for everything we have from the filter service
                            var currentHref = tfinal['filters'][j]['_links']['drilldown']['href'];

                            if(currentHref.indexOf(subjectsInUrl[i]) > -1){ //is it present?
                                subjectsInUrlAndFacets.push(subjectsInUrl[i]); //push it if so
                                break; //don't need to loop after we found one
                            }
                        }
                    }

                    //now go through the list of subjects in url AND facets and remove them from the subjects in url array
                    for(var k = 0; k < subjectsInUrlAndFacets.length; k++){
                        if(subjectsInUrl.indexOf(subjectsInUrlAndFacets[k]) > -1){
                            subjectsInUrl.splice(subjectsInUrl.indexOf(subjectsInUrlAndFacets[k]), 1);
                        }
                    }

                    //now we look and see if there's anything we need to act on in the subjects in url array
                    //which has now had the ones already in facets removed
                    if(subjectsInUrl && subjectsInUrl.length > 0){
                        //we need to make a fake subject facet and inject it into the list of subject facets if so
                        angular.forEach(subjectsInUrl, function(subId){
                            TbApi.one('subjects/' + subId + ".json").get().then(function(ret){
                                var tempObject = {
                                    'name':  ret['data']['name'],//get this from the subjects list
                                    'filtered': true,
                                    'hits': 0,
                                    '_links': buildFacetLinks('subject', subId, $scope.initialParams)
                                };
                                $scope.fsubject['filters'].push(tempObject);
                            });
                        });
                    }
                }
            }
        });

        if($scope.initialParams['jurisdiction']){
          TbApi.one('search/facets/department.json').get($scope.facetsParams('department'))
          .then(function(ret){
              console.log('FACETS:  facets loaded');

              $scope.loadCounter++;
              if(ret['data'] && ret['data']['filters'].length > 0){
                  $scope.hasFacets = true;

                  var tfinal = ret['data'];

                  var tempsub = ret['data']['filters'].slice(0, 10);
                  var temprest = ret['data']['filters'].slice(11);
                  var tempext = _.filter(temprest, function(item){
                      if(item['filtered']){return item;}
                  });
                  tfinal['filters'] = tempsub.concat(tempext);
                  $scope.fdept = tfinal;
              }
          });
        }else{
            $scope.loadCounter++;
        }
    };

    //DO THE THING
    getFacets();

    $scope.filterChange = function(sub){
        //sub is the item in the response that is being picked up
        console.log("FACETS: filter changed, object being submitted:", sub);
        var vars = "";
        var obj = {};

        if(sub['filtered'] === true){
            console.log("FACETS: filtered property true, sending parallel",sub['_links']['parallel']['href']);
            if(sub['_links']['parallel']['href']){
                // if(vars = sub['_links']['parallel']['href'].split('?')[1]){
                //   vars = sub['_links']['parallel']['href'].split('?')[1].split('&');
                // }
                if(sub['_links']['parallel']['href'].indexOf('?') > -1){
                    vars = sub['_links']['parallel']['href'].substr(sub['_links']['parallel']['href'].indexOf('?') + 1).split('&');
                }
            }
        }else{
            console.log("FACETS: filtered property false, sending clear",sub['_links']['clear']['href']);
            if(sub['_links']['clear']['href']){
                // if(sub['_links']['clear']['href'].split('?')[1]){
                //   vars = sub['_links']['clear']['href'].split('?')[1].split('&');
                // }
                if(sub['_links']['clear']['href'].indexOf('?') > -1){
                    vars = sub['_links']['clear']['href'].substr(sub['_links']['clear']['href'].indexOf('?') + 1).split('&');
                }
            }
        }

        if(vars){
            for(var i = 0;i<vars.length;i++){
                var pair = vars[i].split('=');
                obj[pair[0]] = pair[1];
            }
        }

        console.log('object after processing', obj);

        if(obj['sort']){
            switch(obj['sort']){
                case 'title,jurisdiction,date':
                    obj['sort'] = "title";
                    break;
                case '-date,jurisdiction,title':
                    obj['sort'] = "date";
                    break;
                case 'jurisdiction,title,date':
                    obj['sort'] = "title";
                    break;
            }
        }

        console.log("FACETS: facets obj", obj);

        //instead of a blind url parse, let's get smart and do a sref
        //making a brand new copy of the search object
        var oldSearch = JSON.parse(JSON.stringify(tbSearchServiceAlt.searchObject));
        console.log('search object before modding',oldSearch);

        //we don't want to carry over search within in any case from facets
        if(oldSearch['searchwithin']){
            delete oldSearch['searchwithin']['id'];
        }
        if(obj['within']){
            delete obj['within'];
        }
        if(obj['page']){
            delete obj['page'];
        }
        //now go through the facets obj...
        var newSearch = tbSearchServiceAlt.parseUrlToObject(obj);
        console.log('proposed new search object',newSearch);

        if(newSearch){
            if(oldSearch.term){
                newSearch.term = oldSearch.term;
            }
            if(oldSearch.modifier){
                newSearch.modifier = oldSearch.modifier;
            }
            if(oldSearch.searchwithin){
                newSearch.searchwithin = oldSearch.searchwithin;
            }
            if(oldSearch.sort){
                newSearch.sort = oldSearch.sort;
            }
            tbSearchServiceAlt.setSearchObject(newSearch);
            console.log('pre-execution',tbSearchServiceAlt.searchObject);
            tbSearchServiceAlt.executeSearch();
        }else{
            tbSearchServiceAlt.newSearchObject();
            console.log('not new search');
            tbSearchServiceAlt.executeSearch();
        }
    };

    $scope.$on('refreshFacets', function(e, v){
        console.log('REFRESH FACETS RECEIVED', e, v);
        //e.stopPropagation();
        initFacets();
        getFacets();
    });

})

.controller( 'SearchResultsCtrl', function SearchResultsController( $scope, $state, $stateParams, $modal, $timeout, TbApi, TbNewApi, Restangular, tbUtil, tbSearchServiceAlt,tbSavedSearchService) {
    $scope.hasLoaded = false;

    $scope.tempSearchObject = tbSearchServiceAlt.searchObject;

    $scope.sparams = $stateParams;
    console.log('search controller stateparams dump', $scope.sparams);
    $scope.ssearch = {
        'term' : $scope.sparams['term']
    };

    if($scope.sparams['jurisdictions'] && $scope.sparams['jurisdictions'].length){
        $scope.ssearch['jurisdictions'] = $scope.sparams['jurisdictions'].split(',');
    }

    if($scope.sparams['doctypes'] && $scope.sparams['doctypes'].length){
        $scope.ssearch['types'] = $scope.sparams['doctypes'].split(',');
    }

    if($scope.sparams['status'] && $scope.sparams['status'].length){
        $scope.ssearch['status'] = $scope.sparams['status'].split(',');
    }

    if($scope.sparams['option'] && $scope.sparams['option'].length){
        $scope.ssearch['option'] = $scope.sparams['option'].split(',');
    }

    // var params = tbSearchServiceAlt.searchObject;
    // params['page'] = $stateParams['page'];
    // console.log('search controller init dump', params);
    // tbSearchServiceAlt.setSearchObject(params);
    var currentSearch = _.clone(tbSearchServiceAlt.searchObject);

    // console.log('search controller get object', currentSearch);

    //this saves to recent search
    tbSavedSearchService.addRecentSearch({
        date: new Date().toISOString(),
        string: $state.current.data.pageTitle,
        search: currentSearch
    });

    if($scope.sparams['sort']){
        switch($scope.sparams['sort']){
            case 'title':
                $scope.sortBySelected = "Title";
                break;
            case 'date':
                $scope.sortBySelected = "Year";
                break;
            case 'juris':
                $scope.sortBySelected= "Jurisdiction";
                break;
            case 'rel':
                $scope.sortBySelected= "Relevance";
                break;
        }
    }else{
        $scope.sortBySelected = "Title";
    }

    //PAGINATION
    if($scope.sparams['page']){
        $scope.currentPage = $scope.sparams['page'];
    }else{
        $scope.currentPage = 1;
    }
    $scope.maxSize = 5;

    $scope.selectItem = function(item){
        if(item['isChecked']){
            item['isChecked'] = false;
            var index = _.findIndex($scope.data.selected, function(arrItem){
                return arrItem['legislation-id'] == item['legislation-id'];
            });

            if(index != -1){
                $scope.data.selected.splice(index, 1);
            }
        }else{
            item['isChecked'] = true;
            $scope.data.selected.push(item);
        }
        console.log($scope.data.selected);
    };

    $scope.selectAllOnPage = function (){
        console.log('selectAllOnPage');
        for(var i = 0; i < $scope.sresults.length; i++){
            if(!$scope.sresults[i].isChecked){
                $scope.selectItem($scope.sresults[i]);
            }
        }
    };

    $scope.deselectAllOnPage = function(){
        for(var i = 0; i < $scope.sresults.length; i++){
            if($scope.sresults[i].isChecked){
                $scope.selectItem($scope.sresults[i]);
            }
        }
    };

    $scope.expandAllOnPage = function(){
        for(var i = 0; i < $scope.sresults.length; i++){
            if($scope.sresults[i]['content-id'] && !$scope.sresults[i].isCollapsed){
                $scope.getSections($scope.sresults[i]);
            }
        }
    };

    $scope.collapseAllOnPage = function(){
        for(var i = 0; i < $scope.sresults.length; i++){
            $scope.sresults[i].isCollapsed = false;
        }
    };

    $scope.initPagination = function(){
        if($scope.totalItems < 50){
            $scope.itemsPerPage = $scope.totalItems;
        }else{
            $scope.itemsPerPage = 50;
        }

        $scope.numPages = Math.ceil(($scope.totalItems / $scope.itemsPerPage));

        var xval = (($scope.currentPage - 1) * $scope.itemsPerPage) + 1;
        if(xval < $scope.totalItems){
            $scope.xval = xval;
        }

        var yval = ($scope.currentPage * $scope.itemsPerPage);
        if(yval <= $scope.totalItems){
            $scope.yval = yval;
        }

        $scope.$parent.$parent.xvalue = $scope.currentPage;
        $scope.$parent.$parent.yvalue = $scope.numPages;
    };

    $scope.markChecked = function(){
        var ids = $scope.data.selected.map(function(item){
            return item['legislation-id'];
        });
        console.log('HERP',ids);

        for(var i = 0, len = $scope.sresults.length; i < len; i++){
            //check if anything here is in the selected list
            if(ids.indexOf($scope.sresults[i]['legislation-id']) > -1){
                $scope.sresults[i]['isChecked'] = true;
            }
        }
    };

    $scope.expandPresets = function(){
        console.log('expander called', $stateParams['expand']);
        if($stateParams['expand']){
            var expandId = $stateParams['expand'];
            for(var i = 0, len = $scope.sresults.length; i < len; i++){
                //check if anything here is in the expand list
                if($scope.sresults[i]['legislation-id'] == expandId){
                    $scope.getSections($scope.sresults[i]);
                    console.log('SCROLLABLE', $('.ui-layout-center'));
                    console.log('LIST', $('#sresultmain'));
                    console.log('SELECTOR', $('#sresultmain').find('div'));
                    console.log('MANUAL', $stateParams['expand'], document.getElementById($stateParams['expand']));
                    //$('.ui-layout-center').scrollTop(targetSelector, targetSelector.offset().top);
                    break;
                }
            }
        }
    };

    var parsedParams = tbSearchServiceAlt.getSearchParams();
    console.log('EXTRACTING SEARCH OBJECT PARAMS BEFORE REQUEST', parsedParams);
    //re-establishing DEFAULT IS RELEVANCE
    if(!parsedParams['sort']){
        parsedParams['sort'] = "rel";
    }

    TbApi.all('search.json').getList(parsedParams)
    .then(function(tbRequest){
        console.log('Getting back return from search results controller!', tbRequest);
        $scope.sresults = tbRequest['data']['documents'];
        $scope.totalItems = tbRequest['data']['hits'];
        $scope.databox.numHits = tbRequest['data']['hits'];
        $scope.initPagination();
        $scope.markChecked();
        $scope.expandPresets();
        $scope.$emit('SearchResultLoaded', true);
        $scope.hasLoaded = true;
//        $scope.xval = $scope.checkXval();
//        $scope.yval = $scope.checkYval();
    });

    $scope.highlight = $stateParams['term'];
    $scope.highlightMod = $stateParams['modifier'];

    $scope.changeSortBy = function(sorter){

        var newSort = "";
        switch(sorter){
            case 'title':
                if($stateParams['sort'] && $stateParams['sort'] == 'title'){
                    newSort = "-title";
                }else{
                    newSort = "title";
                }
                break;
            case 'date':
                if($stateParams['sort'] && $stateParams['sort'] == 'date'){
                    newSort = "-date";
                }else{
                    newSort = "date";
                }
                break;
            case 'juris':
                if($stateParams && $stateParams['sort'] == 'juris'){
                    newSort = "-juris";
                }else{
                    newSort = "juris";
                }
                break;
            case 'rel':
                newSort = "rel";
                break;
        }

        var sobj = tbSearchServiceAlt.searchObject;
        if(newSort){
            sobj['sort'] = newSort;
        }else{
            sobj['sort'] = null;
        }
        sobj['page'] = 1;
        console.log('SOBJ', sobj);
        tbSearchServiceAlt.setSearchObject(sobj);
        //$state.go('search', tbSearchServiceAlt.getSearchParams());
        tbSearchServiceAlt.executeSearch();
    };

    //function for getting sections when expander button is clicked
    $scope.getSections = function(item){
        //check if sections have already been loaded
        console.log('getSections',item);
        if(!item['sections']){
            //call restangular to grab the sections, returns a promise
            if(item['_links']['section-results']['href']){
                item['loading'] = true;
                var str = item['_links']['section-results']['href'] .replace(/\/api[^/]*\/[^/]+\//gi,'');
                TbApi.one(str).get({count: 10, start: 1})
                    .then(function(section){
                        console.log('get sections response', section);
                        if(section){
                            item['sectionhits'] = section['data']['hits'];
                            item['sections'] = section['data']['sections'];
                        }
                    })
                    .then(function(){
                        $timeout(function(){
                            item['isCollapsed'] = !item['isCollapsed'];
                            item['isNoteCollapsed'] = false;
                            item['loading'] = false;
                        });
                    })
                ;
            }else{
                console.log('no results href');
                alert('The legislation item "' + item['title'] + '" currently has no content.');
            }
        }else{
            item['isCollapsed'] = !item['isCollapsed'];
            item['isNoteCollapsed'] = false;
            item['loading'] = false;
        }
    };

    $scope.getMoreSections = function(item){
        console.log('getMoreSections called');

        var str = item['_links']['section-results']['href'] .replace(/\/api[^/]*\/[^/]+\//gi,'');
        TbApi.one(str).get({
            count: 10,
            start: (item['sections'].length + 1)
        }).then(function(section){
            console.log(section);
            item['sections'] = item['sections'].concat(section['data']['sections']);
        });
    };

    $scope.getNotes = function(item){
        console.log( 'getNotes', item );
        item['totalNotesNum'] = 0;
        if(!item['noteItems']){
            TbApi.one('content/'+ item['doc-id'] + '/comments.json').get({count: 10, start: 1})
                .then(function(note){
                    console.log('get notes response', note);
                    if(note['data']['discussions']){
                        item['noteItems'] = note['data']['discussions'];
                        item['totalNotesNum'] = note['data']['discussions'].length;
                    }
            })
            .then(function(){
                $timeout(function(){
                    item['isNoteCollapsed'] = !item['isNoteCollapsed'];
                    item['isCollapsed'] = false;
                });
            });
        }else{
            item['isNoteCollapsed'] = !item['isNoteCollapsed'];
            item['isCollapsed'] = false;
        }
    };

    $scope.getMoreNotes = function(item){
        //check if sections have already been loaded
        console.log( 'getMoreNotes', item );
        TbNewApi.one('content/'+ item['doc-id'] + '/comments.json').get({
            count: 10,
            start: (item['noteItems'].length + 1)
        }).then(function(note){
            console.log('get more notes response', note);
            item['noteItems'] = item['noteItems'].concat(note['data']['discussions']);
                
        });
    };

    $scope.addInfoboxAssentData = function(item){
        console.log(item);
        item['extras'] = {};

        if(item['legislation-id']){
            TbApi.one('legislation/' + item['legislation-id'] + '/properties.json').get().then(function(ret){
                item['extras']['assentInfo'] = ret['data']['properties'];
            });
        }

        if(item['legislation-id'] && item['content-id']){
            TbApi.one('legislation/' + item['legislation-id'] + '/content/' + item['content-id'] + '.json').get().then(function(ret){
                item['extras']['leg'] = ret['data']['legislation'];
            });
        }
    };

    //pagination change listener
    $scope.$watch('currentPage', function(newPage, oldPage){
        console.log('pagination listener fired ', newPage);
        if(newPage != oldPage){
            console.log('firing search to page',newPage);
            var tempSearch = tbSearchServiceAlt.searchObject;
            tempSearch['page'] = newPage;
            tbSearchServiceAlt.setSearchObject(tempSearch);
            console.log('search object', JSON.stringify(tbSearchServiceAlt.searchObject));
            tbSearchServiceAlt.executeSearch();
            //var params = {'page' : newPage};
            //console.log('params',params);
            //tbSearchServiceAlt.searchObject.page = newPage;
            //console.log('search object', tbSearchServiceAlt.searchObject);
            //$state.go('search', params);
        }
    });

    $scope.subcheck = function(){
        if($scope.sparams['subject'] && ($scope.sparams['subject'] !== null || $scope.sparams['subject'] !== "true")){
            return true;
        }else{
            return false;
        }
    };

    $scope.sublength = function(){
        if($scope.subcheck()){
            return $scope.sparams['subject'].split(',').length;
        }
    };

    $scope.deptcheck = function(){
        if($scope.sparams['department'] && ($scope.sparams['department'] !== null || $scope.sparams['department'] !== "true")){
            return true;
        }else{
            return false;
        }
    };

    $scope.deptlength = function(){
        if($scope.deptcheck()){
            return $scope.sparams['department'].split(',').length;
        }
    };
})

.controller('ModalSearchFavouritesCtrl', function($scope, $modalInstance, selected, tbFavouritesService){
    console.log('SELECTED',selected);
    $scope.selectedItems = selected;

    $scope.ok = function () {
        $modalInstance.close(true);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})


.controller('ModalSearchProfileCtrl', function($scope, $modalInstance, selected, TbApi){
    console.log('SELECTED',selected);
    $scope.selectedItems = selected;

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    $scope.addToProfile = function(profile){
        console.log('add profile',profile);

        var existing = [];

        TbApi.one('profiles/'+profile['id']+'/legislation.json').get()
        .then(function(ret){
            console.log('load existing legs', ret);
            //make a list of existing legislation by item
            for(var i = 0, vlen = ret['data']['tracked-legislation'].length; i < vlen; ++i){
                existing.push({
                    'legislation-id': ret['data']['tracked-legislation'][i]['legislation-id'],
                    'tracked': (ret['data']['tracked-legislation'][i]['tracked'])
                });
            }

            //insert all the selected items
            for(var j = 0, elen = selected.length; j < elen; j++){
                console.log('le select',selected[j]);
                existing.push({
                    'legislation-id': selected[j]['doc-id'],
                    'tracked': true
                });
            }

            //push the list
            TbApi.one('profiles/' + profile['id'] + '/legislation/all.json').customPUT(existing).then(
                function(ret){
                    if(ret['code'] == 200){
                        profile['processed'] = true;
                    }
                }
            );
        });
    };

    if(selected && selected.length > 0){
        TbApi.all('profiles.json').getList().then(function(ret){$scope.profiles = ret['data'];});
    }
    
    ////[LOWEB-204] start: Add new profile on alert modal
    $scope.profile = {
      "name": "",
      "description": "",
      "alert-no-activity": false,
      "report-type": "Standard",
      "frequency": [],
      "alert-events": {
        "progress": true,
        "modified": true,
        "commenced": true,
        "published": true,
        "assented": true,
        "amended": true,
        "repealed": true
      }
    };

    $scope.frequencyOptions = {
        'daily': true
    };

    $scope.reportOptions = [
        {
            'name': "Standard",
            'value': "Standard"
        },
        {
            'name': "Summary Only",
            'value': "Summary"
        }
    ];

    $scope.makeFrequencyArray = function(){
        var arr = [];
        if($scope.frequencyOptions['half-daily']){ arr.push('half-daily'); }
        if($scope.frequencyOptions['daily']){ arr.push('daily'); }
        if($scope.frequencyOptions['weekly']){ arr.push('weekly'); }
        if($scope.frequencyOptions['monthly']){ arr.push('monthly'); }
        return arr;
    };
    
    $scope.saveProfile = function(){
        if(!$scope.profile.name || $scope.profile.name.length <= 0){
            $scope.showErrorMessage = true;
        }else{
            //first check if this is a new or edit profile
            var putData = {};

            $scope.profile['frequency'] = $scope.makeFrequencyArray();

            if($scope.profile['alert-events']['amended']){
                $scope.profile['alert-events']['modified'] = true;
            }

            putData = {
              "name": $scope.profile['name'],
              "description": $scope.profile['description'],
              "alert-no-activity": $scope.profile['alert-no-activity'],
              "report-type": $scope.profile['report-type'],
              "frequency": $scope.profile['frequency'],
              "alert-events": $scope.profile['alert-events']
            };

            TbApi.one('profiles.json').customPOST(putData).then(function(ret){
                $scope.addToProfile(ret['data']);
                TbApi.all('profiles.json').getList().then(function(ret){
                    var tmpArr = [];
                    angular.forEach(ret['data'], function(item){
                        if(item['name'] == putData['name']){
                            item['processed'] = true;
                        }
                        tmpArr.push(item);
                    });
                    $scope.profiles = tmpArr;
                });
            });
            $scope.showErrorMessage = false;
            $scope.isShowProfDialog();
        }
    };

    $scope.isShowProfDialog = function(){
        $scope.filterCollapse = false;
    };

    $scope.isShowAlertDialog = function(){
        $scope.filterCollapse = true;
    };
    ////[LOWEB-204] end
})


.controller('ModalSaveSearchCtrl', function($scope, $modalInstance, searchObject, tbSearchServiceAlt){
    $scope.searchObjectRaw = searchObject;
    $scope.searchObject = tbSearchServiceAlt.getStateParams();

    $scope.ok = function () {
        $modalInstance.close(true);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})

.controller('ModalSearchPrintCtrl', function($scope, $modalInstance, searchItems){
    $scope.ok = function () {
        $modalInstance.close($scope.selectedItem.res);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    $scope.searchItems = searchItems;
    $scope.selectedItem = {};

    if(searchItems.length && searchItems.length > 0){
        $scope.selectedItem.res = "selected";
    }else{
        $scope.selectedItem.res = "results";
    }
})

.controller('ModalSearchDownloadCtrl', function($scope, $modalInstance, searchItems){
    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    $scope.searchItems = searchItems;
    $scope.selectedItem = {};
    $scope.itemFormat = {};
})

.controller('ModalSearchShareCtrl', function($scope, $modalInstance, searchItems){
    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
    $scope.emailTargets = [
        {
            email: ""
        },
        {
            email: ""
        }
    ];

    $scope.addNewTarget = function(){
        $scope.emailTargets.push(
            {email: ""}
        );
    };

    $scope.searchItems = searchItems;
    $scope.selectedItem = {};
    $scope.itemFormat = {};
})

;
