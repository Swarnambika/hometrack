angular.module( 'tbLawOne.directives', [
    'ui.utils'
])

.directive('tbAutoCopy', function(){

    var selectElementText = function(target){
        var range = document.createRange();
        range.selectNodeContents(target);
        var selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);
    };

    var copySelectedText = function(){
        var csc;
        try{
            csc = document.execCommand('copy');
        }catch(e){
            csc = false;
        }

        return csc;
    };

    var linker = function(scope, element, attr){
        element.bind('mouseup', function(e){
            console.log('element text', element[0]);
            selectElementText(element[0]);
            var copy = copySelectedText();
            if(copy){console.log('copy successful');}
        });

    };

    return {
        restrict: 'A',
        link: linker
    };
})

.directive('tbCurrencyBlurb', function($compile, tbCurrencyService){

    var getTemplate = function(){
        if(window.innerWidth <= 480){
            return '<p class="lastupdate"><a title="See latest site currency information" class="visible-phone" data-auto-close="1" data-content="" data-template="home/lastupdatemobile.html" data-placement="auto" bs-popover>Site updated: {{lastUpdateDate | date: \'d MMMM yyyy\'}} <i class="fa fa-angle-double-down"></a><a title="See latest site currency information" class="hidden-phone" data-auto-close="1" data-content="" data-template="home/lastupdatehelp.html" data-placement="bottom-right" bs-popover>Site updated: {{lastUpdateDate | date: \'d MMMM yyyy\'}} <i class="fa fa-angle-double-down"></i></a></p>';
        }else{
            return '<p class="lastupdate"><a title="See latest site currency information" data-auto-close="1" data-content="" data-template="home/lastupdatehelp.html" data-placement="auto" bs-popover>Site updated: {{lastUpdateDate | date: \'d MMMM yyyy\'}} <i class="fa fa-angle-double-down"></i></a></p>';
        }
    };

    var linker = function(scope, element, attr){
        tbCurrencyService.getCurrencyAllData().then(function(ret){
            scope.currency = ret['currency'];
            scope.lastUpdateDate = ret['last-update-date'];
            console.log('get currency and last update', scope.currency, scope.lastUpdateDate);
        });
        
        /*tbCurrencyService.getCurrency().then(function(ret){
            scope.currency = ret;
            console.log('getCurrency', scope.currency);
        });

        tbCurrencyService.getLastUpdate().then(function(ret){
            scope.lastUpdateDate = ret;
            console.log('getLastUpdateDate', scope.lastUpdateDate);
        });*/

        element.html(getTemplate());
        $compile(element.contents())(scope);
    };

    return {
        restrict: 'AE',
        replace: true,
        link: linker
    };
})

.directive('datepickerPopup', function (){
    return {
        restrict: 'EAC',
        require: 'ngModel',
        link: function(scope, element, attr, controller) {
            //remove the default formatter from the input directive to prevent conflict
            controller.$formatters.shift();
        }
    };
})

.directive('tbComFlagWidget', function($modal, $compile, TbApi, $timeout, ActivityFactory){

    var getTemplate = function(item){
        //console.log('getTemplate called', item);
        //console.log('doctype', item['document-type']);
        var boxtpl = "";
        var title = "";
        var icon = "";

        if(item['document-type'] == 'Bill'){
            title = "Show bill progress";
            boxtpl = "directives/infoboxcommbill.tpl.html";
            icon = "fa-tasks";
        }else{
            title = "Show currency information";
            boxtpl = "directives/infoboxcomm.tpl.html";
            icon = "fa-flag";
        }

        return  '<a id="currency-popover-anchor" class="hidden-print" data-auto-close="1" data-template="'+boxtpl+'" data-placement="auto left" title="'+title+'" data-container="body" bs-popover><i class="fa '+icon+' fa-2x"></i></a>';
    };

    var linker = function(scope, element, attrs){
        console.log('LINKER for FLAG', scope);
        scope.activityList = {};

          scope.currentFilter = function(legislation){
              if(legislation['legislative-status'] == 'Current'){
                  return true;
              }else{
                  return false;
              }
          };
          //filter to display principal legislation only
          scope.principalFilter = function(legislation){
              if(legislation['principal'] === true){
                  return true;
              }else{
                  return false;
              }
          };
          //filter to display principal legislation only
          scope.subjectsFilter = function(subject){
              if(subject['_links'].hasOwnProperty('parent-subjects')){
                  return true;
              }else{
                  return false;
              }
          };
          scope.propertyTypeFilter = function(documentType, propertyType){
              if (documentType == "Bill") {
                  switch(propertyType){
                      case 'Amends': return 'Proposed to Amend';
                      case 'Disallowed by': return 'Proposed to be Disallowed by';
                      case 'Commences': return 'Proposed to Commences';
                      case 'Extends Operation of': return 'Proposed to Extend Operation of';
                      case 'Modifies': return 'Proposed to Modify';
                      case 'Repeals': return 'Proposed to Repeal';
                      case 'Events': return 'Progress';
                      default: return propertyType;
                  }
              }
              else {
                  switch(propertyType){
                      case 'Events': return 'Progress';
                      default: return propertyType;
                  }
              }
          };
          scope.reversePropertyTypeFilter = function(propertyType){
              switch(propertyType){
                  case 'Amends': return 'Amended By';
                  case 'Disallowed by': return 'Disallowed by';
                  case 'Commences': return 'Commenced by';
                  case 'Extends Operation of': return 'Operation extended by';
                  case 'Modifies': return 'Modified by';
                  case 'Notification': return 'Notification';
                  case 'Repeals': return 'Repealed by';
                  default: return propertyType;
              }
          };
          scope.reverseBillPropertyTypeFilter = function(propertyType){
              switch(propertyType){
                  case 'Amends': return 'Proposed Amendment By';
                  case 'Disallowed by': return 'Proposed to be Disallowed by';
                  case 'Commences': return 'Proposed Commencedment by';
                  case 'Extends Operation of': return 'Proposed Operation extended by';
                  case 'Modifies': return 'Proposed to be Modified by';
                  case 'Notification': return 'Notification';
                  case 'Repeals': return 'Proposed to be Repealed by';
                  default: return propertyType;
              }
          };

        scope.toggleActivityDetails = function(activity){
            console.log('toggleActivityDetails', activity);
            if(activity){
              //toggle the thing open
              //activity.isCollapsed = !activity.isCollapsed;

              if(!activity['legislation']['extras']){ activity['legislation']['extras'] = {};}

              activity.loadCounter = 0;
              activity.numLinks = _.size(activity['links']);

              angular.forEach(activity['links'], function(value, okey){
                  //make a call to each link
                  //
                  var key = okey.split('_')[1];
                  TbApi.one(value.href .replace(/\/api[^/]*\/[^/]+\//gi,'')).get().then(function(ret){
                      console.log('RET',ret['data']);

                      if(key !== 'properties' && ret['data'][key] && ret['data'][key][0] && ret['data'][key][0]['type']){
                          if(!activity['legislation']['extras'][key]){
                              var newItems = _.groupBy(ret['data'][key], function(item){return item['type'];});
                              console.log('NEW ITEMS', newItems);
                              activity['legislation']['extras'][key] = newItems;
                          }else{
                              //something's already there, we need to add instead of simply replace
                              var addedItems = _.groupBy(ret['data'][key], function(item){return item['type'];});
                              console.log('ADDED ITEMS', addedItems);
                              console.log('TARGET', activity['legislation']['extras'][key]);
                              activity['legislation']['extras'][key] = _.assign(activity['legislation']['extras'][key], addedItems);
                              console.log('AFTER ACTION', activity['legislation']['extras'][key]);
                              //activity['legislation']['extras'][key] = activity['legislation']['extras'][key].concat(addedItems[key]);
                          }

                      }else{
                          activity['legislation']['extras'][key] = ret['data'][key];
                      }
                      activity.loadCounter++;
                      console.log('EXTRAS',activity['legislation']['extras']);
                  });
              });
            }
        };

        scope.getEvents = function(legId, consolDate){
            console.log('getEvents called', scope.item);
            if(legId && consolDate){
                ActivityFactory.getConsolidationEvents(legId, consolDate).then(function(ret){
                    console.log('RETRETRET', ret);
                    scope.activityList = ret;

                    if(scope.activityList.activity.length && scope.activityList.activity.length > 0){
                        scope.notifyFlagController();
                        for(var i = 0; i < scope.activityList.activity.length; i++){
                            scope.toggleActivityDetails(scope.activityList.activity[i]);
                        }

                        var html = getTemplate(scope.item);
                        console.log('template dump',html);
                        element[0].innerHTML = html;
                        element.show();
                        $compile(element.contents())(scope);
                    }
                });
            }
        };

        scope.notifyFlagController = function(){
            scope.$emit('showRedFlag');
        };

        scope.$watch('item',function(){
            console.log('tbComFlag scope.item present, rendering now', scope.item);
            if(scope.item && typeof scope.item !== 'undefined'){
                //get the necessary information from services
                //and now render the icon and hook it up

                if(scope.item['legislation-id'] && scope.item['document-type'] != 'Bill'){
                    if(scope.item['consolidation-date'] && scope.item['consolidation-date'] !== null){
                        scope.getEvents(scope.item['legislation-id'], scope.item['consolidation-date']);
                    }
                }
            }
        });

        scope.$watch('props',function(){
            console.log('tbComFlag scope.legprops present',scope.props);
            if(scope.item && typeof scope.item !== 'undefined'){
                if(scope.item['legislation-id'] && scope.item['document-type'] == 'Bill'){
                    scope.notifyFlagController();
                    var html = getTemplate(scope.item);
                    element[0].innerHTML = html;
                    element.show();
                    $compile(element.contents())(scope);
                }
            }
        });
    };

    return{
        restrict: 'A',
        replace: true,
        link: linker,
        scope: {
            item: '=item',
            props: '=props'
        }
    };
})

.directive('tbInfoboxWidget', function($modal, $compile, TbApi, CaseFactory, $timeout, $filter){
    var iconString = '';
    var moreDownloads = false;

    var getTemplate = function(status, doctype){
        //console.log('tbInfoboxWidget: getTemplate called', status, doctype);
        var template = "";
        var boxtpl = "";

        switch(doctype){
            case 'Act':
            case 'Ordinance':
                boxtpl = 'directives/infoboxact.tpl.html';
                break;
            case 'Regulation':
            case 'Principles':
            case 'Consumer Protection Notice':
                if(status == 'Draft'){
                    boxtpl = 'directives/infoboxdraft.tpl.html';
                }else{
                    boxtpl = 'directives/infoboxreg.tpl.html';
                }
                break;
            case 'Bill':
                boxtpl = 'directives/infoboxbill.tpl.html';
                break;
            default:
                boxtpl = "directives/infobox.tpl.html";
                break;
        }

        template = '<span class="hidden-print" style="cursor: pointer; color: #0088cc;" data-auto-close="1" data-template="'+boxtpl+'" data-placement="left" title="Show further information" data-container="body" ng-click="getExtraProperties(item)" bs-popover>'+iconString+'</span>';
        return template;
    };

    //temporary holding object
    //this needs to vary per jurisdiction
    //work out a way to do this, maybe a switch statement

    var getMoreDownloads = function(){
        console.log('getMoreDownloads called',moreDownloads);
        return moreDownloads;
    };

    //for breaking up download resources
    var processDownloadResources = function(resources, item){
        console.log('processDownloadResources called', resources, item);
        if(resources){

            //template object
            var categories = {};
            var ijuris = $filter('trjurisrev')(item['jurisdiction']);
            switch(ijuris){
                //CTH
                case 'cth':
                    categories = {
                        "Bill": [
                            "Bill",
                            "Bill and EN",
                            "Amended Bill",
                            "Bills Digest",
                            "Bill As Passed"
                        ],
                        "Explanatory Memorandum": [
                            "Explanatory Memorandum",
                        ],
                        "Explanatory Statement": [
                            "Explanatory Statement",
                        ],
                        "Draft": [
                            "Draft"
                        ],
                        "Second Reading Speech" : [
                            "2R Speech",
                            "2R Speech Upper House",
                            "2R Speech Lower House",
                            "2nd Reading Speech (Budget Speech)",
                            "Explanatory Speech"
                        ]
                    };
                    break;
                //ACT
                case 'act':
                    categories = {
                        "Bill": [
                            "Bill",
                            "Bill and EN",
                            "Amended Bill",
                            "Bills Digest",
                            "Bill As Passed"
                        ],
                        "Explanatory Statement": [
                            "Explanatory Statement"
                        ],
                        "Draft": [
                            "Draft"
                        ],
                        "Second Reading Speech" : [
                            "2R Speech",
                            "2R Speech Upper House",
                            "2R Speech Lower House",
                            "2nd Reading Speech (Budget Speech)",
                            "Explanatory Speech"
                        ]
                    };
                    break;
                //QUEENSLAND SPECIAL SNOWFLAKES
                //WATCH THEM SPARKLE BRILLIANTLY
                case 'qld':
                    categories = {
                        "Bill": [
                            "Bill",
                            "Bill and EN",
                            "Amended Bill",
                            "Bills Digest",
                            "Bill As Passed"
                        ],
                        "Explanatory Notes": [
                            "Explanatory Notes",
                        ],
                        "Draft": [
                            "Draft"
                        ],
                        "Explanatory Speech" : [
                            "2R Speech",
                            "2R Speech Upper House",
                            "2R Speech Lower House",
                            "2nd Reading Speech (Budget Speech)",
                            "Explanatory Speech"
                        ]
                    };
                    break;
                //this handles every normal case
                default:
                    categories = {
                        "Bill": [
                            "Bill",
                            "Bill and EN",
                            "Amended Bill",
                            "Bills Digest",
                            "Bill As Passed"
                        ],
                        "Explanatory Materials": [
                            "Explanatory Memorandum",
                            "Explanatory Notes",
                            "Explanatory Statement"
                        ],
                        "Draft": [
                            "Draft"
                        ],
                        "Second Reading Speech" : [
                            "2R Speech",
                            "2R Speech Upper House",
                            "2R Speech Lower House",
                            "2nd Reading Speech (Budget Speech)",
                            "Explanatory Speech"
                        ]
                    };
                    break;
            }

            //function to get resource dates
            var getResourceDate = function(resource){
                var dateRe = /\d{4}-\d{2}-\d{2}/g;
                for (var assetKey in resource['assets']) {
                     if (! resource['assets'].hasOwnProperty(assetKey)) {
                        continue;
                    }
                    var asset = resource['assets'][assetKey];
                    for (var fileKey in asset['files']) {
                         if (! asset['files'].hasOwnProperty(fileKey)) {
                           continue;
                        }
                        var file = asset['files'][fileKey];
                        var dateArray = dateRe.exec(file['filename']);
                        if (dateArray !== null && dateArray.length>0) {
                            return dateArray[0];
                        }
                    }
                }
            };

            var latestConsolDate = "0000-00-00";
            for (var resourceKey in resources) {
                if (! resources.hasOwnProperty(resourceKey)) {
                    continue;
                }
                //set an empty consolidation date if the resource is not a consolidation resource
                if (resources[resourceKey]['type'] !== "Consolidation") {
                    resources[resourceKey]['consolidation-date'] = "";
                    continue;
                }
                var consoleDate = getResourceDate(resources[resourceKey]);
                if (consoleDate) {
                    resources[resourceKey]['consolidation-date'] = consoleDate;
                    if (consoleDate > latestConsolDate) {
                        latestConsolDate = consoleDate;
                    }

                }
            }

            //crazy bullshit to remove zip files from the return
            //"DO NOT RETURN ZIP FILES" should be a service option
            //but we'll do it this way since it is not
            //specifically self-contained code block so this can be easily excised
            var zipfilter = function(item){
                console.log('zipfilter called', item);
                if(item['extension'] !== 'zip'){
                    return true;
                }else{
                    return false;
                }
            };

            for (var rk in resources) {
                console.log('reskey', resources[rk]);
                resources[rk]['dast'] = false;
                resources[rk]['dcas'] = false;

                var wrk = resources[rk]['assets'];
                for(var i=0, il=wrk.length;i<il;i++){
                    console.log('w-file',wrk[i]['files']);
                    if(wrk[i]['files'] && wrk[i]['files'].length > 0){
                        wrk[i]['files'] = wrk[i]['files'].filter(zipfilter);
                    }
                    if(wrk[i]['files'] && wrk[i]['files'].length > 0){
                        resources[rk]['dast'] = true;
                    }
                }

                var crk = resources[rk]['compilation-asset'];
                for(var j=0, jl=crk.length;j<jl;j++){
                    console.log('c-file',crk[j]['files']);
                    if(crk[j]['files'] && crk[j]['files'].length > 0){
                        crk[j]['files'] = crk[j]['files'].filter(zipfilter);
                    }
                    if(crk[j]['files'] && crk[j]['files'].length > 0){
                        resources[rk]['dcas'] = true;
                    }
                }
            }//end crazy bullshit

            //holding arrays
            var asMadeConsolidation = [];
            var latestConsolidations = [];
            var historicalReprints = [];
            var basicResources = [];
            var suppResources = [];

            //big box of stuff to return
            //is returned at the end of this function
            var dcats = [];

            //iterate on, sort all resources into five baskets
            for (resourceKey in resources) {
                if (! resources.hasOwnProperty(resourceKey)) {
                    continue;
                }
                switch(resources[resourceKey]['type']){
                    case 'Consolidation':
                        if(resources[resourceKey]['consolidation-date'] === "0001-01-01"){
                            console.log('AS MADE FOUND');
                            asMadeConsolidation.push(resources[resourceKey]);
                        } else if (resources[resourceKey]['consolidation-date'] === latestConsolDate) {
                            latestConsolidations.push(resources[resourceKey]);
                        } else {
                            historicalReprints.push(resources[resourceKey]);
                        }
                        break;
                    case 'Basic':
                        basicResources.push(resources[resourceKey]);
                        break;
                    case 'Supplementary':
                        suppResources.push(resources[resourceKey]);
                        break;
                    default:
                        break;
                }
            }

            //we have an As Made
            if(asMadeConsolidation.length > 0){
                var amc = _.groupBy(asMadeConsolidation , function(item){return item['title'];});
                dcats.push({'As Made':amc});
            }

            //we have Latest
            if(latestConsolidations.length > 0){
                var lc = _.groupBy(latestConsolidations , function(item){return item['title'];});
                dcats.push({'Latest Consolidation': lc});
            }

            //we have Historical
            if(historicalReprints.length > 0){
                var hr = _.groupBy(historicalReprints , function(item){return item['title'];});
                dcats.push({'Historical Consolidations': hr});
            }

            var findExistingCat = function(string){
                for(var i = 0; i < dcats.length; i++){
                    if(dcats[i][string]){
                        return true;
                    }
                }
                return false;
            };

            var appendToCat = function(cat, object){
                console.log('APPEND CATEGORY NAME', cat);
                console.log('OBJECT TO BE APPENDED', object);
                for(var i = 0; i < dcats.length; i++){
                    if(dcats[i][cat]){
                        console.log('FOUND APPEND TARGET',dcats[i][cat]);
                        console.log('ATTACHMENT KEY', Object.keys(object));
                        dcats[i][cat][Object.keys(object)[0]] = object[Object.keys(object)[0]];
                    }
                }
            };

            //function to further process BASIC and SUPPLEMENTAL resources
            //iterate through each group in input array and compare it to the holding object's
            //predefined strings in order to build the internal categories
            //key is the groupby group title, value is the set of items in the group
            var splitGrouped = function(array){
                console.log('splitGrouped called', array);
                angular.forEach(array, function(value, key){
                    console.log('foreach outer loop', value, key);
                    var outerCheck = false;
                    angular.forEach(categories, function(category, title){
                        for(var i = 0, len = category.length;i<len;i++){
                            console.log('foreach inner loop',category[i]);
                            //check if group title matches
                            if(key == category[i]){
                                //make object to be pushed to match template structure for easy reuse
                                var inner = {};
                                inner[key] = value;

                                var existing = findExistingCat(title);
                                if(existing){
                                    appendToCat(title, inner);
                                }else{
                                    var outer = {};
                                    outer[title] = inner;
                                    console.log('object to be pushed',outer);
                                    //push in as full resource category
                                    console.log('existing dcats array',dcats);
                                    dcats.push(outer);
                                }
                                var outerCheck = true;
                            }
                        }
                    });

                    //handle MORE link
                    if(!outerCheck){
                        moreDownloads = true;
                    }
                });
                console.log('moreDownloads', moreDownloads);
            };

            if(basicResources.length > 0){
                var br = _.groupBy(basicResources , function(item){return item['title'];});
                splitGrouped(br);
            }
            if(suppResources.length > 0){
                var sr = _.groupBy(suppResources , function(item){return item['title'];});
                splitGrouped(sr);
            }

            console.log('DCAT',dcats);

            var mcats = dcats.filter(function(cat){
                var ret = false;

                for(var cr1 in cat){
                    for (var cr2 in cat[cr1]){
                        var cr_arr = cat[cr1][cr2];
                        for(var i=0, il=cr_arr.length;i<il;i++){
                            if(cr_arr[i]['dast'] || cr_arr[i]['dcas']){
                                ret = true;
                                break;
                            }
                        }
                    }
                }

                return ret;
            });
            return mcats;
            //return dcats;
        }else{
            return null;
        }
    };

    var sortProperties = function(val){
        return new Date(val);
    };

    var linker = function(scope, element, attrs){
        scope.govUrl = "https://www.legislation.gov.au/Current/";

        //console.log('tbInfoboxWidget linker function',scope,element,attrs);
        //get extra properties if needed
        scope.getExtraProperties = function(item){
            if(!item['extras']){
                item['extras'] = {};

                if(item['legislation-id']){
                    var casesparams = {};

                    CaseFactory.hasCases(item['legislation-id']).then(function(ret){
                        if(ret){
                            item['extras']['cases'] = true;
                        }
                    });

                    TbApi.one('legislation/' + item['legislation-id'] + '/properties.json').get().then(function(ret){
                        //var props = _.sortBy(ret['data']['properties'], 'property-effective-date');
                        item['extras']['assentInfo'] = ret['data']['properties'];
                    });

                    TbApi.one('legislation/'+item['legislation-id']+'/tables.json').get().then(function(ret){
                        item['extras']['tables'] = ret['data']['tables'];
                    });

                    // TbApi.one('legislation/'+item['legislation-id']+'/subjects.json').get().then(function(ret){
                    //     item['extras']['subjects'] = ret['data']['subjects'];
                    // });

                    TbApi.one('legislation/'+item['legislation-id']+'/subjects.json').get()
                    .then(function(ret){
                        var subjects = [];
                        var keyedSubject = [];
                        var i, subject, subjectKey;

                        //add all the subjects to the keyedSubject object
                        for(i = 0, len = ret['data']['subjects'].length; i < len; i++){
                            subject = ret['data']['subjects'][i];
                            //create a subject key based on the self link
                            subjectKey = subject['_links']['self']['href'];
                            //add the the subjects the the keyedSubject object
                            keyedSubject[subjectKey] = subject;
                        }

                        //add the parent subject to the sub-subjects
                        for(i = 0, len = ret['data']['subjects'].length; i < len; i++){
                            subject = ret['data']['subjects'][i];
                            //create a subject key based on the self link
                            subjectKey = subject['_links']['self']['href'];
                            //porcess any subjects that have parent subjects
                            if(subject['_links'].hasOwnProperty('parent-subjects')){
                                for(var psi = 0, pslen = subject['_links']['parent-subjects'].length; psi < pslen; psi++){
                                    var parentSubjectKey = subject['_links']['parent-subjects'][psi]['href'];
                                    // console.log("Found parent subjects:", parentSubjectKey);
                                    if (keyedSubject.hasOwnProperty(parentSubjectKey)) {
                                        parentSubject = keyedSubject[parentSubjectKey];
                                        //only handle one aprent subject ATM
                                        subject['parent-subject'] = parentSubject;
                                        subject['parent-subject-id'] = parentSubject['id'];
                                        continue;
                                    }
                                }
                                subjects.push(subject);
                            }
                        }
                        item['extras']['subjects'] = _.groupBy(subjects, function(item){return item['parent-subject-id'];});
                        console.log('SUBJECT PROC DUMP', item['extras']['subjects']);
                    });

                    if(item['legislation-id'] && item['content-id']){
                        TbApi.one('legislation/' + item['legislation-id'] + '/content/' + item['content-id'] + '.json').get().then(function(ret){
                            item['extras']['leg'] = ret['data']['legislation'];
                        });
                    }

                    TbApi.one('legislation/'+item['legislation-id']+'/resources.json').get().then(function(ret){
                        if(ret['data']['resources'] && ret['data']['resources'].length > 0){
                            var resources = processDownloadResources(ret['data']['resources'], item);
                            item['extras']['resources'] = resources;
                            var moredownloads = getMoreDownloads();
                            item['extras']['moredownloads'] = moredownloads;
                        }//end if
                    });

                    if(item['document-type'] == 'Act'){
                        TbApi.one('legislation/'+item['legislation-id']+'/bill.json').get().then(function(ret){
                            console.log('BILL', ret['data']);
                            if(ret['data']['bills'] && ret['data']['bills'].length > 0){
                                var bills = ret['data']['bills'];
                                item['extras']['bills'] = bills;

                                TbApi.one('legislation/'+bills[0]['legislation-id']+'/resources.json').get().then(function(ret){
                                    console.log('BILL RESOURCES', ret);
                                    if(ret['data']['resources'] && ret['data']['resources'].length > 0){
                                        var resources = processDownloadResources(ret['data']['resources'], item);
                                        item['extras']['billresources'] = resources;
                                        var moredownloads = getMoreDownloads();
                                        item['extras']['moredownloads'] = moredownloads;
                                    }
                                });
                                if(bills[1]){
                                    TbApi.one('legislation/'+bills[1]['legislation-id']+'/resources.json').get().then(function(ret){
                                        if(ret['data']['resources'] && ret['data']['resources'].length > 0){
                                            var resources = processDownloadResources(ret['data']['resources'], item);
                                            item['extras']['billresources2'] = resources;
                                            var moredownloads = getMoreDownloads();
                                            item['extras']['moredownloads'] = moredownloads;
                                        }
                                    });
                                }
                            }
                        });
                    }else if(item['document-type'] == 'Bill'){
                        TbApi.one('legislation/'+item['legislation-id']+'/enacted-as.json').get().then(function(ret){
                            console.log('ACT', ret['data']);
                            if(ret['data']['enacted-as'] && ret['data']['enacted-as'].length > 0){
                                var act = ret['data']['enacted-as'];
                                item['extras']['act'] = act;

                                TbApi.one('legislation/'+act[0]['legislation-id']+'/resources.json').get().then(function(ret){
                                    console.log('ACT RESOURCES', ret);
                                    if(ret['data']['resources'] && ret['data']['resources'].length > 0){
                                        var resources = processDownloadResources(ret['data']['resources'], item);
                                        item['extras']['actresources'] = resources;
                                        var moredownloads = getMoreDownloads();
                                        item['extras']['moredownloads'] = moredownloads;
                                    }
                                });
                            }
                        });
                    }
                }
            }
        };

        //modal TOA/TOL content-parsing display
        scope.tableInfoOpen = function(item, target){
            //console.log('tableinfoopen',item,target);

            var modalInstance = $modal.open({
                templateUrl: 'legislation/modals/toa.tpl.html',
                controller: 'ModalInfoboxTableCtrl',
                windowClass: "modal-large",
                resolve: {
                    tbLeg: function(TbApi){
                        return item['extras']['tables'];
                    },
                    tbTableType: function(){
                        return target;
                    },
                    tbLegParent: function(){
                        return item;
                    }
                }
            });
        };

        //modal simple display functions
        scope.modalCasesOpen = function(item){
            console.log('modalCasesOpen', item);
            var modalInstance = $modal.open({
                templateUrl: 'legislation/modals/cases.tpl.html',
                controller: 'ModalInfoboxCasesCtrl',
                windowClass: "modal-large",
                resolve: {
                    tbLeg: function(){
                        return item;
                    }
                }
            });
        };

        scope.modalInfoOpen = function(item, target){
            console.log('modalInfoOpen',item,target);

            var subtarget = '';
            switch(target){
                case 'commencements':
                    subtarget = 'commencements';
                    break;
                case 'subordinate':
                    subtarget = 'subordinate';
                    break;
                case 'enabling':
                    subtarget = 'enabling';
                    break;
                case 'departments':
                    subtarget = 'departments';
                    break;
            }
            //console.log(item, target);

            var modalInstance = $modal.open({
                templateUrl: 'legislation/modals/'+subtarget+'.tpl.html',
                controller: 'ModalInfoboxExtraCtrl',
                windowClass: "modal-large",
                resolve: {
                    tbCom: function(TbApi, $stateParams){
                      return TbApi.one('legislation/' + item['legislation-id'] + '/'+subtarget+'.json').get();
                    //     .get().then(function(oRet){
                    //     if( !oRet || !oRet['data'] || !oRet['data']['departments'] || oRet['data']['departments'].length<=0 ){
                    //       var tmpJsonFileID = item['doc-id'];
                    //       if(!tmpJsonFileID && item['content-doc-id']){
                    //         tmpJsonFileID = item['content-doc-id'].substr(0, item['content-doc-id'].indexOf('_'));
                    //       }  
                    //       if( subtarget==='departments' && item && tmpJsonFileID ){
                    //         return TbApi.one('legislation/' + tmpJsonFileID + '/enabling.json').get()
                    //         .then(function(iRet){
                    //           if( iRet && iRet['data'] && iRet['data']['enabling-legislation'] && iRet['data']['enabling-legislation'][0]){
                    //             return TbApi.one('legislation/'+iRet['data']['enabling-legislation'][0]['doc-id']+'/' + subtarget + '.json').get();
                    //           }else{
                    //             return oRet;
                    //           }
                    //         });
                    //       }
                    //     }
                    //     return oRet;
                    //   });
                    },
                    tbLegParent: function(){
                      return item;
                    }
                }
            });

            modalInstance.result.then(function(){
                //$log.info('Share modal dismissed!');
            });
        };

        scope.downloadInfoOpen = function(item, key, value){
            console.log('item', item);
            console.log('resource key', key);
            console.log('resource value', value);

            var modalInstance = $modal.open({
                templateUrl: 'legislation/modals/downloads.tpl.html',
                controller: 'ModalInfoboxDownloadCtrl',
                windowClass: "modal-large",
                resolve: {
                    tbTitle: function(){ return key; },
                    tbItem: function(){ return value; },
                    tbLegParent: function(){ return item; }
                }
            });

            modalInstance.result.then(function(){
                //$log.info('Share modal dismissed!');
            });
        };

        //THIS IS HERESY
        //COMPLETE HERESY
        //DO NOT LET IT LIVE
        scope.currencyPopoverHack = function(){
            var popHack = angular.element('#currency-popover-anchor');
            $timeout(function(){
                if(popHack){
                    popHack.trigger('click');
                    element.find('#popclose').trigger('click');
                }
            },0);
        };

        scope.redirectGovlinker = function(item){
            console.log('redirect govlinker', item);

            //ARGS is a concatenation of the following:
            //jurisdiction=JUR (eg. South%20Australia)
            //legislative-status=STA (eg. Current, Repealed etc)
            //document-type=TYP (Act, Regulation, Bill etc)
            //year=YYYY (eg. 2015)
            //number=NNN (eg. 27)
            //principal=T/F (false if amending legn, true otherwise)
            //title=TTL (eg. Electoral%20Act%201992)

            var uri = "https://www.lawone.com.au/govlinker/find";
            var args = [];

            if(item['jurisdiction']){ args.push("jurisdiction=" + item['jurisdiction']); }
            if(item['legislative-status']){ args.push("legislative-status=" + item['legislative-status']); }
            if(item['document-type']){ args.push("document-type=" + item['document-type']); }
            if(item['year']){ args.push("year=" + item['year']); }
            if(item['number']){ args.push("number=" + item['number']); }
            if(item['principal'] !== null){ args.push("principal=" + item['principal']); }
            if(item['title']){ args.push("title=" + item['title']); }

            uri += "?" + args[0];
            for(var i = 1; i < args.length; i++){
                uri += "&" + args[i];
            }

            console.log(encodeURI(uri));
            window.open(encodeURI(uri), '_blank');
        };

        scope.$watch('item',function(){
            //console.log('tbInfoboxWidget scope.item present, rendering now', scope);
            if(scope.item){
                if(attrs['large'] == 'true'){
                    iconString = '<span class="btn btn-info" title="Show further information"><i class="fa fa-info"></i><span class="visible-desktop" style="margin-left: 5px;">Key Info</span></span>';
                }else{
                    iconString = ' <div class="infopop"><i class="fa fa-info-circle"></i></div> ';
                }
                //element.html(getTemplate(scope.item['legislative-status'], scope.item['document-type'])).show();

                //if(scope.nodisplay){ scope.item.showRedFlag = false; }

                var html = getTemplate(scope.item['legislative-status'], scope.item['document-type']);
                element[0].innerHTML = html;
                element.show();
                $compile(element.contents())(scope);
            }
        });
    };

    return{
        restrict: 'A',
        replace: true,
        link: linker,
        scope: {
            item: '=item',
            nodisplay: '=nodisplay'
        }
    };
})
    //for directive tbInfoboxWidget
    .controller('ModalInfoboxCasesCtrl', function($scope, $state, $timeout, $modalInstance, CaseFactory, tbLeg){

        $scope.leg = tbLeg;

        CaseFactory.getCases(tbLeg['legislation-id']).then(function(ret){
            $scope.cases = ret;
            $timeout(function(){
                $scope.setGroup();
            },150);
        });

        $scope.printCases = function(){
            var casesArray = [];
            var caseCounter = 0;
            for(var i = 0, len = $scope.cases.length; i < len; i++){
                if($scope.cases[i]['isChecked']){
                    casesArray.push($scope.cases[i]['id']);
                    caseCounter++;

                    if(caseCounter >= 200){
                        break;
                    }
                }
            }
            $state.go('caseprint', {'caseIds':casesArray.join(',')});
        };

        $scope.renderCases = function(key){
            $scope.gcases[key]['renderon'] = !$scope.gcases[key]['renderon'];
        };

        $scope.setGroup = function(input){
            $scope.gcases = {};
            $scope.gkeys = [];

            console.log('setGroup called', input);
            console.log('dumping cases', $scope.cases.length);

            if(!input){
                input = 'year';
            }

            $scope.gcases = _.groupBy($scope.cases , function(item){return item[input];});
            $scope.gkeys = _.keys($scope.gcases).sort();

            if(input == 'year'){
                $scope.gkeys = _.keys($scope.gcases).sort().reverse();
            }else{
                $scope.gkeys = _.keys($scope.gcases).sort();
            }

            if($scope.cases.length > 99){
                $scope.gcases[$scope.gkeys[0]]['renderon'] = true;
            }else{
                for(var i=0; i<$scope.gkeys.length; i++){
                    $scope.gcases[$scope.gkeys[i]]['renderon'] = true;
                }
            }

            console.log('grouping completed', $scope.gkeys);
        };

        $scope.cancel = function (event) {
            console.log(event);
            event.stopPropagation();
            $modalInstance.dismiss('cancel');
        };
    })

    //for directive tbInfoboxWidget
    .controller('ModalInfoboxDownloadCtrl', function($scope, $modalInstance, tbTitle, tbItem, tbLegParent){
        $scope.leg = tbLegParent;
        $scope.title = tbTitle;
        $scope.item = tbItem;

        $scope.cancel = function (event) {
            console.log(event);
            event.stopPropagation();
            $modalInstance.dismiss('cancel');
        };
    })

    //for directive tbInfoboxWidget
    .controller('ModalInfoboxTableCtrl', function($scope, $modalInstance, $sce, TbApi, tbLeg, tbLegParent, tbTableType){
        $scope.leg = tbLegParent;
        $scope.tabletype = tbTableType;

        switch(tbTableType){
            case 'toa':
                $scope.tablename = "Table of Amendments";
                break;
            case 'tol':
                $scope.tablename = "Table of Legislation";
                break;
        }

        //filter to display principal legislation only
        $scope.principalFilter = function(legislation){
            if(legislation['principal'] === true){
                return true;
            }else{
                return false;
            }
        };

        $scope.tables = tbLeg;

        $scope.legtable = $scope.tables[tbTableType];

        TbApi.one($scope.legtable['_links']['html']['href'] .replace(/\/api[^/]*\/[^/]+\//gi,'')).get()
        .then(function(ret){
            $scope.rendertable = $sce.trustAsHtml(ret);
        });

        $scope.cancel = function (event) {
            console.log(event);
            event.stopPropagation();
            $modalInstance.dismiss('cancel');
        };
    })

    //for directive tbInfoboxWidget
    .controller('ModalInfoboxExtraCtrl', function($scope, $modalInstance, tbCom, tbLegParent, TbApi, trjurisrevFilter){
        console.log('modalInfoboxExtraCtrl opened!', tbCom, tbLegParent);

        $scope.comms = tbCom;
        $scope.leg = tbLegParent;

        //process shit for subordinate
        if(tbCom['data']['subordinate-legislation']){
            var pf = tbCom['data']['subordinate-legislation'].filter(function(legislation){
                if(legislation['principal'] === true){
                    return true;
                }else{
                    return false;
                }
            });

            $scope.subordinate = _.groupBy(
                pf,
                function(item){
                    return item['legislative-status'];
                }
            );

            $scope.subordinatekeys = Object.keys($scope.subordinate).sort();
        }

        TbApi.one('legislation/' + $scope.leg['legislation-id'] + '/properties.json').get().then(function(ret){
            $scope.assentInfo = ret['data']['properties'];
            console.log($scope.assentInfo);
        });

        $scope.jurisShorten = function(input){
            console.log('juris shortener', input);
            return trjurisrevFilter(input);
        };

        //filter to display principal legislation only
        $scope.principalFilter = function(legislation){
            if(legislation['principal'] === true){
                return true;
            }else{
                return false;
            }
        };

        $scope.cancel = function (event) {
            console.log(event);
            event.stopPropagation();
            $modalInstance.dismiss('cancel');
        };
    })

.directive('tbSubjectWidget',function(TbApi, tbUserService, tbSubjectService){
    return{
        restrict: 'A',
        replace: true,
        templateUrl: 'directives/subjectselector.tpl.html',
        scope: {
            subjectstr: '=tbSubjectWidget',
            subjectCounter: '=tbSubjectCounter',
            subjectChecked: '=tbSubjectChecked'
        },
        link: function(scope, ele, attrs){
            console.log('tbSubjectWidget called!',scope,ele,attrs);
            scope.columns = [];
            scope.columnCount = 3;

            function calcColumns(arr, count) {
                //console.log(arr, count);
                var itemsPerColumn = Math.ceil(arr.length / count);
                for(var i = 0; i<arr.length; i+= itemsPerColumn){
                    var col = {start:i, end:Math.min(i + itemsPerColumn, arr.length)};
                    scope.columns.push(col);
                }
                //console.log(scope.columns);
            }

            //scope.subjectslist = TbApi.all('subjects.json').getList().$object;
            scope.subjectslist = {};
            scope.subjectsloaded = false;

            function getSubjects(){
                scope.subjectsloaded = true;
                console.log('getSubjects function called', scope.subjectslist);
                //TbApi.all('subjects.json').getList().then(function(ret){
                tbSubjectService.get().then(function(ret){
                    //console.log('returning ret');
                    scope.subjectsloaded = true;
                    if(ret && ret['data']['subjects']){
                        scope.subjectslist = ret;
                        console.log('Subjectslist', scope.subjectslist);
                        calcColumns(scope.subjectslist['data']['subjects'], scope.columnCount);
                        console.log('Checking prepop list',scope.subjectChecked);
                        if(scope.subjectChecked){
                            console.log('Subjects present in URL, populating directive!',scope.subjectslist);
                            scope.populateAllSubjects(scope.subjectChecked);
                        }
                    }
                });
            }

            scope.$watch(
                function(){
                    return tbUserService.getUserObject();
                },
                function (user){
                    console.log('navigation watcher for users SUBJECT DIRECTIVE', user);
                    if(user && user['user'] && !scope.subjectsloaded){
                        console.log("calling getSubjects");
                        getSubjects();
                    }
                },
                true
            );

            scope.$watch('subjectChecked', function(newValue, oldValue){
                if(newValue != oldValue){
                    scope.wipeSubjects();
                    scope.populateAllSubjects(newValue);
                }
            });

            function isSubjectPresent(id, subjects){
                for(var i=0;i<subjects.length;i++){
                    if(subjects[i] == id){
                        subjects.splice(i, 1);
                        return true;
                    }else{
                        return false;
                    }
                }
            }

            scope.populateAllSubjects = function(input){
                //assume "subjects" variable input is a comma delimited string
                //split it up into an array, we shall iterate over this to hit each one
                var subjects = input.split(",");
                var list = scope.subjectslist['data']['subjects'];

                //iterating over each subject in the array
                for(var i=0;i<list.length;i++){
                    if(subjects.length > 0){
                        var subs = list[i]['_embedded']['sub-subjects'];
                        var counter = 0;

                        if(isSubjectPresent(list[i]['id'], subjects)){
                            list[i]['ischecked'] = true;
                            for(var k=0;k<subs.length;k++){
                                counter++;
                                subs[k]['ischecked'] = true;
                            }
                        }else{
                            for(var j=0;j<subs.length;j++){
                                if(isSubjectPresent(subs[j]['id'], subjects)){
                                    counter++;
                                    list[i]['collapse'] = true;
                                    subs[j]['ischecked'] = true;
                                }
                            }
                        }
                        list[i]['childCheckedCount'] = counter;
                        scope.subjectCounter += counter;
                    }else{
                        break;
                    }
                }
            };

            //trawls through subjectlist to submit all selected subjects
            scope.trawl = function(){
                var list = scope.subjectslist['data']['subjects'];
                var output = [];
                for(var i=0;i<list.length;i++){
                    if(list[i]['ischecked']){
                        output.push(list[i]['id']);
                    }else{
                        var sub = list[i]['_embedded']['sub-subjects'];
                        for(var j=0;j<sub.length;j++){
                            if(sub[j]['ischecked']){
                                output.push(sub[j]['id']);
                            }
                        }
                    }
                }
                console.log(output);
                scope.subjectstr = output.toString();
                return output.toString();
            };

            scope.$on('tbSubjectWidgetWipe',function(event, args){
                scope.wipeSubjects();
            });

            scope.$on('tbSubjectWidgetPopulate', function(event, string){
                scope.populateAllSubjects(string);
            });

            scope.wipeSubjects = function(){
                console.log('Wipe Subjects debug', scope.subjectslist);
                var list = scope.subjectslist['data']['subjects'];
                for(var i=0;i<list.length;i++){
                    list[i]['ischecked'] = false;
                    list[i]['collapse'] = false;
                    list[i]['childCheckedCount'] = 0;
                    var sub = list[i]['_embedded']['sub-subjects'];
                    for(var j=0;j<sub.length;j++){
                        sub[j]['ischecked'] = false;
                        sub[j]['collapse'] = false;
                    }
                }
                scope.subjectCounter = 0;
            };

            scope.selectMainSubject = function(id){
                console.log('selectMainSubject called', id);
                var subject = _.select(scope.subjectslist['data']['subjects'],{'id': id})[0];
                var counter = 0;
                if(subject['ischecked'] === true){
                    for(var k=0;k<subject['_embedded']['sub-subjects'].length;k++){
                        if(!subject['_embedded']['sub-subjects'][k]['ischecked']){
                            subject['_embedded']['sub-subjects'][k]['ischecked'] = true;
                            scope.subjectCounter++;
                        }
                        counter++;
                    }
                }else{
                    for(var l=0;l<subject['_embedded']['sub-subjects'].length;l++){
                        if(subject['_embedded']['sub-subjects'][l]['ischecked']){
                            subject['_embedded']['sub-subjects'][l]['ischecked'] = false;
                            scope.subjectCounter--;
                        }
                    }
                    counter = 0;
                }
                subject['childCheckedCount'] = counter;
                scope.trawl();
            };

            scope.selectSubSubject = function(pid, id){
                var subject = _.select(scope.subjectslist['data']['subjects'],{'id': pid})[0];
                var counter = 0;
                for(var m=0;m<subject['_embedded']['sub-subjects'].length;m++){
                    if(subject['_embedded']['sub-subjects'][m].ischecked){
                        counter++;
                    }
                }
                if(counter >= subject['_embedded']['sub-subjects'].length){
                    subject['ischecked'] = true;
                }else{
                    subject['ischecked'] = false;
                }
                subject['childCheckedCount'] = counter;
                scope.trawl();
            };

            scope.toggleSubSubject = function(sub){
                sub['ischecked'] = !sub['ischecked'];
                if(sub['ischecked']){
                    scope.subjectCounter += 1;
                }else{
                    scope.subjectCounter -= 1;
                }
            };
        }
    };
})

.directive('legTitleRender', function($compile, trjurisrevFilter, $state, $location){
    var statcheck = function(str){
        switch(str){
            case 'Repealed legislation' : return "*** REPEALED"; //error
            case 'Repealed' : return "*** REPEALED";
            case 'Inoperative legislation': return "*** INOPERATIVE"; //error
            case 'Inoperative': return "*** INOPERATIVE";
            case 'Failed bill': return "*** FAILED"; //error
            case 'Failed': return "*** FAILED";
            case 'Assented bill': return "*** ASSENTED"; //error
            case 'Assented': return "*** ASSENTED";
            case 'Awaiting Assent': return "*** AWAITING ASSENT";
            case 'Spent legislation': return "*** SPENT"; //error
            case 'Spent': return "*** SPENT";
            case 'Draft': return '*** DRAFT';
            case 'Not in current session': return "*** NICS";
            default: return "";
        }
    };

    var homecheck = function(str){
        switch(str){
            case 'Inoperative legislation': return "*** INOPERATIVE"; //error
            case 'Inoperative': return "*** INOPERATIVE";
            case 'Failed bill': return "*** FAILED"; //error
            case 'Failed': return "*** FAILED";
            case 'Assented bill': return "*** ASSENTED"; //error
            case 'Assented': return "*** ASSENTED";
            case 'Awaiting Assent': return "*** AWAITING ASSENT";
            case 'Spent legislation': return "*** SPENT"; //error
            case 'Spent': return "*** SPENT";
            case 'Draft': return '*** DRAFT';
            case 'Not in current session': return "*** NICS";
            default: return "";
        }
    };

    var linker = function(scope, ele, attrs){
        var item = scope.legTitleRender;
        var options = scope.$eval(attrs.legTitleRenderOpts) || false;
        //var params = scope.$eval(attrs.legTitleRenderParams) || false;
        var template = "";

        //console.log('legtitlerender', item, options);
        if((item && item['_links'])){
            if(options['hardlink']){
                if(!item['_links']['content']['href'] || options['displayonly']){
                    if(item['_links']['self']){
                        href = item['_links']['self']['href'];
                    }else{
                        href = item['_links']['legislation']['href'];
                    }
                }else{
                    href = item['_links']['content']['href'];
                }
                href = href.slice().replace(/\/api[^/]*\/[^/]+/,'').replace('.json','');
                template = "<a title=\"" + href + "\" href=\"" + href + "\">" + item['title'] + "</a>";
            }else{
                if((options['link'] || options['statenolink'] || !options)){

                    if(options['statenolink'] && $state.includes('legislation')){
                        console.log('STATENOLINK');
                        template = item['title'];
                    }else{
                        //does any content actually exist?
                        //nope
                        if((item['_links'] && item['_links']['content'] && !item['_links']['content']['href']) || options['displayonly'] === true){ //no, or we're opting to ignore
                            //console.log('TITLE ITEM LINK RENDER',item);
                            //template = '<a title="Legislation details" ui-sref="legdisplay({id:' + item['legislation-id'] + '})"' + 'ui-sref-opts="{inherit: false, reload: true}">' + item['title'] + '</a>';
                            template = '<a title="Legislation details" ui-sref="legdisplay({id:\'' + item['doc-id'] + '\'})"' + 'ui-sref-opts="{inherit: false, reload: true}">' + item['title'] + '</a>';
                        }else{ //yes, content exists
                            var sparams = {};
                            var sparamstring = "";
                            if(!$state.includes('browse')){
                                sparams = $location.search();
                            }

                            sparams['legId'] = item['legislation-id'];
                            sparams['contId'] = item['content-id'];
                            // sparamstring = JSON.stringify(sparams);
                            // sparamstring = "("+sparamstring.replace(/"/g, "'")+")";
                            var thref = $state.href('legislation',sparams,{inherit: false, reload: true});

                            template = '<a title="Legislation content" href="'+thref+'">' + item['title'] + '</a>';
                            sparams = {};
                        }
                    }
                }else{
                    template = item['title'];
                }
            }

            if(options['verbose'] === true || !options){
                template += "<span ng-show=\"" + item['number'] + "> 0\"> (" + item['number'] + " of " + item['year'] + ")</span>";

                template += " [" + trjurisrevFilter(item['jurisdiction']).toUpperCase() + "]";

                template += "<span ng-show=\"" + item['principal'] + "\"> [Principal " + item['document-type'] + "]</span>";

                if(options['norep']){
                    template += "<span style=\"color: red;\"> " + homecheck(item['legislative-status']) + "</span>";
                }else if(!options['nostatus'] && !options['norep']){
                    template += "<span style=\"color: red;\"> " + statcheck(item['legislative-status']) + "</span>";
                }
            }

            //template = "[" + item['doc-id'] + "] " + template;
        }else{
            template = "<div>Error. No item to render.</div>";
        }

        ele.html(template);
        $compile(ele.contents())(scope);
    };


    return{
        restrict: 'A',
        replace: false,
        scope: {
            legTitleRender: '='
        },
        link: linker
    };
})

.directive('printDiv', function(){
    return{
        restrict: 'A',
        link: function(scope, element, attrs) {

            var iframe;
            var elementToPrint = document.querySelector(attrs.printDiv);
            console.log('PRINTDIV DUMP',elementToPrint);
            var title = attrs.printTitle;

            if (!window.frames["print-frame"]) {
                var elm = document.createElement('iframe');
                elm.setAttribute('id', 'print-frame');
                elm.setAttribute('name', 'print-frame');
                elm.setAttribute('style', 'display: none;');
                document.body.appendChild(elm);
            }

            function write(value) {
                var doc;
                if (iframe.contentDocument) { // DOM
                    doc = iframe.contentDocument;
                } else if (iframe.contentWindow) { // IE win
                    doc = iframe.contentWindow.document;
                } else {
                    alert('Wonder what browser this is... ' + navigator.userAgent);
                }
                doc.write(value);
                doc.close();
            }

            var today = new Date();

            element.bind('click', function(event) {

                var printFuncString = "window.print()";

                //SNIFF IE
                var isIE11 = !!navigator.userAgent.match(/Trident\/7\./);
                if(isIE11){
                    printFuncString = "window.document.execCommand(\'print\', false, null)";
                }

                iframe = document.getElementById('print-frame');
                console.log('GETELEMENTBYID',iframe);
                write('<!DOCTYPE html><html moznomarginboxes><head><link rel=\"stylesheet\" type=\"text/css\" href=\"/assets/tbLawOne-0.0.2.css\" media=\"print\"></head><body onload=\"' + printFuncString + '\">' + '<div style=\"font-size: 8px; text-align: center;\">'+ '&copy; TimeBase ' + today.getFullYear().toString() + ' - Printed ' + today.toString() + '</div>' + '<h3>' + title + '</h3>' + elementToPrint.innerHTML + '</body></html>');

//                if (window.navigator.userAgent.indexOf ("MSIE") > 0) {
//                    iframe.contentWindow.document.execCommand('print', false, null);
//                } else {
//                    iframe.contentWindow.focus();
//                    iframe.contentWindow.print();
//                }
            });
        }
    };
})

.directive('scrollToTop', function(){
    var linker = function(scope, ele, attrs){
        ele.bind('click', function(){
            var target = $("#"+scope.scrollToTop)[0];
            $(target).scrollTop(0);
        });
    };

    return {
        restrict: 'A',
        scope: {
            scrollToTop: '@'
        },
        link: linker,
        template: '<a>Return to Top</a>'
    };
})


.directive('bindOnce', function() {
    return {
        scope: true,
        replace: true,
        link: function( $scope, $element ) {
            setTimeout(function() {
                $scope.$destroy();
                $element.removeClass('ng-binding ng-scope');
            }, 0);
        }
    };
})

.directive('linkCompileRender', function($compile){
    return{
        restrict: 'A',
        replace: true,
        link: function(scope, ele, attrs){
            scope.$watch(attrs.linkCompileRender, function(html){
                if(html){
                    //console.log('linkCompileRender', html);
                    var txt = html.toString();
                    ele.html(txt);
                    //compile it so angular knows it's there
                    $compile(ele.contents())(scope);
                }
            });
        }
    };
})

.directive('legPdfRender', function($compile){
    return{
        restrict: 'A',
        replace: true,
        link: function(scope, ele, attrs){
            scope.$watch(attrs.legPdfRender, function(item){
                if(attrs.legPdfRender){
                    console.log('legPdfRender src', item['href'], attrs);
                    var template = '<embed style="z-index: 1000;" id="tbPdfInstance" wmode="transparent" width="100%" height="100%" src="' + item['href'] + '#page=' + attrs.legPdfPage + '&view=FitH"/>';
                    ele.html(template);
                    $compile(ele.contents())(scope);
                }
            });
        }
    };
})

.directive('resultSectionRender', function($compile, tbStringUtils){
    return{
        restrict: 'A',
        replace: true,
        link: function(scope, ele, attrs){
            console.log('resultSectionRender called');

            ele.html(attrs['resultSectionRender'].replace(/(\s|\n)+/g, " "));
            $compile(ele.contents())(scope);

            console.log('resultSectionRender attrs', attrs);

            var filterText = attrs['highlightText'];
            var highlightMod = attrs['highlightMod'];

            //highlight stuff here
            //check for the existence of a highlight term
            if(filterText && filterText !== ""){
                if(highlightMod && highlightMod == "exact"){
                    console.log('EXACT', filterText);
                    ele.highlight(filterText, { wordsOnly: true });
                }else{
                    var termsArr = tbStringUtils.parseSearchTerms(filterText);
                    console.log('not EXACT, array of terms',termsArr);
                    ele.highlight(termsArr, { wordsOnly: true });
                }
            }
        }
    };
})

.directive('genHighlight', function($compile, tbStringUtils){
    return{
        restrict: 'A',
        replace: true,
        link: function(scope, ele, attrs){
            console.log('genHighlight called', ele, attrs);

            var filterText = attrs.genHighlight;
            var highlightMod = attrs.genHighlightModifier;

            //highlight stuff here
            //check for the existence of a highlight term
            if(filterText && filterText !== ""){

                if(highlightMod && highlightMod == "exact"){
                    ele.highlight(filterText, {wordsOnly: true});
                }else{
                    var termsArr = tbStringUtils.parseSearchTerms(filterText);
                    ele.highlight(termsArr, { wordsOnly: true });
                }
            }
        }
    };
})

.directive('legContentAnnotate', function($parse) {
    return function(scope, element, attrs) {
        var fn = $parse(attrs.legContentAnnotate);

        element.bind('contextmenu', function(event) {
            console.log('TBANNOTATE CALLED', event);
            scope.$apply(function() {
                event.preventDefault();
                fn(scope, {$event:event});
            });
        });
    };
})

.directive('legContentRender', function($compile, highlightFilter, tbStringUtils){
    return{
        restrict: 'A',
        replace: true,
        link: function(scope, ele, attrs){
            var filterText = attrs.legHighlightText;
            var highlightScope = attrs.legHighlightScope;
            var highlightMod = attrs.legHighlightModifier;
            var titleAppend = attrs.legTitleAppend;
            var titleStatus = attrs.legTitleStatus;

            scope.goContents = function(){
               var target = document.getElementsByClassName('toc-heading')[0];
               target.scrollIntoView();
            };

            scope.$watch(attrs.legContentRender, function(html){
                if(html){
                    var txt = html.toString();
                    //replace every occurence of 'href' with a prefix of leg-content-link so it gets processed
                    //txt = txt.replace(new RegExp('href=','g'), 'leg-content-link href=');
                    ele.html(txt);

                    var toch = ele.find('.toc-heading');
                    if(toch.length > 0){
                        ele.find('#content-title').after('<div style="margin-bottom: 10px; font-size: 14px;"><a title="Scroll to Contents" ng-click="goContents()">Table of provisions</a></div>');
                    }

                    //compile it so angular knows it's there
                    $compile(ele.contents())(scope);

                    //title append here
                    if(titleAppend && titleAppend !== ""){
                        ele.find('#content-title').find('p').append('<span> '+titleAppend+'</span>');
                    }

                    if(titleStatus && titleStatus !== ""){
                        ele.find('#content-title').find('p').append('<span style="color: red;"> '+titleStatus+'</span>');
                    }

                    //WW start: Only for highlight construction document on 31/05/2017
                    ele.find('.label-plaintext').find('b').highlight("NOTE: Still under construction!.", {wordsOnly: true});
                    //WW end

                    //highlight stuff here
                    //check for the existence of a highlight term
                    if(filterText && filterText !== ""){
                        if(highlightMod && highlightMod == "exact"){
                            ele.highlight(filterText, {wordsOnly: true});
                        }else{

                            var termsArr = tbStringUtils.parseSearchTerms(filterText);

                            console.log('legContentRender highlight terms', termsArr);
                            if(highlightScope && highlightScope !== ""){
                                console.log('highlight scope present', highlightScope);
                                switch(highlightScope){
                                    case 'title':
                                        ele.find('#content-title').highlight(termsArr, { wordsOnly: true });
                                        break;
                                    case 'headings':
                                    case 'section-headings':
                                        ele.find('[id$="title"]').highlight(termsArr, { wordsOnly: true });
                                        break;
                                    default:
                                        ele.highlight(termsArr, { wordsOnly: true });
                                }
                            }else{
                                ele.highlight(termsArr, { wordsOnly: true });
                            }
                        }
                    }
                }
            });
        }
    };
})

.directive('legContentLink', function($state){
    return function(scope, element, attrs) {
        $(element).click(function(event) {
            console.log("legContentLink blocker called");
            event.preventDefault();

            console.log('legContentLink event', event);
            console.log('legContentLink attrs', attrs);
            console.log('legContentLink scope', scope);

            $state.go('legislation',{
                'legId' : attrs['legislationId'],
                'contId' : attrs['contentId']
            },{
                inherit: false
            });
        });
    };
})

//select all checkbox
.directive('selectAllCheckbox', function () {
    return {
        replace: true,
        restrict: 'E',
        scope: {
            checkboxes: '=',
            allselected: '=allSelected',
            allclear: '=allClear'
        },
        template: '<input type="checkbox" ng-model="master" ng-change="masterChange()">',
        controller: function ($scope, $element) {

            $scope.masterChange = function () {
                if ($scope.master) {
                    angular.forEach($scope.checkboxes, function (cb, index) {
                        cb.isSelected = true;
                    });
                } else {
                    angular.forEach($scope.checkboxes, function (cb, index) {
                        cb.isSelected = false;
                    });
                }
            };

            $scope.$watch('checkboxes', function () {
                var allSet = true,
                    allClear = true;
                angular.forEach($scope.checkboxes, function (cb, index) {
                    if (cb.isSelected) {
                        allClear = false;
                    } else {
                        allSet = false;
                    }
                });

                if ($scope.allselected !== undefined) {
                    $scope.allselected = allSet;
                }
                if ($scope.allclear !== undefined) {
                    $scope.allclear = allClear;
                }

                $element.prop('indeterminate', false);
                if (allSet) {
                    $scope.master = true;
                } else if (allClear) {
                    $scope.master = false;
                } else {
                    $scope.master = false;
                    $element.prop('indeterminate', true);
                }

            }, true);
        }
    };
})

//directive for rendering trees with lazy loading
.directive('uiTree', function() {
  return {
    template: '<ul class="uiTree"><li ui-tree-node ng-repeat="node in tree"></li></ul>',
    replace: true,
    transclude: true,
    restrict: 'AE',
    scope: {
      tree: '=ngModel',
      attrNodeId: "@",
      loadFn: '=', //this is assigned in the template
      expandTo: '=',
      selectedId: '=',
      checked: '=' //this looks for checked status
    },
    controller: function($scope, $element, $attrs) {
        console.log("uiTree controller init");

        //if parent's checked, children are all checked
        if($scope.checked){
            for(var i = 0; i < $scope.tree.length; i++){
                $scope.tree[i]['checked'] = true;
            }
        }

        //this tells us if all the child nodes of this tree are checked
        $scope.allChecked = function(){

            var checkedCount = 0;
            for(i=0;i<$scope.tree.length;i++){
                if($scope.tree[i]['checked']){
                    checkedCount++;
                }
            }

            console.log('allChecked running', $scope.tree, checkedCount);

            return (checkedCount === $scope.tree.length) ? true : false;
        };

        $scope.loadFnName = $attrs.loadFn;
        // this seems like an egregious hack, but it is necessary for recursively-generated
        // trees to have access to the loader function
        if($scope.$parent.loadFn){
            $scope.loadFn = $scope.$parent.loadFn;
        }
      // TODO expandTo shouldn't be two-way, currently we're copying it
      if($scope.expandTo && $scope.expandTo.length) {
        $scope.expansionNodes = angular.copy($scope.expandTo);
        var arrExpandTo = $scope.expansionNodes.split(",");
        $scope.nextExpandTo = arrExpandTo.shift();
        $scope.expansionNodes = arrExpandTo.join(",");
      }
    }
  };
})

//directive for rendering individual nodes
.directive('uiTreeNode', ['$compile', '$timeout', '$state', function($compile, $timeout, $state, TbApi) {
  return {
    restrict: 'AE',
    replace: true,
    template: '<li>' +
      '<div class="node ellipsis" id="{{nodeId()}}" data-node-id="{{ nodeId() }}" ng-class="">' +
        '<a class="icon" ng-show="node[\'has-children\']" title="Show / hide children" ng-click="toggleNode(nodeId())"></a>' +
        '<a class="tick" ng-class="{\'offset\': !node[\'has-children\']}" ng-click="setChecked(node)"><i ng-class="checkIcon()"></i></a> ' +
        '<a ng-class="css()" title="{{node.title | trentity}}" ng-click="(legLink(node._links.content.href))"><span style="color: red;" ng-show="node.hits > 0"><span bind-once>{{hitDisplay(node)}}</span></span> <span bind-once>{{ node.title | trentity }}</span></a>' +
      '</div>' +
    '</li>',
    link: function(scope, elm, attrs) {

      scope.spawning = false;

      scope.nodeId = function(node) {
        var localNode = node || scope.node;
        return localNode[scope.attrNodeId];
      };

      //scope extending link functions begin here
      //toggle node children visibility
      //fired via ng-click on the icon part of the template
      scope.toggleNode = function(nodeId) {
            var isVisible = elm.children(".uiTree:visible").length > 0;
            var childrenTree = elm.children(".uiTree");
            if(isVisible) {
              scope.$emit('nodeCollapsed', nodeId);
            } else if(nodeId) {
              scope.$emit('nodeExpanded', nodeId);
            }
            if(!isVisible && scope.loadFn && childrenTree.length === 0) {
                if(!scope.spawning){
                  scope.spawning = true;
                  // load the children asynchronously
                  var callback = function(arrChildren) {
                    scope.node.children = arrChildren;
                    scope.appendChildren();
                    //elm.find("a.icon i").show();
                    //elm.find("a.icon img").remove();

                    elm.find("a.icon i.tog").show();
                    elm.find("a.icon i.loader").remove();

                    scope.toggleNode(); // show it
                  };
                  var promiseOrNodes = scope.loadFn(nodeId, callback);
                  if(promiseOrNodes && promiseOrNodes.then) {
                    promiseOrNodes.then(callback).then();
                  } else {
                      $timeout(function() {
                          callback(promiseOrNodes);
                      }, 0);
                  }

                  //elm.find("a.icon i").hide();
                  //var imgUrl = "/assets/img/ajax-loader.gif";
                  //elm.find("a.icon").append('<img src="' + imgUrl + '" width="18" height="18">');
                  elm.find("a.icon i.tog").hide();
                  elm.find("a.icon").append('<i class="loader fa fa-spinner fa fa-spin"></i>');
                }
            } else {
                childrenTree.toggle(!isVisible);
                elm.find("a.icon i.tog").toggleClass("fa fa-plus");
                elm.find("a.icon i.tog").toggleClass("fa fa-minus");
            }
      };

        //attach children
      scope.appendChildren = function() {
        // Add children by $compiling and doing a new ui-tree directive
        // We need the load-fn attribute in there if it has been provided
        var childrenHtml = '<div ui-tree ng-model="node.children.data.children" attr-node-id="' +
            scope.attrNodeId + '"';
        if(scope.loadFn) {
          childrenHtml += ' load-fn="' + scope.loadFnName + '"';
        }
        // pass along all the variables
        if(scope.expansionNodes) {
          childrenHtml += ' expand-to="expansionNodes"';
        }
        if(scope.selectedId) {
          childrenHtml += ' selected-id="selectedId"';
        }
        if(scope.node['checked']){
          childrenHtml += ' checked="true"';
        }

        childrenHtml += ' style="display: none"></div>';
        return elm.append($compile(childrenHtml)(scope));
      };//end

        //this is setting the CSS styles in the template
        //look at the selected ID, is it singular?
      scope.css = function() {
        return {
          //nodeLabel: true,
          selected: scope.selectedId && scope.nodeId() == scope.selectedId,
          checked: this.node.checked
        };
      };//end

      scope.hitDisplay = function(node){
        if (node['has-children'] === false && node.hits == 1) {
            return "(+)";
        }else{
            return "(" + node.hits + ")";
        }
      };

      scope.setChecked = function(node){
            if(node['checked']){
                scope.$broadcast("nodeUnChecked", node);
                scope.$emit("nodeChildUnChecked", node);
            }else{
                scope.$broadcast("nodeChecked", node);
            }
      };

      //hierarchy listener, pick up when up in parent controller, we detect content change
      scope.$on('hierarchyChanged', function(event, hierarchy){
        var hArr = hierarchy.split(',');
        var isVisible = elm.children(".uiTree:visible").length > 0;
        for(var i = 0; i<hArr.length; i++){
            if(scope.nodeId() === parseInt(hArr[i],10)){
                console.log('this node is in the hierarchy', i, scope.nodeId());
                if(!isVisible){
                    console.log('this node has no visible children');

                    var hstr = "";
                    for(var j = i+1; j<hArr.length;j++){
                        hstr = hstr + hArr[j] + ",";
                    }
                    hstr = hstr.slice(0,-1);
                    console.log('passing on cascade opener',hstr);
                    scope.expansionNodes = hstr;
                    scope.toggleNode(scope.nodeId());
                }
            }
        }
      });

      //listens for if self or parent is checked
        scope.$on("nodeChecked", function(event, node){
            if(!scope.node['checked']){
                scope.node['checked'] = true;
            }
            if(scope.$parent.allChecked()){
                scope.$emit("nodeChildChecked");
            }
        });

        //listens for if self or parent is un checked
        scope.$on("nodeUnChecked", function(event, node){
            if(scope.node['checked']){
                scope.node['checked'] = false;
            }
        });

        scope.$on("nodeChildUnChecked", function(event, node){
            if(scope.node['checked']){
                scope.node['checked'] = false;
            }
        });

        //CHECK FOR ALL CHILDREN FIRST
        scope.$on("nodeChildChecked", function(event, node){
            if(!scope.node['checked']){
                //scope.node['checked'] = true;
                if(scope.node.children && scope.node.children.data.children){
                    var kids = scope.node.children.data.children;
                    var allchecked = kids.every(function(element){
                        return element['checked'];
                    });
                    if(allchecked){
                        scope.node['checked'] = true;
                    }
                }else{
                    scope.node['checked'] = true;
                }
            }
        });

      //dumps class for is-checked or is-not-checked
      scope.checkIcon = function(){
        if(scope.node['checked']){
            return 'fa fa-fw fa-check';
        }else{
            return 'fa fa-fw';
        }
      };

      //parses a legislation link and calls state transition
        scope.legLink = function(href){
            console.log("leg link called");
            console.log(href);

            var params = {};
            var arr = href.split('/');
            var fil = _.filter(arr, function(item){ return item !== ""; });
            params['legId'] = fil[3];
            params['contId'] = fil[5].replace('.json','');
            console.log("directive leg link called", params);

            $state.go('legislation', params, {inherit: false, notify: true});
        };

      //this stuff runs automatically on initialization
      if(scope.node['checked']){
        elm.find("a.tick i").addClass('fa fa-check');
      }

      //checks for has-children
      if(scope.node['has-children'] === true) {
        //elm.find("a.icon").append('<i class="fa fa-fw fa-plus"></i>');
        elm.find("a.icon").append('<i class="tog fa fa-fw fa-plus"></i>');
      }

      if(scope.nextExpandTo && scope.nodeId() == parseInt(scope.nextExpandTo, 10)) {
        scope.toggleNode(scope.nodeId());
      }
    }
  };
}])

//directive for rendering trees with lazy loading
.directive('uiTreeAll', function() {
  return {
    template: '<ul class="uiTree"><div ng-if="legId" class="row-fluid"><p>' + 
        '<span class="collapser" style="margin-left:0px; margin-right: 3px" title="Expand/Collapse All" ng-click="expandAllContents()">' + 
        '<i ng-class="{\'fa fa-expand\': !allChapsCollapse, \'fa fa-compress\': allChapsCollapse}"></i></span><b>Expand/Collapse</b></p></div>' + 
        '<li ui-tree-node-all ng-repeat="node in fullTree"></li></ul>',
    replace: true,
    transclude: true,
    restrict: 'AE',
    scope: {
      fullTree: '=ngModel',
      attrNodeId: "@",
      expandTo: '=?',
      selectedId: '=?',
      checked: '=?', //this looks for checked status
      legId: '=?',
      contentDocId: '=?',
      allChapsCollapse: '=?'
    },
    controller: function($scope, $element, $attrs, TbApi) {
      console.log("ui-tree-all controller init", $scope.allChapsCollapse);

      //if parent's checked, children are all checked
      if($scope.checked){
          for(var i = 0; i < $scope.fullTree.length; i++){
              $scope.fullTree[i]['checked'] = true;
          }
      }

      //this tells us if all the child nodes of this tree are checked
      $scope.allChecked = function(){

          var checkedCount = 0;
          for(i=0;i<$scope.fullTree.length;i++){
              if($scope.fullTree[i]['checked']){
                  checkedCount++;
              }
          }

          console.log('allChecked running', $scope.fullTree, checkedCount);

          return (checkedCount === $scope.fullTree.length) ? true : false;
      };

      // TODO expandTo shouldn't be two-way, currently we're copying it
      if($scope.expandTo && $scope.expandTo.length) {
        $scope.expansionNodes = angular.copy($scope.expandTo);
        var arrExpandTo = $scope.expansionNodes.split(",");
        $scope.nextExpandTo = arrExpandTo.shift();
        $scope.expansionNodes = arrExpandTo.join(",");
      }

      $scope.expandAllContents = function(){
        $scope.allChapsCollapse = !$scope.allChapsCollapse;
        $scope.$broadcast("allNodesExpand", $scope.allChapsCollapse);
      };

      if($scope.$parent.isSubVisible){
        $scope.allChapsCollapse = false;
      }
    }
  };
})

//directive for rendering individual nodes
.directive('uiTreeNodeAll', ['$compile', '$timeout', '$state', function($compile, $timeout, $state, TbApi) {
  return {
    restrict: 'AE',
    replace: true,
    template: '<li>' +
      '<div class="node ellipsis" id="{{nodeId()}}" data-node-id="{{ nodeId() }}" ng-class="">' +
        '<a class="icon" ng-show="node[\'has-children\']" title="Show / hide children" ng-click="allToggleNode()"><i ng-class="{\'fa fa-plus\': !allChapsCollapse, \'fa fa-minus\': allChapsCollapse}"></i></a>' +
        '<a class="tick" ng-class="{\'offset\': !node[\'has-children\']}" ng-click="setChecked(node)"><i ng-class="checkIcon()"></i></a> ' +
        '<a ng-class="css()" title="{{node.title | trentity}}" ng-click="(allLegLink(node._links.content.href))"><span style="color: red;" ng-show="node.hits > 0"><span bind-once>{{hitDisplay(node)}}</span></span> <span bind-once>{{ node.title | trentity }}</span></a>' +
        '<div ng-if="node[\'has-children\'] && allChapsCollapse" all-chaps-collapse="allChapsCollapse" ui-tree-all ng-model="node.children" selected-id="selectedId" expand-to="expansionNodes" checked="node[\'checked\']" attr-node-id="attrNodeId"></div>' +
      '</div>' +
    '</li>',
    link: function(scope, elm, attrs) {
      scope.nodeId = function(node) {
        var localNode = node || scope.node;
        return localNode[scope.attrNodeId];
      };

      //scope extending link functions begin here
      //toggle all children node visibility
      scope.allToggleNode = function() {
        scope.allChapsCollapse = !scope.allChapsCollapse;
        scope.isSubVisible = true;
      };

      //this is setting the CSS styles in the template
      //look at the selected ID, is it singular?
      scope.css = function() {
        return {
          //nodeLabel: true,
          selected: scope.selectedId && scope.node['id'] == scope.selectedId,
          checked: this.node.checked
        };
      };//end

      scope.hitDisplay = function(node){
        if (node['has-children'] === false && node.hits == 1) {
            return "(+)";
        }else{
            return "(" + node.hits + ")";
        }
      };

      scope.setChecked = function(node){
            if(node['checked']){
                scope.$broadcast("nodeUnChecked", node);
                scope.$emit("nodeChildUnChecked", node);
            }else{
                scope.$broadcast("nodeChecked", node);
            }
      };

      //hierarchy listener, pick up when up in parent controller, we detect content change
      scope.$on('hierarchyChanged', function(event, hierarchy){
        var hArr = hierarchy.split(',');
        var isVisible = elm.children(".uiTree:visible").length > 0;
        for(var i = 0; i<hArr.length; i++){
            if(scope.nodeId() === parseInt(hArr[i],10)){
                console.log('All: this node is in the hierarchy', i, scope.nodeId());
                if(!isVisible){
                    console.log('All: this node has no visible children');

                    var hstr = "";
                    for(var j = i+1; j<hArr.length;j++){
                        hstr = hstr + hArr[j] + ",";
                    }
                    hstr = hstr.slice(0,-1);
                    console.log('All: passing on cascade opener',hstr);
                    scope.expansionNodes = hstr;
                }
            }
        }
      });

      //listens for if self or parent is checked
      scope.$on("nodeChecked", function(event, node){
          if(!scope.node['checked']){
              scope.node['checked'] = true;
          }
          if(scope.$parent.allChecked()){
              scope.$emit("nodeChildChecked");
          }
      });

      //listens for if self or parent is un checked
      scope.$on("nodeUnChecked", function(event, node){
          if(scope.node['checked']){
              scope.node['checked'] = false;
          }
      });

      scope.$on("nodeChildUnChecked", function(event, node){
          if(scope.node['checked']){
              scope.node['checked'] = false;
          }
      });

      //CHECK FOR ALL CHILDREN FIRST
      scope.$on("nodeChildChecked", function(event, node){
          if(!scope.node['checked']){
              //scope.node['checked'] = true;
              if(scope.node.children && scope.node.children.length > 0){
                  var kids = scope.node.children;
                  var allchecked = kids.every(function(element){
                      return element['checked'];
                  });
                  if(allchecked){
                      scope.node['checked'] = true;
                  }
              }else{
                  scope.node['checked'] = true;
              }
          }
      });

      //dumps class for is-checked or is-not-checked
      scope.checkIcon = function(){
        if(scope.node['checked']){
            return 'fa fa-fw fa-check';
        }else{
            return 'fa fa-fw';
        }
      };

      //parses a legislation link and calls state transition
      scope.allLegLink = function(href){
          console.log("Expand leg link called", href);

          var params = {};
          var arr = href.split('/');
          var fil = _.filter(arr, function(item){ return item !== ""; });
          params['legId'] = fil[3];
          params['contId'] = fil[5].replace('.json','');
          console.log("Expand directive leg link called", params);

          $state.go('legislation', params, {inherit: false, notify: true});
      };

      //this stuff runs automatically on initialization
      if(scope.node && scope.node['checked']){
        elm.find("a.tick i").addClass('fa fa-check');
      }

      //checks for has-children
      if(scope.node && scope.node['has-children'] === true) {
        elm.find("a.icon").append('<i class="tog fa fa-fw fa-plus"></i>');
      }

      scope.$on("allNodesExpand", function(e, isChapsCollapase){
        if( scope.node['has-children'] ){
          scope.allChapsCollapse = isChapsCollapase;
        }
        scope.isSubVisible = false;
      });
    }
  };
}])

//directive for doing split panel magic for individual legislation view
.directive('uiLayout', function($timeout, $localStorage, $state) {
    return {
        link: function(scope, elm, attrs) {
            var watchLField = attrs.watchLField;
            var watchRField = attrs.watchRField;
            var init = attrs.initClosed;

            console.log('UILAYOUT INIT', init);

            scope.storage = $localStorage;
            console.log('SCOPE STORAGE UILAYOUT',scope.storage);
            console.log('SCOPE STORAGE STATE DATA',scope.storage.layout);

            var modSize = 0.25;
            if(scope.storage && scope.storage.layout){
                modSize = scope.storage.layout[$state['current']['name']];
            }

            console.log('SETTING MODSIZE', modSize);

            var options = {
                defaults: {
                    applyDefaultStyles: false,
                    initClosed: false,
                },
                west: {
                    size: modSize,
                    fxName: "none",
                    togglerLength_open: 28,
                    togglerLength_closed: 28,
                    togglerContent_open: '<i class="fa fa-chevron-circle-left"></i>',
                    togglerContent_closed: '<i class="fa fa-chevron-circle-right"></i>',
                    onresize_end: function(pname, pelm, pstate, poptions){
                        if(window.innerWidth > 768){
                            //save into local storage the state and the size
                            if(!scope.storage.layout){
                                scope.storage.layout = {};
                            }

                            scope.storage.layout[$state['current']['name']] = ""+pstate['size'];
                            console.log('LOCALSTORAGE', scope.storage.layout);
                        }
                    }
                },
                east: {
                    size: modSize,
                    fxName: "none",
                    togglerLength_open: 28,
                    togglerLength_closed: 28,
                    togglerContent_open: '<i class="fa fa-chevron-circle-right"></i>',
                    togglerContent_closed: '<i class="fa fa-chevron-circle-left"></i>',
                    onresize_end: function(pname, pelm, pstate, poptions){
                        if(window.innerWidth > 768){
                            //save into local storage the state and the size
                            if(!scope.storage.layout){
                                scope.storage.layout = {};
                            }

                            scope.storage.layout[$state['current']['name']] = ""+pstate['size'];
                            console.log('LOCALSTORAGE', scope.storage.layout);
                        }
                    }
                }
            };

            //detected mobile window size
            if(window.innerWidth <= 768){
                options.defaults.initClosed = true;
                options.west.resizable = false;
                options.west.size = '100%';
                options.east.resizable = false;
                options.east.size = '100%';
            }

            //load from local storage the state and the size
            //check if the state

            if(init){
                 options.defaults.initClosed = true;
            }

            $timeout(function(){
                return (layout = elm.layout(options));
            }).then(function(l){
                if(watchLField && window.innerWidth > 768){
                    scope.$watch(attrs.watchLField, function(v){
                        if(v === true){
                            l.open('west');
                        }else{
                            l.close('west');
                        }
                    });
                }
                if(watchRField && window.innerWidth > 768){
                    scope.$watch(attrs.watchRField, function(v){
                        if(v === true){
                            l.open('east');
                        }else{
                            l.close('east');
                        }
                    });
                }
            });
        }
    };
})

;//end module
