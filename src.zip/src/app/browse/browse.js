angular.module( 'tbLawOne.browse', [
  'ui.router',
  'ui.bootstrap',
  'restangular',
  'ngSanitize',
  'tbLawOne.directives',
  'tbLawOne.services'
])

.config(function config( $stateProvider ) {
    $stateProvider
        //browse master state, contains sub-views for sidebar frame and main frame
        .state( 'browse', {
            //url: '/browse',
            abstract: true,
            views: {
                "main": {
                    controller: 'BrowseMainCtrl',
                    templateUrl: 'browse/browse.tpl.html'
                },
                "col1@browse" : {
                    controller: 'BrowseSideCtrl',
                    templateUrl: 'browse/browseside.tpl.html'
                },
                "col2@browse" : {
                    controller: 'BrowsePanelCtrl',
                    templateUrl: 'browse/browseresult.tpl.html'
                }
            },
            data:{ pageTitle: 'Browse' }
        })
        //browse child state for refreshing view, placed within main frame template
        .state('browse.form', {
            //url: '/browse?juris?currency?doctype?subjects?starts-with?year?sort-by?page',
            url: '/browse?juris?doc-type?status?subject?year?start?sort?page?principal?open',
            parent: 'browse',
            views: {
                "result" : {
                    controller: 'BrowseResultCtrl',
                    templateUrl: 'browse/browsesub.tpl.html'
                },
                "textbar" : {
                    controller: 'BrowseTextbarCtrl',
                    templateUrl: 'browse/browsetextbar.tpl.html'
                }
            },
            onEnter: function($stateParams, trdoctypeFilter, trstatusFilter, uppercaseFilter){
                //console.log('ONENTER BROWSE EVENT FIRED', $stateParams);
                var title = "Browse";
                if($stateParams['scope'] && $stateParams['scope'] !== ""){
                    title += (" | options: " + uppercaseFilter($stateParams['scope']));
                }

                var temp = "";
                var i = 0;
                var arr = [];

                if($stateParams['juris'] && $stateParams['juris'] !== ""){
                    if($stateParams['juris'] == 'all' || $stateParams['juris'] == 'All'){
                        title += (" | All");
                    }else{
                        arr = $stateParams['juris'].split(',');
                        for(i = 0;i<arr.length;i++){
                            temp = temp += arr[i] + ", ";
                        }
                        temp = temp.slice(0,-2);
                        title += (" | " + uppercaseFilter(temp));
                        temp = "";
                    }
                }

                if($stateParams['doc-type'] && $stateParams['doc-type'] !== ""){
                    if($stateParams['doc-type'] == 'all' || $stateParams['doc-type'] == 'All'){
                        title += (" | All");
                    }else{
                        arr = $stateParams['doc-type'].split(',');
                        for(i = 0;i<arr.length;i++){
                            temp = temp += trdoctypeFilter(arr[i]) + ", ";
                        }
                        temp = temp.slice(0,-2);
                        title += (" | " + temp);
                        temp = "";
                    }
                }

                if($stateParams['status'] && $stateParams['status'] !== ""){
                    if($stateParams['status'] == 'all' || $stateParams['status'] == 'All'){
                        title += (" | All");
                    }else{
                        arr = $stateParams['status'].split(',');
                        for(i = 0;i<arr.length;i++){
                            temp = temp += trstatusFilter(arr[i]) + ", ";
                        }
                        temp = temp.slice(0,-2);
                        title += (" | " + temp);
                        temp = "";
                    }
                }
                if($stateParams['start'] && $stateParams['start'] !== ""){
                    title += (" | starts with: " + $stateParams['start']);
                }
                if($stateParams['year'] && $stateParams['year'] !== ""){
                    title += (" | year: " + $stateParams['year']);
                }
                if($stateParams['subject'] && $stateParams['subject'] !== ""){
                    title += (" | subjects: " + $stateParams['subject'].split(',').length);
                }
                if($stateParams['department'] && $stateParams['department'] !== ""){
                    title += (" | depts: " + $stateParams['department'].split(',').length);
                }
                this.data.pageTitle = title;
            }
        })
    ;//end stateProvider declarations
})

.controller( 'BrowsePanelCtrl', function BrowsePanelCtrl($scope, Restangular) {
    console.log('panel', $scope.browseVars.masterCounter);
})

.controller( 'BrowseSideCtrl', function BrowseSideController($scope, $state, TbApi, $location, tbSubjectService) {
    //$scope.subjectslist = listsubjects.getSubjects().$object;
    //trawls through subjectlist to submit all selected subjects
    var subjectsLoadedAlready = false;
    $scope.$on('loadBrowseSubjects', function(){
        if(!subjectsLoadedAlready){
            //TbApi.all('subjects.json').getList().then(function(ret){
            tbSubjectService.get().then(function(ret){
                $scope.subjectslist = ret['data']['subjects'];

                $scope.subjectsVisible = true;

                if($location.search()['subject'] && ($location.search()['subject'] !== "" && $location.search()['subject'] !== "true")){
                    $scope.populateAllSubjects($location.search()['subject']);
                }

                subjectsLoadedAlready = true;
            });
          }
    });

    $scope.trawl = function(){
        var list = $scope.subjectslist;
        var output = [];
        for(var i=0;i<list.length;i++){
            if(list[i]['ischecked']){
                output.push(list[i]['id']);
            }else{
                var sub = list[i]['_embedded']['sub-subjects'];
                for(var j=0;j<sub.length;j++){
                    if(sub[j]['ischecked']){
                        output.push(sub[j]['id']);
                    }
                }
            }
        }
        $state.go('browse.form',{'subject': output.toString(), 'page': 1});
    };

    $scope.selectMainSubject = function(id){
        var subject = _.select($scope.subjectslist,{'id': id})[0];
        var counter = 0;
        if(subject['ischecked'] === true){
            for(var k=0;k<subject['_embedded']['sub-subjects'].length;k++){
                if(!subject['_embedded']['sub-subjects'][k]['ischecked']){
                    subject['_embedded']['sub-subjects'][k]['ischecked'] = true;
                    $scope.browseVars.masterCounter++;
                }
                counter++;
            }
        }else{
            for(var l=0;l<subject['_embedded']['sub-subjects'].length;l++){
                if(subject['_embedded']['sub-subjects'][l]['ischecked']){
                    subject['_embedded']['sub-subjects'][l]['ischecked'] = false;
                    $scope.browseVars.masterCounter--;
                }
            }
            counter = 0;
        }
        subject['childCheckedCount'] = counter;
        console.log('master dump', $scope.browseVars.masterCounter);
        $scope.trawl();
    };

    $scope.selectSubSubject = function(pid, id){
        var subject = _.select($scope.subjectslist,{'id': pid})[0];
        var counter = 0;

        for(var m=0;m<subject['_embedded']['sub-subjects'].length;m++){
            if(subject['_embedded']['sub-subjects'][m].ischecked){
                counter++;
            }
        }
        if(counter >= subject['_embedded']['sub-subjects'].length){
            subject['ischecked'] = true;
        }else{
            subject['ischecked'] = false;
        }
        subject['childCheckedCount'] = counter;
        console.log('ccc',counter);
        $scope.trawl();
    };

    $scope.toggleSubSubject = function(sub){
        sub['ischecked'] = !sub['ischecked'];
        if(sub['ischecked']){
            $scope.browseVars.masterCounter += 1;
        }else{
            $scope.browseVars.masterCounter -= 1;
        }
        console.log('master dump', $scope.browseVars.masterCounter);
    };

    $scope.populateAllSubjects = function(input){
        //assume "subjects" variable input is a comma delimited string
        //split it up into an array, we shall iterate over this to hit each one
        var subjects = input.split(",");
        var list = $scope.subjectslist;

        //iterating over each subject in the array
        for(var i=0;i<list.length;i++){
            if(subjects.length > 0){
                var subs = list[i]['_embedded']['sub-subjects'];
                var counter = 0;

                if(isSubjectPresent(list[i]['id'], subjects)){
                    list[i]['ischecked'] = true;
                    for(var k=0;k<subs.length;k++){
                        counter++;
                        subs[k]['ischecked'] = true;
                    }
                }else{
                    for(var j=0;j<subs.length;j++){
                        if(isSubjectPresent(subs[j]['id'], subjects)){
                            counter++;
                            list[i]['collapse'] = true;
                            subs[j]['ischecked'] = true;
                        }
                    }
                }
                list[i]['childCheckedCount'] = counter;
                console.log('ccc',counter);
                $scope.browseVars.masterCounter += counter;
            }else{
                break;
            }
        }
    };

    $scope.selectAllSubjects = function(){
        for(var i=0; i<$scope.subjectslist.length; i++){
            if($scope.subjectslist[i]['collapse'] != $scope.allSubCollapse){
                $scope.subjectslist[i]['collapse'] = !$scope.subjectslist[i]['collapse'];
            }
        }
    };

    function isSubjectPresent(id, subjects){
        for(var i=0;i<subjects.length;i++){
            if(subjects[i] == id){
                subjects.splice(i, 1);
                return true;
            }else{
                return false;
            }
        }
    }
})

.controller( 'BrowseTextbarCtrl', function BrowseTextbarController($scope, $state, $stateParams, $modal, tbUserService, tbFavouritesService){
    $scope.pr = $stateParams;
    console.log($stateParams);
    console.log('textbar ctrl loading, parent:', $scope.$parent);
    $scope.getMaster = $scope.browseVars.masterCounter;

    $scope.$watch('$scope.browseVars.masterCounter', function(){
        $scope.getMaster = $scope.browseVars.masterCounter;
    });

    $scope.subcheck = function(){
        if($scope.pr['subject'] && $scope.pr['subject'] !== null){
            if($scope.pr['subject'] === 'true' || $scope.pr['subject'] === true){
                return false;
            }else{
                return true;
            }
        }else{
            return false;
        }
    };
    $scope.sublength = function(){
        if($scope.subcheck()){
            return $scope.pr['subject'].split(',').length;
        }
    };
    $scope.subplural = function(){
        if($scope.subcheck()){
            if($scope.pr['subject'].split(',').length > 1){
                return 'subjects';
            }else{
                return 'subject';
            }
        }
    };

    $scope.modalFavouritesOpen = function(){
        if(!$scope.showUserButtons){
            tbUserService.showShareBlockModal();
        }else{
            console.log('Modal add to favourites called');
            var modalInstance = $modal.open({
                templateUrl: 'browse/modalSearchFavourites.html',
                controller: 'ModalBrowseFavouritesCtrl',
                resolve: {
                    selected: function(){
                        return $scope.data.selected;
                    }
                }
            });

            modalInstance.result.then(function(){
                if($scope.data.selected && $scope.data.selected.length > 0){
                    console.log('SELECTED FAVES',$scope.data.selected);
                    tbFavouritesService.addMultipleFavourites($scope.data.selected.map(function(item){
                        return item['doc-id'];
                    }));
                }
            });
        }
    };

    $scope.modalProfileOpen = function(){
        console.log('Modal add to profile called');
        var modalInstance = $modal.open({
            templateUrl: 'browse/modalSearchProfile.html',
            controller: 'ModalBrowseProfileCtrl',
            resolve: {
                selected: function(){
                    return $scope.data.selected;
                }
            }
        });
    };

    $scope.modalPrintOpen = function(){
        console.log('Modal print called');
        var modalInstance = $modal.open({
            templateUrl: 'browse/modalSearchPrint.html',
            controller: 'ModalBrowsePrintCtrl',
            resolve: {
                searchItems: function(){
                    return $scope.getSelectedItems();
                }
            }
        });

        modalInstance.result.then(function(ret){
            console.log('Print modal dismissed!', ret);

            var sparams = $scope.pr;
            switch(ret){
                case 'selected':
                    var ids = $scope.data.selected.map(function(item){
                        return item['legislation-id'];
                    });

                    sparams.selected = ids.join(',');
                    break;
                case 'results':
                    delete sparams.selected;
                    break;
            }
            if(sparams['subject'] == "true"){
                delete sparams['subject'];
            }
            delete sparams.page;
            console.log('BROWSEPRINT CALL',sparams);
            var url = $state.href('browseprint',sparams);
            window.open(url, '_blank');
        });
    };

    $scope.modalDownloadOpen = function(){
        console.log('Modal download called');
        var modalInstance = $modal.open({
            templateUrl: 'browse/modalSearchDownload.html',
            controller: 'ModalBrowseDownloadCtrl'
        });

        modalInstance.result.then(function(){
            //$log.info('Print modal dismissed!');
        });
    };
})

    .controller('ModalBrowseDownloadCtrl', function($scope, $modalInstance){
        $scope.ok = function () {
            $modalInstance.close();
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    })

    .controller('ModalBrowsePrintCtrl', function($scope, $modalInstance, searchItems){
        $scope.ok = function () {
            $modalInstance.close($scope.selectedItem.res);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };

        $scope.searchItems = searchItems;
        $scope.selectedItem = {};

        if(searchItems.length && searchItems.length > 0){
            $scope.selectedItem.res = "selected";
        }else{
            $scope.selectedItem.res = "results";
        }
    })

.controller ('BrowseMainCtrl', function BrowseMainController($scope, $modal, Restangular, TbApi, $state, $location, $stateParams, trjurisrevFilter, tbUserService){
    $scope.filterCollapse = false;
    $scope.sidebarCollapse = {};
    $scope.sidebarCollapse.lstate = false;
    $scope.sidebarCollapse.rstate = false;

    $scope.data = {};
    $scope.data.selected = [];

    $scope.sp = $stateParams;
    console.log('BROWSEMAINCTRL',$stateParams);

    $scope.params = {};

    $scope.getSelectedItems = function(){
        return $scope.data.selected;
    };

    if($stateParams['sort'] && $stateParams['sort'] !== ''){
        $scope.params['sort'] = $stateParams['sort'];
    }else{
        $scope.params['sort'] = 'title,jurisdiction,date';
    }

    if($location.search()['juris']){$scope.params['juris'] = $location.search()['juris'].split(",");}
    if($location.search()['doc-type']){$scope.params['doc-type'] = $location.search()['doc-type'].split(",");}
    if($location.search()['status']){$scope.params['status'] = $location.search()['status'].split(",");}
    if($location.search()['start']){$scope.params['start'] = $location.search()['start'];}
    //$scope.alphabet = Restangular.all('alphabetical.json').getList().$object;
    $scope.form = {};

    //this counts subjects
    $scope.browseVars = {};
    $scope.browseVars.masterCounter = 0;

    $scope.$on('browseResultsLoaded', function(){
        console.log('BROWSE RESULTS LOADED');
        $scope.$broadcast('loadBrowseSubjects');
    });

    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            if(user['user'] && user.isIndividual()){
                $scope.showUserButtons = true;
            }
        },
        true
    );


    //this counts subjects
    $scope.jurisdictions = {
        "allSelected" : true,
        "noneSelected" : false,
        "data" : [
            {name: "cth", isSelected: false},
            {name: "act", isSelected: false},
            {name: "nsw", isSelected: false},
            {name: "nt", isSelected: false},
            {name: "qld", isSelected: false},
            {name: "sa", isSelected: false},
            {name: "tas", isSelected: false},
            {name: "vic", isSelected: false},
            {name: "wa", isSelected: false}
        ]
    };

    $scope.doctypes = {
        "allSelected" : true,
        "noneSelected" : false,
        "data" : [
            {name: "act", isSelected: false},
//            {name: "ord", isSelected: false},
            {name: "reg", isSelected: false},
            {name: "bill", isSelected: false},
            {name: "prn", isSelected: false},
            {name: "cpn", isSelected: false}
        ]
    };

    $scope.status = {
        "allSelected" : true,
        "noneSelected" : false,
        "data" : [
            {name: "aws", isSelected: false},
            {name: "cur", isSelected: false},
            {name: "rep", isSelected: false},
            {name: "dra", isSelected: false},
//            {name: "inop", isSelected: false},
            {name: "ass", isSelected: false},
//            {name: "spnt", isSelected: false},
            {name: "nis", isSelected: false},
            {name: "fail", isSelected: false}
        ]
    };

    $scope.principal = {
        'principal' : false,
        'amending' : false
    };

    if($location.search()['principal']){
        if($location.search()['principal'] == 'true,false'){
            $scope.principal.principal = true;
            $scope.principal.amending = true;
        }else if($location.search()['principal'] == 'true' ){
            $scope.principal.principal = true;
        }
    }

    function parseFilterParams(fixed, params){
        if(params == 'all'){
            _.forEach(fixed, function(input){
                input.isSelected = true;
            });
        }else{
            for(var i=0;i<fixed.length;i++){
                for(var j=0;j<params.length;j++){
                    if(fixed[i]['name'] == params[j]){
                        fixed[i]['isSelected'] = true;
                    }
                }
            }
        }
    }
    if($scope.params['juris']){parseFilterParams($scope.jurisdictions['data'],$scope.params['juris']);}
    if($scope.params['doc-type']){parseFilterParams($scope.doctypes['data'],$scope.params['doc-type']);}
    if($scope.params['status']){parseFilterParams($scope.status['data'],$scope.params['status']);}

    $scope.submitBrowseControl = function(){
        $state.go("browse.form", {'year': $scope.form.dStart});
    };

    $scope.clearFilter = function(){
        _.forEach($scope.jurisdictions.data, function(input){
            input.isSelected = true;
        });
        _.forEach($scope.doctypes.data, function(input){
            input.isSelected = true;
        });
        _.forEach($scope.status.data, function(input){
            input.isSelected = true;
        });
        $scope.principal.principal = false;
        $scope.principal.amending = false;

        $state.go('browse.form',{
            'juris' : 'all',
            'doc-type' : 'all',
            'status' : 'all',
            'principal': undefined,
            'year': undefined,
            'start': undefined
        },{
            inherit: false
        });
    };

    $scope.applyFilter = function(){
        console.log('applyFilter called');
        var params = {};

        if($scope.jurisdictions.allSelected === true){
            params['juris'] = "all";
        }else{
            var ti = [];
            for(var i = 0;i<$scope.jurisdictions.data.length;i++){
                if($scope.jurisdictions.data[i].isSelected === true){
                    ti.push($scope.jurisdictions.data[i]['name'].toLowerCase());
                }
            }
            params['juris'] = ti.toString();
        }

        if($scope.doctypes.allSelected === true){
            params['doc-type'] = "all";
        }else{
            var tj = [];
            for(var j = 0;j<$scope.doctypes.data.length;j++){
                if($scope.doctypes.data[j].isSelected === true){
                    tj.push($scope.doctypes.data[j]['name'].toLowerCase());
                }
            }
            params['doc-type'] = tj.toString();
        }

        if($scope.status.allSelected === true){
            params['status'] = "all";
        }else{
            var tk = [];
            for(var k = 0;k<$scope.status.data.length;k++){
                if($scope.status.data[k].isSelected === true){
                    tk.push($scope.status.data[k]['name'].toLowerCase());
                }
            }

            params['status'] = tk.toString();
        }

        console.log('applyFilter principal check', $scope.principal);
        if($scope.principal){
            if($scope.principal.principal && $scope.principal.amending){
                params['principal'] = "true,false";
            }else if($scope.principal.principal && !$scope.principal.amending){
                params['principal'] = "true";
            }else if(!$scope.principal.principal && $scope.principal.amending){
                params['principal'] = "false";
            }else if(!$scope.principal.principal && !$scope.principal.amending){
                params['principal'] = undefined;
            }
        }else{
            params['principal'] = undefined;
        }
        params['page'] = 1;

        console.log('applyFilter', params);
        console.log('old state', $state);
        $state.go("browse.form", params);
    };

    //populate years
    $scope.years = "";
    $scope.popYears = function(params){
        console.log('YEARS PARAMS:',params);
        TbApi.all('search/facets/year.json').getList(params).then(function(ret){
            console.log('YEARS RETURN:',ret);
            $scope.years = ret['data']['filters'];
        });
    };

    function sortObject(o) {
        var sorted = {},
        key, a = [];

        for (key in o) {
            if (o.hasOwnProperty(key)) {
                a.push(key);
            }
        }

        a.sort();

        for (key = 0; key < a.length; key++) {
            sorted[a[key]] = o[a[key]];
        }
        return sorted;
    }

    $scope.alphabet = "";
    $scope.alphabetLoaded = false;
    $scope.popAlphabet = function(params, starter){
        $scope.alphabetLoaded = false;
        TbApi.all('search/facets/starts-with.json').getList(params).then(function(ret){
            $scope.alphabetLoaded = true;
            console.log('original return',ret);
            $scope.alphabet = _.groupBy(ret[2]['filters'],function(input){
                return input['name'].charAt(0);
            });

            var alpha=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
            for(var i=0;i<alpha.length;i++){
                if(!$scope.alphabet[alpha[i]]){
                    $scope.alphabet[alpha[i]] = [];
                }
            }

            $scope.alphabet = sortObject($scope.alphabet);

            //comment is pointless comment
            if(starter){
                $scope.toggleAlphabet(starter.charAt(0));
            }

            console.log('grouped by first char of name:',$scope.alphabet);
        });
    };
//    $scope.popYears($scope.searchObject);
//    $scope.popAlphabet($scope.searchObject, $scope.params['start']);
    //populate starts-with selection widget

    $scope.clickToggler = function(){
        var elem = angular.element('.ui-layout-toggler-west');
        elem.trigger('click');
    };

    $scope.toggleAlphabet = function(topletter){
        _.forEach($scope.alphabet, function(item){
            item['selected'] = false;
        });

        $scope.alphabet[topletter]['selected'] = true;
        console.log(topletter, $scope.alphabet);
    };

    $scope.alphaLink = function(string){
        console.log('startswith transition called', string);
        $state.go('browse.form',{'start': string, 'page': 1});
    };

})

.controller( 'BrowseResultCtrl', function BrowseResultController($scope, TbApi, $modal, $stateParams, $state, tbSearchServiceAlt, tbUtil) {
    console.log('result ctrl reloading');
    console.log('master counter', $scope.browseVars.masterCounter);
    $scope.params = $stateParams;
    //$scope.sresults = tbRequest['data']['documents'];
    //$scope.totalItems = tbRequest['data']['hits'];

    if(!$scope.params['page']){
        $scope.currentPage = 1;
    }else{
        $scope.currentPage = $scope.params['page'];
    }

    $scope.searchObject = {};
    if($stateParams['juris'] && ($stateParams['juris'] !== '' && $stateParams['juris'] !== 'all')){
        $scope.searchObject['jurisdiction'] = $stateParams['juris'];
    }
    if($stateParams['doc-type'] && ($stateParams['doc-type'] !== '' && $stateParams['doc-type'] !== 'all')){
        $scope.searchObject['doc-type'] = $stateParams['doc-type'];
    }
    if($stateParams['subject'] && ($stateParams['subject'] !== '' && $stateParams['subject'] !== 'all')){
        if($stateParams['subject'] == 'true' || $stateParams['subject'] === true){
            //console.log("herpaderpa");
        }else{
            $scope.searchObject['subject'] = $stateParams['subject'];
        }
    }
    if($stateParams['scope'] && $stateParams['scope'] !== ''){
        $scope.searchObject['scope'] = $stateParams['scope'];
    }
    if($stateParams['year'] && $stateParams['year'] !== ''){
        $scope.searchObject['year'] = $stateParams['year'];
    }
    if($stateParams['start'] && $stateParams['start'] !== ''){
        $scope.searchObject['starts-with'] = $stateParams['start'];
    }
    if($stateParams['status'] && ($stateParams['status'] !== '' && $stateParams['status'] !== 'all')){
        $scope.searchObject['status'] = $stateParams['status'];
    }
    if($stateParams['department'] && $stateParams['department']  !== ''){
        $scope.searchObject['department'] = $stateParams['department'];
    }

    var initSidebar = ($stateParams['subject']) ? true : false;
    if(initSidebar){
        console.log("init sidebar", initSidebar, $stateParams);
        $scope.sidebarCollapse.lstate = true;
    }

    $scope.currentYear = $stateParams['year'];

    $scope.browseResultsLoaded = false;
    var tbRequest = function(){
        //this is dumb
        var sw = "";
        if($stateParams['start']){
            sw = $stateParams['start'].toLowerCase();
        }

        console.log('browse state params', $stateParams);

        var params={};
        if($stateParams['juris'] && ($stateParams['juris'] !== '' && $stateParams['juris'] !== 'all')){
            params['jurisdiction'] = $stateParams['juris'];
        }
        if($stateParams['doc-type'] && ($stateParams['doc-type'] !== '' && $stateParams['doc-type'] !== 'all')){
            params['doc-type'] = $stateParams['doc-type'];
        }
        if($stateParams['subject'] && ($stateParams['subject'] !== '' && $stateParams['subject'] !== 'all')){
            if($stateParams['subject'] == 'true' || $stateParams['subject'] === true){
            }else{
                params['subject'] = $stateParams['subject'];
            }
        }
        if($stateParams['start'] && $stateParams['start'] !== ''){
            params['starts-with'] = $stateParams['start'];
        }
        if($stateParams['scope'] && $stateParams['scope'] !== ''){
            params['scope'] = $stateParams['scope'];
        }
        if($stateParams['status'] && ($stateParams['status'] !== '' && $stateParams['status'] !== 'all')){
            params['status'] = $stateParams['status'];
        }

        if($stateParams['year'] && $stateParams['year']  !== ''){
            params['year'] = $stateParams['year'];
        }
        if($stateParams['department'] && $stateParams['department']  !== ''){
            params['department'] = $stateParams['department'];
        }
        if($stateParams['page'] && $stateParams['page'] !== ''){
            params['start'] = ((($stateParams['page'] - 1) * 50) + 1);
        }

        if($stateParams['sort'] && $stateParams['sort'] !== ''){
            switch($stateParams['sort']){
                case 'title':
                    params['sort'] = 'title,jurisdiction,date';
                    break;
                case '-title':
                    params['sort'] = '-title,jurisdiction,date';
                    break;
                case 'date':
                    params['sort'] = '-date,jurisdiction,title';
                    break;
                case '-date':
                    params['sort'] = 'date,jurisdiction,title';
                    break;
                case 'juris':
                    params['sort'] = 'jurisdiction,title,date';
                    break;
                case '-juris':
                    params['sort'] = '-jurisdiction,title,date';
                    break;
            }
        }else{
            params['sort'] = 'title,jurisdiction,date';
        }

        if($stateParams['principal']){
            params['principal'] = $stateParams['principal'];
        }

        //NOW DO CHECKS FOR THE DOUBLEUP PARAMS
        //ACT ALSO MEANS ORD, REP ALSO MEANS INOP
        if(params['doc-type'] && params['doc-type'].split(',').indexOf('act') > -1){
            params['doc-type'] = params['doc-type'] + ",ord";
        }
        if(params['status'] && params['status'].split(',').indexOf('rep') > -1){
            params['status'] = params['status'] + ",inop";
        }

        console.log('modified search param object',params);

        TbApi.all('search.json').getList(params).then(function(ret){
            $scope.sresults = ret['data']['documents'];
            $scope.totalItems = ret['data']['hits'];
            $scope.browseResultsLoaded = true;
        }).then(function(){
            $scope.markChecked();
            $scope.$emit('browseResultsLoaded');
            if($scope.totalItems < 50){
                $scope.itemsPerPage = $scope.totalItems;
            }else{
                $scope.itemsPerPage = 50;
            }

            $scope.maxSize = 5;
            $scope.numPages = ($scope.totalItems / $scope.itemsPerPage);
        });
    };

    tbRequest();

    $scope.$on('loadBrowseSubjects', function(){
        $scope.popYears($scope.searchObject);
        $scope.popAlphabet($scope.searchObject, $stateParams['start']);
    });

    $scope.markChecked = function(){
        var ids = $scope.data.selected.map(function(item){
            return item['legislation-id'];
        });
        console.log('HERP',ids);

        for(var i = 0, len = $scope.sresults.length; i < len; i++){
            //check if anything here is in the selected list
            if(ids.indexOf($scope.sresults[i]['legislation-id']) > -1){
                $scope.sresults[i]['isChecked'] = true;
            }
        }
    };
    //$scope.markChecked();

    //pagination change listener
    $scope.$watch('currentPage', function(newPage,oldPage){
        console.log('pagination watcher',newPage,oldPage);
        if(newPage != oldPage){
            $state.go('browse.form', {'page' : newPage});
        }
    });

    if($scope.params['sort']){
        switch($scope.params['sort']){
            case 'title':
                $scope.sortBySelected = "Title";
                break;
            case 'date':
                $scope.sortBySelected = "Year";
                break;
            case 'juris':
                $scope.sortBySelected= "Jurisdiction";
                break;
        }
    }else{
        $scope.sortBySelected = "Title";
    }

    $scope.selectItem = function(item){
        if(item['isChecked']){
            item['isChecked'] = false;
            var index = _.findIndex($scope.data.selected, function(arrItem){
                return arrItem['legislation-id'] == item['legislation-id'];
            });

            if(index != -1){
                $scope.data.selected.splice(index, 1);
            }
        }else{
            item['isChecked'] = true;
            $scope.data.selected.push(item);
        }
        console.log('pushed to selected',$scope.data.selected);
    };

    $scope.selectAllOnPage = function (){
        for(var i = 0; i < $scope.sresults.length; i++){
            if(!$scope.sresults[i].isChecked){
                $scope.selectItem($scope.sresults[i]);
            }
        }
    };

    $scope.deselectAllOnPage = function(){
        for(var i = 0; i < $scope.sresults.length; i++){
            if($scope.sresults[i].isChecked){
                $scope.selectItem($scope.sresults[i]);
            }
        }
    };

    // $scope.sortByOptions = ['Title','Year','Jurisdiction'];
    // $scope.sortByChanged = function(opt){
    //     console.log('SORT BY CHANGED', opt);

    //     var params = {};
    //     switch(opt){
    //         case 'Title':
    //             params['sort'] = '';
    //             break;
    //         case 'Year':
    //             params['sort'] = 'date';
    //             break;
    //         case 'Jurisdiction':
    //             params['sort'] = 'juris';
    //             break;
    //     }
    //     $state.go('browse.form', params);
    // };

    //parses a legislation link and calls state transition
    $scope.legLink = tbUtil.legLink;
    $scope.legParams = tbUtil.legParamsClean;

    $scope.browseParams = function(item){
        console.log('tempLink browse called', item);
        var params = {};
        params['legId'] = item['legislation-id'];
        params['contId'] = item['content-id'];

        $state.go('legislation',params, {inherit: false});
    };

    $scope.changeSortBy = function(input){
        console.log('changeSortBy', input);
        var params = {
            sort: "",
            page: 1
        };
        switch(input){
            case 'title':
                if(!$scope.params['sort'] || ($scope.params['sort'] && $scope.params['sort'] == 'title')){
                    params['sort'] = "-title";
                }else{
                    params['sort'] = "title";
                }
                break;
            case 'date':
                if($scope.params['sort'] && $scope.params['sort'] == 'date'){
                    params['sort'] = "-date";
                }else{
                    params['sort'] = "date";
                }
                break;
            case 'juris':
                if($scope.params['sort'] && $scope.params['sort'] == 'juris'){
                    params['sort'] = "-juris";
                }else{
                    params['sort'] = "juris";
                }
                break;
        }
        $state.go('browse.form',params);
    };
})

.controller('ModalBrowseFavouritesCtrl', function($scope, $modalInstance, selected, tbFavouritesService){
    console.log('SELECTED',selected);
    $scope.selectedItems = selected;

    $scope.ok = function () {
        $modalInstance.close(true);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})


.controller('ModalBrowseProfileCtrl', function($scope, $modalInstance, selected, TbApi){
    console.log('SELECTED',selected);
    $scope.selectedItems = selected;

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    $scope.addToProfile = function(profile){
        console.log('add profile',profile);

        var existing = [];

        TbApi.one('profiles/'+profile['id']+'/legislation.json').get()
        .then(function(ret){
            console.log('load existing legs', ret);
            //make a list of existing legislation by item
            for(var i = 0, vlen = ret['data']['tracked-legislation'].length; i < vlen; ++i){
                existing.push({
                    'legislation-id': ret['data']['tracked-legislation'][i]['legislation-id'],
                    'tracked': (ret['data']['tracked-legislation'][i]['tracked'])
                });
            }

            //insert all the selected items
            for(var j = 0, elen = selected.length; j < elen; j++){
                console.log('le select',selected[j]);
                existing.push({
                    'legislation-id': selected[j]['doc-id'],
                    'tracked': true
                });
            }

            //push the list
            TbApi.one('profiles/' + profile['id'] + '/legislation/all.json').customPUT(existing).then(
                function(ret){
                    if(ret['code'] == 200){
                        profile['processed'] = true;
                    }
                }
            );
        });
    };

    if(selected && selected.length > 0){
        TbApi.all('profiles.json').getList().then(function(ret){$scope.profiles = ret['data'];});
    }

    ////[LOWEB-204] start: Add new profile on alert modal
    $scope.profile = {
      "name": "",
      "description": "",
      "alert-no-activity": false,
      "report-type": "Standard",
      "frequency": [],
      "alert-events": {
        "progress": true,
        "modified": true,
        "commenced": true,
        "published": true,
        "assented": true,
        "amended": true,
        "repealed": true
      }
    };

    $scope.frequencyOptions = {
        'daily': true
    };

    $scope.reportOptions = [
        {
            'name': "Standard",
            'value': "Standard"
        },
        {
            'name': "Summary Only",
            'value': "Summary"
        }
    ];

    $scope.makeFrequencyArray = function(){
        var arr = [];
        if($scope.frequencyOptions['half-daily']){ arr.push('half-daily'); }
        if($scope.frequencyOptions['daily']){ arr.push('daily'); }
        if($scope.frequencyOptions['weekly']){ arr.push('weekly'); }
        if($scope.frequencyOptions['monthly']){ arr.push('monthly'); }
        return arr;
    };
    
    $scope.saveProfile = function(){
        if(!$scope.profile.name || $scope.profile.name.length <= 0){
            $scope.showErrorMessage = true;
        }else{
            //first check if this is a new or edit profile
            var putData = {};

            $scope.profile['frequency'] = $scope.makeFrequencyArray();

            if($scope.profile['alert-events']['amended']){
                $scope.profile['alert-events']['modified'] = true;
            }

            putData = {
              "name": $scope.profile['name'],
              "description": $scope.profile['description'],
              "alert-no-activity": $scope.profile['alert-no-activity'],
              "report-type": $scope.profile['report-type'],
              "frequency": $scope.profile['frequency'],
              "alert-events": $scope.profile['alert-events']
            };

            TbApi.one('profiles.json').customPOST(putData).then(function(ret){
                $scope.addToProfile(ret['data']);
                TbApi.all('profiles.json').getList().then(function(ret){
                    var tmpArr = [];
                    angular.forEach(ret['data'], function(item){
                        if(item['name'] == putData['name']){
                            item['processed'] = true;
                        }
                        tmpArr.push(item);
                    });
                    $scope.profiles = tmpArr;
                });
            });
            $scope.showErrorMessage = false;
            $scope.isShowProfDialog();
        }
    };

    $scope.isShowProfDialog = function(){
        $scope.filterCollapse = false;
    };

    $scope.isShowAlertDialog = function(){
        $scope.filterCollapse = true;
    };
    ////[LOWEB-204] end
})

;
