angular.module( 'tbLawOne.login', [
  'ui.router',
  'ui.bootstrap',
  'tbLawOne.services'
])

.config(function config( $stateProvider ) {
    $stateProvider
        //test
        .state( 'login', {
            url: '/oauth?returnState?returnParams',
            views: {
                "main": {
                    controller: 'LoginCtrl',
                    templateUrl: 'login/login.tpl.html'
                    //template: '<div class="container"><img style="margin: 30% 50% 0 50%;" src="/assets/img/ajax-loader.gif"></img></div>'
                }
            },
            data:{ pageTitle: 'Login' }
        })
//        .state ('holding',{
//            url: '/o',
//            views: {
//                'main': {
//                    controller: 'HoldingCtrl',
//                    template: '<div class="container"><img style="margin: 30% 50% 0 50%;" src="/assets/img/ajax-loader.gif"></img></div>'
//                }
//            },
//            data: {pageTitle: 'Working...'}
//        })
    ;//end stateProvider declarations
})

.controller ('LoginCtrl', function LoginController($scope, $state, $stateParams, $location, $timeout, AccessToken, Profile, TbApi, tbUserService, Endpoint, ENV){
    $scope.params = $stateParams;
    $scope.ENV = ENV;

//    var temp = {
//        "state": $stateParams['returnState'],
//        "params": JSON.parse($stateParams['returnParams'])
//    };
//    $scope.callbackScope = JSON.stringify(temp);
//    console.log('callbackScope string', $scope.callbackScope);
//
//    //AccessToken.set($scope);
//    console.log('Login controller fired', AccessToken.get(), temp);
//    if(!AccessToken.get()){
//        console.log(AccessToken.get());
//        var endpointTest = {
//            site : "https://ps.timebase.com.au",
//            authorizePath :"/o/oauth2/authorize",
//            responseType : "token",
//            clientId: "CC1BF64859B26ECF",
//            redirectUri: "https://angular.jc.timebase.com.au/oauth",
//            oAuthScope: '',
//            state: $scope.callbackScope
//        };
//        Endpoint.set(endpointTest);
//        console.log('PRE REDIRECT PARAMS:',endpointTest);
//        Endpoint.redirect();
//    }
alert('here');
    $scope.goBack = function(){
        if($scope.logged && $scope.logged['state'] && $scope.logged['state'] !== '/oauth'){
            console.log('Landing successful, redirecting!', $scope.logged);
            //set location to what's in the state parameter
            //NOTE - THIS CAUSES PROBLEMS BECAUSE SEARCH OBJECT INIT IS FUCKED
//            var tempurl_red = document.createElement('a');
//            tempurl_red.href = $scope.logged['state'];
//            console.log('path',tempurl_red.pathname);
//            console.log('search',tempurl_red.search);
//            var sst = tempurl_red.search.slice(1).split("=");
//            console.log('array',sst);
            //alert('LANDING SUCCESSFUL ' + $scope.logged['state']);
            //added swarnambika
            alert('LANDING SUCCESSFUL ' + $scope.logged['state']);
              //added swarnambika
            $location.url($scope.logged['state']).replace();
        }else{
            alert('LANDING here ' + $scope.logged['state']);
            $state.go('home');
        }
//        if($scope.logged && $scope.logged['state']){
//            var obj = JSON.parse($scope.logged['state']);
//            console.log('goback function called', obj);
//            if(obj['state']){
//                $state.go(obj['state'],obj['params'],{inherit: false});
//            }else{
//                $state.go('home',{},{inherit: false, reload: true});
//            }
//        }else{
//            console.log("No state to go back to");
//        }
    };

    $timeout(function() {
      console.log('Firing check to see if we got anything back', JSON.stringify(AccessToken.get()));
      $scope.logged = AccessToken.get();
      if($scope.logged){
        $scope.goBack();
      }
    }, 0);
})


.controller( 'HoldingCtrl', function HoldingController(){

})

;//end login.js
