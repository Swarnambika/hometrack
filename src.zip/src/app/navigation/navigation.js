angular.module('tbLawOne.navigation',[
    'tbLawOne.services',
    'ui.router'
])

.controller( 'NavCtrl', function NavController (
    $scope,
    $rootScope,
    $state,
    $window,
    $location,
    tbSearchServiceAlt,
    tbUserService,
    AccessToken,
    $modal,
    $modalStack,
    $localStorage,
    $timeout,
    ENV
){
    //$('#tb-nav-dropdowns-ext').css('display','block');

    $scope.navLoaded = true;
    $scope.navCollapsed = true;

    //these variables control which of the three sub-views are shown
    $scope.browseCollapse = true;
    $scope.trackCollapse = true;
    $scope.searchCollapse = true;
    $scope.navUserShow = false;
    $scope.searchAdv = {
        showAdv : false
    };
    
    $scope.isErrorBarShow = false;
    $scope.is500Error = false;
    $scope.errDetailedMess = [];
    var ajaxModalOpened = false;
    $scope.openRestModal = function(errorObj){
        console.log('openAjaxModal', errorObj);
        if(!ajaxModalOpened){
            var reason = "Multimodal collapse";
            console.log('MMS',$modalStack);
            $modalStack.dismissAll(reason);

            var modalInstance = $modal.open({
               templateUrl: 'error/errormodal.tpl.html',
               controller:  'ErrorInterceptModalCtrl',
               windowClass: 'alert-create-modal',
               resolve: {
                    error: function(){ return errorObj.errorTotalDetail; },
                    redirectUrl: function(){ return errorObj.errRedirectUrl; }
                }
            });

            ajaxModalOpened = true;

            modalInstance.result.then(function(ret){
                console.log('AJAX error modal closed', ret);
                ajaxModalOpened = false;
            });
        }else{
            console.log('Modal already open!');
        }
    };

    $scope.closeErrorDetail = function(){
        $scope.isErrorBarShow=false;
        if($localStorage.errorMessList){
            console.log('Remove localStorage errorMessList object');
            $localStorage.errorMessList = null;
        }
    };

    $scope.$on('RestErrorThrown', function(event, error, redirectUrl){
        console.log('RESTful error has been thrown', error);
        event.preventDefault();
        var currErrorObj = {};
        switch(error.status){
            case 400:
                currErrorObj.currErrorMess = "Warning - Bad request";
                break;
            case 403:
                currErrorObj.currErrorMess = "Warning! You don't have permission to access the resource.";
                break;
            case 404:
                currErrorObj.currErrorMess = "Warning! The document couldn't be found.";
                break;
            case 500:
            case 501:
                currErrorObj.currErrorMess = "Error! The server encountered an unexpected condition which prevented it from fulfilling the request.";
                $scope.is500Error = true;
                break;
            case 502:
                currErrorObj.currErrorMess = "Error! The service was temporarily overloaded. Please try again";
                $scope.is500Error = true;
                break;
            case 503:
                currErrorObj.currErrorMess = "Error! The gateway timed out. The server maybe experiencing high load. Please try again";
                $scope.is500Error = true;
                break;
            default:
                currErrorObj.currErrorMess = "Error! " + error.statusText;
                console.log( 'No availabe RESTful error details', error.status, error.data );
                break;
        }
        if(typeof error['data'] == "string"){
            if(error['data'].slice(-2) != "\"}"){
                error['data'] = error['data'] += "\"}";
            }
        }
        currErrorObj.errorTotalDetail = error;
        currErrorObj.errRedirectUrl = redirectUrl;
        if(!$localStorage.errorMessList){
            console.log('localStorage errorMessList object is not present');
            $localStorage.errorMessList = [];
        }
        console.log($localStorage.errorMessList);
        $localStorage.errorMessList.push(currErrorObj);
        $scope.errDetailedMess = $localStorage.errorMessList;
        $scope.isErrorBarShow = true;
        $timeout(function(){
            if($scope.isErrorBarShow && !ajaxModalOpened){ $scope.isErrorBarShow = false; }
        },5000);
    });

    window.onerror = function(msg, url, line){
        console.log('Error: ' + msg + '\n Line No: ' + line);
    };

    $scope.navClose = function(){
        //console.log("navClose fired");
        $scope.searchCollapse = true;
        $scope.browseCollapse = true;
        $scope.trackCollapse = true;
    };

    $scope.goHome = function(){
        $scope.toggleNav();
        $state.go(
            'home'
        );
    };

    console.log('$window isie8',$window['isie8']);
    console.log('window isie8', window['isie8']);
    //$scope.showIEBanner = $window['isie8'];
    //
    $scope.showIEBanner = window['isie8'];
    $scope.dismissIEBanner = function(){
       $scope.showIEBanner = false;
    };

    //click-outside-nav controls
    $scope.$window = $window;

    $scope.toggleMob = function(skip){
        $scope.navCollapsed = !$scope.navCollapsed;

        if(!skip){
            $scope.browseCollapse = true;
            $scope.trackCollapse = true;
            $scope.searchCollapse = true;
            $scope.navUserShow = false;
        }
    };

    $scope.toggleNav = function(s){
        console.log('togglenav', s);

        //which item?
        switch(s){
            case 'browse':
                $scope.searchCollapse = true;
                $scope.trackCollapse = true;
                $scope.navUserShow = false;
                $scope.browseCollapse = !$scope.browseCollapse;
                $scope.toggleMob(true);
                break;
            case 'search':
                $scope.browseCollapse = true;
                $scope.trackCollapse = true;
                $scope.navUserShow = false;
                $scope.searchCollapse = !$scope.searchCollapse;
                $scope.toggleMob(true);
                break;
            case 'track':
                $scope.searchCollapse = true;
                $scope.browseCollapse = true;
                $scope.navUserShow = false;
                $scope.trackCollapse = !$scope.trackCollapse;
                $scope.toggleMob(true);
                break;
            case 'home':
                $scope.browseCollapse = true;
                $scope.trackCollapse = true;
                $scope.searchCollapse = true;
                $scope.navUserShow = false;
                $scope.$window.onclick = null;
                $scope.toggleMob(true);
                break;
            case 'user':
                $scope.navUserShow = !$scope.navUserShow;
                break;
            default:
                $scope.browseCollapse = true;
                $scope.trackCollapse = true;
                $scope.searchCollapse = true;
                $scope.navUserShow = false;
                $scope.$window.onclick = null;
                break;
        }

        if(!$scope.browseCollapse || !$scope.trackCollapse || !$scope.searchCollapse || $scope.navUserShow){
            //fire up the click-outside listener
            $scope.$window.onclick = function(event){
                closeSearchElsewhere(event, $scope.toggleNav);
            };
        }
    };

    $scope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams){
        $scope.toggleNav();
        $scope.navCollapsed = true;
    });

    $scope.$watch(
        //get the value we care about
        function(){
            var navVar = [
                $scope.navCollapsed,
                $scope.browseCollapse,
                $scope.trackCollapse,
                $scope.searchCollapse
            ];
            var res = navVar.every(function(item){
                return !!item;
            });
            return res;
        },
        function(newVal, oldVal){
            console.log('WC', newVal, oldVal);
            if(newVal !== oldVal){
                if(newVal === false){
                    $('#tb-core').addClass('tb-hidephone');
                }else{
                    $('#tb-core').removeClass('tb-hidephone');
                }
            }
        }
    );

    //for listening to clicks in the mainport
    function closeSearchElsewhere(event, callbackOnClose){
        //did we click in the mainport?
        console.log('clicktrack', $(event.target));
        console.log('closest trace', $(event.target).closest('.tb-nav-searchpane, .tb-navtop, .navsec, .modal, .noclosenav'));
        console.log('parents', $(event.target).parents());

        var pr = event.target;
        var prs = [];
        while(pr){
            prs.unshift(pr);
            pr = pr.parentNode;
        }

        console.log('brute force parents dump, no jquery', prs);

        if($(event.target).closest('.tb-nav-searchpane, .tb-navtop, .navsec, .modal, .noclosenav').length > 0){
            console.log('testing for no-close OK');
            return;
        }else{
            callbackOnClose();
            $scope.$apply();
            return;
        }
    }

    $scope.userInfo = {};
    $scope.$watch(
        function(){
            return AccessToken.get();
        },
        function(token){
            if(token){
                $scope.isLoggedIn = true;
            }
        }
    );

    //$scope.accountLinkString = encodeURIComponent(document.location.href);
    $scope.launchMyAccount = function(){
        var url = "https://auth.timebase.com.au/drm/account/personal.html?return_uri=" + encodeURIComponent($location.absUrl());
        //alert(url);
        window.open(url, '_blank');
    };

    $scope.logOut = function(){
        AccessToken.destroy();
        tbUserService.clearUserObject();
        var logoutlink = "" + ENV.oauthSite + ENV.oauthLogoutPath;
        console.log('LOGOUT', logoutlink);
        window.location.replace(logoutlink);
    };

    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            if(user && user['user']){
                console.log('navigation watcher for users', user);
                $scope.userInfo = user;
                if(user['user'] && user.isIndividual()){
                    console.log('USER IS INDIVIDUAL');
                    $scope.showUserButtons = true;
                }
              }
        },
        true
    );
})

.controller('NavUserCtrl', function NavUserController($scope){

})

.controller( 'NavSearchCtrl', function NavSearchController(
    $scope,
    $state,
    $stateParams,
    $modal,
    $location,
    TbApi,
    TbTestingApi,
    tbUserService,
    tbSearchServiceAlt, //ALTERNATE SEARCH SERVICE
    tbUtil,
    listsubjects, //for getting the subjects object
    trjurisFilter,
    trjurisrevFilter,
    trdoctyperevFilter,
    trstatusrevFilter
){
    //START SEARCH PERSISTENCE SECTION

    //assign the search object
    $scope.searchObject = JSON.parse(JSON.stringify(tbSearchServiceAlt.searchObject));

    console.log('nav controller init, search object check ',$scope.searchObject);
    //END SEARCH PERSISTENCE SECTION

    $scope.$on('refineSearchParams', function(event, value){
        console.log('received refine params event', value);
        if(value && value['searchwithin']){
            $scope.searchObject = JSON.parse(JSON.stringify(tbSearchServiceAlt.searchObject));
            //$scope.jurisbasic = 'All';
            //$scope.$broadcast('tbSubjectWidgetWipe');

            $scope.searchObject.searchwithin.title = value.searchwithin.title;
            $scope.searchObject.searchwithin.id = value.searchwithin.id;
            $scope.searchAdv.showAdv = true;
        }

        if(tbSearchServiceAlt.isSearchFormAdvanced()){
            $scope.searchAdv.showAdv = true;
        }

        $scope.advSearchSubjects = true;
        $scope.toggleNav('search');
    });


    //BEGIN SEARCH FORM SECTION
    $scope.scopeChange = function(input){
        if($scope.searchObject.scope != input){
            $scope.searchObject.scope = input;
        }else{
            $scope.searchObject.scope = "";
        }
    };

    $scope.searchPlaceholderText = "Enter terms for full text search or use restrict options...";

    $scope.modPlaceholderText = function(input){
        console.log("modPlaceholderText called!",input);
        switch(input){
            case "headings":
                $scope.searchPlaceholderText = "Enter terms to search all legislation titles and headings...";
                break;
            case "section-headings":
                $scope.searchPlaceholderText = "Enter terms to search section headings only...";
                break;
            case "title":
                $scope.searchPlaceholderText = "Enter terms to search legislation titles only...";
                break;
            default:
                $scope.searchPlaceholderText = "Enter terms for full text search or use restrict options...";
                break;
        }
    };

    // $scope.$watch('searchObject.scope', function(input){
    //     $scope.modPlaceholderText(input);
    // });

    $scope.principalChange = function(input){
        switch(input){
            case 'amending':
                if($scope.searchObject.principal == "false"){
                    $scope.searchObject.principal = null;
                }else if($scope.searchObject.principal == "true"){
                    $scope.searchObject.principal = "true,false";
                }else if($scope.searchObject.principal == "true,false"){
                    $scope.searchObject.principal = "true";
                }else if($scope.searchObject.principal == null){
                    $scope.searchObject.principal = "false";
                }
                break;
            case 'principal':
                if($scope.searchObject.principal == "true"){
                    $scope.searchObject.principal = null;
                }else if($scope.searchObject.principal == "false"){
                    $scope.searchObject.principal = "true,false";
                }else if($scope.searchObject.principal == "true,false"){
                    $scope.searchObject.principal = "false";
                }else if($scope.searchObject.principal == null){
                    $scope.searchObject.principal = "true";
                }
                break;
        }
    };

    $scope.deleteInput = function(stringModel){
        console.log(stringModel);
        console.log($scope[stringModel]);
        //stringModel = "";
    };

    //search submission stuff
    $scope.navEnterBasic = function(e){
        e.preventDefault();
        console.log(e);
        $scope.submitSearch('basic');
    };

    $scope.navEnterAdv = function(e){
        e.preventDefault();
        console.log(e);
        $scope.submitSearch('adv');
    };

    $scope.clearSearch = function(){
        tbSearchServiceAlt.newSearchObject();
        $scope.searchObject = JSON.parse(JSON.stringify(tbSearchServiceAlt.searchObject));
        $scope.jurisbasic = 'All';

        //$scope.wipeSubjects();
        $scope.$broadcast('tbSubjectWidgetWipe');
        $scope.advSearchSubjects = true;

//        if($state.includes('search')){
//            $state.go('home',{inherit: false, notify: true, reload: true});
//        }else if($state.includes('browse')){
//            $state.go($state.current, tbSearchServiceAlt.getStateParams(), {inherit: false, notify: true, reload: true});
//        }else if($state.includes('legislation')){
//            var params = tbSearchServiceAlt.getStateParams();
//            params['legId'] = $state.params['legId'];
//            params['contId'] = $state.params['contId'];
//            $state.go('legislation', params, {inherit: false, notify: true, reload: true});
//        }
    };

    var sanitiseSearchForm = function(obj){
        //strip act/ord
        if(!(obj['doctype']['act'] && obj['doctype']['ord'])){
            obj['doctype']['act'] = false;
            obj['doctype']['ord'] = false;
        }

        if(!(obj['doctype']['reg'] && obj['doctype']['cpn'] && obj['doctype']['prn'])){
            obj['doctype']['reg'] = false;
            obj['doctype']['cpn'] = false;
            obj['doctype']['prn'] = false;
        }
        if(!(obj['status']['rep'] && obj['status']['inop'])){
            obj['status']['rep'] = false;
            obj['status']['inop'] = false;
        }
        if(!(obj['status']['fail'] && obj['status']['nis'])){
            obj['status']['fail'] =false;
            obj['status']['nis'] = false;
        }
        return obj;
    };

    var directLegLink = function(){
        TbApi.all('search.json').getList(tbSearchServiceAlt.getSearchParams()).then(function(ret){
            console.log('SEARCH WITHIN RET', ret);
            if(ret && ret['data']['documents'] && ret['data']['documents'].length > 0){
                var legParams = tbUtil.legParamsClean(ret['data']['documents'][0]['_links']['content']['href']);

                if($state.includes('legislation') && $stateParams['legId'] && $stateParams['legId'] == legParams['legId']){
                    var tParams = tbSearchServiceAlt.getSearchParams();
                    tParams['legId'] = $stateParams['legId'];
                    tParams['contId'] = $stateParams['contId'];
                   $state.go('legislation', tParams, {reload: true, inherit: false});
                }else{
                    tbUtil.legLink(ret['data']['documents'][0]['_links']['content']['href']);
                }
            }else{
                alert("No results found. Alter your search parameters and try again.");
            }
        });
    };

    $scope.submitSearch = function(mode){
        if($scope.searchObject['term']){
            console.log("TEST search submit called: ", $scope.searchObject);
            var tempObject = {};

            if(mode == 'adv'){
                //$scope.searchObject.subject = $scope.trawl();
                tempObject = $scope.searchObject;
                tempObject.department = null;

            }else if(mode == 'basic'){
                tempObject = _.clone(tbSearchServiceAlt.defaultSearchObject, true);
                tempObject['term'] = $scope.searchObject['term'];
                tempObject['scope'] = $scope.searchObject['scope'];

                for (var sk in tempObject.jurisdiction){
                    if( sk == trjurisrevFilter($scope.jurisbasic)){
                        tempObject.jurisdiction[sk] = true;
                    }else{
                        tempObject.jurisdiction[sk] = false;
                    }
                }
            }

            tempObject = sanitiseSearchForm(tempObject);
            tempObject['page'] = 1;

            //user has selected a search within, let's treat them like the special snowflakes they are
            if($scope.searchObject.searchwithin.id && $scope.searchObject.searchwithin.title){
                tbSearchServiceAlt.setSearchObject(tempObject);
                //we now need to hit the search object without transition
                directLegLink();
                //and if there's any hits go to the first one
            }else if($scope.searchObject.searchwithin.id && ($scope.searchObject.searchwithin.title === "" || $scope.searchObject.searchwithin.title == null)){
                console.log("Search Within id present but no title, assuming delete ID because user probably doesn't care");
                $scope.searchObject.searchwithin.id = null;
                tbSearchServiceAlt.setSearchObject(tempObject);
                tbSearchServiceAlt.executeSearch(true);
            }else if($scope.searchObject.searchwithin.title && $scope.searchObject.searchwithin.id == null){
                console.log('Search Within title present but no ID, assuming first entry is intended entry');
                $scope.getTitles($scope.searchObject.searchwithin.title).then(function(ret){
                    tempObject['searchwithin']['title'] = ret[0]['title'];
                    tempObject['searchwithin']['id'] = ret[0]['legislation-id'];
                    tbSearchServiceAlt.setSearchObject(tempObject);
                    directLegLink();
                });
            }else{
                tbSearchServiceAlt.setSearchObject(tempObject);
                tbSearchServiceAlt.executeSearch(true);
            }
        }else{
            alert('You need to enter some search terms.');
        }
    };

    $scope.jurisbasictamper = false;
    $scope.flagJurisTamper = function(){
        if(!$scope.jurisbasictamper){
            $scope.jurisbasictamper = true;
        }
    };

    //looking for search-within
    if($scope.searchObject.searchwithin.id){
        TbApi.one('legislation/' + $scope.searchObject.searchwithin.id + '.json').get().then(
            function(ret){
                $scope.searchObject.searchwithin.title = ret['data']['legislation']['title'];
            }
        );
    }

    //this is for MANUAL TOGGLES and ON INIT ONLY
    $scope.changeMode = function(mode){
        $scope.advSearchSubjects = true;

        var counter = 0;
        _($scope.searchObject.jurisdiction).each(function(item){
            if(item){ counter++; }
        });

        switch(mode){
            case('basic'): //entering basic from advanced
                if(counter === 1){
                    for(var kb in $scope.searchObject.jurisdiction){
                        if($scope.searchObject.jurisdiction[kb]){
                            $scope.jurisbasic = trjurisFilter(kb);
                        }
                    }
                }else{
                    $scope.jurisbasic = "All";
                }

                $scope.searchAdv.showAdv = false;
                break;
            case('adv'): //entering advanced from basic
                if($scope.jurisbasictamper){
                    if($scope.jurisbasic == 'all' || $scope.jurisbasic == 'All'){
                        for (var k1 in $scope.searchObject.jurisdiction){
                            $scope.searchObject.jurisdiction[k1] = false;
                        }
                    }else{
                        for (var key in $scope.searchObject.jurisdiction){
                            if(key == trjurisrevFilter($scope.jurisbasic)){
                                $scope.searchObject.jurisdiction[key] = true;
                            }else{
                                $scope.searchObject.jurisdiction[key] = false;
                            }
                        }
                    }
                }
                $scope.searchAdv.showAdv = true;
                break;
        }
    };

    var triggerChangeMode = function(){
        if(tbSearchServiceAlt.isSearchFormAdvanced()){
            $scope.changeMode('adv');
        }else{
            $scope.changeMode('basic');
        }
    };

    //this is to toggle WITHOUT PROCESSING on state changes
    $scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams){
        if(toState.name.indexOf('search') > -1 || toState.name.indexOf('legislation') > -1){
            $scope.searchObject = JSON.parse(JSON.stringify(tbSearchServiceAlt.searchObject));
            triggerChangeMode();
        }
    });

    $scope.$on('refineSearch', function(){
        triggerChangeMode();
    });

    //this fires ONCE, on controller initiation
    triggerChangeMode();

    $scope.$watchCollection(function () {
      return tbSearchServiceAlt.searchObject;
    }, function (newVal, oldVal) {
      console.log('NAVIGATION SEARCH OBJECT WATCHER - CHANGE DETECTED', oldVal, newVal);
      if (oldVal != newVal) {
        $scope.searchObject = tbSearchServiceAlt.searchObject;
      }
    });

    //END SEARCH FORM SECTION

    //-----------------------------------------------------------
    //TYPEAHEAD SECTION STARTS
    $scope.typeaheadSelect = function(input){
        console.log("typeahead selected object", input);
        $scope.searchObject.searchwithin.title = input['title'];
        $scope.searchObject.searchwithin.id = input['legislation-id'];
    };

    //grab titles for typeahead
    $scope.getTitles = function(input){
        $scope.loadingLocations = true;

        console.log('navigation getTitles fired', input, $scope.searchObject);

        var params = tbSearchServiceAlt.getSearchParams($scope.searchObject);
        params['term'] = input;
        params['scope'] = 'title';
        params['count'] = 15;
        delete params['within'];

        // if(params['term'].charAt(params['term'].length - 1) != " "){
        //     params['term'] += "*";
        // }

        // return TbApi.all('search.json').getList(params).then(function(res){
        //     //console.log(res['data']['documents']);
        //     $scope.loadingLocations = false;
        //     return res['data']['documents'];
        // });

        return TbApi.all('lookup/legislation.json').getList(params).then(function(res){
            $scope.loadingLocations = false;
            console.log('returning typeahead',res['legislation']);

            var ret = [];

            for(var i = 0; i < res['legislation'].length - 1; i++){
                ret.push({
                    'legislation-id': res['legislation'][i]['id'],
                    'title': res['legislation'][i]['title'],
                    'content-id': res['legislation'][i]['content-id'],
                    'number' : res['legislation'][i]['number'],
                    'jurisdiction' : res['legislation'][i]['jurisdiction'],
                    'legislative-status' : res['legislation'][i]['legislative-status'],
                    'year' : res['legislation'][i] ['year']
                });
            }

            console.log('FFFFF', ret);
            return ret;
            //return res['legislation'];
        });
    };
    //TYPEAHEAD SECTION ENDS

    //PARSING / SUBMISSION FUNCTIONS
    //$scope.subjectslist = TbApi.all('subjects.json').getList().$object;
    $scope.subjectCounter = 0;
    //END SUBJECT SELECTION SECTION

    //graphical interface variables and functions below this line
    $scope.advSearchSubjects = true;

    $scope.savedSearchModal = function(){
        if(tbUserService.getUserObject() && !tbUserService.isUserIndividual()){
            tbUserService.showShareBlockModal();
        }else{
            var modalInstance = $modal.open({
               templateUrl: 'navigation/modalsavedsearch.tpl.html',
               controller:  'NavSavedSearchCtrl'
            });

            modalInstance.result.then(function(ret){
                console.log('SAVED SEARCH SELECTED',ret);

                //clone the search object
                var tempObject = _.clone(tbSearchServiceAlt.defaultSearchObject, true);

                //assign terms - implement rest later
                tempObject['term'] = ret['term'];
                if(ret['jurisdiction']){
                    ret['jurisdiction'].split(',').map(function(item){
                        tempObject['jurisdiction'][item] = true;
                    });
                }
                if(ret['doc-type']){
                    ret['doc-type'].split(',').map(function(item){
                        tempObject['doctype'][item] = true;
                    });
                }
                if(ret['status']){
                    ret['status'].split(',').map(function(item){
                        tempObject['status'][item] = true;
                    });
                }
                tempObject['subject'] = ret['subject'];
                tempObject['department'] = ret['department'];
                tempObject['year'] = ret['year'];
                tempObject['number'] = ret['number'];
                tempObject['start'] = ret['start'];
                tempObject['modifier'] = 'boolean';
                tempObject['sort'] = ret['sort'];
                tempObject['principal'] = ret['principal'];
                tempObject['scope'] = ret['scope'];

                if(ret['within']){
                    tempObject['searchwithin'] = {"id":ret['within']};

                    TbApi.one('legislation/' + ret['within'] + ".json").get().then(function(ret){
                        tempObject['searchwithin']['title'] = ret['data']['legislation']['title'];

                        tbSearchServiceAlt.setSearchObject(tempObject);
                        console.log('set before go',tbSearchServiceAlt.searchObject);
                        tbSearchServiceAlt.executeSearch();
                    });
                }else{
                    //set and execute search
                    tbSearchServiceAlt.setSearchObject(tempObject);
                    console.log('set before go',tbSearchServiceAlt.searchObject);
                    tbSearchServiceAlt.executeSearch();
                }
            });
        }
    };

    $scope.recentSearchModal = function(){
        var modalInstance = $modal.open({
           templateUrl: 'navigation/modalrecentsearch.tpl.html',
           controller:  'NavRecentSearchCtrl'
        });

        modalInstance.result.then(function(ret){
            console.log('RECENT SEARCH SELECTED',ret);

            //clone the search object
            var tempObject = _.clone(tbSearchServiceAlt.defaultSearchObject, true);

            //assign terms - implement rest later
            tempObject['term'] = ret['search']['term'];
            tempObject['jurisdiction'] = ret['search']['jurisdiction'];
            tempObject['doctype'] = ret['search']['doctype'];
            tempObject['status'] = ret['search']['status'];
            tempObject['subject'] = ret['search']['subject'];
            tempObject['department'] = ret['search']['department'];
            tempObject['year'] = ret['search']['year'];
            tempObject['number'] = ret['search']['number'];
            tempObject['start'] = ret['search']['start'];
            tempObject['modifier'] = ret['search']['modifier'];
            tempObject['sort'] = ret['search']['sort'];
            tempObject['principal'] = ret['search']['principal'];
            tempObject['scope'] = ret['search']['scope'];
            tempObject['searchwithin'] = ret['search']['searchwithin'];

            //set and execute search
            tbSearchServiceAlt.setSearchObject(tempObject);
            tbSearchServiceAlt.executeSearch();
        });
    };

    $scope.jurisdictions = [
        "All",
        "Commonwealth",
        "New South Wales",
        "Australian Capital Territory",
        "Northern Territory",
        "Queensland",
        "South Australia",
        "Tasmania",
        "Victoria",
        "Western Australia"
    ];
})

.controller( 'NavSavedSearchCtrl', function NavSavedSearchController($scope, $modalInstance, tbSavedSearchService, TbApi){
    $scope.savedsearch = {};

    tbSavedSearchService.getSavedSearches().then(function(ret){
        console.log('search service',ret);
        $scope.savedsearch.searches = ret['data']['searches'];
    });

    // if(tbSavedSearchService.getSavedSearches()){
    //     $scope.savedsearch.searches = tbSavedSearchService.getSavedSearches();
    //     $scope.savedsearch.selected = {};
    // }

    $scope.ok = function () {
        //console.log($scope.savedsearch.selected);
        $modalInstance.close($scope.savedsearch.selected);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})

.controller( 'NavRecentSearchCtrl', function NavRecentSearchController($scope, $modalInstance, tbSavedSearchService){
    $scope.savedsearch = {};

    if(tbSavedSearchService.getRecentSearches()){
        $scope.savedsearch.searches = tbSavedSearchService.getRecentSearches().slice().reverse();
        $scope.savedsearch.selected = {};
    }

    $scope.ok = function () {
        //console.log($scope.savedsearch.selected);
        $modalInstance.close($scope.savedsearch.selected);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})

.controller( 'NavFooterCtrl', function NavFooterController($scope, $window){
    $scope.$window = $window;
    $scope.footerCollapse = true;

//    $scope.toggleFooter = function(){
//        if($scope.footerCollapse === true){
//            //fire up the click-outside listener
//            $scope.$window.onclick = function(event){
//                closeFooterElsewhere(event, $scope.toggleFooter);
//            };
//        }
//
//        $scope.footerCollapse = !$scope.footerCollapse;
//    };
//
//    //for listening to clicks in the mainport
//    function closeFooterElsewhere(event, callbackOnClose){
//        //did we click in the mainport?
//        console.log(event);
//        if(($(event.target).closest('.footer').length > 0) || $scope.footerCollapse === true){
//            return;
//        }else{
//            callbackOnClose();
//            $scope.$apply();
//            return;
//        }
//    }
})

.controller( 'NavBrowseCtrl', function NavSearchController($scope){
    $scope.today = new Date();
    var yearString = '&year=' + $scope.today.getFullYear();

    $scope.tabs = [
        {
            "active": true,
            "title": "CTH",
            "hover": "Commonwealth &lt;/br&gt; Last Government Gazette received: Last Gazette Notice Reported CC2014G00625 (15 April 2014). &lt;/br&gt; Acts up to: 27/2014. &lt;/br&gt; Regulations up to: 42/2014.",
            "columns": [
                {
                  "name": "Legislation",
                  "hover": "legislation",
                  "help": {
                    "col1title": "Browse legislation",
                    "col1text": "Legislation includes Acts, Ordinances, Regulations.",
                    "col2title": "Applies to",
                    "col2text": "Acts (and Ordinances). Regulations (Subordinate legislation)."
                  },
                  "links": [
                    {
                      "title": "Acts",
                      "params": {
                        "juris": "cth",
                        "doc-type": "act",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "cth",
                            "doc-type": "act",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "cth",
                            "doc-type": "act",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "Regulations",
                      "params": {
                        "juris": "cth",
                        "doc-type": "reg",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "cth",
                            "doc-type": "reg",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "cth",
                            "doc-type": "reg",
                            "status": "rep"
                          }
                        }
                      ]

                    },
                    {
                      "title": "Aged Care Principles",
                      "params": {
                        "juris": "cth",
                        "doc-type": "prn",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "cth",
                            "doc-type": "prn",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "cth",
                            "doc-type": "prn",
                            "status": "rep"
                          }
                        }
                      ]

                    },
                    {
                      "title": "Consumer Protection Notices",
                      "params": {
                        "juris": "cth",
                        "doc-type": "cpn"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "cth",
                            "doc-type": "cpn",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "cth",
                            "doc-type": "cpn",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "By Subject",
                      "params": {
                        "juris": "cth",
                        "subject": true,
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "cth",
                            "status": "cur",
                            "subject": true
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "cth",
                            "status": "rep",
                            "subject": true
                          }
                        }
                      ]

                    }
                  ]
                },
                {
                    "name": "Legislative information",
                    "links": [
                        {
                          "title": "Notification & Commencement Tables",
                          "links": [
                            {
                              "title": "Acts",
                              "href": "/commencement?juris=cth&status=cur,rep&doctype=act,ord" + yearString,
                            },
                            {
                              "title": "Regulations",
                              "href": "/commencement?juris=cth&status=cur,rep&doctype=reg" + yearString
                            }
                          ]
                        },
                        {
                            "title": "Responsible Departments",
                            "href": "/departments/cth"
                        },
                        {
                            "title": "Parliamentary Sitting Dates",
                            "href": "/calendar?juris=cth"
                        }
                    ]
                },
                {
                    "name": "Bills",
                    "hover": "Browse Bills",
                    "help": {
                        "col1title": "Browse bills",
                        "col1text": "Proposed laws that have been introduced to a parliament are known as Bills. Bills have to be passed by a parliament and assented to before they can become an Act.",
                        "col2title": "Applies to",
                        "col2text": "Draft, Awaiting Assent."
                    },
                    "links": [
                        {
                            "title": "All",
                            "params": {
                                "juris": "cth",
                                "doc-type": "bill",
                                "status" : "all"
                            }
                        },
                        {
                            "title": "Awaiting Assent",
                            "params": {
                                "juris": "cth",
                                "doc-type": "bill",
                                "status": "aws"
                            }
                        },
                        {
                            "title": "Current",
                            "params": {
                                "juris": "cth",
                                "doc-type": "bill",
                                "status": "cur"
                            }
                        },
                        {
                            "title": "Draft",
                            "params": {
                                "juris": "cth",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Assented",
                            "params": {
                                "juris": "cth",
                                "doc-type": "bill",
                                "status": "ass"
                            }
                        },
                        {
                            "title": "Not in current session",
                            "params": {
                                "juris": "cth",
                                "doc-type": "bill",
                                "status": "nis"
                            }
                        },
                        {
                            "title": "Failed",
                            "params": {
                                "juris": "cth",
                                "doc-type": "bill",
                                "status": "fail"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "cth",
                                "doc-type": "bill",
                                "subject": true
                            }
                        }
                    ]
                },
                {
                    "name": "Draft Legislation",
                    "hover": "Browse Draft legislation",
                    "help": {
                        "col1title": "Browse draft legislation",
                        "col1text": "Draft legislation is a proposal for a new law that has been drafted but is yet to be presented to a parliament as a bill.",
                        "col2title": "Applies to",
                        "col2text": "Draft bills, Draft regulations."
                    },
                    "links": [
                        {
                            "title": "Bills",
                            "params": {
                                "juris": "cth",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Regulations",
                            "params": {
                                "juris": "cth",
                                "doc-type": "reg",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "cth",
                                "status": "dra",
                                "subject": true
                            }
                        }
                    ]
                }
            ]
        },
        {
            "title": "ACT",
            "hover": "Australian Capital Territory",
            "columns": [
                {
                  "name": "Legislation",
                  "hover": "legislation",
                  "help": {
                    "col1title": "Browse legislation",
                    "col1text": "Legislation includes Acts, Ordinances, Regulations.",
                    "col2title": "Applies to",
                    "col2text": "Acts (and Ordinances). Regulations (Subordinate legislation)."
                  },
                  "links": [
                    {
                      "title": "Acts",
                      "params": {
                        "juris": "act",
                        "doc-type": "act",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "act",
                            "doc-type": "act",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "act",
                            "doc-type": "act",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "Regulations",
                      "params": {
                        "juris": "act",
                        "doc-type": "reg",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "act",
                            "doc-type": "reg",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "act",
                            "doc-type": "reg",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "By Subject",
                      "params": {
                        "juris": "act",
                        "subject": true,
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "act",
                            "status": "cur",
                            "subject": true
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "act",
                            "status": "rep",
                            "subject": true
                          }
                        }
                      ]

                    }
                  ]
                },
                {
                    "name": "Legislative information",
                    "links": [
                        {
                          "title": "Notification & Commencement Tables",
                          "links": [
                            {
                              "title": "Acts",
                              "href": "/commencement?juris=act&status=cur,rep&doctype=act,ord" + yearString,
                            },
                            {
                              "title": "Regulations",
                              "href": "/commencement?juris=act&status=cur,rep&doctype=reg" + yearString
                            }
                          ]
                        },
                        {
                            "title": "Responsible Departments",
                            "href": "/departments/act"
                        },
                        {
                            "title": "Parliamentary Sitting Dates",
                            "href": "/calendar?juris=act"
                        }
                    ]
                },
                {
                    "name": "Bills",
                    "hover": "Browse Bills",
                    "help": {
                        "col1title": "Browse bills",
                        "col1text": "Proposed laws that have been introduced to a parliament are known as Bills. Bills have to be passed by a parliament and assented to before they can become an Act.",
                        "col2title": "Applies to",
                        "col2text": "Draft, Awaiting Assent."
                    },
                    "links": [
                        {
                            "title": "All",
                            "params": {
                                "juris": "act",
                                "doc-type": "bill",
                                "status" : "all"
                            }
                        },
                        {
                            "title": "Awaiting Assent",
                            "params": {
                                "juris": "act",
                                "doc-type": "bill",
                                "status": "aws"
                            }
                        },
                        {
                            "title": "Current",
                            "params": {
                                "juris": "act",
                                "doc-type": "bill",
                                "status": "cur"
                            }
                        },
                        {
                            "title": "Draft",
                            "params": {
                                "juris": "act",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Assented",
                            "params": {
                                "juris": "act",
                                "doc-type": "bill",
                                "status": "ass"
                            }
                        },
                        {
                            "title": "Not in current session",
                            "params": {
                                "juris": "act",
                                "doc-type": "bill",
                                "status": "nis"
                            }
                        },
                        {
                            "title": "Failed",
                            "params": {
                                "juris": "act",
                                "doc-type": "bill",
                                "status": "fail"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "act",
                                "doc-type": "bill",
                                "subject": true,
                                "status" : "all"
                            }
                        }
                    ]
                },
                {
                    "name": "Draft Legislation",
                    "hover": "Browse Draft legislation",
                    "help": {
                        "col1title": "Browse draft legislation",
                        "col1text": "Draft legislation is a proposal for a new law that has been drafted but is yet to be presented to a parliament as a bill.",
                        "col2title": "Applies to",
                        "col2text": "Draft bills, Draft regulations."
                    },
                    "links": [
                        {
                            "title": "Bills",
                            "params": {
                                "juris": "act",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Regulations",
                            "params": {
                                "juris": "act",
                                "doc-type": "reg",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "act",
                                "status": "dra",
                                "subject": true
                            }
                        }
                    ]
                }
            ]
        },
        {
            "title": "NSW",
            "hover": "New South Wales",
            "columns": [
                {
                  "name": "Legislation",
                  "hover": "legislation",
                  "help": {
                    "col1title": "Browse legislation",
                    "col1text": "Legislation includes Acts, Ordinances, Regulations.",
                    "col2title": "Applies to",
                    "col2text": "Acts (and Ordinances). Regulations (Subordinate legislation)."
                  },
                  "links": [
                    {
                      "title": "Acts",
                      "params": {
                        "juris": "nsw",
                        "doc-type": "act",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "nsw",
                            "doc-type": "act",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "nsw",
                            "doc-type": "act",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "Regulations",
                      "params": {
                        "juris": "nsw",
                        "doc-type": "reg",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "nsw",
                            "doc-type": "reg",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "nsw",
                            "doc-type": "reg",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "By Subject",
                      "params": {
                        "juris": "nsw",
                        "subject": true,
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "nsw",
                            "status": "cur",
                            "subject": true
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "nsw",
                            "status": "rep",
                            "subject": true
                          }
                        }
                      ]
                    }
                  ]
                },
                {
                    "name": "Legislative information",
                    "links": [
                        {
                          "title": "Notification & Commencement Tables",
                          "links": [
                            {
                              "title": "Acts",
                              "href": "/commencement?juris=nsw&status=cur,rep&doctype=act,ord" + yearString,
                            },
                            {
                              "title": "Regulations",
                              "href": "/commencement?juris=nsw&status=cur,rep&doctype=reg" + yearString
                            }
                          ]
                        },
                        {
                            "title": "Responsible Departments",
                            "href": "/departments/nsw"
                        },
                        {
                            "title": "Parliamentary Sitting Dates",
                            "href": "/calendar?juris=nsw"
                        }
                    ]
                },
                {
                    "name": "Bills",
                    "hover": "Browse Bills",
                    "help": {
                        "col1title": "Browse bills",
                        "col1text": "Proposed laws that have been introduced to a parliament are known as Bills. Bills have to be passed by a parliament and assented to before they can become an Act.",
                        "col2title": "Applies to",
                        "col2text": "Draft, Awaiting Assent."
                    },
                    "links": [
                        {
                            "title": "All",
                            "params": {
                                "juris": "nsw",
                                "doc-type": "bill",
                                "status" : "all"
                            }
                        },
                        {
                            "title": "Awaiting Assent",
                            "params": {
                                "juris": "nsw",
                                "doc-type": "bill",
                                "status": "aws"
                            }
                        },
                        {
                            "title": "Current",
                            "params": {
                                "juris": "nsw",
                                "doc-type": "bill",
                                "status": "cur"
                            }
                        },
                        {
                            "title": "Draft",
                            "params": {
                                "juris": "nsw",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Assented",
                            "params": {
                                "juris": "nsw",
                                "doc-type": "bill",
                                "status": "ass"
                            }
                        },
                        {
                            "title": "Not in current session",
                            "params": {
                                "juris": "nsw",
                                "doc-type": "bill",
                                "status": "nis"
                            }
                        },
                        {
                            "title": "Failed",
                            "params": {
                                "juris": "nsw",
                                "doc-type": "bill",
                                "status": "fail"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "nsw",
                                "doc-type": "bill",
                                "subject": true
                            }
                        }
                    ]
                },
                {
                    "name": "Draft Legislation",
                    "hover": "Browse Draft legislation",
                    "help": {
                        "col1title": "Browse draft legislation",
                        "col1text": "Draft legislation is a proposal for a new law that has been drafted but is yet to be presented to a parliament as a bill.",
                        "col2title": "Applies to",
                        "col2text": "Draft bills, Draft regulations."
                    },
                    "links": [
                        {
                            "title": "Bills",
                            "params": {
                                "juris": "nsw",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Regulations",
                            "params": {
                                "juris": "nsw",
                                "doc-type": "reg",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "nsw",
                                "status": "dra",
                                "subject": true
                            }
                        }
                    ]
                }
            ]
        },
        {
            "title": "NT",
            "hover": "Northern Territory",
            "columns": [
                {
                  "name": "Legislation",
                  "hover": "legislation",
                  "help": {
                    "col1title": "Browse legislation",
                    "col1text": "Legislation includes Acts, Ordinances, Regulations.",
                    "col2title": "Applies to",
                    "col2text": "Acts (and Ordinances). Regulations (Subordinate legislation)."
                  },
                  "links": [
                    {
                      "title": "Acts",
                      "params": {
                        "juris": "nt",
                        "doc-type": "act",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "nt",
                            "doc-type": "act",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "nt",
                            "doc-type": "act",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "Regulations",
                      "params": {
                        "juris": "nt",
                        "doc-type": "reg",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "nt",
                            "doc-type": "reg",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "nt",
                            "doc-type": "reg",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "By Subject",
                      "params": {
                        "juris": "nt",
                        "subject": true,
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "nt",
                            "status": "cur",
                            "subject": true
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "nt",
                            "status": "rep",
                            "subject": true
                          }
                        }
                      ]

                    }
                  ]
                },
                {
                    "name": "Legislative information",
                    "links": [
                        {
                          "title": "Notification & Commencement Tables",
                          "links": [
                            {
                              "title": "Acts",
                              "href": "/commencement?juris=nt&status=cur,rep&doctype=act,ord" + yearString,
                            },
                            {
                              "title": "Regulations",
                              "href": "/commencement?juris=nt&status=cur,rep&doctype=reg" + yearString
                            }
                          ]
                        },
                        {
                            "title": "Responsible Departments",
                            "href": "/departments/nt"
                        },
                        {
                            "title": "Parliamentary Sitting Dates",
                            "href": "/calendar?juris=nt"
                        }
                    ]
                },
                {
                    "name": "Bills",
                    "hover": "Browse Bills",
                    "help": {
                        "col1title": "Browse bills",
                        "col1text": "Proposed laws that have been introduced to a parliament are known as Bills. Bills have to be passed by a parliament and assented to before they can become an Act.",
                        "col2title": "Applies to",
                        "col2text": "Draft, Awaiting Assent."
                    },
                    "links": [
                        {
                            "title": "All",
                            "params": {
                                "juris": "nt",
                                "doc-type": "bill",
                                "status" : "all"
                            }
                        },
                        {
                            "title": "Awaiting Assent",
                            "params": {
                                "juris": "nt",
                                "doc-type": "bill",
                                "status": "aws"
                            }
                        },
                        {
                            "title": "Current",
                            "params": {
                                "juris": "nt",
                                "doc-type": "bill",
                                "status": "cur"
                            }
                        },
                        {
                            "title": "Draft",
                            "params": {
                                "juris": "nt",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Assented",
                            "params": {
                                "juris": "nt",
                                "doc-type": "bill",
                                "status": "ass"
                            }
                        },
                        {
                            "title": "Not in current session",
                            "params": {
                                "juris": "nt",
                                "doc-type": "bill",
                                "status": "nis"
                            }
                        },
                        {
                            "title": "Failed",
                            "params": {
                                "juris": "nt",
                                "doc-type": "bill",
                                "status": "fail"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "nt",
                                "doc-type": "bill",
                                "subject": true
                            }
                        }
                    ]
                },
                {
                    "name": "Draft Legislation",
                    "hover": "Browse Draft legislation",
                    "help": {
                        "col1title": "Browse draft legislation",
                        "col1text": "Draft legislation is a proposal for a new law that has been drafted but is yet to be presented to a parliament as a bill.",
                        "col2title": "Applies to",
                        "col2text": "Draft bills, Draft regulations."
                    },
                    "links": [
                        {
                            "title": "Bills",
                            "params": {
                                "juris": "nt",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Regulations",
                            "params": {
                                "juris": "nt",
                                "doc-type": "reg",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "nt",
                                "status": "dra",
                                "subject": true
                            }
                        }
                    ]
                }
            ]
        },
        {
            "title": "QLD",
            "hover": "Queensland",
            "columns": [
                {
                  "name": "Legislation",
                  "hover": "legislation",
                  "help": {
                    "col1title": "Browse legislation",
                    "col1text": "Legislation includes Acts, Ordinances, Regulations.",
                    "col2title": "Applies to",
                    "col2text": "Acts (and Ordinances). Regulations (Subordinate legislation)."
                  },
                  "links": [
                    {
                      "title": "Acts",
                      "params": {
                        "juris": "qld",
                        "doc-type": "act",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "qld",
                            "doc-type": "act",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "qld",
                            "doc-type": "act",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "Regulations",
                      "params": {
                        "juris": "qld",
                        "doc-type": "reg",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "qld",
                            "doc-type": "reg",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "qld",
                            "doc-type": "reg",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "By Subject",
                      "params": {
                        "juris": "qld",
                        "subject": true,
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "qld",
                            "status": "cur",
                            "subject": true
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "qld",
                            "status": "rep",
                            "subject": true
                          }
                        }
                      ]

                    }
                  ]
                },
                {
                    "name": "Legislative information",
                    "links": [
                        {
                          "title": "Notification & Commencement Tables",
                          "links": [
                            {
                              "title": "Acts",
                              "href": "/commencement?juris=qld&status=cur,rep&doctype=act,ord" + yearString,
                            },
                            {
                              "title": "Regulations",
                              "href": "/commencement?juris=qld&status=cur,rep&doctype=reg" + yearString
                            }
                          ]
                        },
                        {
                            "title": "Responsible Departments",
                            "href": "/departments/qld"
                        },
                        {
                            "title": "Parliamentary Sitting Dates",
                            "href": "/calendar?juris=qld"
                        }
                    ]
                },
                {
                    "name": "Bills",
                    "hover": "Browse Bills",
                    "help": {
                        "col1title": "Browse bills",
                        "col1text": "Proposed laws that have been introduced to a parliament are known as Bills. Bills have to be passed by a parliament and assented to before they can become an Act.",
                        "col2title": "Applies to",
                        "col2text": "Draft, Awaiting Assent."
                    },
                    "links": [
                        {
                            "title": "All",
                            "params": {
                                "juris": "qld",
                                "doc-type": "bill",
                                "status" : "all"
                            }
                        },
                        {
                            "title": "Awaiting Assent",
                            "params": {
                                "juris": "qld",
                                "doc-type": "bill",
                                "status": "aws"
                            }
                        },
                        {
                            "title": "Current",
                            "params": {
                                "juris": "qld",
                                "doc-type": "bill",
                                "status": "cur"
                            }
                        },
                        {
                            "title": "Draft",
                            "params": {
                                "juris": "qld",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Assented",
                            "params": {
                                "juris": "qld",
                                "doc-type": "bill",
                                "status": "ass"
                            }
                        },
                        {
                            "title": "Not in current session",
                            "params": {
                                "juris": "qld",
                                "doc-type": "bill",
                                "status": "nis"
                            }
                        },
                        {
                            "title": "Failed",
                            "params": {
                                "juris": "qld",
                                "doc-type": "bill",
                                "status": "fail"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "qld",
                                "doc-type": "bill",
                                "subject": true,
                                "status" : "all"
                            }
                        }
                    ]
                },
                {
                    "name": "Draft Legislation",
                    "hover": "Browse Draft legislation",
                    "help": {
                        "col1title": "Browse draft legislation",
                        "col1text": "Draft legislation is a proposal for a new law that has been drafted but is yet to be presented to a parliament as a bill.",
                        "col2title": "Applies to",
                        "col2text": "Draft bills, Draft regulations."
                    },
                    "links": [
                        {
                            "title": "Bills",
                            "params": {
                                "juris": "qld",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Regulations",
                            "params": {
                                "juris": "qld",
                                "doc-type": "reg",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "qld",
                                "status": "dra",
                                "subject": true
                            }
                        }
                    ]
                }
            ]
        },
        {
            "title": "SA",
            "hover": "South Australia",
            "columns": [
                {
                  "name": "Legislation",
                  "hover": "legislation",
                  "help": {
                    "col1title": "Browse legislation",
                    "col1text": "Legislation includes Acts, Ordinances, Regulations.",
                    "col2title": "Applies to",
                    "col2text": "Acts (and Ordinances). Regulations (Subordinate legislation)."
                  },
                  "links": [
                    {
                      "title": "Acts",
                      "params": {
                        "juris": "sa",
                        "doc-type": "act",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "sa",
                            "doc-type": "act",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "sa",
                            "doc-type": "act",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "Regulations",
                      "params": {
                        "juris": "sa",
                        "doc-type": "reg",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "sa",
                            "doc-type": "reg",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "sa",
                            "doc-type": "reg",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "By Subject",
                      "params": {
                        "juris": "sa",
                        "subject": true,
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "sa",
                            "status": "cur",
                            "subject": true
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "sa",
                            "status": "rep",
                            "subject": true
                          }
                        }
                      ]

                    }
                  ]
                },
                {
                    "name": "Legislative information",
                    "links": [
                        {
                          "title": "Notification & Commencement Tables",
                          "links": [
                            {
                              "title": "Acts",
                              "href": "/commencement?juris=sa&status=cur,rep&doctype=act,ord" + yearString,
                            },
                            {
                              "title": "Regulations",
                              "href": "/commencement?juris=sa&status=cur,rep&doctype=reg" + yearString
                            }
                          ]
                        },
                        {
                            "title": "Responsible Departments",
                            "href": "/departments/sa"
                        },
                        {
                            "title": "Parliamentary Sitting Dates",
                            "href": "/calendar?juris=sa"
                        }
                    ]
                },
                {
                    "name": "Bills",
                    "hover": "Browse Bills",
                    "help": {
                        "col1title": "Browse bills",
                        "col1text": "Proposed laws that have been introduced to a parliament are known as Bills. Bills have to be passed by a parliament and assented to before they can become an Act.",
                        "col2title": "Applies to",
                        "col2text": "Draft, Awaiting Assent."
                    },
                    "links": [
                        {
                            "title": "All",
                            "params": {
                                "juris": "sa",
                                "doc-type": "bill",
                                "status" : "all"
                            }
                        },
                        {
                            "title": "Awaiting Assent",
                            "params": {
                                "juris": "sa",
                                "doc-type": "bill",
                                "status": "aws"
                            }
                        },
                        {
                            "title": "Current",
                            "params": {
                                "juris": "sa",
                                "doc-type": "bill",
                                "status": "cur"
                            }
                        },
                        {
                            "title": "Draft",
                            "params": {
                                "juris": "sa",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Assented",
                            "params": {
                                "juris": "sa",
                                "doc-type": "bill",
                                "status": "ass"
                            }
                        },
                        {
                            "title": "Not in current session",
                            "params": {
                                "juris": "sa",
                                "doc-type": "bill",
                                "status": "nis"
                            }
                        },
                        {
                            "title": "Failed",
                            "params": {
                                "juris": "sa",
                                "doc-type": "bill",
                                "status": "fail"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "sa",
                                "doc-type": "bill",
                                "subject": true,
                                "status" : "all"
                            }
                        }
                    ]
                },
                {
                    "name": "Draft Legislation",
                    "hover": "Browse Draft legislation",
                    "help": {
                        "col1title": "Browse draft legislation",
                        "col1text": "Draft legislation is a proposal for a new law that has been drafted but is yet to be presented to a parliament as a bill.",
                        "col2title": "Applies to",
                        "col2text": "Draft bills, Draft regulations."
                    },
                    "links": [
                        {
                            "title": "Bills",
                            "params": {
                                "juris": "sa",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Regulations",
                            "params": {
                                "juris": "sa",
                                "doc-type": "reg",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "sa",
                                "status": "dra",
                                "subject": true
                            }
                        }
                    ]
                }
            ]
        },
        {
            "title": "TAS",
            "hover": "Tasmania",
            "columns": [
                {
                  "name": "Legislation",
                  "hover": "legislation",
                  "help": {
                    "col1title": "Browse legislation",
                    "col1text": "Legislation includes Acts, Ordinances, Regulations.",
                    "col2title": "Applies to",
                    "col2text": "Acts (and Ordinances). Regulations (Subordinate legislation)."
                  },
                  "links": [
                    {
                      "title": "Acts",
                      "params": {
                        "juris": "tas",
                        "doc-type": "act",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "tas",
                            "doc-type": "act",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "tas",
                            "doc-type": "act",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "Regulations",
                      "params": {
                        "juris": "tas",
                        "doc-type": "reg",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "tas",
                            "doc-type": "reg",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "tas",
                            "doc-type": "reg",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "By Subject",
                      "params": {
                        "juris": "tas",
                        "subject": true,
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "tas",
                            "status": "cur",
                            "subject": true
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "tas",
                            "status": "rep",
                            "subject": true
                          }
                        }
                      ]

                    }
                  ]
                },
                {
                    "name": "Legislative information",
                    "links": [
                        {
                          "title": "Notification & Commencement Tables",
                          "links": [
                            {
                              "title": "Acts",
                              "href": "/commencement?juris=tas&status=cur,rep&doctype=act,ord" + yearString,
                            },
                            {
                              "title": "Regulations",
                              "href": "/commencement?juris=tas&status=cur,rep&doctype=reg" + yearString
                            }
                          ]
                        },
                        {
                            "title": "Responsible Departments",
                            "href": "/departments/tas"
                        },
                        {
                            "title": "Parliamentary Sitting Dates",
                            "href": "/calendar?juris=tas"
                        }
                    ]
                },
                {
                    "name": "Bills",
                    "hover": "Browse Bills",
                    "help": {
                        "col1title": "Browse bills",
                        "col1text": "Proposed laws that have been introduced to a parliament are known as Bills. Bills have to be passed by a parliament and assented to before they can become an Act.",
                        "col2title": "Applies to",
                        "col2text": "Draft, Awaiting Assent."
                    },
                    "links": [
                        {
                            "title": "All",
                            "params": {
                                "juris": "tas",
                                "doc-type": "bill",
                                "status" : "all"
                            }
                        },
                        {
                            "title": "Awaiting Assent",
                            "params": {
                                "juris": "tas",
                                "doc-type": "bill",
                                "status": "aws"
                            }
                        },
                        {
                            "title": "Current",
                            "params": {
                                "juris": "tas",
                                "doc-type": "bill",
                                "status": "cur"
                            }
                        },
                        {
                            "title": "Draft",
                            "params": {
                                "juris": "tas",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Assented",
                            "params": {
                                "juris": "tas",
                                "doc-type": "bill",
                                "status": "ass"
                            }
                        },
                        {
                            "title": "Not in current session",
                            "params": {
                                "juris": "tas",
                                "doc-type": "bill",
                                "status": "nis"
                            }
                        },
                        {
                            "title": "Failed",
                            "params": {
                                "juris": "tas",
                                "doc-type": "bill",
                                "status": "fail"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "tas",
                                "doc-type": "bill",
                                "subject": true,
                                "status" : "all"
                            }
                        }
                    ]
                },
                {
                    "name": "Draft Legislation",
                    "hover": "Browse Draft legislation",
                    "help": {
                        "col1title": "Browse draft legislation",
                        "col1text": "Draft legislation is a proposal for a new law that has been drafted but is yet to be presented to a parliament as a bill.",
                        "col2title": "Applies to",
                        "col2text": "Draft bills, Draft regulations."
                    },
                    "links": [
                        {
                            "title": "Bills",
                            "params": {
                                "juris": "tas",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Regulations",
                            "params": {
                                "juris": "tas",
                                "doc-type": "reg",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "tas",
                                "status": "dra",
                                "subject": true
                            }
                        }
                    ]
                }
            ]
        },
        {
            "title": "VIC",
            "hover": "Victoria",
            "columns": [
                {
                  "name": "Legislation",
                  "hover": "legislation",
                  "help": {
                    "col1title": "Browse legislation",
                    "col1text": "Legislation includes Acts, Ordinances, Regulations.",
                    "col2title": "Applies to",
                    "col2text": "Acts (and Ordinances). Regulations (Subordinate legislation)."
                  },
                  "links": [
                    {
                      "title": "Acts",
                      "params": {
                        "juris": "vic",
                        "doc-type": "act",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "vic",
                            "doc-type": "act",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "vic",
                            "doc-type": "act",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "Regulations",
                      "params": {
                        "juris": "vic",
                        "doc-type": "reg",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "vic",
                            "doc-type": "reg",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "vic",
                            "doc-type": "reg",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "By Subject",
                      "params": {
                        "juris": "vic",
                        "subject": true,
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "vic",
                            "status": "cur",
                            "subject": true
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "vic",
                            "status": "rep",
                            "subject": true
                          }
                        }
                      ]

                    }
                  ]
                },
                {
                    "name": "Legislative information",
                    "links": [
                        {
                          "title": "Notification & Commencement Tables",
                          "links": [
                            {
                              "title": "Acts",
                              "href": "/commencement?juris=vic&status=cur,rep&doctype=act,ord" + yearString,
                            },
                            {
                              "title": "Regulations",
                              "href": "/commencement?juris=vic&status=cur,rep&doctype=reg" + yearString
                            }
                          ]
                        },
                        {
                            "title": "Responsible Departments",
                            "href": "/departments/vic"
                        },
                        {
                            "title": "Parliamentary Sitting Dates",
                            "href": "/calendar?juris=vic"
                        }
                    ]
                },
                {
                    "name": "Bills",
                    "hover": "Browse Bills",
                    "help": {
                        "col1title": "Browse bills",
                        "col1text": "Proposed laws that have been introduced to a parliament are known as Bills. Bills have to be passed by a parliament and assented to before they can become an Act.",
                        "col2title": "Applies to",
                        "col2text": "Draft, Awaiting Assent."
                    },
                    "links": [
                        {
                            "title": "All",
                            "params": {
                                "juris": "vic",
                                "doc-type": "bill",
                                "status" : "all"
                            }
                        },
                        {
                            "title": "Awaiting Assent",
                            "params": {
                                "juris": "vic",
                                "doc-type": "bill",
                                "status": "aws"
                            }
                        },
                        {
                            "title": "Current",
                            "params": {
                                "juris": "vic",
                                "doc-type": "bill",
                                "status": "cur"
                            }
                        },
                        {
                            "title": "Draft",
                            "params": {
                                "juris": "vic",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Assented",
                            "params": {
                                "juris": "vic",
                                "doc-type": "bill",
                                "status": "ass"
                            }
                        },
                        {
                            "title": "Not in current session",
                            "params": {
                                "juris": "vic",
                                "doc-type": "bill",
                                "status": "nis"
                            }
                        },
                        {
                            "title": "Failed",
                            "params": {
                                "juris": "vic",
                                "doc-type": "bill",
                                "status": "fail"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "vic",
                                "doc-type": "bill",
                                "subject": true,
                                "status" : "all"
                            }
                        }
                    ]
                },
                {
                    "name": "Draft Legislation",
                    "hover": "Browse Draft legislation",
                    "help": {
                        "col1title": "Browse draft legislation",
                        "col1text": "Draft legislation is a proposal for a new law that has been drafted but is yet to be presented to a parliament as a bill.",
                        "col2title": "Applies to",
                        "col2text": "Draft bills, Draft regulations."
                    },
                    "links": [
                        {
                            "title": "Bills",
                            "params": {
                                "juris": "vic",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Regulations",
                            "params": {
                                "juris": "vic",
                                "doc-type": "reg",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "vic",
                                "status": "dra",
                                "subject": true
                            }
                        }
                    ]
                }
            ]
        },
        {
            "title": "WA",
            "hover": "Western Australia",
            "columns": [
                {
                  "name": "Legislation",
                  "hover": "legislation",
                  "help": {
                    "col1title": "Browse legislation",
                    "col1text": "Legislation includes Acts, Ordinances, Regulations.",
                    "col2title": "Applies to",
                    "col2text": "Acts (and Ordinances). Regulations (Subordinate legislation)."
                  },
                  "links": [
                    {
                      "title": "Acts",
                      "params": {
                        "juris": "wa",
                        "doc-type": "act",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "wa",
                            "doc-type": "act",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "wa",
                            "doc-type": "act",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "Regulations",
                      "params": {
                        "juris": "wa",
                        "doc-type": "reg",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "wa",
                            "doc-type": "reg",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "wa",
                            "doc-type": "reg",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "By Subject",
                      "params": {
                        "juris": "wa",
                        "subject": true,
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "wa",
                            "status": "cur",
                            "subject": true
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "wa",
                            "status": "rep",
                            "subject": true
                          }
                        }
                      ]

                    }
                  ]
                },
                {
                    "name": "Legislative information",
                    "links": [
                        {
                          "title": "Notification & Commencement Tables",
                          "links": [
                            {
                              "title": "Acts",
                              "href": "/commencement?juris=wa&status=cur,rep&doctype=act,ord" + yearString,
                            },
                            {
                              "title": "Regulations",
                              "href": "/commencement?juris=wa&status=cur,rep&doctype=reg" + yearString
                            }
                          ]
                        },
                        {
                            "title": "Responsible Departments",
                            "href": "/departments/wa"
                        },
                        {
                            "title": "Parliamentary Sitting Dates",
                            "href": "/calendar?juris=wa"
                        }
                    ]
                },
                {
                    "name": "Bills",
                    "hover": "Browse Bills",
                    "help": {
                        "col1title": "Browse bills",
                        "col1text": "Proposed laws that have been introduced to a parliament are known as Bills. Bills have to be passed by a parliament and assented to before they can become an Act.",
                        "col2title": "Applies to",
                        "col2text": "Draft, Awaiting Assent."
                    },
                    "links": [
                        {
                            "title": "All",
                            "params": {
                                "juris": "wa",
                                "doc-type": "bill",
                                "status" : "all"
                            }
                        },
                        {
                            "title": "Awaiting Assent",
                            "params": {
                                "juris": "wa",
                                "doc-type": "bill",
                                "status": "aws"
                            }
                        },
                        {
                            "title": "Current",
                            "params": {
                                "juris": "wa",
                                "doc-type": "bill",
                                "status": "cur"
                            }
                        },
                        {
                            "title": "Draft",
                            "params": {
                                "juris": "wa",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Assented",
                            "params": {
                                "juris": "wa",
                                "doc-type": "bill",
                                "status": "ass"
                            }
                        },
                        {
                            "title": "Not in current session",
                            "params": {
                                "juris": "wa",
                                "doc-type": "bill",
                                "status": "nis"
                            }
                        },
                        {
                            "title": "Failed",
                            "params": {
                                "juris": "wa",
                                "doc-type": "bill",
                                "status": "fail"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "wa",
                                "doc-type": "bill",
                                "subject": true,
                                "status" : "all"
                            }
                        }
                    ]
                },
                {
                    "name": "Draft Legislation",
                    "hover": "Browse Draft legislation",
                    "help": {
                        "col1title": "Browse draft legislation",
                        "col1text": "Draft legislation is a proposal for a new law that has been drafted but is yet to be presented to a parliament as a bill.",
                        "col2title": "Applies to",
                        "col2text": "Draft bills, Draft regulations."
                    },
                    "links": [
                        {
                            "title": "Bills",
                            "params": {
                                "juris": "wa",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Regulations",
                            "params": {
                                "juris": "wa",
                                "doc-type": "reg",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "wa",
                                "status": "dra",
                                "subject": true
                            }
                        }
                    ]
                }
            ]
        },
        {
            "title": "ALL",
            "hover": "All Jurisdictions &lt;/br&gt; Last Government Gazette received: Last Gazette Notice Reported CC2014G00625 (15 April 2014). &lt;/br&gt; Acts up to: 27/2014. &lt;/br&gt; Regulations up to: 42/2014.",
            "columns": [
                {
                  "name": "Legislation",
                  "hover": "legislation",
                  "help": {
                    "col1title": "Browse legislation",
                    "col1text": "Legislation includes Acts, Ordinances, Regulations, Aged Care Principles and Consumer Protection Notices.",
                    "col2title": "Applies to",
                    "col2text": "Acts (and Ordinances). Regulations (Subordinate legislation)."
                  },
                  "links": [
                    {
                      "title": "Acts",
                      "params": {
                        "juris": "all",
                        "doc-type": "act",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "all",
                            "doc-type": "act",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "all",
                            "doc-type": "act",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "Regulations",
                      "params": {
                        "juris": "all",
                        "doc-type": "reg",
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "all",
                            "doc-type": "reg",
                            "status": "cur"
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "all",
                            "doc-type": "reg",
                            "status": "rep"
                          }
                        }
                      ]
                    },
                    {
                      "title": "By Subject",
                      "params": {
                        "juris": "all",
                        "subject": true,
                        "status" : "all"
                      },
                      "links": [
                        {
                          "title": "Current",
                          "params": {
                            "juris": "all",
                            "status": "cur",
                            "subject": true
                          }
                        },
                        {
                          "title": "Repealed",
                          "params": {
                            "juris": "all",
                            "status": "rep",
                            "subject": true
                          }
                        }
                      ]

                    }
                  ]
                },
                {
                    "name": "Legislative information",
                    "links": [
                        {
                            "title": "Parliamentary Sitting Dates",
                            "href": "/calendar?juris=all"
                        }
                    ]
                },
                {
                    "name": "Bills",
                    "hover": "Browse Bills",
                    "help": {
                        "col1title": "Browse bills",
                        "col1text": "Proposed laws that have been introduced to a parliament are known as Bills. Bills have to be passed by a parliament and assented to before they can become an Act.",
                        "col2title": "Applies to",
                        "col2text": "Draft, Awaiting Assent."
                    },
                    "links": [
                        {
                            "title": "All",
                            "params": {
                                "juris": "all",
                                "doc-type": "bill",
                                "status" : "all"
                            }
                        },
                        {
                            "title": "Awaiting Assent",
                            "params": {
                                "juris": "all",
                                "doc-type": "bill",
                                "status": "aws"
                            }
                        },
                        {
                            "title": "Current",
                            "params": {
                                "juris": "all",
                                "doc-type": "bill",
                                "status": "cur"
                            }
                        },
                        {
                            "title": "Draft",
                            "params": {
                                "juris": "all",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Assented",
                            "params": {
                                "juris": "all",
                                "doc-type": "bill",
                                "status": "ass"
                            }
                        },
                        {
                            "title": "Not in current session",
                            "params": {
                                "juris": "all",
                                "doc-type": "bill",
                                "status": "nis"
                            }
                        },
                        {
                            "title": "Failed",
                            "params": {
                                "juris": "all",
                                "doc-type": "bill",
                                "status": "fail"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "all",
                                "doc-type": "bill",
                                "subject": true,
                                "status" : "all"
                            }
                        }
                    ]
                },
                {
                    "name": "Draft Legislation",
                    "hover": "Browse Draft legislation",
                    "help": {
                        "col1title": "Browse draft legislation",
                        "col1text": "Draft legislation is a proposal for a new law that has been drafted but is yet to be presented to a parliament as a bill.",
                        "col2title": "Applies to",
                        "col2text": "Draft bills, Draft regulations."
                    },
                    "links": [
                        {
                            "title": "Bills",
                            "params": {
                                "juris": "all",
                                "doc-type": "bill",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "Regulations",
                            "params": {
                                "juris": "all",
                                "doc-type": "reg",
                                "status": "dra"
                            }
                        },
                        {
                            "title": "By Subject",
                            "params": {
                                "juris": "all",
                                "status": "dra",
                                "subject": true
                            }
                        }
                    ]
                }
            ]
        }
    ];
})

;
