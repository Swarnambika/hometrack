angular.module( 'tbLawOne.trail', [
  'ui.router',
  'ui.bootstrap',
  'tbLawOne.services'
])

.config(function config( $stateProvider ) {
    $stateProvider
        //about page
        .state( 'trail', {
            url: '/trail',
            views: {
                "main": {
                    controller: 'TrailCtrl',
                    templateUrl: 'trail/trail.tpl.html'
                }
            },
            data:{ pageTitle: 'Trail' }
        })
    ;//end stateProvider declarations
})

.controller( 'TrailCtrl', function TrailController( $scope , tbTrailService) {
    var rawTrail = tbTrailService.getTrailItems();
    if(rawTrail['trail'] && (rawTrail['trail'].length > 0)){
        $scope.trailList = rawTrail['trail'].slice().reverse();
    }
    if(rawTrail['recently'] && (rawTrail['recently'].length > 0)){
        $scope.recentList = rawTrail['recently'].slice().reverse();
    }

    $scope.manualPrint = function(){
        window.print();
    };
})

;
