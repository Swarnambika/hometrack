angular.module( 'tbLawOne.print', [
  'ui.router',
  'ui.bootstrap',
  'tbLawOne.services'
])

.config(function config( $stateProvider ) {
    $stateProvider
        //test
        .state( 'print', {
            url: '/print?root?ids',
            views: {
                "main": {
                    controller: 'LegPrintCtrl',
                    templateUrl: 'print/print.tpl.html'
                }
            },
            data:{ pageTitle: 'Print Legislation' }
        })
        .state('alertsprint', {
            url: '/alerts/print?sections?admin',
            views: {
                "main" : {
                    controller: 'AlertsPrintCtrl',
                    templateUrl: 'lawtracker/alerts/alertsprint.tpl.html'
                }
            },
            data:{ pageTitle: 'Print Alerts' }
        })
        .state('alertsusersprint', {
            url: '/alerts/print/users?users?details',
            views: {
                "main" : {
                    controller: 'AlertsUsersPrintCtrl',
                    templateUrl: 'lawtracker/alerts/alertsusersprint.tpl.html'
                }
            },
            data:{ pageTitle: 'Print Alerts' }
        })
        .state( 'searchprint' , {
            url: '/search/print?term?modifier?scope?juris?doc-type?status?subject?start?sort?page?open?department?within?principal?sections?selected?profile?prep',
            views: {
                "main": {
                    controller: 'SearchPrintCtrl',
                    templateUrl: 'search/searchprint.tpl.html'
                }
            },
            data:{ pageTitle: 'Print Search Results' }
        })
        .state( 'browseprint' , {
            url: '/browse/print?term?modifier?scope?juris?doc-type?status?subject?start?sort?page?open?department?within?principal?sections?selected?year',
            views: {
                "main": {
                    controller: 'BrowsePrintCtrl',
                    templateUrl: 'browse/browseprint.tpl.html'
                }
            },
            data:{ pageTitle: 'Print Browse Display' }
        })
        .state ('activityprint', {
            url: '/lawtracker/print?sdate?edate?juris?doctype?principal?eventtype?eventdate?legislation?subject?profile?sections?selected?fromcustom?prep?fromdaily?lti',
            views: {
                "main" :{
                    controller: 'ActivityPrintCtrl',
                    templateUrl: 'lawtracker/activityprint.tpl.html'
                }
            },
            data:{ pageTitle: 'Print Lawtracker Report' }
        })
        .state('caseprint', {
            url: '/print/cases?caseIds',
            views:{
                "main":{
                    controller: 'CasesPrintCtrl',
                    templateUrl: 'print/cases.tpl.html'
                }
            },
            data: { pageTitle: 'Print Cases'}
        })
        ////[LOWEB-200] WW start
        .state('commenceprint', {
            url: '/commence/print?juris?doctype?sort?year?start?count',
            views:{
                "main":{
                    controller: 'CommencePrintCtrl',
                    templateUrl: 'commencements/commenceprint.tpl.html'
                }
            },
            data: { pageTitle: 'Print Commencement Display' }
        })
        ////[LOWEB-200] WW end
    ;//end stateProvider declarations
})

//controller for cases print
//should accept an array of caseIDs or a single legislation ID
//only enable print coming from the details page cases tab for now
.controller('CasesPrintCtrl', function CasesPrintController($scope, $stateParams, $q, CaseFactory){
    console.log('CasesPrintCtrl init', $stateParams);
    //389250 and 3698329

    if($stateParams['caseIds']){ //no limit (array of selections)
        console.log('print cases: selected specifics', $stateParams['caseIds']);
        $scope.caseIds = $stateParams['caseIds'].split(',');
        if($scope.caseIds.length > 200){
            $scope.caseIds = $scope.caseIds.slice(0,200);
        }

        var defer = $q.defer();
        var promises = [];

        angular.forEach($scope.caseIds, function(item){
            promises.push(CaseFactory.getCaseDetails(item));
        });

        $q.all(promises).then(function(ret){
            $scope.cases = ret;
        });
    }

    $scope.manualPrint = function(){
        window.print();
    };
})

.controller('AlertsUsersPrintCtrl', function AlertsUsersPrintController($scope, $stateParams, tbUserService, TbApi, TbDrmApi){
    $scope.loading = true;
    $scope.showDetails = false;
    $scope.sparams = $stateParams;

    if($stateParams['details']){
        $scope.showDetails = true;
    }

    // $scope.loadOrgProfiles = function(){
    //     TbApi.all('profiles.json').getList({ 'organisation': tbUserService.getOrgID()}).then(function(ret){
    //         console.log('loading org profiles', ret);
    //     });
    // };

    $scope.loadOrgUsers = function(){
        // TbApi.all('users.json').getList({ 'organisation' : tbUserService.getOrgID()}).then(function(ret){
        //     console.log('loadorgusers',ret);
        // });

        TbDrmApi.all('users.json').getList({'organisation': tbUserService.getOrgID()}).then(function(ret){
            console.log('loadorgusers',ret);
            $scope.orgUserList = ret['users'];
            $scope.loading = false;

            if($stateParams['details']){
                for(var i = 0; i < $scope.orgUserList.length; i++){
                    $scope.loadUserProfiles($scope.orgUserList[i]);
                }
            }
        });
    };

    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            if(user['user']){
                //$scope.loadOrgProfiles();
                $scope.loadOrgUsers();
            }
        },
        true
    );

    $scope.loadUsers = function(profile){
        console.log('loadUsers', profile);
        if(!profile['extras'] || !profile['extras']['users']){
            profile['loading'] = true;
            TbApi.all('profiles/' + profile['id'] + '/members.json').getList().then(function(ret){
                console.log('loading members list',ret);
                profile['extras'] = {};
                profile['extras']['users'] = ret['data']['members'];

                profile['loading'] = false;
            });
        }
    };

    $scope.loadUserProfiles = function(user){
        console.log('getUserProfiles called', user);

        if(!user['extras'] || !user['extras']['profiles']){
            user.isCollapsed = !user.isCollapsed;
            user['loading'] = true;
            TbApi.all('profiles.json').getList({ 'user': user.id }).then(function(ret){
                console.log('loading users profiles', ret);
                user['extras'] = {};
                user['extras']['profiles'] = ret['data'];
                user['loading'] = false;
            });
        }else{
            user.isCollapsed = !user.isCollapsed;
        }
    };


    $scope.manualPrint = function(){
        window.print();
    };
})

.controller('AlertsPrintCtrl', function AlertsPrintController($scope, $stateParams, tbUserService, TbApi){
    $scope.loading = true;
    $scope.showSections = false;
    $scope.sparams = $stateParams;

    if($stateParams['sections']){
        $scope.showSections = true;
    }

    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            $scope.userInfo = user;
            if(user['user']){
                console.log('Alerts List User Load', user);
                $scope.loadProfiles();
            }
        },
        true
    );

    $scope.loadProfiles = function(){
        if($stateParams['admin']){
            console.log('ADMIN MODE PRINTING');

            var orgId = tbUserService.getOrgID();
            TbApi.all('profiles.json').getList({organisation: orgId}).then(function(ret){
                console.log('LOAD PROFILES!', ret);
                $scope.alertsList = ret['data'];

                $scope.loading = false;
            });
        }else{
            TbApi.all('profiles.json').getList().then(function(ret){
                console.log('LOAD PROFILES!', ret);
                $scope.alertsList = ret['data'];
                console.log($scope.alertsList);

                $scope.loading = false;
            });
        }
    };

    $scope.manualPrint = function(){
        window.print();
    };

})

.controller( 'ActivityPrintCtrl', function ActivityPrintController( $scope, $stateParams, $q, TbApi, tbSearchServiceAlt, $location, ActivityFactory) {
  $scope.sparams = $stateParams;
  $scope.hasLoaded = false;
  $scope.today = new Date();

  $scope.printmode = $stateParams['sections'];

  var startDate, endDate, eventType, eventDate, detail;
  var legislation, jurisdiction, docType, principal;
  var subject, profile, department;
  var start, count, sort, selfInitiated;

  sort = 'title';

  if($stateParams['prep']){
    $scope.fromalert = true;
    $scope.profilename = $stateParams['prep'];
  }

  if($stateParams['lti']){
    $scope.legtitle = $stateParams['lti'];
  }

  if($stateParams['sections']){
        count = 50;
  }else{
        count = 200;
  }

  var tempEventStringSwitch = function(input){
      console.log('tempEventStringSwitch', input);
      var str = input.toLowerCase();
      switch(str){
          case 'commence':
              return 'Commenced';
          case 'assent':
              return 'Assent/Notification';
          case 'amend':
              return 'Amended';
          case 'repeal':
              return 'Repealed';
          case 'progress':
              return 'Bill/Draft Progress';
          case 'all':
              break;
      }
  };

  var tempEventTypeSwitch = function(input){
      var str = input.toLowerCase();
      switch(str){
          case 'commence':
              return 'commencement,commenced';
          case 'assent':
              return 'assent,notification';
          case 'amend':
              return 'amended,modified';
          case 'repeal':
              return 'repealed,expiry,disallowed by';
          case 'progress':
              return 'events';
          case 'all':
              return 'commencement,commenced,assent,notification,amended,modified,repealed,expiry,disallowed by,subordinate,events';
          default:
              return input;
      }
  };

  //set the arguments from the $stateParams
  if($stateParams['sdate']){ startDate = $stateParams['sdate']; }
  if($stateParams['edate']){ endDate = $stateParams['edate']; }
  if($stateParams['juris']){ jurisdiction = $stateParams['juris']; }
  if($stateParams['doctype']){ docType = $stateParams['doctype']; }
  if($stateParams['principal']){ principal = $stateParams['principal']; }
  if($stateParams['subject']){ subject = $stateParams['subject']; }
  if($stateParams['profile'] && !$stateParams['legislation']){ profile = $stateParams['profile']; }
  if($stateParams['legislation'] && !$stateParams['profile']){ legislation = $stateParams['legislation']; }

  if($stateParams['eventtype']){
      var ts = "";
      var ttypes = $stateParams['eventtype'].split(',');
      for(var i = 0; i < ttypes.length; i++){
          ts += ","+tempEventTypeSwitch(ttypes[i]);
      }
      ts = ts.substring(1);
      console.log('TSTS',ts);
      eventType = ts;

      var tev = "";

      for(var j = 0; j < ttypes.length; j++){
          tev += ", "+ tempEventStringSwitch(ttypes[j]);
      }
      tev = tev.substring(2);
      $scope.tempEventString = tev;

  }else{
      eventType = 'commencement,commenced,assent,notification,amended,modified,repealed,expiry,disallowed by,subordinate,events';
  }

  ////[WW fix the LOWEB-196]: The custom reports and daily activity reports show different results when displaying the print page
  /*
  eventDate = "occur,effective,as-made";
  if($stateParams['eventdate'] && $stateParams['eventdate'].indexOf('editorial') > -1){
      eventDate += ',create,update';
  }*/
  if($stateParams['fromcustom']){
    eventDate = 'occur,effective'; //real dates
    if($stateParams['eventdate'] && $stateParams['eventdate'].indexOf('editorial') > -1){
      eventDate += ',create,update,as-made'; //editorial dates
    }
    if(($stateParams['eventtype'] && $stateParams['eventtype'].indexOf('progress') > -1) || ($stateParams['eventdate'] && $stateParams['eventdate'].indexOf('progress') > -1)){
      if($stateParams['eventdate'] && $stateParams['eventdate'].indexOf('editorial') > -1){
        eventDate += ',progress-update';
      }else{
        eventDate += ',progress';
      }
    }
  }else if($stateParams['fromdaily']){
    eventDate = "occur,effective,progress,as-made";
  }else{
    eventDate = "occur,effective,as-made";
  }
  ////fix ending

    $scope.manualPrint = function(){
        window.print();
    };


    if(!$stateParams['selected']){
      ActivityFactory.getActivity(startDate, endDate, eventType, eventDate, detail,
       legislation, jurisdiction, docType, principal, subject, profile, department,
       start, count, sort, selfInitiated).then(function(ret){
          console.log('Activity Factory test', ret);
          $scope.activityReturn = ret;
          $scope.hasLoaded = true;

          angular.forEach($scope.activityReturn.activity, function(activity){
                activity['legislation']['applicableEventNames'] = activity.applicableEventNames().join(', ');
          });
      });
    }else{
        var selectedIDs = $stateParams['selected'].split(',');
        $scope.activityReturn = {};
        $scope.activityReturn.activity = [];

        var promises = [];

        selectedIDs.map(function(id){
            legislation = id;

            promises.push(
                ActivityFactory.getActivity(startDate, endDate, eventType, eventDate, detail,
                legislation, jurisdiction, docType, principal, subject, profile, department,
                start, count, sort, selfInitiated).then(function(ret){
                    console.log('SELECTION', id);
                    console.log('RET', ret);

                    $scope.activityReturn.activity = $scope.activityReturn.activity.concat(ret.activity);

                })
            );
        });

        $q.all(promises).then(function(){
            console.log('all promises done');

            angular.forEach($scope.activityReturn.activity, function(activity){
                activity['legislation']['applicableEventNames'] = activity.applicableEventNames().join(', ');
            });

            legislation = undefined;
            $scope.hasLoaded = true;
        });
    }
})


.controller( 'SearchPrintCtrl', function SearchPrintController( $scope, $stateParams, $q, TbApi, tbSearchServiceAlt, $location) {
    if($stateParams['sections'] || $stateParams['selected']){
        $scope.sections = true;
    }

    if(!$stateParams['profile']){
        $scope.sparams = tbSearchServiceAlt.getStateParams();
    }

    $scope.sextras = $stateParams;

    if($stateParams['subject']){
        $scope.numSubjects = $stateParams['subject'].split(',').length;
    }

    $scope.manualPrint = function(){
        window.print();
    };
    $scope.today = new Date();

    var parsedParams;
    if(tbSearchServiceAlt.searchObject.term){
        parsedParams = tbSearchServiceAlt.getSearchParams();

        if(!$scope.sections){
            parsedParams['count'] = 200;
        }
    }else{
        parsedParams = tbSearchServiceAlt.getSearchParams(tbSearchServiceAlt.parseUrlToObject($location.search()));
        parsedParams['count'] = 200;

    }

    if($stateParams['profile']){
        parsedParams['profile'] = $stateParams['profile'];
    }
    console.log('PARSEDPARAMS test', parsedParams);
    console.log('check state params', $stateParams);

    if(!parsedParams['sort']){ parsedParams['sort'] = 'relevance'; }

    if($stateParams['selected']){
        $scope.parsedParams = parsedParams;
        var ids = $stateParams['selected'].split(',');
        $scope.sresults = [];
        ids.map(function(id){
            TbApi.one('legislation/'+ id + '.json').get().then(function(ret){
                if(ret){
                    $scope.sresults.push(ret['data']['legislation']);
                }
            });
        });
    }else{
        TbApi.all('search.json').getList(parsedParams)
        .then(function(tbRequest){
            if($stateParams['selected']){
                var fresults = [];

                console.log('SELECTED LIST', $stateParams.selected);
                tbRequest['data']['documents'].map(function(item){
                    if(_.contains($stateParams.selected, item['legislation-id'])){
                        console.log('pre FRESULTS CHECK TRUE', item);
                        fresults.push(item);
                    }
                });

                console.log('FRESULTS', fresults);
                $scope.sresults = fresults;
            }else{
                $scope.hits = tbRequest['data']['hits'];
                $scope.sresults = tbRequest['data']['documents'];
            }
        });
    }
})

.controller( 'BrowsePrintCtrl', function BrowsePrintController( $scope, $stateParams, $q, TbApi, tbSearchServiceAlt, $location) {
    if($stateParams['selected']){
        $scope.sections = true;
    }
    $scope.sparams = $stateParams;

    $scope.manualPrint = function(){
        window.print();
    };
    $scope.today = new Date();

    if($stateParams['subject']){
        $scope.numSubjects = $stateParams['subject'].split(',').length;
    }

    console.log('STUFFTOPARSE',$location.search());
    parsedParams = tbSearchServiceAlt.getSearchParams(tbSearchServiceAlt.parseUrlToObject($location.search()));
    parsedParams['count'] = 200;
    console.log('PARSEDPARAMS', parsedParams);

    if(!parsedParams['sort']){ parsedParams['sort'] = 'title,jurisdiction,date'; }

    //NOW DO CHECKS FOR THE DOUBLEUP PARAMS
    //ACT ALSO MEANS ORD, REP ALSO MEANS INOP
    if(parsedParams['doc-type'] && parsedParams['doc-type'].split(',').indexOf('act') > -1){
        parsedParams['doc-type'] = parsedParams['doc-type'] + ",ord";
    }
    if(parsedParams['status'] && parsedParams['status'].split(',').indexOf('rep') > -1){
        parsedParams['status'] = parsedParams['status'] + ",inop";
    }

    if($stateParams['selected']){
        var ids = $stateParams['selected'].split(',');
        $scope.sresults = [];
        ids.map(function(id){
            TbApi.one('legislation/'+ id + '.json').get().then(function(ret){
                if(ret){
                    $scope.sresults.push(ret['data']['legislation']);
                }
            });
        });
    }else{
        TbApi.all('search.json').getList(parsedParams)
        .then(function(tbRequest){
            if($stateParams['selected']){
                var fresults = [];

                console.log('SELECTED LIST', $stateParams.selected);
                tbRequest['data']['documents'].map(function(item){
                    if(_.contains($stateParams.selected, item['legislation-id'])){
                        console.log('pre FRESULTS CHECK TRUE', item);
                        fresults.push(item);
                    }
                });

                console.log('FRESULTS', fresults);
                $scope.sresults = fresults;
            }else{
                $scope.hits = tbRequest['data']['hits'];
                $scope.sresults = tbRequest['data']['documents'];
            }
        });
    }
})

.directive('printSearchResult', function($compile, TbApi){
    var linker = function(scope, element, attrs){

        scope.num = scope.number + 1;

        var render = function(template){
            element.html(template).show();
            $compile(element.contents())(scope);
        };

        if((scope.showSections === true || scope.showSections == 'true')){
            if(scope.params){
                var sp = scope.params;
                sp['count'] = 100;

                TbApi.one(scope.item['_links']['section-results']['href'] .replace(/\/api[^/]*\/[^/]+\//gi,'')).get(sp)
                .then(function(ret){
                    if(ret){
                        scope.item['sections'] = ret['data']['sections'];
                        render(
                            '<p><h4>{{num}} - <span leg-title-render="item"></span></h4><div sly-repeat="section in item.sections"><b><span data-highlight-text="{{highlight}}" result-section-render="{{section.title}}"></span></b><div style="margin-left: 20px;"><span sly-repeat="frag in section.fragments" data-highlight-text="{{highlight}}" result-section-render="{{frag}}"></span></div></div></p>'
                        );
                    }
                });
            } else if(scope.item['_links']['section-results']['href']){
                TbApi.one(scope.item['_links']['section-results']['href'] .replace(/\/api[^/]*\/[^/]+\//gi,'')).get({count: 100})
                .then(function(ret){
                    if(ret){
                        scope.item['sections'] = ret['data']['sections'];
                        render(
                            '<p><h4>{{num}} - <span leg-title-render="item"></span></h4><div sly-repeat="section in item.sections"><b><span data-highlight-text="{{highlight}}" result-section-render="{{section.title}}"></span></b><div style="margin-left: 20px;"><span sly-repeat="frag in section.fragments" data-highlight-text="{{highlight}}" result-section-render="{{frag}}"></span></div></div></p>'
                        );
                    }
                });
            }else{
                render('<p><h4>{{num}} - <span leg-title-render="item"></span></h4><div>This legislation item currently has no content.</div></p>');
            }
        }else{
            render(
                '<p><h4>{{num}} - <span leg-title-render="item"></span></h4></p>'
            );
        }
    };

    return {
        restrict: "AE",
        replace: true,
        link: linker,
        scope: {
            item: '=',
            number: '=',
            highlight: '=',
            showSections: '=',
            params: '='
        }
    };
})

.controller( 'LegPrintCtrl', function SandboxController( $scope, $stateParams, $q, TbApi) {
    $scope.root = $stateParams['root'];
    if($stateParams['ids']){
        $scope.ids = $stateParams['ids'].split(',');
    }
    var getDescendants = function(array){
        var promises = array.map(function(item){
            return TbApi.one('legislation/' + $scope.root + '/content/' + item + '/descendants.json').get();
        });

        return $q.all(promises);
    };

    $scope.today = new Date();

    if($scope.root && $scope.ids){
        getDescendants($scope.ids).then(function(ret){
            console.log('DESCENDANTS', ret);
            for(var i=0; i<ret.length;i++){
                ret[i] = ret[i]['data'];
                ret[i]['id'] = $scope.ids[i];
            }
            $scope.originalNodes = ret;
        });
    }

    $scope.manualPrint = function(){
        window.print();
    };
})

.directive('printBreaker', function($compile, TbApi){
    var linker = function(scope, element, attrs){
        TbApi.one('legislation/'+scope.root+'/content/'+scope.node.id+'.json').get()
        .then(function(ret){
            scope.legdata = ret['data'];
            element.html(
                '<hr/><span ng-repeat="location in legdata[\'_links\'][\'location\']">' + 
                '<span class="divider" ng-hide="$first"> / </span>' +
                '<a href="{{location.url | stripHref}}">' +
                '{{location.title}}</a></span>' +
                '<span ng-show="legdata[\'_links\'][\'location\']"> / </span>' +
                '<span>{{legdata.legislation.title}}</span><hr/>'
            );
            element.show();
            $compile(element.contents())(scope);
        });
    };

    return {
        restrict: "AE",
        replace: true,
        link: linker,
        scope: {
            node: '=',
            root: '='
        }
    };
})

.directive( 'printTree', function($compile, $q, TbApi){
    var linker = function(scope, element, attrs){
        console.log('printTree linker called');
        //this directive is spawned once per id passed passed in from controller to start
        TbApi.one(scope.node['_links']['content']['href'] .replace(/\/api[^/]*\/[^/]+\//gi,'')).get()
        .then(function(ret){
            TbApi.one(ret['data']['legislation']['_links']['html']['href'] .replace(/\/api[^/]*\/[^/]+\//gi,'')).get()
            .then(function(ret){
                //this is to be put in EXACTLY AS IT WOULD EXIST IN A NORMAL TEMPLATE
                element.html(ret);
                //check for children
                if(scope.node.children){
                    //now we do our weird stuff by removing the toc-mini and
                    //stuff the old .toc-mini element with the new directives
                    element.find('.toc-mini').html('<div ng-repeat="child in node.children" data-root="root" data-node="child" print-tree></div>');
                    element.find('.toc-mini').removeClass('toc-mini');
                }
                //now we reveal it
                element.show();
                //and give it to angular to handle
                $compile(element.contents())(scope);
            });
        });
    };

    return {
        restrict: "AE",
        replace: true,
        link: linker,
        scope: {
            node: '=',
            root: '='
        }
    };
})


.directive( 'printLegActivities', function($compile, $q, TbApi){
    var getTemplate = function(){
        return '<pre>{{node}}</pre>';
    };

    var render = function(template){
        element.html(template).show();
        $compile(element.contents())(scope);
    };

    var expandActivityLinks = function(activity){
        if(activity){
            if(!activity['legislation']['extras']){ activity['legislation']['extras'] = {};}

            activity.loadCounter = 0;
            activity.numLinks = _.size(activity['links']);

            angular.forEach(activity['links'], function(value, key){
                //make a call to each link
                TbApi.one(value.href .replace(/\/api[^/]*\/[^/]+\//gi,'')).get().then(function(ret){
                    console.log('RET',ret['data']);

                    if(key !== 'properties' && ret['data'][key] && ret['data'][key][0] && ret['data'][key][0]['type']){
                        activity['legislation']['extras'][key] = _.groupBy(ret['data'][key], function(item){return item['type'];});
                    }else{
                        activity['legislation']['extras'][key] = ret['data'][key];
                    }
                    activity.loadCounter++;
                });
            });
        }
    };

    var linker = function(scope, element, attrs){
        if(scope.node){
            expandActivityLinks(scope.node);
            render(getTemplate());
        }
    };

    return {
        restrict: "A",
        replace: true,
        link: linker,
        scope: {
            node: '='
        }
    };
})

////[LOWEB-200] WW start
.controller( 'CommencePrintCtrl', function CommencePrintController( $scope, $state, $stateParams, CommencementsFactory, TbApi) {

    $scope.sparams = $stateParams;

    $scope.displayDoctype = $stateParams['doctype'];
    if($stateParams['doctype'] && ($stateParams['doctype'].indexOf(',') > -1)){
        $scope.displayDoctype = $stateParams['doctype'].split(',')[0];
    }

    $scope.manualPrint = function(){
        window.print();
    };
    
    var params = {
        'jurisdiction' : ($stateParams['juris'] ? $stateParams['juris'] : 'cth'),
        'doc-type' : ($stateParams['doctype'] ? $stateParams['doctype'] : 'act,ord'),
        //[LOWEB-205]'status' : ($stateParams['status'] ? $stateParams['status'] : 'cur,rep'),
        'start' : $stateParams['start']? $stateParams['start'] : 1,
        'count' : $stateParams['count']? $stateParams['count'] : 250,
        'year' : ($stateParams['year'] ? $stateParams['year'] : new Date().getFullYear()),
        'sort' : ($stateParams['sort'] ? $stateParams['sort'] : 'date,title')
    };

    CommencementsFactory.getCommencements(params).then(function(ret){
        console.log('I GOT RETURN VALUE', ret);
        $scope.commencements = ret['legislation'];
        $scope.totalItems = ret['total'];
        window.sessionStorage.setItem('totalCommencesNum',ret['total']);
        $scope.hasLoaded = true;
    });
    
    var totalItemsNum = parseInt(window.sessionStorage.getItem('totalCommencesNum') , 10);
    var itemsPerPage = params['count'];
    console.log("Total and perpage count" , totalItemsNum, itemsPerPage);
    if(totalItemsNum > itemsPerPage){
      var serviceTimes = Math.ceil((totalItemsNum / itemsPerPage));
      var tmpParamArr = [];
      for(var i=1; i < serviceTimes;i++){
        tmpParamArr.push(i*itemsPerPage + 1);
      }
      console.log("Commence parameter array" , tmpParamArr);
      $scope.commencementsleft = [];
      tmpParamArr.map(function(currstart){
          params['start'] = currstart;
          CommencementsFactory.getCommencements(params).then(function(ret){
              if(ret){
                  $scope.commencementsleft = $scope.commencementsleft.concat(ret['legislation']);
              }
          });
      });
      //console.log("Commence page retrieved" , $scope.commencementsleft);
    }
})
////[LOWEB-200] WW end
;//end sandbox.js
