angular.module( 'tbLawOne.error', [
    'ui.router',
    'ui.bootstrap'
])

.config(function config( $stateProvider ) {
    $stateProvider
        //about page
        .state( 'error', {
            url: '/error/:code',
            views: {
                "main": {
                    controller: 'ErrorCtrl',
                    templateUrl: 'error/error.tpl.html'
                }
            },
            data:{ pageTitle: 'Error' }
        })
        .state( 'userblock', {
            url: '/user/role',
            views: {
                "main": {
                    controller: 'UserBlockCtrl',
                    templateUrl: 'error/userblock.tpl.html'
                }
            },
            data:{ pageTitle: 'Error' }
        })
    ;//end stateProvider declarations
})

.controller( 'ErrorCtrl', function ErrorController( $scope, $stateParams ) {
    $scope.code = $stateParams['code'];
})

.controller( 'UserBlockCtrl', function UserBlockController( $scope, $stateParams ) {
    $scope.code = $stateParams['code'];
})

.controller( 'ErrorInterceptModalCtrl', function ErrorInterceptModalController($scope, $modalInstance, error, redirectUrl){
    console.log('ErrorInterceptModalCtrl', error.data);
    var tstr = error.data;
    console.log('ERROR DUMP', tstr);

    if(typeof tstr == "string" || tstr instanceof String){
        $scope.error = JSON.parse(tstr);
    }else{
        $scope.error = error.data;
    }

    $scope.redirectUrl = redirectUrl;

    $scope.ok = function () {
        $modalInstance.close(error);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})

;
