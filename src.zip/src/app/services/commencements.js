angular.module('tbLawOne.api.commencements', [
    'tbLawOne.api.link',
    'tbLawOne.api.wrapper'
])

.factory('CommencementsFactory', function(TbApi, $q){
    var getCommencements = function(params){

        return TbApi.one('legislationdetails.json').get(params).then(function(ret){
            return ret['data'];
        });
    };

    return {
        getCommencements : getCommencements
    };
})

;
