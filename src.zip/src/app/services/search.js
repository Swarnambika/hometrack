/*
 * timebase-api-search
 *
 */
angular.module('tbLawOne.api.search', [

])

.service('tbSearchUtils', function(){
    this.countListTrue = function(input){
        var counter = 0;
        _.each(input,function(v,k){
            if(v === true){
                counter++;
            }
        });
        return counter;
    };
    this.convertListParams = function(input){
        console.log('convertListParams called', input);
        var ret = "";
        if(input){

            var jstring = "";
            var total = 0;
            var selected = 0;

            angular.forEach(input, function(v, k){
                if(v){
                    jstring += (k + ",");
                    selected++;
                }
                total++;
            });

            ret = jstring.slice(0,-1);
        }
        return ret;
    };
})

//global storage of the search object
.factory('tbSearchServiceAlt', function(TbApi, $state, tbSearchUtils, trjurisFilter, trjurisrevFilter, trstatusrevFilter, Restangular){
    return {
        passthrough: false,     //for legislation passthrough hack
        defaultSearchObject: {  //default copy of the search object in virgin state
          "term": null,
          "searchwithin": {
            "title": null,
            "id": null
          },
          "jurisdiction": {
            "cth":false,
            "act":false,
            "nsw":false,
            "nt":false,
            "qld":false,
            "sa":false,
            "tas":false,
            "vic":false,
            "wa":false
          },
          "doctype": {
            "act":false,
            "ord":false,
            "reg":false,
            "prn":false,
            "cpn":false,
            "bill":false,
            "clact":false,
            "clreg":false
          },
          "status": {
            "cur":false,
            "rep":false,
            "dra":false,
            "inop":false,
            "ass":false,
            "fail":false,
            "spnt":false,
            "nis":false,
            "aws":false
          },
          "scope": null,
          "subject": null,
          "department": null,
          "year": null,
          "number": null,
          "start": null,
          "page": 1,
          "modifier": "boolean",
          "sort": null,
          "principal": null
        },
        searchObject: {}, //defines actual search object
        setSearchObject: function(obj){ //sets search object to passed in object
            console.log('searchService: search object set', obj);
            this.searchObject = _.clone(obj, true);
        },
        newSearchObject: function(){ //makes a brand new copy of the search object from default
            this.searchObject = _.clone(this.defaultSearchObject, true);
        },
        isSearchFormAdvanced: function(){ //checks whether form needs to be advanced
            var jcounter = 0;
            var scounter = 0;
            var dcounter = 0;

            _(this.searchObject.jurisdiction).each(function(item){
                if(item){ jcounter++; }
            });

            _(this.searchObject.doctype).each(function(item){
                if(item){ dcounter++; }
            });

            _(this.searchObject.status).each(function(item){
                if(item){ scounter++; }
            });

            if(
                jcounter > 1 ||
                scounter > 0 ||
                dcounter > 0 ||
                this.searchObject.modifier != "boolean" ||
                this.searchObject.principal !== null ||
                this.searchObject.subject !== null ||
                this.searchObject.searchwithin.id !== null
            ){
                return true;
            }else{
                return false;
            }
        },
        executeSearch: function(reload){
            console.log('execute search params',this.getSearchParams());
            var params = this.getStateParams();
            var options = {
                inherit: false
            };

            if(reload){
                options['reload'] = true;
            }

            $state.go('search',params,options);
        },
        isSearchEmpty: function(){ //compares the current search object to the default search and returns true if identical
            if(JSON.stringify(this.searchObject) == JSON.stringify(this.defaultSearchObject)){
                return true;
            }else{
                return false;
            }
        },
        getStateParamsNew: function(){//turns search object into Angular URL parameters object for templating
            var params = {};
            for(var paramName in this.searchObjectStateParams){
                console.log('searchService: getStateParams: Testing', paramName);
                if (this.searchObject[paramName])
                {
                    console.log('getStateParams: Object has param', paramName);
                    var urlParamName = this.searchObjectStateParams[paramName]["name"];
                    var urlParamValue = this.searchObject[paramName];
                    var stateParamsObj = this.searchObjectStateParams[paramName];
                    console.log('getStateParams: name/value', urlParamName,urlParamValue);
                    if (stateParamsObj['convert'])
                    {
                        urlParamValue = stateParamsObj.convert(urlParamValue);
                    }
                    params[urlParamName] = urlParamValue;
                }
            }
            return params;
        },
        getStateParams: function(){ //turns search object into Angular URL parameters object for templating
            var params = {};
            console.log('searchService: getStateParams for current search object called', this.searchObject);

            //params['term'] = encodeURIComponent(decodeURIComponent(this.searchObject.term));
            params['term'] = this.searchObject.term;

            if(this.searchObject.scope !== this.defaultSearchObject.scope){
                params['scope'] = this.searchObject.scope;
            }

            if(this.searchObject['scope'] == 'title' || this.searchObject['scope'] == 'headings' || this.searchObject['scope'] == 'section-headings'){
                params['sort'] = "title";
            }

            if(this.searchObject['sort'] !== this.defaultSearchObject['sort']){
                params['sort'] = this.searchObject['sort'];
            }

            if(this.searchObject.page > 1){
                params['page'] = this.searchObject.page;
            }else{
                params['page'] = 1;
            }

            if(this.searchObject.modifier !== this.defaultSearchObject.modifier){
                params['modifier'] = this.searchObject.modifier;
            }

            if(this.searchObject.subject !== this.defaultSearchObject.subject){
                params['subject'] = this.searchObject.subject;
            }

            if(this.searchObject.department !== this.defaultSearchObject.department){
                params['department'] = this.searchObject.department;
            }

            if(this.searchObject.principal !== this.defaultSearchObject.principal){
                params['principal'] = this.searchObject.principal;
            }

            //handle jurisdiction parsing
            var jurisLength = tbSearchUtils.countListTrue(this.searchObject.jurisdiction);
            console.log('NUMBER OF JURISDICTIONS TRUE', jurisLength);
            //if(jurisLength === 9){
                //do nothing
            //}else if(jurisLength > 0 && jurisLength < 9){
            if(jurisLength > 0){
                params['juris'] = tbSearchUtils.convertListParams(this.searchObject.jurisdiction);
                console.log('CONVERTED JURIS PARAMS', params['juris']);
            }

            //handle doctype parsing
            var docLength = tbSearchUtils.countListTrue(this.searchObject.doctype);
            //if(docLength === 8){
                //params['doc-type'] = 'all';
            //}else if(docLength > 0 && docLength < 8){
            if(docLength > 0){
                if(tbSearchUtils.convertListParams(this.searchObject.doctype) !== ""){
                    params['doc-type'] = tbSearchUtils.convertListParams(this.searchObject.doctype);
                }
            }

            //handle status parsing
            var statusLength = tbSearchUtils.countListTrue(this.searchObject.status);
            //if(statusLength === 9){
                //params['status'] = 'all';
            //}else if(statusLength > 0){
            if(statusLength > 0){
                if(tbSearchUtils.convertListParams(this.searchObject.status) !== ""){
                    params['status'] = tbSearchUtils.convertListParams(this.searchObject.status);
                }
            }

            if(this.searchObject.searchwithin.id){
                params['within'] = this.searchObject.searchwithin.id;
            }

            console.log('parsed state params return',params);
            return params;
        },
        getSearchParams: function(input){ //turns search object into URL params object to be sent to API - ONLY to API, NEVER to state
            //object to be returned
            var params = {};

            if(input){
                workingObject = input;
            }else{
                workingObject = this.searchObject;
            }

            console.log('searchService: getSearchParams called',workingObject);

            var terms = workingObject.term;
            var mod = workingObject.modifier;

            //check if NOT boolean search / default
            if(terms && (mod == 'any' || mod == 'all' || mod == 'exact')){
                console.log('modifier is ANY, ALL or EXACT');
                console.log('terms dump pre processing', terms);

                //strip out quotes before we do anything
                //because this is special sauce
                terms = terms.replace(/\"/g, "");

                //check if mod is all or any
                if(mod == 'all' || mod == 'any'){
                    arr = terms.split(" ");
                    res = [];

                    for(var i = 0;i<arr.length;i++){
                        var cur = arr[i].toUpperCase();
                        console.log(cur);
                        // if(cur == 'AND' || cur == 'OR' || cur == 'NOT' || cur == '&' || cur == "|" || cur == '^'){
                        //     res.push('"'+arr[i]+'"');
                        // }else{
                        //     res.push(arr[i]);
                        // }

                        if(cur == 'AND' || cur == 'OR' || cur == '&' || cur == "|"){
                            res.push('"'+arr[i]+'"');
                        }else if(cur == 'NOT' || cur == '^'){
                            //do absolutely nothing
                        }else{
                            res.push(arr[i]);
                        }

                        if(mod == 'any'){
                            res.push("OR");
                        }
                    }

                    if(res[res.length-1] == 'OR'){
                        res.pop();
                    }

                    terms = res.join(" ");
                }else if(mod == 'exact'){ //mod is EXACT, so wrap the entire phrase in quotes
                    terms = '"'+terms+'"';
                }

                console.log('terms dump post processing', terms);
                params['term'] = terms;
            }else{
                console.log('modifier is NOT PRESENT or BOOLEAN');
                params['term'] = workingObject.term;
            }

            if(workingObject.scope !== this.defaultSearchObject.scope){
                params['scope'] = workingObject.scope;
            }

            if(params['scope'] == 'title' || params['scope'] == 'headings' || params['scope'] == 'section-headings'){
                params['sort'] = 'title,jurisdiction,date';
            }

            if(workingObject['sort'] !== "" && workingObject['sort']){
                switch(workingObject['sort']){
                    case 'title':
                        params['sort'] = 'title,jurisdiction,date';
                        break;
                    case '-title':
                        params['sort'] = '-title,jurisdiction,date';
                        break;
                    case 'date':
                        params['sort'] = '-date,jurisdiction,title';
                        break;
                    case '-date':
                        params['sort'] = 'date,jurisdiction,title';
                        break;
                    case 'juris':
                        params['sort'] = 'jurisdiction,title,date';
                        break;
                    case '-juris':
                        params['sort'] = '-jurisdiction,title,date';
                        break;
                    case 'rel':
                        params['sort'] = 'relevance';
                        break;
                }
            }

            if(workingObject.page > 1){
                params['start'] = (((workingObject.page - 1) * 50) + 1);
            }

            if(workingObject.subject !== this.defaultSearchObject.subject){
                params['subject'] = workingObject.subject;
            }

//            if(workingObject.modifier !== this.defaultSearchObject.modifier){
//                params['modifier'] = workingObject.modifier;
//            }
//
            if(workingObject.principal !== this.defaultSearchObject.principal){
                params['principal'] = workingObject.principal;
            }

            if(workingObject.department !== this.defaultSearchObject.department){
                params['department'] = workingObject.department;
            }

            //handle jurisdiction parsing
            var jurisLength = tbSearchUtils.countListTrue(workingObject.jurisdiction);
            //if(jurisLength > 0 && jurisLength < 9){
            if(jurisLength > 0){
                params['jurisdiction'] = tbSearchUtils.convertListParams(workingObject.jurisdiction);
            }

            //handle doctype parsing
            var docLength = tbSearchUtils.countListTrue(workingObject.doctype);
            //if(docLength > 0 && docLength < 8){
            if(docLength > 0){
                if(tbSearchUtils.convertListParams(workingObject.doctype) !== ""){
                    params['doc-type'] = tbSearchUtils.convertListParams(workingObject.doctype);
                }
            }

            //handle status parsing
            var statusLength = tbSearchUtils.countListTrue(workingObject.status);
            //if(statusLength > 0 && statusLength < 9){
            if(statusLength > 0){
                if(tbSearchUtils.convertListParams(workingObject.status) !== ""){
                    params['status'] = tbSearchUtils.convertListParams(workingObject.status);
                }
            }

            if(workingObject.searchwithin.id && workingObject.searchwithin.id !== 0){
                params['within'] = workingObject.searchwithin.id;
            }

            if(workingObject.year){
                params['year'] = workingObject.year;
            }

            if(workingObject.number){
                params['number'] = workingObject.number;
            }

            if(workingObject['start']){
                params['starts-with'] = workingObject['start'];
            }

            console.log('getSearchParams search output:',params);
            return params;
        },
        setObjectFromUrl: function(url){
            console.log('searchService: setObjectFromUrl called', url);
            if(url){
                var parsedObject = this.parseUrlToObject(url);

                console.log('searchService: setObjectFromUrl object',parsedObject);
                if(parsedObject){
                    this.setSearchObject(parsedObject);
                }else{
                    this.newSearchObject();
                }
                return parsedObject;
            }else{
              return null;
            }
        },
        //given URL params (angular location), makes a search object and RETURNS it
        //DOES NOT ASSIGN THE OBJECT! THIS SIMPLY RETURNS A SEARCH OBJECT.
        parseUrlToObject: function(input){
            console.log('searchService: parsing URL params and returning object without assignation: ', input);

            var pobj = _.clone(this.defaultSearchObject, true);
            var hasParamsDefined = false;

            if(input['term']){
                console.log( 'original input term string', input['term'] );
                try{
                    pobj['term'] = decodeURIComponent( input['term'] );
                    console.log( 'decoding input term string', pobj['term'] );
                }catch(err){
                    pobj['term'] = input['term'];
                    console.log( 'Just recorde decoding input term string error', err );
                }
                hasParamsDefined = true;
            }
            if(input['scope']){ pobj['scope'] = input['scope']; hasParamsDefined = true;}
            if(input['page']){ pobj['page'] = input['page']; hasParamsDefined = true;}
            if(input['modifier']){ pobj['modifier'] = input['modifier']; hasParamsDefined = true;}
            if(input['subject']){ pobj['subject'] = input['subject']; hasParamsDefined = true;}
            if(input['department']){ pobj['department'] = input['department']; hasParamsDefined = true;}
            if(input['year']){ pobj['year'] = input['year']; hasParamsDefined = true;}
            if(input['count']){ pobj['count'] = input['count']; hasParamsDefined = true;}
            if(input['sort']){ pobj['sort'] = input['sort']; hasParamsDefined = true;}
            if(input['principal']){ pobj['principal'] = input['principal']; hasParamsDefined = true;}
            if(input['number']){ pobj['number'] = input['number']; hasParamsDefined = true;}

            if(input['juris']){
                console.log('parseUrlToObject, juris input', input['juris']);
                hasParamsDefined = true;
                var jstring = input['juris'].split(',');
                for (var key1 in pobj['jurisdiction']){
                    if(_.contains(jstring, key1)){
                        pobj['jurisdiction'][key1] = true;
                        console.log(jstring, key1, pobj['jurisdiction'][key1]);
                    }else{
                        pobj['jurisdiction'][key1] = false;
                    }
                }
            }

            if(input['jurisdiction']){
                console.log('parseUrlToObject, jurisdiction input', input['jurisdiction']);
                hasParamsDefined = true;
                var jdstring = input['jurisdiction'].split(',');
                for (var key2 in pobj['jurisdiction']){
                    if(_.contains(jdstring, key2)){
                        pobj['jurisdiction'][key2] = true;
                    }else{
                        pobj['jurisdiction'][key2] = false;
                    }
                    console.log(key2, pobj['jurisdiction'][key2]);
                }
            }

            if(input['doc-type']){
                hasParamsDefined = true;
                var dstring = input['doc-type'].split(',');
                for (var key3 in pobj['doctype']){
                    if(_.contains(dstring, key3)){
                        pobj['doctype'][key3] = true;
                    }else{
                        pobj['doctype'][key3] = false;
                    }
                }
            }

            if(input['status']){
                hasParamsDefined = true;
                var sstring = input['status'].split(',');
                for (var key4 in pobj['status']){
                    if(_.contains(sstring, key4)){
                        pobj['status'][key4] = true;
                    }else{
                        pobj['status'][key4] = false;
                    }
                }
            }

            if(input['within']){
                hasParamsDefined = true;
                pobj['searchwithin'] = {
                    id: input['within']
                };
            }

            if(input['start']){
                hasParamsDefined = true;
                pobj['start'] = input['start'];
            }

            console.log('parsed search object: ',pobj);
            //this.searchObject = pobj;
            if(hasParamsDefined){
                return pobj;
            }else{
                return null;
            }
        },
        clearSearchObject: function(){ // clear the search object entirely
            console.log('searchService: search object cleared');
            this.searchObject = {};
        },
        isPassthrough: function(){
            return this.passthrough;
        },
        setPassthrough: function(){ //enable legislation passthrough hack
            this.passthrough = true;
        },
        clearPassthrough: function(){ //disable legislation passthrough hack
            this.passthrough = false;
        }
    };
})

.directive('tbBreadcrumbArrayitemRender', function($compile, $state, $filter){

    var getTemplate = function(item, params, key){
        var sname = $state.current.name;
        //var sparams = omitSubArray(params, key, item);

        //var t = '<a class="btn btn-bc" href="' + $state.href(sname, ,{reload: true, inherit: false}) + '">';
        var t = '<a class="btn btn-bc" ui-sref="' + sname + '(omitSubArray(params, key, item))" ui-sref-opts="{inherit: false}">';

        switch(key){
            case 'juris':
                t += item.toUpperCase() + " ";
                break;
            case 'doc-type':
                t += $filter('trdoctype')(item) + " ";
                break;
            case 'status':
                t += $filter('trstatus')(item) + " ";
                break;
            default:
                t += item + " ";
        }

        t += '<i class="fa fa-times"></i></a>';
        return t;
    };

    var linker = function(scope,element,attrs){

        scope.omitSubArray = function(params, key, item){
            var obj = _.clone(params);
            var arr = obj[key].split(',');

            if(arr.indexOf(item) > -1){
                arr.splice(arr.indexOf(item), 1);
                obj[key] = arr.join(',');
            }

            return obj;
        };

        console.log('tbBreadcrumbArrayitemRender, linker scope', scope);
        element.html(getTemplate(scope.item, scope.params, scope.key));
        $compile(element.contents())(scope);
    };

    return{
        restrict: 'A',
        replace: true,
        link: linker,
        scope: {
            item: '=tbBreadcrumbArrayitemRender',
            params: '=tbBreadcrumbParams',
            key: '=tbBreadcrumbKey'
        }
    };
})

//this directive takes in stateParams, as usually seen in the search object, and generates a breadcrumb
//which is interactive in a negatory fashion - one may click stuff to get rid of it and reload the page.
//this ONLY HANDLES STUFF IN THE SEARCH OBJECT.
.directive('tbBreadcrumbRender', function($compile, $state, $filter){

    //SAMPLE PARAMS OBJECT CONTENTS
    // department: undefined
    // doc-type: "act,ord"
    // expand: undefined
    // juris: "cth"
    // modifier: undefined
    // open: undefined
    // page: "1"
    // principal: undefined
    // scope: undefined
    // sort: undefined
    // start: undefined
    // status: "cur"
    // subject: undefined
    // term: "test"
    // within: undefined
    //
    // <span sly-show="sparams['term']">terms: ({{sparams['term']}})</span>
    // <span sly-show="!sparams['term']">no terms</span>
    // <span sly-show="sparams['scope']"> | options: {{sparams['scope']}}</span>
    // <span sly-show="sparams['juris']"> | jurisdiction: <span sly-repeat="item in sparams['juris'].split(',')">{{item | uppercase}}<span sly-show="!$last">, </span></span></span>
    // <span sly-show="sparams['doc-type']"> | document type: <span sly-repeat="item in sparams['doc-type'].split(',')">{{item | trdoctype}}<span sly-show="!$last">, </span></span></span>
    // <span sly-show="sparams['status']"> | status: <span sly-repeat="item in sparams['status'].split(',')">{{item | trstatus}}<span sly-show="!$last">, </span></span></span>
    // <span sly-show="sparams['year']"> | year: {{sparams['year']}}</span>
    // <span sly-show="sparams['start']"> | starting with: {{sparams['start']}}</span>
    // <span sly-show="sparams['principal'] == 'true'"> | principal</span>
    // <span sly-show="sparams['principal'] == 'false'"> | amending</span>
    // <span sly-show="subcheck()"> | subjects: {{sublength()}}</span>
    // <span sly-show="deptcheck()"> | departments: {{deptlength()}}</span>
    // <span sly-show="sparams['within']"> | within specific legislation</span>
    //
    var stateStringName = function(string){
        switch(string){
            case 'search':
                return 'Search';
        }
    };

    var getTemplate = function(params){
        var sname = $state.current.name;

        console.log('tbBreadcrumbRender, template building function', params);
        template = "<div>";

        template += '<strong>' + stateStringName($state.current.name) + '</strong> - ';

        //params['page'] = 1;

        //cannot click off term, that would make no sense
        if(params['term']){
            template += '<span>terms: ('+ params['term'] +')</span>';
        }

        if(params['scope']){
            template += '<span> | options: <a class="btn btn-bc" href="' + $state.href(sname, _.omit(params,'scope'),{inherit: false}) + '">' + $filter('capitalise')(params['scope']) + ' <i class="fa fa-times"></i></a></span>';
        }

        if(params['juris']){
            template += '<span> | jurisdiction: <span tb-breadcrumb-arrayitem-render="item" tb-breadcrumb-params="params" tb-breadcrumb-key="\'juris\'" sly-repeat="item in params[\'juris\'].split(\',\')"></span></span>';
        }

        if(params['doc-type']){
            template += '<span> | document type: <span tb-breadcrumb-arrayitem-render="item" tb-breadcrumb-params="params" tb-breadcrumb-key="\'doc-type\'" sly-repeat="item in params[\'doc-type\'].split(\',\')"></span></span>';
        }

        if(params['status']){
            template += '<span> | status: <span tb-breadcrumb-arrayitem-render="item" tb-breadcrumb-params="params" tb-breadcrumb-key="\'status\'" sly-repeat="item in params[\'status\'].split(\',\')"></span></span>';
        }

        if(params['year']){
            template += '<span> | options: <a class="btn btn-bc" href="' + $state.href(sname, _.omit(params,'year'),{inherit: false}) + '">' + params['scope'] + ' <i class="fa fa-times"></i></a></span>';
        }

        if(params['start']){
            template += '<span> | options: <a class="btn btn-bc" href="' + $state.href(sname, _.omit(params,'start'),{inherit: false}) + '">' + params['scope'] + ' <i class="fa fa-times"></i></a></span>';
        }

        //both of these should show
        if(params['principal'] == 'true'){
            template += '<span> | principal: <a class="btn btn-bc" href="' + $state.href(sname, _.omit(params,'principal'),{inherit: false}) + '">' + 'Principal' + ' <i class="fa fa-times"></i></a></span>';
        }

        if(params['principal'] == 'false'){
            template += '<span> | principal: <a class="btn btn-bc" href="' + $state.href(sname, _.omit(params,'principal'),{inherit: false}) + '">' + 'Amending' + ' <i class="fa fa-times"></i></a></span>';
        }

        if(params['principal'] == 'true,false'){
            var ptemp = _.omit(params,'principal');
            var ptempp = _.clone(ptemp);
            ptempp['principal'] = "false";
            var ptempa = _.clone(ptemp);
            ptempa['principal'] = "true";

            template += '<span> | principal: ';
            template +=  '<a class="btn btn-bc" href="' + $state.href(sname, ptempp ,{inherit: false}) + '">' + 'Principal' + ' <i class="fa fa-times"></i></a></span>';
            template +=  '<a class="btn btn-bc" href="' + $state.href(sname, ptempa ,{inherit: false}) + '">' + 'Amending' + ' <i class="fa fa-times"></i></a></span>';
        }

        if(params['department']){
            template += '<span> | departments: <a class="btn btn-bc" href="' + $state.href(sname, _.omit(params,'department'),{inherit: false}) + '">' + 'departments' + ' <i class="fa fa-times"></i></a></span>';
        }

        if(params['subject']){
            template += '<span> | subjects: <a class="btn btn-bc" href="' + $state.href(sname, _.omit(params,'subject'),{inherit: false}) + '">' + 'subjects' + ' <i class="fa fa-times"></i></a></span>';
        }

        if(params['within']){
            template += '<span> | within: <a class="btn btn-bc" href="' + $state.href(sname, _.omit(params,'start'),{inherit: false}) + '">' + 'legislation' + ' <i class="fa fa-times"></i></a></span>';
        }

        template += "</div>";
        return template;
    };

    var linker = function(scope,element,attrs){
        console.log('tbBreadcrumbRender, linker scope', scope);
        console.log('tbBreadcrumbRender, state', $state);
        //scope.params.page = 1;
        element.html(getTemplate(scope.params));
        $compile(element.contents())(scope);
    };

    return{
        restrict: 'A',
        replace: true,
        link: linker,
        scope: {
            params: '=tbBreadcrumbRender'
        }
    };
})

;
