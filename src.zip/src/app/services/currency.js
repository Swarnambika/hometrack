/*
 * timebase-api-currency
 *
 */
angular.module('tbLawOne.api.currency', [])

.factory('tbCurrencyService', function($q, TbApi, Restangular){
    var today = new Date();

    var getCurrencyData = function(){
        return TbApi.one('content/currency.json').get().then(function(ret){
            return ret;
        });
    };

    return{
        getCurrencyAllData: function(){
            return TbApi.one('content/currency.json').get().then(function(ret){
                return ret['data'];
            });
        },
        getCurrency: function(){
            var promise = getCurrencyData().then(function(ret){
                return ret['data']['currency'];
            });
            return promise;
        },
        getLastUpdate: function(){
            var promise = getCurrencyData().then(function(ret){
                return ret['data']['last-update-date'];
            });
            return promise;
        }
    };
})

;
