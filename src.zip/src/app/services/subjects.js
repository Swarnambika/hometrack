/*
 * timebase-api-subjects
 *
 */
angular.module('tbLawOne.api.subjects', [
    'tbLawOne.api.api'
])

//because we make so many stupid calls to this one service, sometimes in parallel
.factory('tbSubjectService', function(TbApi, $q){
    var _cache; //for holding the in-progress chain

    return {
        get: function(){
            if(_cache){ //a request is currently being made, so return the in-progress chain
                return _cache;
            }else{ //no request is currently being made, start a new chain
                _cache = TbApi.one('subjects.json').withHttpConfig({cache: true}).get()
                .then(function(ret) {
                    return ret;
                }).catch(function(ret) {
                    return $q.reject(ret);
                }).finally(function(){
                    _cache = null; //nullify the cache after we're done
                });

                return _cache;
            }
        }
    };
})

//gets subject list - we don't want to do this more than once, so let's do it once.
.factory('listsubjects', function(Restangular, TbApi){
    var data = [];
    var promise;

    return{
        getSubjects: function(){
            return Restangular.all('subjectsapi.json').getList();
        },
        getApiSubjects: function(){
            if(!promise){
                promise = TbApi.all('subjects.json').getList().then(
                    function(result){
                        console.log(result.data.subjects);
                        data = result.data.subjects;
                        return data;
                    }
                );
            }
            return promise;
        }
    };
})

;
