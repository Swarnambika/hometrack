/*
 * timebase-api-cases
 *
 */
angular.module('tbLawOne.api.filters', [])

.filter('unsafe_render', function($sce){
    return function(text){
        return $sce.parseAsHtml(text);
    };
})

.filter('unsafe_bind', function($sce){
    return function(text) {
        return $sce.trustAsHtml(text);
    };
})

.filter('striphtml', function(){
    return function(text){
        return String(text).replace(/<[^>]+>/gm, '');
    };
})

.filter('capitalise', function() {
    return function(input, scope) {
        if (input){
            input = input.toLowerCase();
            return input.substring(0,1).toUpperCase()+input.substring(1);
        }
    };
})

.filter('trentity', function(){
    return function(input){
        if(input){
            return input.replace('&#8212;',' - ');
        }
    };
})

.filter('slice', function() {
    return function(arr, start, end) {
        return arr.slice(start, end);
    };
})

.filter('troptions', function(){
    return function(input){
        if(input){
            switch(input.toLowerCase()){
                case 'titles': return 'Titles';
                case 'headings': return 'All Headings';
                case 'sectiontitles': return 'Section Titles';
            }
        }
    };
})

//filter to turn short-form jurisdictions into long-form and vice versa
.filter('trjuris', function(){
    return function(input){
        if(input){
            switch(input.toLowerCase()){
                case 'all': return "All";
                case 'cth': return "Commonwealth";
                case 'act': return "Australian Capital Territory";
                case 'nsw': return "New South Wales";
                case 'nt': return "Northern Territory";
                case 'qld': return "Queensland";
                case 'sa': return "South Australia";
                case 'tas': return "Tasmania";
                case 'vic': return "Victoria";
                case 'wa': return "Western Australia";
            }
        }
    };
})

.filter('trjurisrev', function(){
    return function(input){
        if(input){
            switch(input.toLowerCase()){
                case 'all jurisdictions': return 'all';
                case 'all': return 'all';
                case 'commonwealth': return 'cth';
                case 'australian capital territory': return 'act';
                case 'new south wales': return 'nsw';
                case 'northern territory': return 'nt';
                case 'queensland': return 'qld';
                case 'south australia': return 'sa';
                case 'tasmania': return 'tas';
                case 'victoria': return 'vic';
                case 'western australia': return 'wa';
            }
        }
    };
})

//filter to turn short-form doctypes into long-form and vice versa
.filter('trdoctype', function(){
    return function(input){
        if(input){
            switch(input.toLowerCase()){
                case 'all': return 'All';
                case 'act': return "Act";
                case 'ord': return "Ordinance";
                case 'reg': return "Regulation";
                case 'prn': return 'Aged Care Principle';
                case 'cpn': return 'Consumer Protection Notice';
                case 'bill': return "Bill";
                case 'clact': return "Case Link - Act";
                case 'clreg': return "Case Link - Regulation";
                case 'clbill': return "Case Link - Bill";
            }
        }
    };
})

.filter('trdoctypelimited', function(){
    return function(input){
        if(input){
            switch(input.toLowerCase()){
                case 'all': return 'All';
                case 'act': return "Act";
                case 'reg': return "Regulation";
                case 'bill': return "Bill";
            }
        }
    };
})


.filter('trdoctyperev', function(){
    return function(input){
        if(input){
            switch(input.toLowerCase()){
                case 'all': return 'all';
                case 'act': return "act";
                case 'acts': return "act";
                case 'ord': return "ord";
                case 'ordinance': return "ord";
                case 'ordinances': return "ord";
                case 'reg' : return "reg";
                case 'regulation': return "reg";
                case 'regulations': return "reg";
                case 'prn': return 'prn';
                case 'aged care principles': return 'prn';
                case 'cpn': return 'cpn';
                case 'consumer protection notice': return 'cpn';
                case 'bill': return "bill";
                case 'bills': return "bill";
                case 'clact': return "clact";
                case 'clreg': return 'clreg';
                case 'clbill': return 'clbill';
                case 'case link - act': return "clact";
                case 'case link - regulation': return "clreg";
                case 'case link - bill': return "clbill";
            }
        }
    };
})

//filter to turn short-form status into long-form and vice versa
.filter('trstatus', function(){
    return function(input){
        if(input){
            switch(input.toLowerCase()){
                case 'all': return "All";
                case 'cur': return "Current";
                case 'rep': return "Repealed";
                case 'dra': return "Draft";
                case 'inop': return "Inoperative";
                case 'ass': return "Assented";
                case 'fail': return "Failed";
                case 'spnt': return "Spent";
                case 'nis': return "Not in current session";
                case 'aws': return "Awaiting assent";
            }
        }
    };
})

.filter('trstatusrev', function(){
    return function(input){
        if(input){
            switch(input.toLowerCase()){
                case 'all': return "all";
                case 'current': return "cur";
                case 'repealed': return "rep";
                case 'draft': return "dra";
                case 'inoperative': return "inop";
                case 'assented': return "ass";
                case 'failed': return "fail";
                case 'spent': return "spnt";
                case 'not in current session': return "nis";
                case 'awaiting assent': return "aws";
                case 'awaiting': return "aws";
            }
        }
    };
})

.filter('trstatustext', function(){
    return function(input){
        if(input){
            switch(input){
                case 'Repealed legislation' : return "*** REPEALED"; //error
                case 'Repealed' : return "*** REPEALED";
                case 'Inoperative legislation': return "*** INOPERATIVE"; //error
                case 'Inoperative': return "*** INOPERATIVE";
                case 'Failed bill': return "*** FAILED"; //error
                case 'Failed': return "*** FAILED";
                case 'Assented bill': return "*** ASSENTED"; //error
                case 'Assented': return "*** ASSENTED";
                case 'Awaiting Assent': return "*** AWAITING";
                case 'Spent legislation': return "*** SPENT"; //error
                case 'Spent': return "*** SPENT";
                case 'Draft': return '*** DRAFT';
                case 'Not in current session': return "*** NICS";
            }
        }
    };
})

.filter('trfrequency', function(){
    return function(input){
        if(input){
            switch(input){
                case 'half-daily' : return 'twice daily';
                default: return input;
            }
        }
    };
})

.filter('prettyjson', function(){
    return function(input){
        if(input){
            return JSON.stringify(input, null, 4);
        }
    };
})

.filter('downloadspaces', function(){
    return function(input){
        console.log('download space replacer IN', input);
        if(input){
            console.log('download space replacer OUT', input.replace(/\+/g,'%20'));
            return input.replace(/\+/g,'%20');
        }
    };
})

.filter('debugfilter', function(){
    return function(input){
        console.log('debug filter dump', input);
        if(input) {return input;}
    };
})

.filter('stringToDate', function(){
    return function(arr, string){
        console.log('stringToDate called', arr, string);
        arr.map(function(item){
          item[string] = new Date(item[string]);
        });
        return arr;
    };
})

.filter('toArray', function () {
  return function (obj, addKey) {
    if (!angular.isObject(obj)) { return obj; }
    if ( addKey === false ) {
      return Object.keys(obj).map(function(key) {
        return obj[key];
      });
    } else {
      return Object.keys(obj).map(function (key) {
        var value = obj[key];
        return angular.isObject(value) ?
          Object.defineProperty(value, '$key', { enumerable: false, value: key}) :
          { $key: key, $value: value };
      });
    }
  };
})

.filter('groupBy', function () {
    var results={};
    return function (data, key) {
        if (!(data && key)) {
            return;
        }
        var result;
        if(!this.$id){
            result={};
        }else{
            var scopeId = this.$id;
            if(!results[scopeId]){
                results[scopeId]={};
                this.$on("$destroy", function() {
                    delete results[scopeId];
                });
            }
            result = results[scopeId];
        }

        for(var groupKey in result){
          result[groupKey].splice(0,result[groupKey].length);
        }

        for (var i=0; i<data.length; i++) {
            if (!result[data[i][key]]){
                result[data[i][key]]=[];
            }
            result[data[i][key]].push(data[i]);
        }

        var keys = Object.keys(result);
        for(var k=0; k<keys.length; k++){
          if(result[keys[k]].length===0){
            delete result[keys[k]];
          }
        }
        return result;
    };
})

.filter('stripHref', function() {
    return function(input){
        if(input){
            return input.replace(/\/api[^/]*\/[^/]+\//gi,'').replace('.json','');
        }
    };
})
;
