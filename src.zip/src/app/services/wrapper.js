/*
 * tbLawOne.api.wrapper
 *
 */
angular.module('tbLawOne.api.wrapper', [
    'tbLawOne.services'
])


/**
 * @name WrapperFactory
 * @class
 *
 * @description
 * The WrapperFactory is a class used to create the WrapperObject and perform various functions on
 * WrapperObjects
 */
.factory('WrapperFactory', function($q) {

  /**
   * @name WrapperFactory#createWrapperObject
   * @methodOf WrapperFactory
   *
   * @description
   * Creates a new WapperObject from a JSON object
   *
   * @param {object} jsonObject A API JSON wrapper-object
   *
   * @returns {WapperObject}
   */
  var createWrapperObject = function(jsonObject) {
    //console.log('createWrapperObject called', jsonObject);

    //get the required properties directly from the JSON object
    var code = jsonObject['code'];
    var status = jsonObject['status'];

    var myWrapper = new WrapperObject(code, status);

    if (jsonObject.hasOwnProperty('message')) {
      myWrapper.message = jsonObject.message;
    }

    if (jsonObject.hasOwnProperty('data')) {
      myWrapper.data = jsonObject.data;
    }

    return myWrapper;
  };


  /* * * * * * * * * *
  * PRIVATE METHODS *
  * * * * * * * * * */

  /**
   * @name WrapperObject
   * @class
   *
   * @description
   * WapperObject is an class that represents a wrapper-object
   * as defined in the TimeBase LawOne API.
   *
   * @see The
   * <a href="https://ps.allette.com.au/ps/page/timebase-documentation/uri/90002">
   * wrapper-object</a> documentation.
   */
  function WrapperObject(code, status) {
    /**
     * The HTTP status code of the response.
     * @type {Number}
     */
    this.code = code;
    /**
     * A text description of the successfulness of the request
     * @type {String}
     */
    this.status = status;
    /**
     * A meaningful, end-user-readable (or at the least log-worthy) message, explaining what went wrong.
     * @type {String}
     */
    this.events = null;
    /**
     * A JSON Hypertext Application Language object.
     * @type {String}
     */
    this.data = null;
  }

  //export any public methods
  return {
    createWrapperObject: createWrapperObject
  };
});
