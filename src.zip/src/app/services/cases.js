/*
 * timebase-api-cases
 *
 */
angular.module('tbLawOne.api.cases', [
    'tbLawOne.api.link',
    'tbLawOne.api.wrapper'
])

/**
 * @name CaseFactory
 * @class
 *
 * @description
 * The CaseFactory is a class used to create the various types of activity
 * objects. This is injected into other stuff as a dependency.
 */

.factory('CaseFactory', function(TbApi, $q){

  /**
   * @name CaseFactory#getCases
   * @methodOf CaseFactory
   *
   * @description
   * Calls the TimeBase cases API service and returns cases.
   *
   * @param {String} legId The legislation root ID
   * @param {String} contId The specific section content ID
   * @param {Number} year Specific year to look in
   * @returns {CaseObject[]}
   */
  var getCases = function(legId, contId, year){
      var casesParams = {};
      if(contId){
          casesParams.content = contId;
      }
      if(year){
          casesParams.year = year;
      }

      return TbApi.one('legislation/'+legId+'/cases.json').get(casesParams).then(function(ret){
          return ret['data']['cases'];
      });
  };

  /**
   * @name CaseFactory#hasCases
   * @methodOf CaseFactory
   *
   * @description
   * Calls the TimeBase cases API service and checks if cases exist
   *
   * @param {String} legId Legislation ID to be checked
   * @param {String} contId Optional content ID to be checked
   * @returns Boolean
   */
  var hasCases = function(legId, contId){
      var casesParams = {};
      if(contId){
          casesParams.content = contId;
      }

      return TbApi.one('legislation/' + legId + '/cases/status.json').get(casesParams).then(function(ret){
          return ret['cases'];
      });
  };

  var getCaseDetails = function(id){
      return TbApi.one('case/' + id + '.json').get().then(function(ret){
          // var modcase = ret['data']['case'];
          // modcase['resources'] = [
          //     {
          //         "href": "/cases/003/002/003002.pdf",
          //         "title": "Test Resource A",
          //         "resource-class": "pdf",
          //         "hover-text": "Test Resource A"
          //     },
          //     {
          //         "href": "/cases/003/002/003002.docx",
          //         "title": "Test Resource B",
          //         "resource-class": "docx",
          //         "hover-text": "Test Resource B"
          //     }
          // ];
          return ret['data']['case'];
      });
  };

  return {
      getCases: getCases,
      hasCases: hasCases,
      getCaseDetails: getCaseDetails
  };
})

/**
 * @name CaseFactory#tbSectionCaseWidget
 *
 * @description
 * Directive
 * Turns into the cases button on individual sections
 *
 * @param {} item Legislation object
 */
.directive('tbSectionCaseWidget', function($modal, $compile){
    var getTemplate = function(){
        return '<a class="btn btn-info" ng-click="modalCasesOpen(item)">Cases</a>';
    };

    var linker = function(scope,element,attrs){

        scope.modalCasesOpen = function(item){
            console.log('modalCasesOpen', item);
            var modalInstance = $modal.open({
                templateUrl: 'directives/casesecmodal.tpl.html',
                controller: 'ModalCaseSectionCtrl',
                windowClass: "modal-large",
                resolve: {
                    tbLeg: function(){
                        return item;
                    }
                }
            });
        };

        var html = getTemplate();
        element[0].innerHTML = html;
        element.show();
        $compile(element.contents())(scope);
    };

    return{
        restrict: 'A',
        replace: true,
        link: linker,
        scope: {
            item: '=tbSectionCaseWidget'
        }
    };
})

    /**
     * @name CaseFactory#ModalCaseSectionCtrl
     *
     * @description
     * Controller for the tbSectionCaseWidget directive
     */
    .controller('ModalCaseSectionCtrl', function($scope, $state, $modalInstance, CaseFactory, tbLeg){

        $scope.leg = tbLeg;

        CaseFactory.getCases(tbLeg['legislation-id'], tbLeg['content-id']).then(function(ret){
            console.log('modalCaseSection cases', ret);
            $scope.cases = ret;
            $scope.setGroup();
        });

        $scope.renderCases = function(key){
            $scope.gcases[key]['renderon'] = !$scope.gcases[key]['renderon'];
        };

        $scope.printCases = function(){
            var casesArray = [];
            var caseCounter = 0;
            for(var i = 0, len = $scope.cases.length; i < len; i++){
                if($scope.cases[i]['isChecked']){
                    casesArray.push($scope.cases[i]['id']);
                    caseCounter++;

                    if(caseCounter >= 200){
                        break;
                    }
                }
            }
            $state.go('caseprint', {'caseIds':casesArray.join(',')});
        };

        $scope.setGroup = function(input){
            $scope.gcases = {};
            $scope.gkeys = [];

            console.log('setGroup called', input);
            console.log('dumping cases', $scope.cases.length);

            if(!input){
                input = 'year';
            }

            $scope.gcases = _.groupBy($scope.cases , function(item){return item[input];});
            $scope.gkeys = _.keys($scope.gcases).sort();

            if(input == 'year'){
                $scope.gkeys = _.keys($scope.gcases).sort().reverse();
            }else{
                $scope.gkeys = _.keys($scope.gcases).sort();
            }

            if($scope.cases.length > 99){
                $scope.gcases[$scope.gkeys[0]]['renderon'] = true;
            }else{
                for(var i=0; i<$scope.gkeys.length; i++){
                    $scope.gcases[$scope.gkeys[i]]['renderon'] = true;
                }
            }

            console.log('grouping completed', $scope.gkeys);
        };

        $scope.cancel = function (event) {
            console.log(event);
            event.stopPropagation();
            $modalInstance.dismiss('cancel');
        };
    })

/**
 * @name CaseFactory#tbCaseRender
 *
 * @description
 * Directive
 * Turns into expandable case rows
 *
 * @param {} item Legislation objecta
 */
.directive('tbCaseRender', function(CaseFactory, $sce){
    var decodeCatchwords = function(string){
        var tempnode = angular.element('<textarea />').html(string).text();
        return $sce.trustAsHtml(tempnode);
    };

    var checkBannedCourts = function(court){
        var banned = [
            "Supreme Court of Supreme Court of Queensland Court of Appeal",
            "District Court Of Queensland",
            "Supreme Court of Queensland",
            "District Court of South Australia",
            "Magistrates Court of South Australia",
            "Supreme Court of South Australia",
            "Supreme Court of Victoria",
            "Supreme Court of Victoria Court of Appeal",
            "District Court of Western Australia",
            "Western Australia Mining Warden's Court",
            "Western Australian State Administrative Tribunal",
            "Supreme Court of Western Australia",
            "Court of Appeal of the Supreme Court of Western Australia"
        ];

        if(banned.indexOf(court) > -1){
            return false;
        }else{
            return true;
        }
    };

    var getCaseDetails = function(item){
        if(!item['legislation-text']){
            CaseFactory.getCaseDetails(item['id']).then(function(ret){
                $.extend(item, ret);
                item['catchwords'] = decodeCatchwords(item['catchwords']);
                item['showres'] = checkBannedCourts(item['court']);
            });
        }
    };

    var linker = function(scope,element,attrs){
        scope.toggleCaseDetails = function(item){
            if(item){
                getCaseDetails(item);
                item.isCollapsed = !item.isCollapsed;
            }
        };
    };

    return{
        restrict: 'A',
        replace: true,
        link: linker,
        scope: {
            item: '=tbCaseRender'
        },
        templateUrl: 'directives/caserow.tpl.html'
    };
})

/**
 * @name CaseFactory#tbCasePrintRender
 *
 * @description
 * Directive
 * Turns into fully expanded case rows for print
 *
 * @param {} item Legislation object
 */
.directive('tbCasePrintRender', function(CaseFactory, $sce){
    var decodeCatchwords = function(string){
        var tempnode = angular.element('<textarea />').html(string).text();
        return $sce.trustAsHtml(tempnode);
    };

    var linker = function(scope,element,attrs){
        scope.item['catchwords'] = decodeCatchwords(scope.item['catchwords']);
    };

    return{
        restrict: 'A',
        replace: true,
        link: linker,
        scope: {
            item: '=tbCasePrintRender'
        },
        templateUrl: 'directives/caseprintrow.tpl.html'
    };
});
