angular.module('tbLawOne.services',[
    'config',
    'restangular',
    'ui.router',
    'oauth',
    'ngStorage',
    'ngSanitize',
    'tbLawOne.api.filters',
    'tbLawOne.api.api',
    'tbLawOne.api.users',
    'tbLawOne.api.activity',
    'tbLawOne.api.cases',
    'tbLawOne.api.search',
    'tbLawOne.api.currency',
    'tbLawOne.api.commencements'
])

.factory('tbFavouritesService', function($q, TbApi){
    return {
        getFavourites: function(counter, start, sort){
            console.log('getFavourites called', counter, start, sort);
            var params = {'_':Date.now()};

            if(counter){
                params['count'] = counter;
            }
            if(start){
                params['start'] = start;
            }
            if(sort){
                params['sort'] = sort;
            }
            console.log('sending params to getFavourites', params);
            return TbApi.one('favourites.json').get(params);
        },
        addFavourite: function(id){
            if(id){
                console.log('addFavourite called',id);
                var postdata = {
                    "legislation" : ("" + id)
                };
                return TbApi.one('favourites.json').customPOST(postdata);
            }else{
                console.log("ERROR, no ID");
            }
        },
        addMultipleFavourites: function(items){
            console.log('adding multifaves', items);

            function setTimeoutPromise(ms) {
              var defer = $q.defer();
              setTimeout(defer.resolve, ms);
              return defer.promise;
            }

            function foo(item, ms) {
              return function() {
                return setTimeoutPromise(ms).then(function () {
                  console.log(item);
                });
              };
            }

            function pushSingleStep(id){
                return TbApi.one('favourites.json').customPOST({
                    "legislation" : ("" + id)
                });
            }

            function foobar(id){
                return function(){
                    return pushSingleStep(id).then(function(ret){
                        console.log('DARK SORCERY', id, ret);
                    });
                };
            }

            if(items){
                var chain = $q.when();
                items.forEach(function (el) {
                    chain = chain.then(foobar(el));
                });
                return chain;
            }else{
                return null;
            }
        },
        deleteFavourite: function(id){
            return TbApi.one('favourites.json?legislation='+id).customDELETE();
        }
    };
})

.factory('tbSavedSearchService', function($localStorage, TbApi, tbSearchServiceAlt){
    var defaultSearchObject = {};
    return{
        addSavedSearch: function(item){
            console.log('addSavedSearch called', item);

            var postdata = tbSearchServiceAlt.getSearchParams();
            console.log('getting search object', postdata);

            TbApi.one('searches.json').customPOST(postdata).then(function(ret){
                console.log('Add new saved search, return object',ret);
            });
        },
        deleteSavedSearch: function(id){
            return TbApi.one('searches.json?id='+id).customDELETE();
        },
        addRecentSearch: function(item){
            console.log('addRecentSearch called', item);
            if(!$localStorage.recentsearch){
                console.log('localStorage recent search object is not present');
                $localStorage.recentsearch = [];
            }
            console.log($localStorage.recentsearch);
            //there is something in there
            if($localStorage.recentsearch[0]){
                var lastIndex = $localStorage.recentsearch.length - 1;

                console.log('localStorage recent search dupe compare NEW', item['search']);
                console.log('localStorage recent search dupe compare OLD', $localStorage.recentsearch[lastIndex]['search']);
                console.log('isEqual', _.isEqual(item['search'], $localStorage.recentsearch[lastIndex]['search'], true));

                //they are not the same, so push
                if(!_.isEqual(item['search'], $localStorage.recentsearch[lastIndex]['search'], true)){
                    $localStorage.recentsearch.push(item);
                }else{ //they are the same, so pop and push
                    $localStorage.recentsearch.pop();
                    $localStorage.recentsearch.push(item);
                }
            }else{
                $localStorage.recentsearch.push(item);
            }
        },
        getSavedSearches: function(){
            var today = new Date();
            return TbApi.one('searches.json').get({'_':today, count: 20});
        },
        getRecentSearches: function(){
            if($localStorage.recentsearch){
                return $localStorage.recentsearch;
            }else{
                return null;
            }
        },
        clearSavedSearches: function(){
            delete $localStorage.savedsearch;
        },
        clearRecentSearches: function(){
            delete $localStorage.recentsearch;
        }
    };
})

.factory('tbPageTitleService', function(){
    return{
        title: "LawOne",
        setTitle: function(string){
            this.title = string;
            console.log(this.title);
        }
    };
})

.factory('tbTrailService', function($localStorage, $location, $window){
    return{
        addRecentlyItem: function(item){
            console.log('addRecentlyItem called', item);
            if((item.url.indexOf('legislation/content') > -1) || !$.isNumeric(item.url.split('/')[2])){
                console.log('special legislation replace, do not push');
            }else{
                //now we do another check to push stuff into Recently Viewed that obeys the super version of the no dupe clause
                if(!$localStorage.history.recently){
                    console.log('localStorage recently object is not present');
                    $localStorage.history.recently = [];
                }

                var legId = item.url.split('/')[2];

                var today = new Date();

                var tempItem = {
                    title: item.title,
                    url: item.url,
                    status: item.status,
                    date: today
                };

                //go through the Recently array and kill everything that contains this LegID
                $localStorage.history.recently = _.remove($localStorage.history.recently, function(n){
                    //console.log('recently filter, processing',n);
                    if(n.url.split('/')[2] == legId){
                        //console.log('recently filter, removing ',n);
                        return false;
                    }else{
                        return true;
                    }
                });

                //now push the item
                $localStorage.history.recently.push(tempItem);
                tempItem = {};

                if($localStorage.history.recently.length > 50){
                    $localStorage.history.recently.shift();
                }

            }
        },
        addTrailItem: function(item){
            console.log('addTrailItem called', item);
            //first check if there is a trail in local storage
            //$window.ga('send','pageview',{page: $location.url(), title: item['title']});
            $window.dataLayer.push({
                'event':'updateVirtualPath',
                'virtualPageUrl': $location.url(),
                'virtualPageTitle': item['title']
            });

            var matcher = item['url'].split('/')[1].split('?')[0];
            console.log('matcher token',matcher);

            if(!$localStorage.history){
                console.log('localStorage trail object is not present');
                $localStorage.history = {
                    trail : []
                };
            }

            //check if it's legislation, browse or search first
            if(matcher == 'browse' || matcher == 'search'){
                //now check if this is a replace or a new item, if it is a replace then replace
                if($localStorage.history.trail[0]){
                    var comparator = $localStorage.history.trail[$localStorage.history.trail.length-1]['url'].split('/')[1].split('?')[0];
                    if(matcher == comparator){
                        console.log('trail object is a dupe');
                        $localStorage.history.trail.pop();
                        $localStorage.history.trail.push(item);
                    }else{
                        console.log('trail object is not a dupe');
                        $localStorage.history.trail.push(item);
                    }
                }
                //else simply push the new item onto the end of the array
                else{
                    console.log('trail object is not a dupe');
                    $localStorage.history.trail.push(item);
                }

            }else if (matcher == 'legislation') {
                if($localStorage.history.trail[0]){
                    if(item['title'] != $localStorage.history.trail[$localStorage.history.trail.length-1]['title']){
                        $localStorage.history.trail.push(item);
                    }
                }else{
                    $localStorage.history.trail.push(item);
                }
            }else if(matcher == 'lawtracker'){
                var ltsubtemp = item.url.slice(0).replace('/lawtracker/','').split('?')[0];
                var ltsub = ltsubtemp.split('/')[0] + "/" + ltsubtemp.split('/')[1];


                if(ltsub == 'reports/custom'){ //detect custom reports
                    console.log('custom report caught', ltsubtemp);
                    //is form state
                    if(ltsubtemp == 'reports/custom/form'){
                        //do nothing
                    }else{ //is results state
                        if($localStorage.history.trail[0]){
                            if(item.url == $localStorage.history.trail[$localStorage.history.trail.length-1]['url']){
                                console.log('trail object is a dupe');
                                $localStorage.history.trail.pop();
                                $localStorage.history.trail.push(item);
                            }else{
                                console.log('trail object is not a dupe 1');
                                $localStorage.history.trail.push(item);
                            }
                        }else{
                            console.log('trail object is not a dupe 1');
                            $localStorage.history.trail.push(item);
                        }
                    }
                }else{
                    //eject form transition, we don't want it
                    console.log('ltsub', ltsub);
                    if(ltsub == 'alerts/profile'){
                        //$localStorage.history.trail.push(item);
                        //do nothing!
                    }else{
                        if($localStorage.history.trail[0]){
                            var ltsubcomptemp = $localStorage.history.trail[$localStorage.history.trail.length-1]['url'].slice(0).split('?')[0].replace('/lawtracker/',"");
                            var ltsubcomp = ltsubcomptemp.split('/')[0] + "/" + ltsubcomptemp.split('/')[1];

                            console.log('ltsubcomp', ltsubcomp);

                            if((ltsub == ltsubcomp) || (ltsub.split('/')[0] == 'alerts' && ltsubcomp.split('/')[0] == 'alerts')){
                                console.log('trail object is a dupe');
                                $localStorage.history.trail.pop();
                                $localStorage.history.trail.push(item);
                            }else{
                                console.log('trail object is not a dupe 1');
                                $localStorage.history.trail.push(item);
                            }
                        }else{
                            console.log('trail object is not a dupe 1');
                            $localStorage.history.trail.push(item);
                        }
                    }
                }
                //rest put through same matching process as above
            }else{
                console.log('state is not legislation, browse, search or lawtracker');
            }
            //now check if the size of the array is >50 and if so shift off the oldest item
            if($localStorage.history.trail.length > 50){
                $localStorage.history.trail.shift();
            }
            console.log('addTrailItem finished ',$localStorage.history);
        },
        getTrailItems: function(){
            if($localStorage.history){
                return $localStorage.history;
            }else{
                console.log('localStorage trail object is not present');
                return null;
                // $localStorage.history = {
                //     trail : []
                // };

                // return $localStorage.history;
            }
        },
        resetTrail: function(){
            delete $localStorage.history;
        }
    };
})

//for highlighting and other things
.factory('tbStringUtils', function(){
    return {
        parseSearchTerms: function(terms){
            var termsObj = { str: terms };
            console.log('parseSearchTerms fired', termsObj);

            //tokenize the input
            var tokens = searchTokenize(termsObj);
            console.log('tokenizer result', tokens);
            //process the tokens
            var proc = processTokens(tokens);
            console.log('flattened result', proc);

            return proc;

            //function takes token tree and turns it into a flat array for highlighting
            //is called recursively
            function processTokens(tokens){
                var termsArr = [];
                console.log("processing tokens", tokens);

                for(var i = 0; i<tokens.length; i++){
                    if(_.isArray(tokens[i])){
                        termsArr = termsArr.concat(processTokens(tokens[i]));
                    }else{
                        var cur = tokens[i];
                        cur = cur.toUpperCase();
                        if(cur == 'AND' || cur == '&' || cur == '^'){
                            //since this is highlighting, all terms here go in, carry on
                        }else if(cur == 'OR' || cur == '|'){
                            //since this is highlighting, all terms here go in, carry on
                        }else if(cur == 'NOT' || cur == '~'){
                            i++; //do not push, whatever is next is discarded, so skip over
                        }else if(cur == 'XOR'){
                            //do nothing, we are not handling exclusive or, just dump it
                        }else if(cur.charAt(0) == '/'){
                            // for /p /s and /NUM
                        }else{
                            termsArr.push(tokens[i]);
                        }
                    }
                }

                return termsArr;
            }

            //function for tokenizing the input string to a nested array
            function searchTokenize(termsObj){
                var parsedTerms = [];
                var curArrayPos = 0;
                var quoted = false;

                while (termsObj.str.length > 0){
                  var charStr = termsObj.str.substr(0, 1);
                  termsObj.str = termsObj.str.substr(1, termsObj.str.length-1);

                  if (charStr == '"') {
                    quoted = !quoted;
                  }

                  if (charStr == ')' & quoted === false) {
                    return parsedTerms;
                  } else if (charStr == '(' & quoted === false) {
                    parsedTerms[curArrayPos] = searchTokenize(termsObj);
                    curArrayPos++;
                  } else if (charStr == ' ' & quoted === false) {
                      if (parsedTerms[curArrayPos] != null) {
                        curArrayPos++;
                      }
                  } else {
                    if (parsedTerms[curArrayPos] == null) {
                      parsedTerms[curArrayPos] = "";
                    }
                    parsedTerms[curArrayPos] += charStr;
                  }
                }
                return parsedTerms;
            }
        }
    };
})

.service('tbUtil', function($state, tbSearchServiceAlt){
    this.legParams = function(href){
        console.log('tbUtil legParams called');
        if(href){
            var params = {};
            var arr = href.split('/');
            var fil = _.filter(arr, function(item){ return item !== ""; });
            params['legId'] = fil[3];
            params['contId'] = fil[5].split('.json')[0];

            if(!tbSearchServiceAlt.isSearchEmpty()){
                var transition = tbSearchServiceAlt.getStateParams();
                _(transition).each(function(v,k){
                    params[k] = v;
                });
            }
            return params;
        }else{
            return null;
        }
    };

    this.legParamsClean = function(href){
        if(href){
            var params = {};
            var arr = href.split('/');
            var fil = _.filter(arr, function(item){ return item !== ""; });
            params['legId'] = fil[3];
            params['contId'] = fil[5].split('.json')[0];

            return params;
        }else{
            return null;
        }
    };

    this.legLink = function(href){
        console.log("leg link called", href);

        if(href){
            if(href == 'null' || href === null){
                alert("href is null");
            }else{
                var params = {};
                var arr = href.split('/');
                var fil = _.filter(arr, function(item){ return item !== ""; });
                params['legId'] = fil[3];
                params['contId'] = fil[5].split('.json')[0];

                if(!tbSearchServiceAlt.isSearchEmpty()){
                    var transition = tbSearchServiceAlt.getStateParams();
                    _(transition).each(function(v,k){
                        params[k] = v;
                    });
                }
                console.log('leg link params', params);
                $state.go('legislation', params, {inherit: false});
            }
        }
    };
})

//because we make so many stupid calls to this one service, sometimes in parallel
.factory('tbSubjectService', function(TbApi, $q){
    var _cache; //for holding the in-progress chain

    return {
        get: function(){
            if(_cache){ //a request is currently being made, so return the in-progress chain
                return _cache;
            }else{ //no request is currently being made, start a new chain
                _cache = TbApi.one('subjects.json').withHttpConfig({cache: true}).get()
                .then(function(ret) {
                    return ret;
                }).catch(function(ret) {
                    return $q.reject(ret);
                }).finally(function(){
                    _cache = null; //nullify the cache after we're done
                });

                return _cache;
            }
        }
    };
})

//gets subject list - we don't want to do this more than once, so let's do it once.
.factory('listsubjects', function(Restangular, TbApi){
    var data = [];
    var promise;

    return{
        getSubjects: function(){
            return Restangular.all('subjectsapi.json').getList();
        },
        getApiSubjects: function(){
            if(!promise){
                promise = TbApi.all('subjects.json').getList().then(
                    function(result){
                        console.log(result.data.subjects);
                        data = result.data.subjects;
                        return data;
                    }
                );
            }
            return promise;
        }
    };
})

;
