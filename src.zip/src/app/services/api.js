/*
 * timebase-api-api
 *
 */
angular.module('tbLawOne.api.api', [])

.factory('TbApiHandler', function($q, $rootScope, cfpLoadingBar){
    var requests = [];

    function newTimeout(){
        console.log('TbApiHandler: killswitch installed');
        var request = $q.defer();
        //requests.push(request);
        return request.promise;
    }

    function killAllRequests(){
        console.log('TbApiHandler: promises in queue', requests);
        // requests.map(function(request){
        //     request.resolve();
        // });
        // requests = [];
        // cfpLoadingBar.complete();
        console.log('TbApiHandler: EXTERMINATE!', requests);
    }

    //automatic cancel
    //$rootScope.$on('$locationChangeStart', function(event, newUrl, oldUrl){
        //if(newUrl !== oldUrl){ killAllRequests(); }
    //});

    //manual cancel
    //$rootScope.$on('TbApiCancel', function(event, newUrl, oldUrl){
        //killAllRequests();
    //});

    return {
        newTimeout: newTimeout,
        killAllRequests: killAllRequests
    };
})

.factory('TbDrmApi', function (Restangular, AccessToken, ENV){
    return Restangular.withConfig(
        function(RestangularConfigurer){
            ////RestangularConfigurer.setBaseUrl('https://angular-jc.timebase.com.au/drm/api/0.1/');
            if(ENV.drmEndpoint){
                RestangularConfigurer.setBaseUrl(ENV.drmEndpoint);
            }
        }
    );
})

.factory('TbTestingApi', function (Restangular, AccessToken, ENV){
    return Restangular.withConfig(
        function(RestangularConfigurer){
            RestangularConfigurer.setBaseUrl(ENV.apiEndpoint);
        }
    );
})

.factory('TbNewApi', function (Restangular, AccessToken, ENV){
    return Restangular.withConfig(
        function(RestangularConfigurer){
            RestangularConfigurer.setBaseUrl(ENV.newApiEndpoint);
            RestangularConfigurer.setFullRequestInterceptor(function(element, operation, what, url, headers, params, httpConfig){
                console.log('FULL REQUEST INTERCEPTOR url of NewAPI',JSON.stringify(url));

                //add a date parameter to stop caching for all of the 'comments' services
                if((what.indexOf('comments.json') > 0) && (operation == 'get' || operation == 'getList')){
                    params['_'] = Date.now();
                }

                return { 'element' : element, 'params' : params};
            });
        }
    );
})

//API access restangular instance
.factory('TbApi', function (Restangular, TbApiHandler, AccessToken, ENV){
    return Restangular.withConfig(
        function(RestangularConfigurer){

            RestangularConfigurer.setBaseUrl(ENV.apiEndpoint);

            RestangularConfigurer.setFullRequestInterceptor(function(element, operation, what, url, headers, params, httpConfig){
                console.log('FULL REQUEST INTERCEPTOR url',JSON.stringify(url));

                //determine the type of the service from the first part of the address
                var serviceRegex = /^[^\.\/]+/;
                var serviceType = serviceRegex.exec(what);

                //add a date parameter to stop caching for all of the 'profiles' services
                if((serviceType == 'profiles' || serviceType == 'users') && (operation == 'get' || operation == 'getList')){
                    params['_'] = Date.now();
                }

                // httpConfig = httpConfig || {};

                // if(httpConfig.timeout === undefined){
                //     httpConfig.timeout = TbApiHandler.newTimeout();
                // }

                return { 'element' : element, 'params' : params};
            });
        }
    );
})

;
