/*
 * timebase-api-users
 *
 */
angular.module('tbLawOne.api.users', [])


.factory('tbAuthService', function($state, $http, AccessToken, Endpoint, ENV){
    return{
        initAuthService: function(scope){
            console.log('initAuthService called');
            AccessToken.set(scope);
        },
        pingAuthService: function(){
            $http({
                method: 'GET',
                url: 'https://auth.timebase.com.au/o/ping'
            }).then(function(ret){
                console.log('PING', ret);
            });
        },
        loginAuthService: function(state, params){
            console.log('loginAuthService called',state,params);
            var stateStr = $state.href(state, params);

            //the State URI needs to be DOUBLE ENCODED even though the lib does this already in Endpoint.set(). Dunno why!
            stateStr = encodeURIComponent(stateStr);

            //set up the oauth end point with the environment config
            var endpointTest = {
                site :          ENV.oauthSite,
                authorizePath:  ENV.oauthAuthorizePath,
                clientId:       ENV.oauthClientId,
                redirectUri:    ENV.oauthRedirectUri,
                responseType :  'token',
                oAuthScope:     '',
                state:          stateStr
            };

            if(endpointTest.state){
                Endpoint.set(endpointTest);
                console.log('ENDPOINT REDIRECT', endpointTest);
                Endpoint.redirect();
            }else{
                alert('OAUTH error: please refresh the page.');
            }
        },
        loginAuthServiceRaw: function(url){
            console.log('loginAuthServiceRaw called',url);

            stateStr = encodeURIComponent(url);

            //set up the oauth end point with the environment config
            var endpointTest = {
                site :          ENV.oauthSite,
                authorizePath:  ENV.oauthAuthorizePath,
                clientId:       ENV.oauthClientId,
                redirectUri:    ENV.oauthRedirectUri,
                responseType :  'token',
                oAuthScope:     '',
                state:          stateStr
            };

            if(endpointTest.state){
                Endpoint.set(endpointTest);
                console.log('ENDPOINT REDIRECT RAW', endpointTest);
                Endpoint.redirect();
            }else{
                alert('OAUTH error: please refresh the page.');
            }
        }
    };
})


//global user
.factory('tbUserService',function(TbApi,AccessToken,tbAuthService, $modal, $http){
    var user = {};

    var loadUserObject = function(){
        console.log('Calling loadUserObject');
        TbApi.one('users/self.json').get().then(
            function(ret){
                console.log('User object return',JSON.stringify(ret));
                if(ret){
                    console.log('user object successfully retrieved', ret['data']);
                    user = ret['data'];

                    user.isIndividual = function(){
                        console.log('user isIndividual ONE called', this['user']['type']);
                        if(this['user']['type'] == 'individual'){
                            return true;
                        }else{
                            return false;
                        }
                    };
                }else{
                    console.log('NO USER! GET USER FAILED!');
                }
            },
            function(error){
                console.log('USER ACCESS ERROR ',error);
            }
        );
    };

    var clearUserObject = function(){
        console.log('clearUserObject');
        user = null;
    };

    return{
        getUserObject: function(){
            return user;
        },
        getUserRoles: function(){
            if(user['user']){
                //return user['user']['role'].split(',');
                return user['user']['roles'];
            }else{
                return null;
            }
        },
        setUserObject: function(input){
            console.log('setUserObject', input);
            user = input;
            user.isIndividual = function(){
              console.log('user isIndividual TWO called', this['user']['type']);
              if(this['user']['type'] == 'individual'){
                  return true;
              }else{
                  return false;
              }
            };
            console.log('user object set', user);
        },
        isUserIndividual: function(){
            if(user['user'] && user.isIndividual()){
                return true;
            }else{
                return false;
            }
        },
        isUserProfileAdmin: function(){
            return (this.getUserRoles().indexOf('Profile Administrator') > -1 ? true : false);
        },
        loadUserObject: function(){
            loadUserObject();
        },
        loadUserPromise: function(){
            return TbApi.one('users/self.json').get();
        },
        clearUserObject: function(){
            clearUserObject();
        },
        getOrgID: function(){
            console.log('GET ORG ID', user);
            if( user['user'] && user['user']['_links'] ){
                return user['user']['_links']['organisation']['href'].replace(/\/api[^/]*\/[^/]+\/organisation\//gi,"").replace('.json',"");
            }else{
                return 1;////Default ID is Timebase company
            }    
        },
        getOrgDomain: function(){
            return user['user']['email'].split('@')[1];
        },
        showShareBlockModal: function(){
            var modalInstance = $modal.open({
                templateUrl: 'services/templates/modalshareblock.tpl.html',
                controller:  function NavRecentSearchController($scope, $modalInstance){
                    $scope.ok = function () {
                        $modalInstance.close();
                    };

                    $scope.cancel = function () {
                        $modalInstance.dismiss('cancel');
                    };
                }
            });
        }
    };
})

;
