/*
 * timebase-api-link
 *
 * Provides an class representing the link-object that is used in the TimeBase
 * LawOne API and methods to create an manipulate the class
 *
 */
angular.module('tbLawOne.api.link', [])

/**
 * @name LinkFactory
 * @class
 *
 * @description
 * The LinkFactory is a class used to create LinkObjects
 */
.factory('LinkFactory', function() {

  /**
   * @name LinkFactory#createLinkObject
   * @methodOf LinkFactory
   *
   * @description
   * Creates a new LinkObject from a JSON object
   *
   * @param {Object} jsonObject A API JSON link-object
   *
   * @returns {LinkObject}
   */
  var createLinkObject = function(jsonObject) {
    //console.log('createLinkObject called', jsonObject);
    var myLink = new LinkObject(jsonObject.href);
    if (jsonObject.hasOwnProperty('name')) {
      myLink.name = jsonObject.name;
    }
    if (jsonObject.hasOwnProperty('title')) {
      myLink.title = jsonObject.title;
    }
    if (jsonObject.hasOwnProperty('templated')) {
      myLink.templated = jsonObject.templated;
    }
    return myLink;
  };



  /* * * * * * * * * *
   * PRIVATE METHODS *
   * * * * * * * * * */

  /**
   * @name LinkObject
   * @class
   *
   * @description
   * LinkObject is an class that represents a link-object
   * as defined in the TimeBase LawOne API.
   *
   * @see The
   * <a href="https://ps.allette.com.au/ps/page/timebase-documentation/path/documents/lawone/API/Objects/link-object.psml">
   * link-object</a> documentation.
   */
  var LinkObject = function(href, name) {
    /**
     * Either a URI [RFC3986] or a URI Template.
     * @type {String}
     */
    this.href = href;
    /**
     * Its value MAY be used as a secondary key for selecting LinkObject which share the same relation type.
     * @type {String}
     */
    this.name = null;
    if (name){
      this.name = name;
    }
    /**
     * Used for labelling the link with a  human-readable identifier
     * @type {String}
     */
    this.title = null;
    /**
     * Indicates that the href is a URI Template
     * @type {Boolean}
     */
    this.templated = false;
  };


  return {
      createLinkObject: createLinkObject,
      LinkObject : LinkObject
  };
});
