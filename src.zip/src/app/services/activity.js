/*
 * timebase-api-activity
 *
 */
angular.module('tbLawOne.api.activity', [
    'tbLawOne.api.link',
    'tbLawOne.api.wrapper',
    'tbLawOne.services'
])

/**
 * @name ActivityNameFilter
 * @class
 *
 * @description
 * This is a filter meant for activity name translation in the interface templates.
 */

.filter('activityNameFilter', function() {
    return function(input) {
        if (input){
            input = input.toLowerCase();
            var proc = function(str){
                switch(str){
                    case 'progress':
                        return 'Bill/Draft Progress';
                    case 'commenced':
                        return 'Commenced';
                    case 'assented':
                        return 'Assent / Notification';
                    case 'amended':
                        return 'Amended';
                    case 'repealed':
                        return 'Repealed';
                    case 'modified': //unused
                        return null;
                    case 'published': //unused
                        return null;
                    default:
                        return null;
                    }
                };
            var ret = proc(input);
            return ret;
        }
    };
})

/**
 * @name ActivityFactory
 * @class
 *
 * @description
 * The ActivityFactory is a class used to create the various types of activity
 * objects
 */

.factory('ActivityFactory', function(TbApi, WrapperFactory, LinkFactory, $q, ENV) {
  //var service = {};

  var apiUrl = "activity.json";

  /**
   * @name ActivityService#getConsolidationEvents
   * @methodOf ActivityFactory
   *
   * @description
   * Calls the TimeBase activity API service to determine if legislation has had changes that aren't
   * included in consolidation
   *
   * @param {String} legislation The URI id or DocId of the legislation
   * @param {Date} consolDate The consolidation date of the legislation
   *
   * @returns {Boolean}
   */
  var getConsolidationEvents = function(legid, consolDate) {
    console.log('getConsolidationEvents', legid, consolDate);
    if (arguments.length !== 2) {
      throw "CurrencyFactory#getConsolidationEvents: 'legislation' and 'consolDate' parameters are required.";
    }
    var now = new Date();
    var params = {};

    var zeroPad = function(n){
        return (n < 10) ? ("0" + n) : n;
    };
    var getRoundString = function(date){
        //console.log('getRoundString', date.getFullYear() + "-" + zeroPad(parseInt(date.getMonth() + 1, 10)) + "-" + zeroPad(date.getDate()) + "T" + zeroPad(date.getHours()) + ":" + zeroPad(date.getMinutes()) + ":00");
        return date.getFullYear() + "-" + zeroPad(parseInt(date.getMonth() + 1, 10)) + "-" + zeroPad(date.getDate()) + "T" + zeroPad(date.getHours()) + ":" + zeroPad(date.getMinutes()) + ":00";
    };
    var getCutRoundString = function(date){
        //console.log('getCutRoundString input', date);
        //console.log('getCutRoundString', date.getFullYear() + "-" + zeroPad(parseInt(date.getMonth() + 1, 10)) + "-" + zeroPad(date.getDate()));
        return date.getFullYear() + "-" + zeroPad(parseInt(date.getMonth() + 1, 10)) + "-" + zeroPad(date.getDate());
    };

    var tempDate = new Date(consolDate.replace(/-/g, "/"));
    //console.log('tempDate before',tempDate);
    tempDate.setDate(tempDate.getDate()+1);
    //console.log('tempDate after',tempDate);

    if(consolDate == '0001-01-01'){
        params['sdate'] = '1998-01-01';
    }else if(consolDate.split('-')[0] < 1901){
        params['sdate'] = '1901-01-01';
    }else{
        params['sdate'] = getCutRoundString(tempDate);
    }

    params['edate'] = getRoundString(now);
    params['legislation'] = legid;
    params['event-date'] = 'occur,effective';
    params['event-type'] = 'modified,amended';

    //don't called the activity service when the consiol date is today or later
    var nowIso = getCutRoundString(now);
    if (consolDate >= nowIso) {
      return;
    }

     //cal the get-activity service and test if any acttivty object are returned
    return TbApi.one(apiUrl).get(params).then(
      function(ret){
        var wrapperObject = WrapperFactory.createWrapperObject(ret);
        if(wrapperObject['data']){
            var activityWrappers = createActivityWrapperObject(wrapperObject['data']);
            return activityWrappers;
        }
      }
    );
  };

  /**
   * @name ActivityService#getActivity
   * @methodOf ActivityFactory
   *
   * @description
   * Calls the TimeBase activity API service and return actvity objects
   *
   * @param {Date} startDate The start date of the time range to for find activity for
   * @param {Date} endDate The end date of the time range to for find activity for
   * @param {String} eventType The type of the event to display.
   * @param {Boolean} detail A switch to display the details of the events. I.e. the data field of the event-object
   * @param {String} legislation The URI id or DocId of the legislation to restrict the activity to.
   * @param {String} jurisdiction A comma separeted list of jurisdiction(s) to restrict the activity to.
   * @param {String} docType A comma separeted list of document-types of the documents to restrict the activity to.
   * @param {Boolean} principal Restricts the activity to principal or not principal legislation.
   * @param {String} subject URI id(s) of the subjects to restrict the activity to.
   * @param {String} profile ID of a profile to restrict the activity to.
   * @param {String} department URI id(s) of the responsible departments to restrict the activity to.
   * @param {Number} start The position of the first item to return.  Used for pagination in combination with count.
   * @param {Number} count The number of items to return. Used for pagination.
   * @param {Number} sort The order to return the results.
   *
   * @returns {ActivityObject[]}
   */
  var getActivity = function(startDate, endDate, eventType, eventDate, detail,
     legislation, jurisdiction, docType, principal, subject, profile, department,
     start, count, sort, selfInitiated)
  {
    console.log('getActivity', startDate);

    if (startDate === undefined) {
      throw "ActivityFactory#getActivity: A startDate parameter is required.";
    }
    if (endDate === undefined) {
      throw "ActivityFactory#getActivity: A endDate parameter is required.";
    }

    var params = {};

    if (startDate !== undefined) {
      console.log('startDate', startDate);
      params['sdate'] = startDate;
    }
    if (endDate !== undefined) {
      params['edate'] = endDate;
    }
    if (eventType !== undefined) {
      params['event-type'] = eventType;
    }
    if (eventDate !== undefined) {
      params['event-date'] = eventDate;
    }
    if (detail !== undefined) {
      params['detail'] = detail;
    }
    if (legislation !== undefined) {
      params['legislation'] = legislation;
    }
    if (jurisdiction !== undefined) {
      params['jurisdiction'] = jurisdiction;
    }
    if (docType !== undefined) {
      params['doc-type'] = docType;
    }
    if (principal !== undefined) {
      params['principal'] = principal;
    }
    if (subject !== undefined) {
      params['subject'] = subject;
    }
    if (profile !== undefined) {
      params['profile'] = profile;
    }
    if (department !== undefined) {
      params['department'] = department;
    }
    if (start !== undefined) {
      params['start'] = start;
    }
    if (count !== undefined) {
      params['count'] = count;
    }
    if (sort !== undefined) {
      params['sort'] = sort;
    }
    if (selfInitiated !== undefined) {
      params['self-initiated'] = selfInitiated;
    }

    //params['sort'] = 'date';

     //cal the get-activity service and build the activity objects
    return TbApi.one(apiUrl).get(params).then(function(ret){
        //console.log('returning activity JSON', ret);
        var wrapperObject = WrapperFactory.createWrapperObject(ret);
        if(wrapperObject['data']){
            var activityWrappers = createActivityWrapperObject(wrapperObject['data']);
            return activityWrappers;
        }
    });
  };

  /* * * * * * * * * *
  * PRIVATE METHODS *
  * * * * * * * * * */

  /**
   * @name ActivityFactory#createActivityObject
   * @methodOf ActivityFactory
   *
   * @description
   * Creates a new ActivityObject from a JSON object
   *
   * @param {object} jsonObject A API JSON activity-object
   *
   * @returns {ActivityObject}
   */
  function createActivityObject(jsonObject) {
      //console.log('createActivityObject called', jsonObject);
      //get the required properties directly from the JSON object
      var legislation = jsonObject['legislation'];
      var events = jsonObject['events'];
      //create a new ActivityObject using the legislation object as is
      var myActivity = new ActivityObject(legislation);
      if(events){
        //console.log('events',events, events.length);
        for(var i = 0; i < events.length; i++){
          var myEvent = createEventObject(events[i]);
          myEvent.activity = myActivity;
          myEvent.populateLinks();
          myActivity.events.push(myEvent);
        }
      }
      myActivity.links = myActivity.getActivityDetailLinks();
      return myActivity;
  }

  /**
   * @name ActivityFactory#createEventObject
   * @methodOf ActivityFactory
   *
   * @description
   * Creates a new EventObject from a JSON object
   *
   * @param {object} jsonObject A API JSON event-object
   *
   * @returns {EventObject}
   */
  function createEventObject(jsonObject) {
    //get the event properties from the JSON object
    var eventType = jsonObject["event-type"];
    var selfInitiated = jsonObject["self-initiated"];
    var occurrences = jsonObject['occurrences'];
    //create a new EventObject
    var myEvent = new EventObject(eventType,selfInitiated);
    //create an EventOccurrenceObject for each occurrences and add them to the event
    if(occurrences){
      for(var i = 0; i < occurrences.length; i++){
        myEvent.occurrences.push(createEventOccurrenceObject(occurrences[i]));
      }
    }
    return myEvent;
  }

  /**
   * @name nActivityFactory#createEventOccurrenceObject
   * @methodOf ActivityFactory
   *
   * @description
   * Creates a new EventOccurrenceObject from a JSON object
   *
   * @param {object} jsonObject A API JSON event-occurrence-object
   *
   * @returns {EventOccurrenceObject}
   */
  function createEventOccurrenceObject(jsonObject) {
    //console.log('createEventOccurenceObject called', jsonObject);
    //get the reuired event occurrence properties from the JSON object
    var eventDate = new Date(jsonObject["event-date"]);
    var dateType = jsonObject["date-type"];
    //create a new EventOccurrenceObject
    var myOccurrence = new EventOccurrenceObject(eventDate,dateType);
    //console.log('createEventOccurenceObject return', myOccurrence);
    //
    myOccurrence.applicableUriId = jsonObject['applicable-uri-id'];
    myOccurrence.applicableDocId = jsonObject['applicable-doc-id'];
    myOccurrence.applicableFragmentId = jsonObject['applicable-fragment-id'];
    myOccurrence.initiatingUriId = jsonObject['initiating-uri-id'];
    myOccurrence.initiatingDocId = jsonObject['initiating-doc-id'];
    myOccurrence.initiatingFragmentId = jsonObject['initiating-fragment-id'];
    myOccurrence.affectedUriId = jsonObject['affected-uri-id'];
    myOccurrence.affectedDocId = jsonObject['affected-doc-id'];
    myOccurrence.affectedFragmentId = jsonObject['affected-fragment-id'];
    myOccurrence.comment = jsonObject['comment'];
    return myOccurrence;
  }

  /**
   * @name nActivityFactory#createActivityWrapperObject
   * @methodOf ActivityFactory
   *
   * @description
   * Takes ret['data'] from the service call, a hal-object.
   * Contains activity array.
   *
   * @see https://ps.allette.com.au/ps/page/timebase-documentation/path/documents/lawone/API/Objects/hal-object.psml
   *
   * @param {object} jsonObject A hal object
   */
  function createActivityWrapperObject(jsonObject){
      //console.log('createActivityWrapperObject called', jsonObject);
      var activityWrapperObject = new ActivityWrapperObject();

      if(jsonObject.hasOwnProperty('activity')) {
        var jsonActivities = jsonObject['activity'];
        for(var i = 0; i < jsonActivities.length; i++){
            activityWrapperObject.activity.push(createActivityObject(jsonActivities[i]));
        }
      }

      if(jsonObject.hasOwnProperty('_links')) {
        angular.forEach(jsonObject['_links'], function(value, key){
            activityWrapperObject['links'][key] = LinkFactory.createLinkObject(jsonObject['_links'][key]);
        });
      }
      return activityWrapperObject;
  }

  /**
   * @name ActivityWrapperObject
   * @class
   *
   * @description
   * ActivityWrapperObject is an class that encapsulates a activity-object
   * as defined in the TimeBase LawOne API.
   */
  function ActivityWrapperObject(){
    /**
     * @type {LinkObject[]}
     */
    this.links = {};
    /**
     * A list of the activity that occurs
     * @type {ActivityObject[]}
     */
    this.activity = [];
  }

  /**
   * @name ActivityObject
   * @class
   *
   * @description
   * ActivityObject is an class that represents a activity-object
   * as defined in the TimeBase LawOne API.
   *
   * @see The
   * <a href="https://ps.allette.com.au/ps/page/timebase-documentation/docid/activity-object">
   * activity-object</a> documentation.
   *
   * @param {object} legislation A Legislation object
   */
  function ActivityObject(legislation) {
    /**
     * The legislation that the activity occurs on.
     * @type {String}
     */
    this.legislation = legislation;
    /**
     * The events the caused the activity to occur
     * @type {EventObject[]}
     */
    this.events = [];
    /**
     * A collection of link to obtain the data that is can be used to get the data that
     * caused the activity.
     * @type {LinkObject{}}
     */
    this.links = {};
  }

  /**
   * @name ActivityObject#hasEventType
   * @methodOf EventObject
   *
   * @description
   * Return the booean indicating if the ActivityObject has a event with the eventType
   * and selfInitiated
   *
   * @param {String} eventType The type of event
   * @param {Boolean} selfInitiated Events with a specifiy selfInitiated value.
   *
   * @returns {Boolen}
   */
  ActivityObject.prototype.hasEventType = function(eventType, selfInitiated){
    //test each of the event for the eventType
    for(var i = 0; i < this.events.length; i++){
      if (this.events[i].eventType === eventType) {
        if (selfInitiated === undefined) {
          return true;
        }
        else
        {
          if (this.events[i].selfInitiated === selfInitiated) {
            return true;
          }
        }
      }
    }
    return false;
  };

  /**
   * @name ActivityObject#hasEventType
   * @methodOf EventObject
   *
   * @description
   * Return the boo;ean indicating if the ActivityObject has a event with the eventType
   * and selfInitiated
   *
   * @param {String}
   *
   * @returns {Boolen}
   */
  ActivityObject.prototype.getActivityDetailLinks = function(){
    //console.log('getActivityDetailLinks called');
    var relevantEvents = this.relevantEvents();
    var detailLinks = {};
    for(var rei = 0; rei < relevantEvents.length; rei++){
      var myEventLinks = relevantEvents[rei].links;
      for (var linkName in myEventLinks) {
        if (! myEventLinks.hasOwnProperty(linkName)) {
          continue;
        }
        //detailLinks[linkName] = myEventLinks[linkName];
        detailLinks[relevantEvents[rei].eventType + "_" + linkName] = myEventLinks[linkName];
        //change this so that we don't have name collisions
        //pick something like the relevant event's type as part of the key
        //like a namespace, separated by a unique character to break from
      }
    }
    //console.log('getActivityDetailLinks object', detailLinks);
    return detailLinks;
  };

  //TODO: Investigate concatenating links that call the same service here.

  /**
   * @name ActivityObject#applicableEventNames
   * @methodOf EventObject
   *
   * @description
   * Return an list of the appicable events names
   *
   * @returns {String[]}
   */
  ActivityObject.prototype.applicableEventNames = function(){
    var relevantEvents = this.relevantEvents();
    var eventNames = [];
    var myEvent;

    //pick the events that the details of activity is needed
    for(var ei = 0; ei < relevantEvents.length; ei++){
      eventNames.push(relevantEvents[ei].getEventName());
    }
    console.log('activity.js ApplicableEventNames called', eventNames);
    return eventNames;
  };

  /**
   * @name ActivityObject#RelevantEvents
   * @methodOf EventObject
   *
   * @description
   * Return an list of the events relevant to the activity
   *
   * @returns {EventObject[]}
   */
  ActivityObject.prototype.relevantEvents = function(){
    var events = [];
    var myEvent;

    //pick the events that the details of activity is needed
    for(var ei = 0; ei < this.events.length; ei++){
      myEvent = this.events[ei];
      var relevantEvent = false;
      //all events that aren't self initiated are important
      if (! myEvent.selfInitiated) {
        relevantEvent = true;
      }
      //'new' events are important
      else if (myEvent.eventType === 'new') {
        relevantEvent = true;
      }
      //'subordinate' events are relevante regardless of other events
      else if (myEvent.eventType === 'subordinate') {
        relevantEvent = true;
      }
      // other types of events aren't need if there is a new event
      // becuase the are included in the new event
      else if (! this.hasEventType('new'))
      {
        relevantEvent = true;
      }
      if (relevantEvent){
        events.push(myEvent);
      }
    }
    return events;
  };

  /**
   * @name EventObject
   * @class
   *
   * @description
   * ActivityObject is an class that represents a event-object
   * as defined in the TimeBase LawOne API.
   *
   * @see The
   * <a href="https://ps.allette.com.au/ps/page/timebase-documentation/docid/event-object">
   * event-object</a> documentation.
   *
   * @param {String} eventType The type of event
   * @param {Boolean} selfInitiated Indicates if the event was initiated by the document it applies to
   */
  function EventObject(eventType, selfInitiated) {
    /**
     * The type of the event.
     * @type {String}
     */
    this.eventType = eventType;
    /**
     * Indicates if the event was initiated by the document it applies to.
     * @type {Boolean}
     */
    this.selfInitiated = selfInitiated;
    /**
     * A list of all the occurrences of the event. Each occurrence represents the time when the event occurred.
     * @type {EventOccurrenceObject[]}
     */
    this.occurrences = [];
    /**
     * A collection of link to obtain the data that is applicable to the event.
     * @type {LinkObject{}}
     */
    this.links = {};
    /**
     * A the ActivityObject the the event belongs to
     * @type {ActivityObject}
     */
    this.activity = null;
  }

  /**
   * @name EventObject#getUniqueCombinedPropertyValues
   * @methodOf EventObject
   *
   * @description
   * Returns a array of unique property values for the specified property names.
   * When multiple property names are specified property value is created by joining each property
   * values with hyphens
   *
   * @param {String[]} propertyNames The array of property names
   *
   * @returns {Array} The name of the event
   */
  EventObject.prototype.getUniqueCombinedPropertyValues = function(propertyNames, comparePropertyNames){
    var uniqueValues = [];
    //process each of the occurences
    for(var i = 0; i < this.occurrences.length; i++){
      var occurrence = this.occurrences[i];
      var propertyValue = this.getOccurrenceValues(occurrence, propertyNames);
      if (comparePropertyNames !== undefined) {
        var comparePropertyValue = this.getOccurrenceValues(occurrence, comparePropertyNames);
        //the comparePropertyValue must be different
        if (propertyValue === comparePropertyValue) {
          continue;
        }
      }
      //only add the propertyValue to the array if it doesn't already exist
      if(propertyValue !== null && uniqueValues.indexOf(propertyValue) == -1){
        uniqueValues.push(propertyValue);
      }
    }
    return uniqueValues;
  };

  /**
   * @name EventObject#getOccurrenceValues
   * @methodOf EventObject
   *
   * @description
   * Returns the property value for the specified property names.
   * When multiple property names are specified property value is created by joining each property
   * values with hyphens
   *
   * @param {String[]} propertyNames The array of property names
   *
   * @returns {object}
   */
  EventObject.prototype.getOccurrenceValues = function(occurrence, propertyNames){
    var propertyValue = null;
    // get the property value for each of the propertyNames
    for(var pi = 0; pi < propertyNames.length; pi++){
      var propertyName = propertyNames[pi];
      if (! occurrence.hasOwnProperty(propertyName)) {
        continue;
      }
      if (occurrence[propertyName]) {
        propertyValue = propertyValue===null ? occurrence[propertyName] : propertyValue+"-"+occurrence[propertyName];
      }
    }
    return propertyValue;
  };

  /**
   * @name EventObject#filterPropertyValues
   * @methodOf filterPropertyValues
   *
   * @description
   * Return the name of the event based on the values of the eventType and selfInitiated
   *
   * @param {String[]} propertyValues An array of property values
   * @param {String} propertyValueSubstr A string that the property value must contain
   *
   * @returns {String[]}
   */
  EventObject.filterPropertyValues = function(propertyValues, propertyValueSubstr){
    var filteredValues = [];
    for(var pvi = 0; pvi < propertyValues.length; pvi++){
      var propertyValue = propertyValues[pvi];
      if (propertyValue.indexOf(propertyValueSubstr) > -1){
        filteredValues.push(propertyValue);
      }
    }
    return filteredValues;
  };

  /**
   * @name EventObject#getEventName
   * @methodOf EventObject
   *
   * @description
   * Return the name of the event based on the values of the eventType and selfInitiated
   *
   * @returns {String} The name of the event
   */
  EventObject.prototype.getEventName = function(){
    var et = this.eventType.toLowerCase();
    //console.log('getEventName called:', this, et);
    //TODO; check for a bill and use a bill specific event name
    var isBill = this.activity.legislation['document-type'] === "Bill";
    //console.log('isBill', isBill);

    console.log('getEventName stuff', this, et, isBill);

    var nameFilter = function(input){
        switch(input) {
          //basic forward only events based on properties
          case 'assent': return 'Assent'; //self-initiated
          case 'commencement': return 'Commenced';
          case 'disallowed by': return 'Disallowed';
          case 'events': return 'Progress';
          case 'expiry': return 'Expires';
          case 'notification': return 'Notification';
          //affecting properties - forward names
          case 'amends': return isBill ? 'Proposes to amend' : 'Amends';
          case 'commences': return isBill ? 'Proposes to commence' : 'Commences';
          case 'repeals': return isBill ? 'Proposes to repeal' : 'Repeals';
          case 'extends operation of': return isBill ? 'Proposed to extend operation' : 'Extends operation';
          case 'modifies': return isBill ? 'Proposes to modify' : 'Modifies';
          //affecting properties - reverse names
          case 'amended': return isBill ? 'Proposed amendment by' : 'Amended';
          case 'commenced': return isBill ? 'Proposed to commencement by' : 'Commenced by'; //self-initiated
          case 'repealed': return isBill ? 'Proposed repeal by' : 'Repealed';
          case 'operation-extended': return isBill ? 'Proposed to extend operation' : 'Operation extended';
          case 'modified': return isBill ? 'Proposed modify by' : 'Modified';
          // determined events
          case 'status': return 'Status';
          case 'update': return 'Updated';
          case 'new': return 'New';
          case 'subordinate': return 'Subordinate';
          //new property name used for principal consolidations
          case 'consolidation': return 'Consolidated';
          //everything else - shouldn't be any thing
          default: return input.substring(0,1).toUpperCase()+input.substring(1);
        }
    };
    var name = nameFilter(et);
    console.log('getEventName output:', name);

    return name;
  };

  /**
   * @name EventObject#populateLinks
   * @methodOf EventObject
   *
   * @description
   * Populautes the link property of the event based on the eventType and occurrences
   * NOTE: The update event is not currently being used.
   */
  EventObject.prototype.populateLinks = function() {
    var applicableLegislation = this.activity.legislation;
    var baseLegnHref = ENV.apiPath + "legislation/" + applicableLegislation['legislation-id'] + "/";
    var linkHref;
    var linkName;
    var amIds, commIds;
    var et = this.eventType.toLowerCase();
    var initiatingUriIds = this.getUniqueCombinedPropertyValues(["initiatingUriId"]);
    var applicableFragmentIds = this.getUniqueCombinedPropertyValues(["applicableFragmentId"]);
    var initiatingComboIds;

    //console.log('populateLinks called', this, initiatingUriIds, applicableFragmentIds);

    if (this.eventType === 'new') {
      //if the legislation is a "Act" or "Ordinance" create a link to get the bills
      if (applicableLegislation['document-type'] === "Act" ||
          applicableLegislation['document-type'] === "Ordinance") {
        this.addLink(new LinkFactory.LinkObject(baseLegnHref + "bill.json", 'bill'));
      }
      this.addLink(new LinkFactory.LinkObject(baseLegnHref + "properties.json", 'properties'));
      this.addLink(new LinkFactory.LinkObject(baseLegnHref + "enabling.json", 'enabling-legislation'));
      //a commencements link is only needed if there are modifies type events
      if (this.activity.hasEventType('commencement', true)) {
        this.addLink(new LinkFactory.LinkObject(baseLegnHref + "commencements.json", 'commencements'));
      }
      //an affect link is only needed if there are modifies type events
      if (this.activity.hasEventType('amends', true) || this.activity.hasEventType('repeals', true)) {
        this.addLink(new LinkFactory.LinkObject(baseLegnHref + "affects.json", 'affects'));
      }
      //a modifies link is only needed if there are modifies type events
      if (this.activity.hasEventType('commences', true) || this.activity.hasEventType('extends operation of', true)) {
        this.addLink(new LinkFactory.LinkObject(baseLegnHref + "modifies.json", 'modifies'));
      }
      if (applicableLegislation['document-type'] === "Bill") {
        //if the legislation is a bill create a link to the enacted legislation
        this.addLink(new LinkFactory.LinkObject(baseLegnHref + "enacted-as.json", 'enacted-as'));
      }
    }

    if (this.eventType === 'subordinate') {
      linkHref = baseLegnHref + "subordinate.json";
      //the get-subordinate-legislation service isn't currently working using URI id's use docIds instead
      var initiatingDocIds = this.getUniqueCombinedPropertyValues(["initiatingDocId"]);
      if (initiatingDocIds.length>0) {
        linkHref += "?subordinate=" + initiatingDocIds;
      }
      this.addLink(new LinkFactory.LinkObject(linkHref, 'subordinate-legislation'));
    }

    if (this.eventType === 'commencement') {
      linkHref = baseLegnHref + "commencements.json";
      if (! this.activity.hasEventType('new')) {
        if (applicableFragmentIds.length>0) {
          linkHref += "?commencements=" + applicableFragmentIds;
        }
      }
      this.addLink(new LinkFactory.LinkObject(linkHref, 'commencements'));
    }

    if (this.eventType === 'assent') {
      this.addLink(new LinkFactory.LinkObject(baseLegnHref + "bill.json", 'bill'));
    }

    //Bills with 'events' link need a link to get-legislation-enacted-as
    if (this.eventType === 'events' && applicableLegislation['document-type'] === "Bill") {
      //if the legislation is a bill create a link to the enacted legislation
      this.addLink(new LinkFactory.LinkObject(baseLegnHref + "enacted-as.json", 'enacted-as'));
    }

    //'events', 'notification'  and 'assent' events need a link need a link to get-legislation-properties
    if (this.eventType === 'events' || this.eventType === 'notification' || this.eventType === 'assent' || this.eventType === 'expiry') {
      linkHref = baseLegnHref + "properties.json";
      if (applicableFragmentIds.length>0) {
        linkHref += "?properties=" + applicableFragmentIds;
      }
      this.addLink(new LinkFactory.LinkObject(linkHref, 'properties'));
    }

    // if(this.eventType === 'expiry'){
    //     console.log('EXPIRY DETECTED', this);
    //     linkHref = baseLegnHref + "properties.json";
    //     console.log('linkHref', linkHref);
    //     this.addLink(new LinkFactory.LinkObject(linkHref, 'expiry'));
    // }

    if (this.eventType === 'amends' || this.eventType === 'repeals' || this.eventType === 'modifies') {
      initiatingComboIds = this.getUniqueCombinedPropertyValues(["initiatingFragmentId"],["applicableFragmentId"]);
      //console.log('initiatingComboIds test:', initiatingComboIds);
      //create a link to get the applicable affecting properties
      linkHref = baseLegnHref + "affects.json?";
      if (applicableFragmentIds.length>0) {
       linkHref += "&affects=" + applicableFragmentIds;
      }
      if (initiatingComboIds.length>0) {
        linkHref += "&commencements=" + initiatingComboIds;
      }
      this.addLink(new LinkFactory.LinkObject(linkHref, 'affects'));
     }

     if (this.eventType === 'amended' || this.eventType === 'repealed' || this.eventType === 'modified') {
      initiatingComboIds = this.getUniqueCombinedPropertyValues(["initiatingUriId","initiatingFragmentId"]);
      amIds = EventObject.filterPropertyValues(initiatingComboIds, "affected");
      commIds = EventObject.filterPropertyValues(initiatingComboIds, "commencement");
      linkHref = baseLegnHref + "affected-by.json?";
      if (amIds.length>0) {
       linkHref += "&affects=" + amIds;
      }
      if (commIds.length>0) {
        linkHref += "&commencements=" + commIds;
      }
      this.addLink(new LinkFactory.LinkObject(linkHref, 'affected-by'));
    }

    if (this.eventType === 'commences' || this.eventType === 'extends operation of') {
      initiatingComboIds = this.getUniqueCombinedPropertyValues(["initiatingFragmentId"],["applicableFragmentId"]);
      linkHref = baseLegnHref + "affects.json?";
      if (applicableFragmentIds.length>0) {
       linkHref += "&affects=" + applicableFragmentIds;
      }
      if (initiatingComboIds.length>0) {
        linkHref += "&commencements=" + initiatingComboIds;
      }
      this.addLink(new LinkFactory.LinkObject(linkHref, 'modifies'));
    }

    if (this.eventType === 'commenced' || this.eventType === 'operation-extended') {
      initiatingComboIds = this.getUniqueCombinedPropertyValues(["initiatingUriId","initiatingFragmentId"]);
      amIds = EventObject.filterPropertyValues(initiatingComboIds, "affected");
      commIds = EventObject.filterPropertyValues(initiatingComboIds, "commencement");
      linkHref = baseLegnHref + "modified-by.json?";
      if (amIds.length>0) {
       linkHref += "&affects=" + amIds;
      }
      if (commIds.length>0) {
        linkHref += "&commencements=" + commIds;
      }
      this.addLink(new LinkFactory.LinkObject(linkHref, 'modified-by'));
    }

    /* case 'modifies':
        break;
    */
  };


  /**
   * @name EventObject#addLink
   * @methodOf EventObject
   *
   * @description
   * EventOccurrenceObject is an class that represents a vent-occurrence-object
   * as defined in the TimeBase LawOne API.
   *
   * @param {Date} name The name (object key) of the link
   * @param {String} A LinkObject
   */
  EventObject.prototype.addLink = function(link,name) {
    if (! name) {
      if (link.name) {
        name = link.name;
      }
      else {
        throw "EventObject#addLink: A link name is required.";
      }
    }
    this.links[name] = link;
  };

  /**
   * @name EventOccurrenceObject
   * @class

   * @description
   * EventOccurrenceObject is an class that represents a vent-occurrence-object
   * as defined in the TimeBase LawOne API.
   *
   * @see The
   * <a href="https://ps.allette.com.au/ps/page/timebase-documentation/docid/event-occurrence-object">
   * vent-occurrence-object</a> documentation.
   *
   * @param {Date} eventDate The date the event occured
   * @param {String} dateType The type of date
   */
  function EventOccurrenceObject(eventDate, dateType) {
    /**
     * The type of the event.
     * @type {String}
     */
    this.eventDate = eventDate;
    /**
     * The type of the event.
     * @type {String}
     */
    this.dateType = dateType;
    /**
     * The URI ID of the document that the event relates to.
     * @type {String}
     */
    this.applicableUriId = null;
    /**
     * The DocID of the document that the event relates to.
     * @type {String}
     */
    this.applicableDocId = null;
    /**
     * TThe ID of the fragment that the event relates to.
     * @type {String}
     */
    this.applicableFragmentId = null;
    /**
     * TThe URI ID of the document that initiates the event.
     * @type {String}
     */
    this.initiatingUriId = null;
    /**
     * The DocID of the document that initiates the event.
     * @type {String}
     */
    this.initiatingDocId = null;
    /**
     * The ID of the fragment that initiates the event.
     * @type {String}
     */
    this.initiatingFragmentId = null;
    /**
     * The type of the event.
     * @type {String}
     */
    this.affectedUriId = null;
    /**
     * The DocID of the document that is affected by the event.
     * @type {String}
     */
    this.affectedDocId = null;
    /**
     * The ID of the fragment that is affected by the event.
     * @type {String}
     */
    this.affectedFragmentId = null;
    /**
     * The comment on the applicable fragment with the label "Editorial".
     * @type {String}
     */
    this.comment = null;
  }

  return {
    getActivity: getActivity,
    getConsolidationEvents: getConsolidationEvents
  };
})

.directive('tbActivityRender', function($compile, TbApi, $filter){
    var linker = function(scope,element,attrs){
        //console.log('tbActivityRender', scope);

        scope.currentFilter = function(legislation){
            if(legislation['legislative-status'] == 'Current'){
                return true;
            }else{
                return false;
            }
        };
        //filter to display principal legislation only
        scope.principalFilter = function(legislation){
            if(legislation['principal'] === true){
                return true;
            }else{
                return false;
            }
        };
        //filter to display principal legislation only
        scope.subjectsFilter = function(subject){
            if(subject['_links'].hasOwnProperty('parent-subjects')){
                return true;
            }else{
                return false;
            }
        };
        scope.propertyTypeFilter = function(documentType, propertyType){
            if (documentType == "Bill") {
                switch(propertyType){
                    case 'Amends': return 'Proposed to Amend';
                    case 'Disallowed by': return 'Proposed to be Disallowed by';
                    case 'Commences': return 'Proposed to Commences';
                    case 'Extends Operation of': return 'Proposed to Extend Operation of';
                    case 'Modifies': return 'Proposed to Modify';
                    case 'Repeals': return 'Proposed to Repeal';
                    case 'Events': return 'Progress';
                    default: return propertyType;
                }
            }
            else {
                switch(propertyType){
                    case 'Events': return 'Progress';
                    default: return propertyType;
                }
            }
        };
        scope.reversePropertyTypeFilter = function(propertyType){
            switch(propertyType){
                case 'Amends': return 'Amended By';
                case 'Disallowed by': return 'Disallowed by';
                case 'Commences': return 'Commenced by';
                case 'Extends Operation of': return 'Operation extended by';
                case 'Modifies': return 'Modified by';
                case 'Notification': return 'Notification';
                case 'Repeals': return 'Repealed by';
                default: return propertyType;
            }
        };
        scope.reverseBillPropertyTypeFilter = function(propertyType){
            switch(propertyType){
                case 'Amends': return 'Proposed Amendment By';
                case 'Disallowed by': return 'Proposed to be Disallowed by';
                case 'Commences': return 'Proposed Commencedment by';
                case 'Extends Operation of': return 'Proposed Operation extended by';
                case 'Modifies': return 'Proposed to be Modified by';
                case 'Notification': return 'Notification';
                case 'Repeals': return 'Proposed to be Repealed by';
                default: return propertyType;
            }
        };

        scope.reverseEventTypeFilter = function(input){
            switch(input){
                case 'commencement':
                    return 'Commenced';
                case 'assent,notification':
                    return 'Assent / Notification';
                case 'modifies':
                    return 'Modified';
                case 'amends':
                    return 'Amended';
                case 'repeals':
                    return 'Repealed';
                case 'events':
                    return 'Bill / Draft progress';
            }
        };

        scope.validActivityCheck = function(activity){
              if(_.isEmpty(activity.links)){
                  return false;
              }else{
                  return true;
              }
        };

        scope.toggleActivityDetails = function(activity){
            //console.log('toggle activity',activity);
            //set the correct icon for spinner

            if(activity){
                activity.isCollapsed = !activity.isCollapsed;
                if(!activity['legislation']['extras']){
                    //console.log('EXTRAS LOADER FIRING');
                    activity['legislation']['extras'] = {};

                    activity.loadCounter = 0;
                    activity.numLinks = _.size(activity['links']);

                    angular.forEach(activity['links'], function(value, okey){

                        //make a call to each link

                        var key = okey.split('_')[1];
                        TbApi.one(value.href .replace(/\/api[^/]*\/[^/]+\//gi,'')).get().then(function(ret){
                            //console.log('RET DATA',ret['data']);
                            //console.log('ACTIVITY KEY', key);

                            //key must not be 'properties'
                            //key must exist
                            //key must have a first child
                            //first child must have a type

                            //this groups the items by their doctype so we have bills and not-bills
                            var billtest = {};
                            if(ret['data']){
                                billtest = _.groupBy(
                                    ret['data'][key],
                                    function(item){
                                        if(item['legislation'] && item['legislation'][0]['document-type'] === 'Bill'){
                                            return 'IsBill';
                                        }else{
                                            return 'NotBill';
                                        }
                                    }
                                );
                            }

                            //and now we do group for everything that is NOT a bill
                            if(billtest['NotBill']){
                                //console.log('NOT BILLS', key, billtest['NotBill']);
                                var newItems = _.groupBy(
                                    billtest['NotBill'],
                                    function(item){
                                        if(item['type']){
                                            return item['type'];
                                        }else{
                                            return 'properties';
                                        }
                                    }
                                );
                                //console.log('NOT BILLS - post process', newItems);

                                //now we deal with not-bills
                                if(ret['data'][key] && ret['data'][key][0] && ret['data'][key][0]['type']){
                                    if(!activity['legislation']['extras'][key]){
                                        //console.log('NOT BILLS - this is NOT already in extras, assigning');
                                        activity['legislation']['extras'][key] = newItems;

                                    }else{
                                        //something's already there, we need to add instead of simply replace
                                        //console.log('NOT BILLS - this is already in extras, concatenating SOURCE', activity['legislation']['extras'][key]);
                                        //.log('ADDITION', newItems);
                                        for(var k in newItems){
                                            activity['legislation']['extras'][key][k] = newItems[k];
                                        }
                                    }
                                }else{
                                    console.log('NOT BILLS - escape');
                                    if(!activity['legislation']['extras'][key]){
                                        activity['legislation']['extras'][key] = ret['data'][key];
                                    }else{
                                        activity['legislation']['extras'][key] =  activity['legislation']['extras'][key].concat(ret['data'][key]);
                                    }
                                }

                                //console.log('NOT BILLS - extras dump', activity['legislation']['extras']);
                            }

                            //and this is for all the bills
                            if(billtest['IsBill']){
                                var billItems = _.groupBy(
                                    billtest['IsBill'],
                                    function(item){
                                        return item['type'];
                                    }
                                );

                                //and bills get special treatment because lol bills
                                if(billItems){
                                    //console.log('GETBILLS', billItems);
                                    if(!activity['legislation']['extras']['procbills']){
                                        activity['legislation']['extras']['procbills'] = billItems;
                                    }else{
                                        $.extend(activity['legislation']['extras']['procbills'], billItems);
                                    }
                                }
                            }

                            activity.loadCounter++;

                            //console.log('EXTRAS',activity['legislation']['extras']);

                            if(activity['legislation']['extras']['properties'] && !activity['legislation']['extras']['gprops']){
                                console.log('PROPS CHECK', activity['legislation']['extras']['properties']);
                                var gProps = _.groupBy(
                                    activity['legislation']['extras']['properties'],
                                    function(item){
                                        return item['property-type'];
                                    }
                                );
                                activity['legislation']['extras']['gprops'] = gProps;
                            }
                        });
                    });
                }
            }
        };

        scope.$on('tbExpandAllActivities', function(event){
            if(scope.activity && !scope.activity.isCollapsed){
                scope.toggleActivityDetails(scope.activity);
            }
        });

        scope.$on('tbCollapseAllActivities', function(event){
            if(scope.activity && scope.activity.isCollapsed){
                scope.toggleActivityDetails(scope.activity);
            }
        });

        if(scope.printMode){
            scope.toggleActivityDetails(scope.activity);
        }
    };

    return{
        restrict: 'A',
        replace: true,
        link: linker,
        scope: {
            activity: '=tbActivityRender',
            selectItem: '&',
            printMode: '='
        },
        templateUrl: 'directives/activityrow.tpl.html'
    };
});
