angular.module( 'tbLawOne.legislation.deeplink', [
  'ui.router',
  'ui.bootstrap',
  'ngSanitize',
  'restangular',
  'tbLawOne.services'
])

.config(function config( $stateProvider ) {
    $stateProvider
        .state( 'deeplink', {
            url: '/legislation/link?juris?title?year?number?scope?doc-type?status?subject?department?principal?lawtracker-id',
            views: {
                "main": {
                    controller: 'LegislationDeeplinkCtrl',
                    templateUrl: 'legislation/deeplink.tpl.html'
                }
            },
            data:{ pageTitle: 'Legislation Link' }
        })
    ;
})

.controller('LegislationDeeplinkCtrl', function LegislationDeeplinkController($scope, $state, $http, $stateParams, TbApi, tbSearchServiceAlt){
    console.log('doing the search thing', $stateParams);
    $scope.rawparams = $stateParams;
    $scope.sparams = {};

    if($stateParams['lawtracker-id']){
        $scope.sparams = { 'lawtracker-id' : $stateParams['lawtracker-id']};
        TbApi.all('search.json').getList($scope.sparams).then(function(ret){
            $scope.sresults = ret['data'];
            var target = ret['data']['documents'][0];

            if(ret['data']['hits'] && ret['data']['hits'] === 1){
                $state.go('legislation',{legId: target['legislation-id'], contId: target['content-id']}, {location: "replace"});
            }else{
                $scope.showError = true;
            }
        });
    }else if($stateParams['juris']){
        $scope.sparams = tbSearchServiceAlt.getSearchParams(tbSearchServiceAlt.parseUrlToObject($stateParams));

        if(!$stateParams['scope']){
            $scope.sparams['scope'] = 'title';
        }

        $scope.sparams['term'] = '"' + $scope.rawparams['title'] + '"';

        TbApi.all('search.json').getList($scope.sparams).then(function(ret){
            $scope.sresults = ret['data'];
            var target = ret['data']['documents'][0];

            if(ret['data']['hits'] && ret['data']['hits'] === 1){
                $state.go('legislation',{legId: target['legislation-id'], contId: target['content-id']}, {location: "replace"});
            }else{
                $scope.showError = true;
            }
        });

        console.log('PARAMS', $scope.sparams);
    }else{
        $scope.showError = true;
    }
})

;
