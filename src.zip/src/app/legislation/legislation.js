angular.module( 'tbLawOne.legislation', [
  'ui.router',
  'ui.bootstrap',
  'ngSanitize',
  'restangular',
  'tbLawOne.directives',
  'tbLawOne.legislation.deeplink',
  'textAngular'
])

.config(function($provide) {
    $provide.decorator('taOptions', ['taRegisterTool', '$delegate', function(taRegisterTool, taOptions) { 
        taOptions.toolbar=[
            ['h1', 'h2'],
            ['bold', 'italics', 'underline', 'ul', 'ol'],
        ];
        return taOptions;
    }]);
})

.config(function config( $stateProvider ) {
    $stateProvider
        .state( 'legmaster', {
            abstract: true,
            views: {
                "main": {
                    controller: 'LegislationCtrl',
                    templateUrl: 'legislation/legislation.tpl.html'
                },
                "col1@legmaster" : {
                    controller: 'LegislationTocCtrl',
                    templateUrl: 'legislation/toc.tpl.html'
                },
                "col2@legmaster" :{
                    controller: 'LegislationHoldCtrl',
                    template: '<div ui-view="content" style="height: 100%;"></div>'
                },
                "col3@legmaster" :{
                    controller: 'LegislationAnnotationCtrl',
                    templateUrl: 'legislation/annotation.tpl.html'
                }
            },
            data:{ pageTitle: 'Legislation' }
        })
        .state('legsummary', {
            abstract: true,
            url: '/legislation/:id',
            views: {
                main: {
                    controller: 'LegislationSummaryCtrl',
                    templateUrl: 'legislation/summary.tpl.html'
                }
            },
            data: { pageTitle: "Legislation Details" }
        })
        .state('legdisplay',{
            parent: 'legsummary',
            url: '',
            views: {
                stab: {
                    controller: 'LegislationDisplayCtrl',
                    templateUrl: 'legislation/display.tpl.html'
                }
            }
        })
        .state('legcases',{
            parent: 'legsummary',
            url: '/cases',
            views: {
                stab: {
                    controller: 'LegislationCasesCtrl',
                    templateUrl: 'legislation/cases.tpl.html'
                }
            }
        })
        .state('legdownloads',{
            parent: 'legsummary',
            url: '/downloads',
            views: {
                stab: {
                    controller: 'LegislationDownloadCtrl',
                    templateUrl: 'legislation/download.tpl.html'
                }
            }
        })
        .state('legtoa',{
            parent: 'legsummary',
            url: '/toa',
            views: {
                stab: {
                    controller: 'LegislationToaCtrl',
                    templateUrl: 'legislation/tabletoa.tpl.html'
                }
            }
        })
        .state('legtol',{
            parent: 'legsummary',
            url: '/tol',
            views: {
                stab: {
                    controller: 'LegislationTolCtrl',
                    templateUrl: 'legislation/tabletol.tpl.html'
                }
            }
        })
        .state('legtov',{
            parent: 'legsummary',
            url: '/tov',
            views: {
                stab: {
                    controller: 'LegislationTovCtrl',
                    templateUrl: 'legislation/tabletov.tpl.html'
                }
            }
        })
        .state('leghistorical', {
            parent: 'legsummary',
            url: '/historical',
            views: {
                stab: {
                    controller: 'LegislationHistoricalCtrl',
                    templateUrl: 'legislation/historical.tpl.html'
                }
            }
        })
        .state('legforward',{
            url: '/legislation/{legId}/content?pass',
            views: {
                main: {
                    controller: 'LegislationForwardCtrl',
                    template: '<div class="container"><div class="cloadcontainer"><div class="cloader">Loading...</div></div></div>'
                }
            },
            data: { pageTitle: "Legislation"}
        })
        .state('legsingle',{
            views: {
                main: {
                    controller: 'LegislationSingleCtrl',
                    template: '<div class="container"><div class="cloadcontainer"><div class="cloader">Loading...</div></div></div>'
                }
            },
            params: {
                contId: null
            },
            data: { pageTitle: "Legislation"}
        })
        .state('legislation',{
            url: '/legislation/{legId}/content/{contId}?term?scope?juris?doc-type?status?subject?department?modifier?page?isprev',
            parent: 'legmaster',
            views: {
                "content" : {
                    controller: 'LegislationSecCtrl',
                    templateUrl: 'legislation/sec.tpl.html'
                }
            },
            resolve: {
                tbLeg: function($stateParams, TbApi, tbSearchServiceAlt){
                    var params = tbSearchServiceAlt.getSearchParams();
                    console.log("tbLeg called", $stateParams, params);
                    return TbApi.one('legislation/' + $stateParams['legId'] + '/content/' + $stateParams['contId'] + '.json').get(params);
                },
                tbParentLeg: function(tbLeg, TbApi, tbUtil){
                    console.log('PARENTAL SUPERVISION',tbLeg);
                    if(tbLeg['data']['_links']['location'] && tbLeg['data']['_links']['location'].length > 0){
                        var parentIds = tbUtil.legParamsClean(tbLeg['data']['_links']['location'][0]['url']);
                        return TbApi.one('legislation/' + parentIds['legId'] + '/content/' + parentIds['contId'] + '.json').get();
                    }else{
                        return false;
                    }
                }
            },
            onEnter: function(tbLeg, tbTrailService, trjurisrevFilter){
                var tempTitle = "";
                console.log('LOCATION',tbLeg['data']['_links']['location']);

                if(tbLeg['data']['_links']['location'][0]){
                    tempTitle += tbLeg['data']['_links']['location'][0]['title'];
                    tempTitle += " ["+trjurisrevFilter(tbLeg['data']['legislation']['jurisdiction']).toUpperCase()+"]";

                    for(var i = 1, len = tbLeg['data']['_links']['location'].length; i < len; i++){
                        tempTitle += (" / " + tbLeg['data']['_links']['location'][i]['title']);
                    }

                    if(tbLeg['data']['legislation']['title'] && tbLeg['data']['legislation']['title']!==''){
                        tempTitle += " / " + tbLeg['data']['legislation']['title'];
                    }
                }else{
                    if(tbLeg['data']['legislation']['title'] && tbLeg['data']['legislation']['title']!==''){
                        tempTitle += tbLeg['data']['legislation']['title'];
                        tempTitle += " ["+trjurisrevFilter(tbLeg['data']['legislation']['jurisdiction']).toUpperCase()+"]";

                        if(tbLeg['data']['legislation']['number'] && tbLeg['data']['legislation']['number'] > 0){
                            tempTitle += " (" + tbLeg['data']['legislation']['number'] + " of " + tbLeg['data']['legislation']['year'] + ")";
                        }
                    }
                }

                console.log('TBLEG', tbLeg);
                console.log('TEMPTITLE', tempTitle);
                this.data.pageTitle = tempTitle;

                //here we construct an object to be pushed to tbTrailService as well
                //THIS IS EXPLICITLY TEMPORARY!
                var trailUrl = "";
                trailUrl = trailUrl = tbLeg['data']['_links']['self']['href'].replace(/\/api[^/]*\/[^/]+/gi,'').split('.json')[0];

                //this is always the parent
                var recentlyUrl = "";
                if(tbLeg['data']['_links']['location'].length > 0){
                    recentlyUrl = tbLeg['data']['_links']['location'][0]['url'].replace(/\/api[^/]*\/[^/]+/gi,'').replace('.json','');
                }else{
                    recentlyUrl = tbLeg['data']['_links']['self']['href'].replace(/\/api[^/]*\/[^/]+/gi,'').split('.json')[0];
                }

                var recentlyTitle = "";
                if(tbLeg['data']['_links']['location'].length > 0){
                    recentlyTitle = tbLeg['data']['_links']['location'][0]['title'] + " ["+trjurisrevFilter(tbLeg['data']['legislation']['jurisdiction']).toUpperCase()+"]";
                }else{
                    recentlyTitle = tempTitle;
                }

                if(tempTitle!==""){
                    tbTrailService.addTrailItem({title: tempTitle,url: trailUrl});
                    tbTrailService.addRecentlyItem({title: recentlyTitle,url: recentlyUrl, status:tbLeg['data']['legislation']['legislative-status']});
                }
            }
        })
        .state('legislation.info',{
            url: '/:sub',
            parent: 'legislation',
            resolve: {
                tbCom: function(TbApi, $stateParams){
                    console.log($stateParams);
                    //console.log('tbcom placeholder firing');
                    switch($stateParams['sub']){
                        case 'commencement':
                            return TbApi.one('legislation/' + $stateParams['legId'] + '/commencements.json').get();
                        default:
                            console.log("nope");
                            break;
                    }
                },
                tbParentLeg: function(tbLeg){
                    //console.log('tbParentLeg called', tbLeg);
                    return tbLeg;
                }
            },
            views: {
                "main@" :{
                    controller: 'LegislationInfoCtrl',
                    templateUrl: 'legislation/subpages/commencement.tpl.html'
                }
            }
        })
    ;//end stateProvider declarations
})

.controller('LegislationAnnotationCtrl', function LegislationAnnotationController($scope, $state, $stateParams, TbApi){
    console.log('Annotation Controller');
    $scope.isAddComm = false;
    $scope.isEditComm = false;
    $scope.isCommDisplay = true;
    $scope.currComments = [];
    $scope.newNoteContent = '';
    $scope.changedComment = {};

    var initCommentsList = function(isNewDisp){
        console.log("Notes display refreshed: ", $scope.legislation);
        var commParaID = $scope.legislation['legislation']['content-doc-id'];
        if(!commParaID){
          commParaID = $scope.legislation['legislation']['content-id'];
        }
        TbApi.one('content/'+ commParaID + '/comments.json')
            .get().then(function(ret){
                if(ret['data']['discussions']){
                    $scope.currComments = ret['data']['discussions'];
                    $scope.$emit('NoteIconStatusChanged', true);                    
                }else{
                    $scope.currComments = [];
                    $scope.$emit('NoteIconStatusChanged', false);
                }
                console.log("Notes display details: ", $scope.currComments);
                if( isNewDisp && $scope.currComments.length < 1 ){
                    $scope.isAddComm = true;
                    $scope.isEditComm = false;
                    $scope.isCommDisplay = false;
                }
        });
    };
    
    $scope.$on('RefreshNotesDisplay', function(e, leg){
        console.log("Notes refresh fired for:", leg);
        var commParaID = leg['legislation']['content-doc-id'];
        if(!commParaID){
          commParaID = leg['legislation']['content-id'];
        }
        TbApi.one('content/'+ commParaID + '/comments.json')
            .get().then(function(ret){
                if(ret['data']['discussions']){
                    $scope.currComments = ret['data']['discussions'];
                    $scope.$emit('NoteIconStatusChanged', true);                    
                }else{
                    $scope.currComments = [];
                    $scope.$emit('NoteIconStatusChanged', false);
                }
                if( $scope.currComments.length < 1 ){
                    $scope.isAddComm = true;
                    $scope.isEditComm = false;
                    $scope.newNoteContent = '';
                    $scope.isCommDisplay = false;
                }else{
                    $scope.isAddComm = false;
                    $scope.isEditComm = false;
                    $scope.isCommDisplay = true;
                }
        });
    });

    initCommentsList(true);

    $scope.backToDisplay = function(){
        $scope.isAddComm = false;
        $scope.isEditComm = false;
        $scope.isCommDisplay = true;
    };

    $scope.editToDisplay = function(){
        $scope.isAddComm = false;
        $scope.isEditComm = false;
        $scope.isCommDisplay = true;
        initCommentsList();
    };

    $scope.toAddDisplay = function(){
        $scope.newNoteContent = '';
        $scope.isAddComm = true;
        $scope.isEditComm = false;
        $scope.isCommDisplay = false;
    };

    $scope.toEditDisplay = function(comment){
        $scope.changedComment = comment;
        $scope.isAddComm = false;
        $scope.isEditComm = true;
        $scope.isCommDisplay = false;
    };

    $scope.onAddComments = function(){
        var commParaID = $scope.legislation['legislation']['content-doc-id'];
        if(!commParaID){
          commParaID = $scope.legislation['legislation']['content-id'];
        }
        var postData = {
            "title": "Note",
            "type": $scope.legislation['legislation']['document-type'],
            "doc-id": commParaID,
            "content": {
                "type": "text/html",
                "data": $scope.newNoteContent
            }
        };
        TbApi.one('comments.json').customPOST(postData).then(function(ret){
            console.log( "Add a new comment:", ret['data'] );
            if(ret['code'] == 200){
                console.log("Add comments successfully!");
            }
            initCommentsList();
        });
        $scope.isAddComm = false;
        $scope.isEditComm = false;
        $scope.isCommDisplay = true;
    };

    $scope.onSaveComments = function(){
        var commParaID = $scope.legislation['legislation']['content-doc-id'];
        if(!commParaID){
          commParaID = $scope.legislation['legislation']['content-id'];
        }
        var putData = {
            "title": $scope.changedComment.title,
            "type": $scope.legislation['legislation']['document-type'],
            "doc-id": commParaID,
            "content": {
                "type": $scope.changedComment.content.type,
                "data": $scope.changedComment.content.data
            }
        };
        TbApi.one('comments/' + $scope.changedComment.id + '.json')
            .customPUT(putData).then(function(ret){
                console.log( "Save comments:", ret['data'] );
                if(ret['code'] == 200){
                    console.log("Save comments successfully!");
                }
                initCommentsList();
        });
        $scope.isAddComm = false;
        $scope.isEditComm = false;
        $scope.isCommDisplay = true;
    };

    $scope.onDeleteComments = function(commentID){
        if(window.confirm('Are you sure you want to delete this comment?')){
            TbApi.one('comments/' + commentID + '.json').customDELETE().then(function(ret){
                console.log( "Delete comment " + commentID + " : ", ret['data'] );
                if(ret['code'] == 200){
                    console.log("Delete comment" + commentID + " successfully!");
                }
                initCommentsList();
            });
            $scope.isAddComm = false;
            $scope.isEditComm = false;
            $scope.isCommDisplay = true;
        }
    };

    $scope.pasteHandler = function(inputHtml){
        return inputHtml.replace(/<script[^>]*>.*<\/script[^>]*>/gm, " ")
                          .replace(/<!--[^-->]*-->/gm, " ")
                            .replace(/<[^>]+>/g, " ")
                              .replace(/\s+-?\d+\s*[\"|\'][^>]*>/g,'');
    };
})

.controller('LegislationForwardCtrl', function LegislationForwardController($scope, $state, $stateParams, TbApi){
    console.log('FORWARDING CONTROLLER FIRED',$stateParams['legId']);
    TbApi.one('legislation/'+ $stateParams['legId'] + '.json').get().then(function(ret){
        var leg = ret['data']['legislation'];

        if(leg['content-id']){
            var params = {
                'legId': $stateParams['legId'],
                'contId': leg['content-id']
            };
            window.location.replace($state.href('legislation', params, {absolute: true}));
        }else{
            window.location.replace($state.href('legdisplay', {id: $stateParams['legId']}, {absolute: true}));
        }
    });
})

.controller('LegislationSingleCtrl', function LegislationSingleForwardController($scope, $state, $stateParams, TbApi){
    console.log('CONTENT FORWARDING CONTROLLER FIRED',$stateParams['contId']);
    TbApi.one('content/'+ $stateParams['contId'] + '.json').get().then(function(ret){
        console.log('CONTENT FORWARDING REQUEST', ret);
        var leg = ret['data']['legislation'];

        if(leg['content-id']){
            var params = {
                'legId': $stateParams['legId'],
                'contId': leg['content-id']
            };
            //window.location.replace($state.href('legislation', params, {absolute: true}));
            $state.go('legislation', {
                legId: leg['legislation-id'],
                contId: leg['content-id']
            },{
                location: 'replace'
            });
        }else{
            //window.location.replace($state.href('legdisplay', {id: $stateParams['legId']}, {absolute: true}));
            $state.go('legdisplay', {
                id: leg['legislation-id']
            },{
                location: 'replace'
            });
        }
    });
})

.controller('LegislationCasesCtrl', function LegislationDownloadController($scope, tbTrailService, $location){
   console.log('temptitle',$scope.tempTitle);
    if($scope.tempTitle){
        $scope.$emit('PageTitleChanged', $scope.tempTitle);
        tbTrailService.addTrailItem({title: $scope.tempTitle + " - Cases", url: $location.url()});
    }

    $scope.renderCases = function(key){
        $scope.gcases[key]['renderon'] = !$scope.gcases[key]['renderon'];
    };

    $scope.setGroup = function(input){
        $scope.gcases = {};
        $scope.gkeys = [];

        console.log('setGroup called', input);
        console.log('dumping cases', $scope.legcases.length);

        if(!input){
            input = 'year';
        }

        $scope.gcases = _.groupBy($scope.legcases , function(item){return item[input];});
        $scope.gkeys = _.keys($scope.gcases).sort();

        if(input == 'year'){
            $scope.gkeys = _.keys($scope.gcases).sort().reverse();
        }else{
            $scope.gkeys = _.keys($scope.gcases).sort();
        }

        if($scope.legcases.length > 99){
            $scope.gcases[$scope.gkeys[0]]['renderon'] = true;
        }else{
            for(var i=0; i<$scope.gkeys.length; i++){
                $scope.gcases[$scope.gkeys[i]]['renderon'] = true;
            }
        }

        console.log('grouping completed', $scope.gkeys);
    };

    $scope.$on('casesLoaded', function(e){
        e.preventDefault();
        $scope.setGroup();
    });

    if($scope.legcases){
        $scope.setGroup();
    }
})

.controller('LegislationHistoricalCtrl', function LegislationDownloadController($scope, tbTrailService, $location){
   console.log('temptitle',$scope.tempTitle);
    if($scope.tempTitle){
        $scope.$emit('PageTitleChanged', $scope.tempTitle);
        tbTrailService.addTrailItem({title: $scope.tempTitle + " - Historical Consolidations", url: $location.url()});
    }
})

.controller('LegislationDownloadCtrl', function LegislationDownloadController($scope, tbTrailService, $location){
   console.log('temptitle',$scope.tempTitle);
    if($scope.tempTitle){
        $scope.$emit('PageTitleChanged', $scope.tempTitle);
        tbTrailService.addTrailItem({title: $scope.tempTitle + " - Downloads", url: $location.url()});
    }
})

.controller('LegislationDisplayCtrl', function LegislationDisplayController($scope, tbTrailService, $location){
    console.log('temptitle',$scope.tempTitle);
    if($scope.tempTitle){
        $scope.$emit('PageTitleChanged', $scope.tempTitle);
        tbTrailService.addTrailItem({title: $scope.tempTitle + " - Details", url: $location.url()});
    }
})

.controller('LegislationToaCtrl', function LegislationToaController($scope, tbTrailService, $location){
    console.log('temptitle',$scope.tempTitle);
    if($scope.tempTitle){
        $scope.$emit('PageTitleChanged', $scope.tempTitle);
        tbTrailService.addTrailItem({title: $scope.tempTitle + " - Table of Amendments", url: $location.url()});
    }
})

.controller('LegislationTolCtrl', function LegislationTolController($scope, tbTrailService, $location){
    console.log('temptitle',$scope.tempTitle);
    if($scope.tempTitle){
        $scope.$emit('PageTitleChanged', $scope.tempTitle);
        tbTrailService.addTrailItem({title: $scope.tempTitle + " - Table of Legislation", url: $location.url()});
    }
})

.controller('LegislationTovCtrl', function LegislationTovController($scope, tbTrailService, $location){
    console.log('temptitle',$scope.tempTitle);
    if($scope.tempTitle){
        $scope.$emit('PageTitleChanged', $scope.tempTitle);
        tbTrailService.addTrailItem({title: $scope.tempTitle + " - Table of Variations", url: $location.url()});
    }
})

.controller('LegislationSummaryCtrl', function LegislationSummaryController($scope, $state, $stateParams, trjurisrevFilter, $modal, TbApi, $sce, $location, CaseFactory, tbTrailService, tbSavedSearchService, tbFavouritesService, tbUserService){

    var subtitle = function(){
        switch($state.current.name){
            case 'legdisplay' : return "Details";
            case 'legdownloads' : return "Downloads";
            case 'legtoa' : return "Table of Amendments";
            case 'legtol' : return 'Table of Legislation';
        }
    };

    $scope.tupd = function(input){
        console.log('tupd', input, $state);
    };

    $scope.browserPrint = function(){
        window.print();
    };

    $scope.currentFilter = function(legislation){
        if(legislation['legislative-status'] == 'Current'){
            return true;
        }else{
            return false;
        }
    };
    //filter to display principal legislation only
    $scope.principalFilter = function(legislation){
        if(legislation['principal'] === true){
            return true;
        }else{
            return false;
        }
    };
    //filter to display principal legislation only
    $scope.subjectsFilter = function(subject){
        if(subject['_links'].hasOwnProperty('parent-subjects')){
            return true;
        }else{
            return false;
        }
    };
    $scope.propertyTypeFilter = function(documentType, propertyType){
        if (documentType == "Bill") {
            switch(propertyType){
                case 'Amends': return 'Proposed to Amend';
                case 'Disallowed by': return 'Proposed to be Disallowed by';
                case 'Commences': return 'Proposed to Commences';
                case 'Extends Operation of': return 'Proposed to Extend Operation of';
                case 'Modifies': return 'Proposed to Modify';
                case 'Repeals': return 'Proposed to Repeal';
                case 'Events': return 'Progress';
                default: return propertyType;
            }
        }
        else {
            switch(propertyType){
                case 'Events': return 'Progress';
                default: return propertyType;
            }
        }
    };
    $scope.reversePropertyTypeFilter = function(propertyType){
        switch(propertyType){
            case 'Amends': return 'Amended By';
            case 'Disallowed by': return 'Disallowed by';
            case 'Commences': return 'Commenced by';
            case 'Extends Operation of': return 'Operation extended by';
            case 'Modifies': return 'Modified by';
            case 'Notification': return 'Notification';
            case 'Repeals': return 'Repealed by';
            default: return propertyType;
        }
    };
    $scope.reverseBillPropertyTypeFilter = function(propertyType){
        switch(propertyType){
            case 'Amends': return 'Proposed Amendment By';
            case 'Disallowed by': return 'Proposed to be Disallowed by';
            case 'Commences': return 'Proposed Commencedment by';
            case 'Extends Operation of': return 'Proposed Operation extended by';
            case 'Modifies': return 'Proposed to be Modified by';
            case 'Notification': return 'Notification';
            case 'Repeals': return 'Proposed to be Repealed by';
            default: return propertyType;
        }
    };

    /*
    Determine the consolidation date of the resource
    by matching the date in the filename
    */
    $scope.getResourceDate = function(resource){
        var dateRe = /\d{4}-\d{2}-\d{2}/g;
        for (var assetKey in resource['assets']) {
             if (! resource['assets'].hasOwnProperty(assetKey)) {
                continue;
            }
            var asset = resource['assets'][assetKey];
            for (var fileKey in asset['files']) {
                 if (! asset['files'].hasOwnProperty(fileKey)) {
                   continue;
                }
                var file = asset['files'][fileKey];
                var dateArray = dateRe.exec(file['filename']);
                if (dateArray !== null && dateArray.length>0) {
                    return dateArray[0];
                }
            }
        }
    };

    ///modals for legislation summary
    $scope.modalProfileOpen = function(){
        console.log('Modal add to profile called');
        var modalInstance = $modal.open({
            templateUrl: 'legislation/summary/modalLegProfile.html',
            controller: 'ModalSumProfileCtrl',
            resolve: {
                breadcrumb: function(){
                    return $scope.legsum;
                }
            }
        });
    };

    //modals for legislation summary
    $scope.modalFavouritesOpen = function(op){
        if(tbUserService.getUserObject() && !tbUserService.isUserIndividual()){
            tbUserService.showShareBlockModal();
        }else{
            console.log('Modal faves called', op);
            var modalInstance = $modal.open({
                templateUrl: 'legislation/summary/modalLegFavourites.html',
                controller: 'ModalSumFavouritesCtrl',
                resolve: {
                    legsum: function(){
                        return $scope.legsum;
                    },
                    op: function(){
                        return op;
                    }
                }
            });

            modalInstance.result.then(function(){
                console.log('Faves modal dismissed!', $scope.legsum, op);
                //add to favourites via TBAPI
                if(op == 'delete'){
                    tbFavouritesService.deleteFavourite($scope.legsum.legislation['doc-id']).then(function(ret){
                        if(ret['data']){
                            $scope.showFaves = false;
                        }
                    });
                }else{
                    tbFavouritesService.addFavourite($scope.legsum.legislation['doc-id']).then(function(ret){
                        if(ret['data'] && ret['data']['favourite']){
                            $scope.showFaves = true;
                        }
                    });
                }
            });
        }
    };

    $scope.modalPrintOpen = function(){
        console.log('Modal print called');

        if($state.current.name == 'legcases'){
            var casesArray = [];
            console.log('legcases dump', $scope.legcases);

            var caseCounter = 0;
            for(var i = 0, len = $scope.legcases.length; i < len; i++){
                if($scope.legcases[i]['isChecked']){
                    casesArray.push($scope.legcases[i]['id']);
                    caseCounter++;

                    if(caseCounter >= 200){
                        break;
                    }
                }
            }

            console.log('casesArray', casesArray);

            var modalInstance = $modal.open({
                templateUrl: 'legislation/summary/modalLegPrint.html',
                controller: 'ModalSumPrintCtrl',
                resolve: {}
            });

            modalInstance.result.then(function(ret){
                console.log('modal closed',ret);
                $state.go('caseprint', {'caseIds':casesArray.join(',')});
            });
        }else{
            $scope.browserPrint();
        }
    };

    $scope.modalDownloadOpen = function(){
        console.log('Modal download called');
        var modalInstance = $modal.open({
            templateUrl: 'legislation/summary/modalLegDownload.html',
            controller: 'ModalSumDownloadCtrl',
            resolve: {

            }
        });

        modalInstance.result.then(function(){
            //$log.info('Print modal dismissed!');
        });
    };

    $scope.modalShareOpen = function(){
        console.log('modal share called');
        var modalInstance = $modal.open({
            templateUrl: 'legislation/summary/modalLegShare.html',
            controller: 'ModalSumShareCtrl',
            resolve: {

            }
        });

        modalInstance.result.then(function(){
            //$log.info('Share modal dismissed!');
        });
    };

    $scope.isObjectEmpty = function(obj){
        return _.isEmpty(obj);
    };

    //ON INIT
    $scope.showProperties = true;
    $scope.showCommencements = true;
    $scope.showAffects = true;
    $scope.showAffectedBy = true;
    $scope.showAffectedByCur = true;
    $scope.showAffectedByFail = true;
    $scope.showModifies = true;
    $scope.showModifiedBy = true;
    $scope.showSubordinate = true;
    $scope.showEnabling = true;
    $scope.showSubjects = true;
    $scope.showDepartments = true;
    $scope.showBill = true;
    $scope.showEnactedAs = true;
    $scope.showFaves = false;

    var firedInit = false;
    var init = function(){
        firedInit = true;
        TbApi.one('legislation/' + $stateParams['id'] + '.json').get()
        .then(function(ret){
            $scope.legsum = ret['data'];
            //clean up empty summary
            if ($scope.legsum['legislation']['summary'] == "<p></p>") {
                delete $scope.legsum['legislation']['summary'];
            }

            var title = $scope.legsum['legislation']['title'];

            if($scope.legsum['legislation']['number'] && $scope.legsum['legislation']['number'] > 0){
                title += " (" + $scope.legsum['legislation']['number'] + " of " + $scope.legsum['legislation']['year'] + ")";
            }

            title += " [" + trjurisrevFilter($scope.legsum['legislation']['jurisdiction']).toUpperCase() + "]";
            console.log('CURRENT',$state.current);

            tbTrailService.addTrailItem({title: ($scope.legsum['legislation']['title'] + " ["+trjurisrevFilter($scope.legsum['legislation']['jurisdiction']).toUpperCase()+"]" + " - " + subtitle()), url: $location.url()});
            $state.current.data.pageTitle = title;
            $scope.tempTitle = title;
            $scope.$emit('PageTitleChanged', title);

            if(tbUserService.getUserObject() && tbUserService.isUserIndividual()){
                tbFavouritesService.getFavourites(50).then(function(ret){
                    console.log('onload favescheck', ret);
                    $scope.faves = ret['data']['favourites'];

                    if($scope.faves){
                        console.log('onload docid',$scope.legsum['legislation']['doc-id']);
                      $scope.showFaves = $scope.faves.some(function(item){
                          if(item['legislation-id'].indexOf($scope.legsum['legislation']['doc-id']) > -1){
                              return true;
                          }else{
                              return false;
                          }
                      });
                    }
                });
            }
        })
        .then(function(){
            TbApi.one('legislation/'+$stateParams['id']+'/tables.json').get()
            .then(function(ret){
                if(ret['data']['tables']['toa']){
                    $scope.legtoa = ret['data']['tables']['toa'];

                    TbApi.one($scope.legtoa['_links']['html']['href'] .replace(/\/api[^/]*\/[^/]+\//gi,'')).get()
                    .then(function(ret){
                        $scope.legtoatable = $sce.trustAsHtml(ret);
                    });
                }
                if(ret['data']['tables']['tol']){
                    $scope.legtol = ret['data']['tables']['tol'];

                    TbApi.one($scope.legtol['_links']['html']['href'] .replace(/\/api[^/]*\/[^/]+\//gi,'')).get()
                    .then(function(ret){
                        $scope.legtoltable = $sce.trustAsHtml(ret);
                    });
                }
                if(ret['data']['tables']['tov']){
                    $scope.legtov = ret['data']['tables']['tov'];

                    TbApi.one($scope.legtov['_links']['html']['href'] .replace(/\/api[^/]*\/[^/]+\//gi,'')).get()
                    .then(function(ret){
                        $scope.legtovtable = $sce.trustAsHtml(ret);
                    });
                }
            });
            //this is for DOWNLOADS
            TbApi.one('legislation/'+$stateParams['id']+'/resources.json').get()
            .then(function(ret){
                if(ret['data']['resources'].length > 0){
                    var resources  = ret['data']['resources'];
                    console.log('resources dump', resources);

                    var latestConsolDate = "0000-00-00";
                    for (var resourceKey in resources) {
                        //it doesn't exist
                        if (! resources.hasOwnProperty(resourceKey)) {
                            continue; //jump over
                        }

                        //set an empty consolidation date if the resource is not a consolidation resource
                        if (resources[resourceKey]['type'] !== "Consolidation") {
                            resources[resourceKey]['consolidation-date'] = "";
                            continue; //jump over
                        }

                        //only happens if neither continue occurs
                        var consoleDate = $scope.getResourceDate(resources[resourceKey]);
                        if (consoleDate) {
                            resources[resourceKey]['consolidation-date'] = consoleDate;
                            if (consoleDate > latestConsolDate) {
                                latestConsolDate = consoleDate;
                            }

                        }
                    }

                    //crazy bullshit to remove zip files from the return
                    //"DO NOT RETURN ZIP FILES" should be a service option
                    //but we'll do it this way since it is not
                    //specifically self-contained code block so this can be easily excised
                    var zipfilter = function(item){
                        //console.log('zipfilter called', item);
                        if(item['extension'] !== 'zip'){
                            return true;
                        }else{
                            return false;
                        }
                    };

                    for (var rk in resources) {
                        //console.log('reskey', resources[rk]);
                        resources[rk]['dast'] = false;
                        resources[rk]['dcas'] = false;

                        var wrk = resources[rk]['assets'];
                        for(var i=0, il=wrk.length;i<il;i++){
                            console.log('w-file',wrk[i]['files']);
                            if(wrk[i]['files'] && wrk[i]['files'].length > 0){
                                wrk[i]['files'] = wrk[i]['files'].filter(zipfilter);
                            }
                            if(wrk[i]['files'] && wrk[i]['files'].length > 0){
                                resources[rk]['dast'] = true;
                            }
                        }

                        var crk = resources[rk]['compilation-asset'];
                        for(var j=0, jl=crk.length;j<jl;j++){
                            console.log('c-file',crk[j]['files']);
                            if(crk[j]['files'] && crk[j]['files'].length > 0){
                                crk[j]['files'] = crk[j]['files'].filter(zipfilter);
                            }
                            if(crk[j]['files'] && crk[j]['files'].length > 0){
                                resources[rk]['dcas'] = true;
                            }
                        }
                    }//end crazy bullshit about zip files

                    //holding arrays
                    var asMadeConsolidation = [];
                    var latestConsolidations = [];
                    var historicalReprints = [];
                    var basicResources = [];
                    var suppResources = [];

                    //big box
                    var dcats = [];

                    console.log('latestConsolDate:', latestConsolDate);

                    for (resourceKey in resources) {
                        if (! resources.hasOwnProperty(resourceKey)) {
                            continue;
                        }
                        switch(resources[resourceKey]['type']){
                            case 'Consolidation':
                                if(resources[resourceKey]['consolidation-date'] === "0001-01-01"){
                                    console.log('AS MADE FOUND');
                                    $scope.asMadeConsolidation = resources[resourceKey];
                                    asMadeConsolidation.push(resources[resourceKey]);
                                } else if (resources[resourceKey]['consolidation-date'] === latestConsolDate) {
                                    latestConsolidations.push(resources[resourceKey]);
                                } else {
                                    historicalReprints.push(resources[resourceKey]);
                                }
                                break;
                            case 'Basic':
                                basicResources.push(resources[resourceKey]);
                                break;
                            case 'Supplementary':
                                suppResources.push(resources[resourceKey]);
                                break;
                            default:
                                break;
                        }
                    }

                    if(asMadeConsolidation.length > 0){
                        var amc = _.groupBy(asMadeConsolidation , function(item){return item['title'];});
                        dcats.push({'As Made':amc});
                    }

                    if(latestConsolidations.length > 0){
                        $scope.latestConsolidations = _.groupBy(latestConsolidations , function(item){return item['title'];});
                        dcats.push({'Latest Consolidation':$scope.latestConsolidations});
                    }
                    if(historicalReprints.length > 0){
                        $scope.historicalReprints = _.groupBy(historicalReprints , function(item){return item['title'];});
                        dcats.push({'Historical Consolidations':$scope.historicalReprints});
                        console.log('history dump',$scope.historicalReprints);
                    }
                    if(basicResources.length > 0){
                        $scope.basicResources = _.groupBy(basicResources , function(item){return item['title'];});
                        dcats.push({'Basic Resources':$scope.basicResources});
                    }
                    if(suppResources.length > 0){
                        $scope.suppResources = _.groupBy(suppResources , function(item){return item['title'];});
                        dcats.push({'Supplemental Resources':$scope.suppResources});
                    }


                    $scope.hasBillDownload = basicResources.some(function(input){
                        if(input['title'] == 'Bill'){
                            return true;
                        }else{
                            return false;
                        }
                    });
                    console.log('$scope.hasBillDownload', $scope.hasBillDownload);

                    //to eliminate bad entries because our data is filthy
                    $scope.dcats = dcats.filter(function(cat){
                        var ret = false;

                        for(var cr1 in cat){
                            for (var cr2 in cat[cr1]){
                                var cr_arr = cat[cr1][cr2];
                                for(var i=0, il=cr_arr.length;i<il;i++){
                                    if(cr_arr[i]['dast'] || cr_arr[i]['dcas']){
                                        ret = true;
                                        break;
                                    }
                                }
                            }
                        }
                        return ret;
                    });
                    //$scope.dcats = dcats;
                    console.log('DANGEROUS CATS', dcats);
                }
            });

            TbApi.one('legislation/'+$stateParams['id']+'/old-titles.json').get()
            .then(function(ret){
                $scope.legoldtitles = ret['data'];
            });

            TbApi.one('legislation/'+$stateParams['id']+'/properties.json').get()
            .then(function(ret){
                if (ret['data']['properties'].length > 0) {
                    //var sorted = _.sortBy(ret['data']['properties'], 'property-effective-date');

                    var working = _.groupBy(ret['data']['properties'], function(item){return item['property-type'];});
                    $scope.legproperties = working;
                }
            });

            TbApi.one('legislation/'+$stateParams['id']+'/commencements.json').get()
            .then(function(ret){
                // ret['data']['commencements'] = _.sortBy(ret['data']['commencements'],function(item){
                //     return item['commencement-date'];
                // }).reverse();

                $scope.legcommencements = ret['data'];
            });

            TbApi.one('legislation/'+$stateParams['id']+'/affects.json').get()
            .then(function(ret){
                if (ret['data']['affects'].length > 0) {
                    $scope.legaffects =  _.groupBy(ret['data']['affects'], function(item){return item['type'];});
                }
            });

            TbApi.one('legislation/'+$stateParams['id']+'/affected-by.json').get()
            .then(function(ret){
                //$scope.legaffectedby = ret['data'];
                var legaffectedby = []; //this is for "Amending Legislation"
                var legaffectedcur = []; //this is for "Current Amending Bills"
                var legaffectedfail = []; //this is for "Failed Amending Bills"
                var legrepealedby = []; //this is for "Repealing legislation"

                for(var i = 0, len = ret['data']['affected-by'].length; i < len; i++){
                    var cur = ret['data']['affected-by'][i];

                    if(cur['legislation'][0]){
                        if(cur['legislation'][0]['document-type'] == 'Bill'){
                            var status = cur['legislation'][0]['legislative-status'];
                            if(status == 'Awaiting Assent' || status == 'Current' || status == 'Draft'){
                                legaffectedcur.push(cur);
                            }else if(status == 'Not in current session' || status == 'Failed'){
                                legaffectedfail.push(cur);
                            }
                        }else{
                            //push repealing legislation into a seperate array
                            if (cur['type'] == "Repeals") {
                                legrepealedby.push(cur);
                            } else {
                                legaffectedby.push(cur);
                            }
                        }
                    }else{
                        console.log('Invalid object in the return for AFFECTED BY',i ,cur);
                    }
                }
                if (legrepealedby.length > 0) {
                    $scope.legrepealedby = legrepealedby;
                }
                if (legaffectedby.length > 0) {
                    $scope.legaffectedby = _.groupBy(legaffectedby, function(item){return item['type'];});
                }
                if (legaffectedcur.length > 0) {
                    $scope.legaffectedcur =  _.groupBy(legaffectedcur, function(item){return item['type'];});
                }
                if (legaffectedfail.length > 0) {
                    $scope.legaffectedfail = _.groupBy(legaffectedfail, function(item){return item['type'];});
                }
            });

            TbApi.one('legislation/'+$stateParams['id']+'/modifies.json').get()
            .then(function(ret){
                $scope.legmodifies = ret['data'];
            });

            TbApi.one('legislation/'+$stateParams['id']+'/modified-by.json').get()
            .then(function(ret){
                //$scope.legmodifiedby = ret['data'];
                $scope.legmodifiedby = _.groupBy(ret['data']['modified-by'], function(item){return item['type'];});
                $scope.showlegmodifiedby = !_.isEmpty($scope.legmodifiedby);
            });

            TbApi.one('legislation/'+$stateParams['id']+'/subjects.json').get()
            .then(function(ret){
                var subjects = [];
                var keyedSubject = [];
                var i, subject, subjectKey;

                //add all the subjects to the keyedSubject object
                for(i = 0, len = ret['data']['subjects'].length; i < len; i++){
                    subject = ret['data']['subjects'][i];
                    //create a subject key based on the self link
                    subjectKey = subject['_links']['self']['href'];
                    //add the the subjects the the keyedSubject object
                    keyedSubject[subjectKey] = subject;
                }

                //add the parent subject to the sub-subjects
                for(i = 0, len = ret['data']['subjects'].length; i < len; i++){
                    subject = ret['data']['subjects'][i];
                    //create a subject key based on the self link
                    subjectKey = subject['_links']['self']['href'];
                    //porcess any subjects that have parent subjects
                    if(subject['_links'].hasOwnProperty('parent-subjects')){
                        for(var psi = 0, pslen = subject['_links']['parent-subjects'].length; psi < pslen; psi++){
                            var parentSubjectKey = subject['_links']['parent-subjects'][psi]['href'];
                            // console.log("Found parent subjects:", parentSubjectKey);
                            if (keyedSubject.hasOwnProperty(parentSubjectKey)) {
                                parentSubject = keyedSubject[parentSubjectKey];
                                //only handle one aprent subject ATM
                                subject['parent-subject'] = parentSubject;
                                subject['parent-subject-id'] = parentSubject['id'];
                                continue;
                            }
                        }
                        subjects.push(subject);
                    }
                }
                $scope.legsubjects = _.groupBy(subjects, function(item){return item['parent-subject-id'];});
                console.log("subjects", $scope.legsubjects);
            });

            TbApi.one('legislation/'+$stateParams['id']+'/departments.json').get()
            .then(function(ret){
                $scope.legdepartments = ret['data'];
            });

            if($scope.legsum['legislation']['document-type'] == "Act" || $scope.legsum['legislation']['document-type'] == "Ordinance" ){
                //this only fires if principal is true
                TbApi.one('legislation/'+$stateParams['id']+'/subordinate.json').get()
                .then(function(ret){
                    console.log('SUBWAY BLUES', ret);
                    $scope.legsubordinate = [];

                    for(var i = 0; i < ret['data']['subordinate-legislation'].length; i++){
                        if(ret['data']['subordinate-legislation'][i]['principal']){
                            $scope.legsubordinate.push(ret['data']['subordinate-legislation'][i]);
                        }
                    }

                    var subgrp = _.groupBy(
                        $scope.legsubordinate,
                        function(item){
                            return item['legislative-status'];
                        }
                    );
                    var subkeys = Object.keys(subgrp).sort();

                    console.log('KEYCHECK', subkeys);
                    $scope.legsubordinate = subgrp;
                    $scope.legsubordinatekeys = subkeys;

                    console.log('GROUPCHECK', subgrp);
                });
            }else{
                //this only fires if principal is false
                TbApi.one('legislation/'+$stateParams['id']+'/enabling.json').get()
                .then(function(ret){
                    $scope.legenabling = ret['data'];
                    // if( ret['data'] && ret['data']['enabling-legislation'] && ret['data']['enabling-legislation'][0]){
                    //   TbApi.one('legislation/'+ret['data']['enabling-legislation'][0]['doc-id']+'/departments.json').get()
                    //                 .then(function(iRet){
                    //     if(iRet['data'] && iRet['data']['departments'] && iRet['data']['departments'].length > 0){
                    //       $scope.legdepartments = iRet['data'];
                    //       ////console.log("want to know iRet", iRet['data']['departments']);
                    //     }
                    //   });
                    // }
                });
            }

            //this only fires if doctype is act
            if($scope.legsum['legislation']['document-type'] == 'Act'){
                TbApi.one('legislation/'+$stateParams['id']+'/bill.json').get()
                .then(function(ret){
                    $scope.legbill = ret['data'];
                });
            }

            //this only fires if doctype is bill and status is assented
            if($scope.legsum['legislation']['document-type'] == 'Bill' && $scope.legsum['legislation']['legislative-status'] == 'Assented'){
                TbApi.one('legislation/'+$stateParams['id']+'/enacted-as.json').get()
                .then(function(ret){
                    $scope.legenactedas = ret['data'];
                });
            }

            //cases
            CaseFactory.hasCases($scope.legsum.legislation['legislation-id']).then(function(ret){
                console.log('caseFactory hascases', ret);
                if(ret){
                    CaseFactory.getCases($scope.legsum.legislation['legislation-id']).then(function(ret){
                        console.log('caseFactory getcases', ret);
                        $scope.legcases = ret;
                        $scope.$broadcast('casesLoaded');
                    });
                }
            });
        });
    }; //end init

    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            if(!firedInit){
                init();
            }
            if(user['user'] && user.isIndividual()){
                $scope.showUserButtons = true;
            }
        },
        true
    );
})

.controller( 'LegislationInfoCtrl', function LegislationInfoController($scope, $state, $stateParams, tbUtil, tbCom, tbParentLeg){
    console.log('Info controller fired', $stateParams);
    var sub = $stateParams['sub'].charAt(0).toUpperCase() + $stateParams['sub'].substring(1);
    $scope.subtitle = sub;
    $scope.leg = tbParentLeg;
    $scope.comms = tbCom;
    $scope.legLink = tbUtil.legLink;
})

.controller( 'LegislationCtrl', function LegislationController( $scope, $q, $window, $state, $stateParams, tbUserService, tbUtil, TbApi, $modal, tbSearchServiceAlt, tbFavouritesService) {
    console.log("Legislation main controller fired");
    console.log("TEST LEG, object response dump");

    //update page title

    $scope.legislation = {};
    //$scope.sectionObject = tbLeg['data'];
    //$scope.tree = tbToc;

    $scope.noprev = false;

    //parses a legislation link and calls state transition
    $scope.legLink = tbUtil.legLink;

    //gets the search object again
    $scope.searchParams = tbSearchServiceAlt.getStateParams();

    if(!_.isEmpty($scope.searchParams)){
        $scope.hasAttachedSearch = true;
    }

    if(tbSearchServiceAlt.isSearchEmpty()){
        $scope.isSearchEmpty = true;
    }

    $scope.searchWithin = function(){
        var title = "";

        if($scope.legislation['_links']['location'][0]){
            title = $scope.legislation['_links']['location'][0]['title'];
        }else{
            title = $scope.legislation.legislation.title;
        }

        $scope.$emit('refineSearch', {
            'searchwithin' : {
                'title': title,
                'id': $scope.legislation.legislation['legislation-id']
            }
        });
    };

    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            if(user['user'] && user.isIndividual()){
                $scope.showUserButtons = true;
            }
            ////If orgID is Timebase
            var tmpOrgID = tbUserService.getOrgID();
            if( tmpOrgID == 1 || tmpOrgID == 172){
                $scope.isSelectedOrg = true;    
            }
            if($scope.legislation.legislation['document-type']=='Bill' || $scope.legislation.legislation['legislative-status']=='Draft'){
                $scope.isSelectedDoc = false;    
            }else{
                $scope.isSelectedDoc = true;
            }
        },
        true
    );

    $scope.returnSearch = function(){
        var params = tbSearchServiceAlt.getStateParams();
        console.log('RETURN TEST', params);
        if(params['scope'] != 'title'){
            params['expand'] = $scope.legislation.legislation['legislation-id'];
        }
        $state.go('search',params,{inherit: false});
    };

    $scope.$on('LegislationSectionChanged', function(e, leg){
        $scope.$broadcast('RefreshNotesDisplay', leg);
        console.log('LEG CTRL:LegislationSectionChanged listener', leg);
        console.log('current leg?', $scope.legislation);

        if(!_.isEmpty($scope.legislation) && leg){
            if($scope.legislation.legislation['legislation-id'] != leg.legislation['legislation-id'] || $scope.legislation.legislation['hits-total'] != leg.legislation['hits-total']){
                $scope.firstLoad = true;
            }
        }
        $scope.legislation = leg;
        $scope.$broadcast('LegislationMasterChanged',leg);
    });

    $scope.tocSnap = function(){
        var toc = $('#uicol1');
        var cur = toc.find("#"+$scope.legislation.legislation['content-id']);
        if(cur.position()){
            toc.scrollTop(toc.scrollTop() + cur.position().top - 15);
        }
    };

    $scope.$on("nodeSelected", function(event, node) {
        $scope.selected = node;
        $scope.$broadcast("selectNode", node);
    });

    //// This fires when the content inside Notes page changed 
    $scope.$on('NoteIconStatusChanged', function(e, v){
        $scope.hasComms = v;
    });
    //this fires when the legislation substate changes
    $scope.firstLoad = true;
    $scope.$on('LegislationMasterChanged', function(e, leg){
        console.log('LEG CTRL: Legislation Master Changed listener fired', leg);
        //$scope.legislation = leg;
        console.log('Current $scope.legislation object:',$scope.legislation);
        if(!_.isEmpty($scope.legislation)){
            if($scope.firstLoad){
                $scope.hierarchy = $scope.populateHierarchy($scope.legislation._links.location);
                $scope.initToc();
                $scope.currentNode = $scope.legislation.legislation['content-id'];

                if(tbUserService.getUserObject() && tbUserService.isUserIndividual()){
                    tbFavouritesService.getFavourites(50).then(function(ret){
                        $scope.faves = ret['data']['favourites'];

                        if($scope.faves){
                            TbApi.one('legislation/' + $scope.legislation['legislation']['legislation-id'] + '.json').get().then(function(ret){
                                $scope.showFaves = $scope.faves.some(function(item){
                                    if(item['legislation-id'].indexOf(ret['data']['legislation']['doc-id']) > -1){
                                        return true;
                                    }else{
                                        return false;
                                    }
                                });
                                console.log('ILKOOI', $scope.showFaves);
                            });
                        }
                    });
                }

                $scope.firstLoad = false;
            }else{
                $scope.currentNode = leg.legislation['content-id'];
                if($scope.isExpandShow){
                    $scope.$broadcast('hierarchyChanged', $scope.populateHierarchy(leg._links.location));
                }
                $scope.tocSnap();
            }
        }

        if(window.innerWidth <= 768){
            var elem = angular.element('.ui-layout-toggler-west').first();
            if(elem.hasClass('ui-layout-toggler-open')){
                elem.trigger('click');
            }
        }
    });

    //this fires on init and sets the root node as $scope.tree
    //check if legislation hierarchy is > 0, so we're not at root node
    $scope.tocTemplate = '';
    $scope.loadInProgress = false;
    $scope.tocVisible = {};
    $scope.tocVisible.lstate = false;
    $scope.tocVisible.rstate = false;

    $scope.initToc = function(){

        console.log("TOC init function fired", $scope.tocVisible.lstate, $scope.tocVisible.rstate);

        $scope.currentNode = {};

        if($scope.legislation._links.location.length > 0){
            console.log('toc child hierarchy', $scope.legislation._links.location);
            var parentIds = extractUrlIDs($scope.legislation._links.location[0].url);
            console.log('searchParams on if: ',tbSearchServiceAlt.getSearchParams());
            TbApi.one('content/' + parentIds['content'] + '/children.json').get(tbSearchServiceAlt.getSearchParams())
            .then(function(ret){
                $scope.rootNode = ret;

                if(window.innerWidth > 768){
                    $scope.tocVisible.lstate = true;
                }
            });
        }else{ //we are at root node
            console.log('searchParams on else:',$scope.searchParams);
            console.log($scope.legislation);

            //TbApi.one('legislation/' + $scope.legislation.legislation['legislation-id'] + '/content/' + $scope.legislation.legislation['content-id'] + '/children.json').get(tbSearchServiceAlt.getSearchParams())
            TbApi.one('content/' + $scope.legislation.legislation['content-id'] + '/children.json').get(tbSearchServiceAlt.getSearchParams())
                .then(function(ret){
                    $scope.rootNode = ret;
                    if(window.innerWidth > 768){
                        $scope.tocVisible.lstate = true;
                    }
                }
            );
        }
    };

    $scope.isExpandShow = true;

    $scope.selectAllContents = function(){

        console.log("Expand TOC init function fired");
        $scope.isExpandShow = false;
        $scope.tocTemplate = '<div>Loading index... <i class="fa fa-spinner fa-spin"></i></div>';
        var tmpContentID = $scope.legislation.legislation['content-id'];
        if($scope.legislation._links.location.length > 0){
            console.log('expand toc child hierarchy', $scope.legislation._links.location);
            var parentIds = extractUrlIDs($scope.legislation._links.location[0].url);
            tmpContentID = parentIds['content'];
            console.log('expand searchParams on if: ',tbSearchServiceAlt.getSearchParams());
            TbApi.one('legislation/' + $scope.legislation.legislation['legislation-id'] + '/content/' + parentIds['content'] + '/descendants.json')
                    .get(tbSearchServiceAlt.getSearchParams()).then(function(ret){
                $scope.rootNode = ret;
                $scope.tocTemplate = '<div ui-tree-all style="margin-left: 0;" ng-model="rootNode[\'data\'][\'children\']" expand-to="hierarchy" selected-id="currentNode" attr-node-id="id" leg-id="' + $scope.legislation.legislation['legislation-id'] + '" content-doc-id="' + tmpContentID + '" all-chaps-collapse="true"></div>';
            });
        }else{ //we are at root node
            console.log('expand searchParams on else:',$scope.searchParams);
            console.log($scope.legislation);

            TbApi.one('legislation/' + $scope.legislation.legislation['legislation-id'] + '/content/' + $scope.legislation.legislation['content-id'] + '/descendants.json')
                    .get(tbSearchServiceAlt.getSearchParams()).then(function(ret){
                $scope.rootNode = ret;
                $scope.tocTemplate = '<div ui-tree-all style="margin-left: 0;" ng-model="rootNode[\'data\'][\'children\']" expand-to="hierarchy" selected-id="currentNode" attr-node-id="id" leg-id="' + $scope.legislation.legislation['legislation-id'] + '" content-doc-id="' + tmpContentID + '" all-chaps-collapse="true"></div>';
            });
        }
    };

    //function to get the two ID numbers out of a legislation URL
    function extractUrlIDs(input){
        //this gets the ultimate parent
        var ret = {};
        var arr = input.split('/');
        var fil = _.filter(arr, function(item){ return item !== ""; });
        ret['legislation'] = fil[3];
        ret['content'] = fil[5].replace('.json','');
        return ret;
    }

    //fill array of nodes to open by tree
    $scope.populateHierarchy = function(hierarchy){
        var ret = "";
        for(var i = 1;i<hierarchy.length;i++){
            var nodeid = extractUrlIDs(hierarchy[i]['url'])['content'];
            ret = ret += (nodeid + ",");
        }
        ret = ret.slice(0,-1);
        console.log("Populating hierarchy object!",ret);
        return ret;
    };

    $scope.dumpToc = function(){
        console.log($scope.tree);
    };

//    $scope.currentlyLoading = false;
    $scope.loadChildren = function(nodeID){
        return TbApi.one('legislation/' + $scope.legislation.legislation['legislation-id'] + '/content/' + nodeID + '/children.json').get(tbSearchServiceAlt.getSearchParams());
    };

    //get the currently ticked items from the TOC tree
    $scope.getSelectedItems = function(){
        var results = [];
        var trawl = function(set){
            console.log('Calling trawl!', set);
            for(var i=0;i<set.length;i++){
                if(set[i]['checked']){
                    results.push(set[i]['id']);
                }
                else if(set[i]['has-children'] && set[i]['children']){
                    ////if(set[i]['children']['data']){
                    trawl(set[i]['children']['data']['children']);
                    ////}else{
                    ////    trawl(set[i]['children']);
                    ////}
                }
            }
        };

        trawl($scope.rootNode.data.children);

        if(results.length > 0){
            console.log('Trawled results',results);
            return results;
        }else{
            console.log("Nothing checked");
            return false;
        }
    };

    $scope.linkAlertPass = function(href, type){
        var isprev = false;
        switch(type){
            case 'prev-page':
                if($scope.legislation['_links']['previous-page']['href'] == 'null'){alert('There is no page before the current page.');}
                isprev = true;
                break;
            case 'next-page':
                if($scope.legislation['_links']['next-page']['href'] == 'null'){alert('There is no page after the current page.');}
                break;
            case 'prev-hit':
                if($scope.legislation['_links']['previous-hit']['href'] == 'null'){alert('There are no hits before the current page.');}
                break;
            case 'next-hit':
                if($scope.legislation['_links']['next-hit']['href'] == 'null'){alert('There are no hits after the current page.');}
                break;
        }

        if(href !== null && href !== 'null'){
            if(isprev){
                var params = tbUtil.legParams(href);
                params['isprev'] = true;
                console.log(params);
                $state.go('legislation', params, {inherit: false});
            }else{
                $scope.legLink(href);
            }
        }
    };

    $scope.getModalBreadcrumb = function(){
        return $scope.legislation;
    };

    //modal functions for legislation full content
    $scope.modalFavouritesOpen = function(op){
        if(tbUserService.getUserObject() && !tbUserService.isUserIndividual()){
            tbUserService.showShareBlockModal();
        }else{

            console.log('Modal faves called', $scope);
            var modalInstance = $modal.open({
                templateUrl: 'legislation/modalLegFavourites.html',
                controller: 'ModalLegFavouritesCtrl',
                resolve: {
                    legsum: function(){
                        return $scope.legislation;
                    },
                    op: function(){
                        return op;
                    }
                }
            });

            modalInstance.result.then(function(){
                console.log('Faves modal dismissed!');
                //add to favourites via TBAPI
                console.log('scope legislation', $scope.legislation.legislation);
                TbApi.one('legislation/' + $scope.legislation.legislation['legislation-id'] + '.json').get().then(function(ret){
                    console.log('FAVETEST', ret);
                    if(op == 'delete'){
                        tbFavouritesService.deleteFavourite(ret['data']['legislation']['doc-id']).then(function(ret){
                            if(ret['data']){
                                $scope.showFaves = false;
                            }
                        });
                    }else{
                        tbFavouritesService.addFavourite(ret['data']['legislation']['doc-id']).then(function(ret){
                            if(ret['data'] && ret['data']['favourite']){
                                $scope.showFaves = true;
                            }
                        });
                    }
                });
            });
        }
    };

    //
    //
    //ANCHOR MODALPROFILE
    $scope.modalProfileOpen = function(){
        console.log('Modal add to profile called');
        var modalInstance = $modal.open({
            templateUrl: 'legislation/modalLegProfile.html',
            controller: 'ModalLegProfileCtrl',
            resolve: {
                breadcrumb: function(){
                    return $scope.getModalBreadcrumb();
                }
            }
        });
    };

    $scope.modalPrintOpen = function(){
        console.log('Modal print called');
        var modalInstance = $modal.open({
            templateUrl: 'legislation/modalLegPrint.html',
            controller: 'ModalLegPrintCtrl',
            resolve: {
                searchItems: function(){
                    return $scope.getSelectedItems();
                },
                breadcrumb: function(){
                    return $scope.getModalBreadcrumb();
                }
            }
        });

        modalInstance.result.then(function(ret){
            console.log('modal print fired, return',ret);
            if(ret.title == 'selected'){
                if($scope.getSelectedItems()){
                    var ids = $scope.getSelectedItems().join(',');
                    $window.open('/print?root='+$scope.legislation['legislation']['legislation-id']+'&ids=' + ids, '_blank');
                }
            }else if(ret.title == 'full'){
                $window.open('/print?root='+$scope.legislation['legislation']['legislation-id']+'&ids=' + $scope.legislation['legislation']['content-id'], '_blank');
            }else{
                var params = tbUtil.legParams(ret.title);
                $window.open('/print?root='+params['legId']+'&ids='+params['contId'], '_blank');
            }
        });
    };

    $scope.modalDownloadOpen = function(){
        console.log('Modal download called');
        var modalInstance = $modal.open({
            templateUrl: 'legislation/modalLegDownload.html',
            controller: 'ModalLegDownloadCtrl',
            resolve: {
                searchItems: function(){
                    return $scope.getSelectedItems();
                },
                breadcrumb: function(){
                    return $scope.getModalBreadcrumb();
                }
            }
        });

        modalInstance.result.then(function(){
            //$log.info('Print modal dismissed!');
        });
    };

    $scope.modalShareOpen = function(){
        console.log('modal share called');
        var modalInstance = $modal.open({
            templateUrl: 'legislation/modalLegShare.html',
            controller: 'ModalLegShareCtrl',
            resolve: {
                searchItems: function(){
                    return $scope.getSelectedItems();
                },
                breadcrumb: function(){
                    return $scope.getModalBreadcrumb();
                }
            }
        });

        modalInstance.result.then(function(){
            //$log.info('Share modal dismissed!');
        });
    };
})

.controller( 'LegislationTocCtrl', function LegislationTocController($scope, $stateParams, TbApi, Restangular, $timeout, tbSearchServiceAlt) {
    console.log("Legislation TOC controller fired");

})

.controller('LegislationHoldCtrl', function LegislationHoldController($scope){
    //$scope.$parent.legislation = $scope.legislation;
})

.controller( 'LegislationSecCtrl', function LegislationSecController($scope, $rootScope, $state, $location, $timeout, CaseFactory, tbLeg, tbParentLeg, $stateParams, $sce, TbApi, highlightFilter, trjurisrevFilter, $modal, $aspopover) {
    console.log("Legislation section controller fired",$stateParams);

    $scope.$on('showRedFlag', function(){
        console.log('red flag event received');
        $scope.legislation['legislation'].showRedFlag = true;
    });

    var statcheck = function(str){
        switch(str){
            case 'Repealed legislation' : return "*** REPEALED"; //error
            case 'Repealed' : return "*** REPEALED";
            case 'Inoperative legislation': return "*** INOPERATIVE"; //error
            case 'Inoperative': return "*** INOPERATIVE";
            case 'Failed bill': return "*** FAILED"; //error
            case 'Failed': return "*** FAILED";
            case 'Assented bill': return "*** ASSENTED"; //error
            case 'Assented': return "*** ASSENTED";
            case 'Awaiting Assent': return "*** AWAITING";
            case 'Spent legislation': return "*** SPENT"; //error
            case 'Spent': return "*** SPENT";
            case 'Draft': return '*** DRAFT';
            case 'Not in current session': return "*** NICS";
            default: return "";
        }
    };

    $scope.legislation = tbLeg['data'];
    console.log('scope legislation', $scope.legislation);
    //$scope.$parent.$parent.legislation = $scope.legislation;
    if(tbParentLeg){
        $scope.parentLeg = tbParentLeg['data']['legislation'];
    }

    TbApi.one('legislation/'+$stateParams['legId']+'/properties.json').get()
    .then(function(ret){
        console.log('leg props', ret);
        if (ret['data']['properties'].length > 0) {
            var sorted = _.sortBy(ret['data']['properties'], 'property-effective-date');
            var working = _.groupBy(sorted, function(item){return item['property-type'];});
            $scope.legproperties = working;
        }
    });

    CaseFactory.hasCases($scope.legislation.legislation['legislation-id'], $scope.legislation.legislation['content-id']).then(function(ret){
        console.log('CASES CONTENT CHECK', ret);
        if(ret){ $scope.legislation['hascases'] = true; }
    });

    $scope.appendTitle = "";
    $scope.appendStatus = statcheck($scope.legislation.legislation['legislative-status']);


    if($scope.legislation['_links']['location'].length === 0) {
        if($scope.legislation.legislation['number'] && $scope.legislation.legislation['number'] > 0 && $scope.legislation.legislation['year']){
            $scope.appendTitle += (" - No. " + $scope.legislation.legislation['number'] + " of " + $scope.legislation.legislation['year'] );
        }
        
        if($scope.legislation.legislation['consolidation-date']){
            $scope.appendTitle += " - ";
            if ($scope.legislation.legislation['consolidation-date'] == '0001-01-01') {
                $scope.appendTitle += "As made";
            } else {
                $scope.appendTitle += processConDate($scope.legislation.legislation['consolidation-date']);
            }
            
        }
    }

    console.log('LEGOBJ',$scope.legislation);

    function processConDate(date){
        console.log('processConDate', date);
        var cDate = new Date(date.replace(/-/g, "/"));
        var str = "";

        if(date == '0001-01-01'){
            if($scope.legislation['legislation']['document-type'] == 'Act'){
                str += "At Assent";
            }else if($scope.legislation['legislation']['document-type'] == 'Regulation'){
                str += "At Notification";
            }
        }else{
            str += "Updated on ";

            var monthnames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            var day = cDate.getDate();
            var month = monthnames[cDate.getMonth()];
            var year = cDate.getFullYear();

            str += day + " " + month + " " + year;
        }

        console.log('processConDate string', str);
        return str;
    }

    $scope.updatePageTitle = function(leg){
        console.log('update page title called', leg);

        var tempTitle = "";

        if(leg['_links']['location'][0]){
            tempTitle += leg['_links']['location'][0]['title'];
            tempTitle += " [" + trjurisrevFilter(leg['legislation']['jurisdiction']).toUpperCase() + "]";

            for(var i = 1, len = leg['_links']['location'].length; i < len; i++){
                tempTitle += (" / " + leg['_links']['location'][i]['title']);
            }

            tempTitle += " / " + tbLeg['data']['legislation']['title'];
        }else{
            tempTitle += leg['legislation']['title'];

            if(leg['legislation']['number'] && leg['legislation']['number'] > -1){
                tempTitle += " (" + leg['legislation']['number'] + " of " + tbLeg['data']['legislation']['year'] + ")";
            }
        }

        $state.current.data['pageTitle'] = tempTitle;
        $scope.$emit('PageTitleChanged', tempTitle);
    };

    $scope.updatePageTitle($scope.legislation);

    //$scope.$emit('LegislationSectionChanged', $scope.legislation.legislation['content-id']);
    $scope.$emit('LegislationSectionChanged', $scope.legislation);

    //REDIRECT HELL
    if($scope.legislation.legislation['legislation-doc-id'] && $scope.legislation.legislation['content-doc-id']){
        var newUrl = "/legislation/content/" + $scope.legislation.legislation['content-doc-id'];
        $rootScope.locationSpoof(newUrl);
    }else{
        console.log('Cannot redirect, missing stuff', $scope.legislation.legislation);
    }

    //CONTENT RENDER SECTION

    var pushHtmlContent = function(){
        console.log('pushHtmlContent',$scope.legislation);

        $scope.contentLink = $scope.legislation['legislation']['_links']['html']['href'] .replace(/\/api[^/]*\/[^/]+\//gi,'');
        $scope.highlightText = $scope.searchParams['term'];

        if($scope.searchParams['modifier'] && $scope.searchParams['modifier'] !== ""){
            $scope.highlightMod = $scope.searchParams['modifier'];
        }
            if($scope.searchParams['scope'] && $scope.searchParams['scope'] !== ""){
            $scope.highlightMod = $scope.searchParams['scope'];
        }

        //this is for content - insert PDF shit here
        $scope.loadingContent = true;
        TbApi.one($scope.contentLink).get().then(function(item){
            $scope.contentText = $sce.trustAsHtml(item);
            $scope.loadingContent = false;
        });
    };

    //picks up PDF viewer
    var getAcrobatInfo = function() {

      var getBrowserName = function() {
        return this.name = this.name || (function() {
          var userAgent = navigator ? navigator.userAgent.toLowerCase() : "other";

          if(userAgent.indexOf("chrome") > -1)        {return "chrome";}
          else if(userAgent.indexOf("safari") > -1)   {return "safari";}
          else if(userAgent.indexOf("msie") > -1)     {return "ie";}
          else if(userAgent.indexOf("firefox") > -1)  {return "firefox";}
          return userAgent;
        }());
      };

      var getActiveXObject = function(name) {
        try { return new ActiveXObject(name); } catch(e) {}
      };

      var getNavigatorPlugin = function(name) {
        for(var key in navigator.plugins) {
          var plugin = navigator.plugins[key];
          if(plugin.name == name) {return plugin;}
        }
      };

      var getPDFPlugin = function() {
        return this.plugin = this.plugin || (function() {
          if(getBrowserName() == 'ie') {
            //
            // load the activeX control
            // AcroPDF.PDF is used by version 7 and later
            // PDF.PdfCtrl is used by version 6 and earlier
            return getActiveXObject('AcroPDF.PDF') || getActiveXObject('PDF.PdfCtrl');
          }
          else {
            return getNavigatorPlugin('Adobe Acrobat') || getNavigatorPlugin('Chrome PDF Viewer') || getNavigatorPlugin('WebKit built-in PDF');
          }
        }());
      };

      var isAcrobatInstalled = function() {
        return !!getPDFPlugin();
      };

      var getAcrobatVersion = function() {
        try {
          var plugin = getPDFPlugin();

          if(getBrowserName() == 'ie') {
            var versions = plugin.GetVersions().split(',');
            var latest   = versions[0].split('=');
            return parseFloat(latest[1]);
          }

          if(plugin.version) {return parseInt(plugin.version,10);}
          else{ return plugin.name; }
        }
        catch(e) {
          return null;
        }
      };

      //
      // The returned object
      //
      return {
        browser:        getBrowserName(),
        acrobat:        isAcrobatInstalled() ? 'installed' : false,
        acrobatVersion: getAcrobatVersion()
      };
    };

    //let's see if there is a pdf
    console.log('PDF CHECK', $scope.legislation['legislation']['_links']['pdf']);

    //Check if we are a bill AND we are on root node, IF we are, we need to go to first child
    //TODO: change this so that it checks to see if the node has children, and if so, goes to first child
    if($scope.legislation['legislation']['document-type'] == 'Bill' && $scope.legislation['_links']['location'].length === 0){
        console.log('WE ARE BILL ROOT', $scope.legislation);
        $scope.$parent.$parent.noprev = true;
        $state.go('legislation', {
            legId: $scope.legislation['legislation']['legislation-id'],
            contId: $scope.legislation['_links']['next-page']['href'].replace('.json','').split('/')[6]
        },{
            location: 'replace'
        });
    }else{
        console.log('PDF POSTCHCK', $scope.legislation);
        var parentContId = 0;
        var prevContId = -1;
        if ($scope.legislation['_links']['location'].length > 0)
        {
          parentContId = $scope.legislation['_links']['location'][0]['url'].replace('.json','').split('/')[6];
        }
        console.log('PDF POSTCHCK 1', $scope.legislation);
        if ($scope.legislation['_links']['previous-page']['href'])
        {
          prevContId = $scope.legislation['_links']['previous-page']['href'].replace('.json','').split('/')[6];
        }
        console.log(parentContId, prevContId);
        if(parentContId == prevContId){
            console.log('WE ARE ON FIRST CHILD', $scope);
            $scope.$parent.$parent.noprev = true;
        }else{
            $scope.$parent.$parent.noprev = false;
        }

        //now we see if what we are on has children of its own
        if($scope.legislation['legislation']['document-type'] == 'Bill' && $scope.legislation.legislation['title'].indexOf("Pages") > -1){
            console.log('WE ARE ON A BILL AND IT IS NOT AN IMAGE',$scope.legislation);

            if($stateParams['isprev'] && $scope.legislation['_links']['previous-page']['href'] !== 'null'){
                $state.go('legislation', {
                    legId: $scope.legislation['legislation']['legislation-id'],
                    contId: $scope.legislation['_links']['previous-page']['href'].replace('.json','').split('/')[6]
                },{
                    location: 'replace',
                    inherit: false
                });
            }else{
                $state.go('legislation', {
                    legId: $scope.legislation['legislation']['legislation-id'],
                    contId: $scope.legislation['_links']['next-page']['href'].replace('.json','').split('/')[6]
                },{
                    location: 'replace',
                    inherit: false
                });
            }
        }

        if($scope.legislation['legislation']['document-type'] == 'Bill' && $scope.legislation['legislation']['_links']['pdf']){
        //if(false){
            var pluginfo = getAcrobatInfo();
            console.log('DETECT PDF PLUGIN', pluginfo.browser, pluginfo.acrobat, pluginfo.acrobatVersion);

            var isIE11 = !!navigator.userAgent.match(/Trident\/7\./);

            console.log('isIE11', isIE11);

            // if(isIE11){
            //     pushHtmlContent();
            // }else{
                if(pluginfo.acrobat == 'installed'){

                    var pnum = 0;
                    if($scope.legislation.legislation['title'].indexOf("Pages") > -1){
                        console.log('LUL DO NOTHING');
                        //pushHtmlContent();
                    }else{
                        var re = /page0*(\d+)\.html$/g;
                        pnum = re.exec($scope.legislation['legislation']['_links']['html']['href']);

                        console.log('PIN',$scope.legislation['legislation']['_links']['html']['href']);
                        console.log('PNUM',pnum);

                        $scope.highlightText = $scope.searchParams['term'];
                        $scope.contentPdf = $scope.legislation['legislation']['_links']['pdf'];

                        if(pnum){
                            $scope.pdfPageNo = pnum[1];
                        }

                        $timeout(function(){
                            console.log('FIRING IE window resize event');
                            $('#tbPdfInstance').css("padding-left","0px");
                        }, 200);
                    }
                }else{
                    console.log('PUSH HTML 1');
                    pushHtmlContent();
                }
            //}
        }else{
            console.log('PUSH HTML 2');
            pushHtmlContent();
        }
    }

    $scope.addInfoboxAssentData = function(){
        TbApi.one('legislation/' + $scope.legislation['legislation']['legislation-id'] + '/properties.json').get().then(function(ret){
            $scope.assentInfo = ret['data']['properties'];
            console.log('ASSENT',$scope.assentInfo);
        });
    };

    $scope.demoHighlight = function(){
        console.log('CAPTURED',window.getSelection());
        $scope.modalDemoAnnotate(window.getSelection().toString());
    };

    $scope.modalDemoAnnotate = function(input){
        console.log('modalDemoAnnotate',input);
        var modalInstance = $modal.open({
            templateUrl: 'legislation/modals/demoannotate.tpl.html',
            controller: 'ModalLegDemoAnnotateCtrl',
            windowClass: "modal-large",
            resolve: {
                selectedText: function(){
                    return input;
                }
            }
        });
    };

        //modal functions
    $scope.modalCommOpen = function(target){
        //var subtarget = 'commencements';
        console.log(target);
        var subtarget = '';
        switch(target){
            case 'commencements':
                subtarget = 'commencements';
                break;
            case 'subordinate':
                subtarget = 'subordinate';
                break;
            case 'enabling':
                subtarget = 'enabling';
                break;
            case 'departments':
                subtarget = 'departments';
                break;
        }

        var modalInstance = $modal.open({
            templateUrl: 'legislation/modals/'+subtarget+'.tpl.html',
            controller: 'ModalLegCommCtrl',
            windowClass: "modal-large",
            resolve: {
                tbCom: function(TbApi, $stateParams){
                    return TbApi.one('legislation/' + $stateParams['legId'] + '/'+ subtarget +'.json').get();
                },
                tbLegParent: function(){
                    return $scope.legislation;
                }
            }
        });

        modalInstance.result.then(function(){
            //$log.info('Share modal dismissed!');
        });
    };

    //YES I KNOW THIS IS HERESY
    //EXPLICITLY TEMPORARY UNTIL I CAN FIGURE OUT
    //WHY THE FUCK ANGULARSTRAP POPOVER IS DYING
    $scope.toggleCurrencyPop = function(){
        console.log('trying to toggle currency popover');
        var elem = angular.element('#currency-popover-anchor');
        elem.trigger('click');
    };
})

//ANCHOR

.controller('ModalLegFavouritesCtrl', function($scope, $modalInstance, op, legsum, TbApi){
    $scope.legsum = legsum;
    $scope.op = op;

    if(legsum['_links']['location'][0]){
        $scope.legtitle = legsum['_links']['location'][0]['title'];
    }else{
        $scope.legtitle = legsum['legislation']['title'];
    }

    console.log('LEGSUM',legsum);

    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})

.controller('ModalLegDemoAnnotateCtrl', function($scope, $modalInstance, selectedText, TbApi){
    $scope.selectedText = selectedText;
    $scope.annotation = "Mining exclusion in the spotlight.\r\nIn Thiess Pty Ltd v Warren Brothers Earthmoving Pty Ltd & Anor [2012] QCA 276 the Queensland Court of Appeal considered the application of the BCIP Act to the mining industry.\r\n·         The decision provides important guidance as to the operation of s10(3) of the Act.\r\n·         Decision confirms that mining activities that do not involve the direct extraction of minerals are unlikely to be excluded from the operation of the Building and Construction Industry Payments Act 2004 (Qld) (the Act).\r\n·         Decision adopts a more narrow interpretation of the 'mining exclusion' so potentially additional payment claims.\r\n·         When scope of works under a contract contains both ‘construction worlk’ and work that is not construction work, the entire scope of works under the contract will be a ‘construction contract’ for the purposes of the Act.\r\n·         Determination by an adjudicator not invalidated if they make an error when determining the extent to which a payment claim relates to work regulated by the Act.";

    $scope.ok = function() {
        $modalInstance.close(annotation);
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})

.controller('ModalLegProfileCtrl', function($scope, $modalInstance, breadcrumb, TbApi){
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };


    if(breadcrumb['_links']['location'][0]){
        $scope.legtitle = breadcrumb['_links']['location'][0]['title'];
    }else{
        $scope.legtitle = breadcrumb['legislation']['title'];
    }


    $scope.addToProfile = function(profile){
        console.log('add profile',profile);
        console.log('crumbs', breadcrumb);

        var existing = [];

        TbApi.one('profiles/'+profile['id']+'/legislation.json').get()
        .then(function(ret){
            console.log('load existing legs', ret);
            //make a list of existing legislation by item
            for(var i = 0, vlen = ret['data']['tracked-legislation'].length; i < vlen; ++i){
                existing.push({
                    'legislation-id': ret['data']['tracked-legislation'][i]['legislation-id'],
                    'tracked': (ret['data']['tracked-legislation'][i]['tracked'])
                });
            }

            //add the current legislation to the list
            TbApi.one('legislation/'+breadcrumb['legislation']['legislation-id']+'.json').get()
            .then(function(ret){

                existing.push({
                    'legislation-id': "" + ret['data']['legislation']['doc-id'],
                    'tracked': true
                });

                //push the list
                TbApi.one('profiles/' + profile['id'] + '/legislation/all.json').customPUT(existing).then(
                    function(ret){
                        if(ret['code'] == 200){
                            profile['processed'] = true;
                        }
                    }
                );
            });
        });
    };

    TbApi.all('profiles.json').getList().then(function(ret){$scope.profiles = ret['data'];});

    $scope.breadcrumb = breadcrumb;
    $scope.selectedItem = {};
    $scope.itemFormat = {};
    
    ////[LOWEB-204] start: Add new profile on alert modal
    $scope.profile = {
      "name": "",
      "description": "",
      "alert-no-activity": false,
      "report-type": "Standard",
      "frequency": [],
      "alert-events": {
        "progress": true,
        "modified": true,
        "commenced": true,
        "published": true,
        "assented": true,
        "amended": true,
        "repealed": true
      }
    };

    $scope.frequencyOptions = {
        'daily': true
    };

    $scope.reportOptions = [
        {
            'name': "Standard",
            'value': "Standard"
        },
        {
            'name': "Summary Only",
            'value': "Summary"
        }
    ];

    $scope.makeFrequencyArray = function(){
        var arr = [];
        if($scope.frequencyOptions['half-daily']){ arr.push('half-daily'); }
        if($scope.frequencyOptions['daily']){ arr.push('daily'); }
        if($scope.frequencyOptions['weekly']){ arr.push('weekly'); }
        if($scope.frequencyOptions['monthly']){ arr.push('monthly'); }
        return arr;
    };
    
    $scope.saveProfile = function(){
        if(!$scope.profile.name || $scope.profile.name.length <= 0){
            $scope.showErrorMessage = true;
        }else{
            //first check if this is a new or edit profile
            var putData = {};

            $scope.profile['frequency'] = $scope.makeFrequencyArray();

            if($scope.profile['alert-events']['amended']){
                $scope.profile['alert-events']['modified'] = true;
            }

            putData = {
              "name": $scope.profile['name'],
              "description": $scope.profile['description'],
              "alert-no-activity": $scope.profile['alert-no-activity'],
              "report-type": $scope.profile['report-type'],
              "frequency": $scope.profile['frequency'],
              "alert-events": $scope.profile['alert-events']
            };

            TbApi.one('profiles.json').customPOST(putData).then(function(ret){
                $scope.addToProfile(ret['data']);
                TbApi.all('profiles.json').getList().then(function(ret){
                    var tmpArr = [];
                    angular.forEach(ret['data'], function(item){
                        if(item['name'] == putData['name']){
                            item['processed'] = true;
                        }
                        tmpArr.push(item);
                    });
                    $scope.profiles = tmpArr;
                });
            });
            $scope.showErrorMessage = false;
            $scope.isShowProfDialog();
        }
    };

    $scope.isShowProfDialog = function(){
        $scope.filterCollapse = false;
    };

    $scope.isShowAlertDialog = function(){
        $scope.filterCollapse = true;
    };
    ////[LOWEB-204] end
})

.controller('ModalLegCommCtrl', function($scope, $modalInstance, tbCom, tbLegParent, TbApi, trjurisrevFilter){

    $scope.comms = tbCom;
    $scope.leg = tbLegParent['legislation'];
    console.log('modal leg comm ctrl', tbLegParent);

    TbApi.one('legislation/' + $scope.leg['legislation-id'] + '/properties.json').get().then(function(ret){
        $scope.assentInfo = ret['data']['properties'];
        console.log($scope.assentInfo);
    });

    $scope.jurisShorten = function(input){
        console.log('juris shortener', input);
        return trjurisrevFilter(input);
    };

    $scope.today = new Date();

    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function (event) {
        console.log(event);
        event.stopPropagation();
        $modalInstance.dismiss('cancel');
    };
})

.controller('ModalLegPrintCtrl', function($scope, $modalInstance, searchItems, breadcrumb){
    $scope.ok = function () {
        $modalInstance.close($scope.selectedItem);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    $scope.searchItems = searchItems;

    console.log('modal print dump', searchItems, searchItems.length);

    $scope.breadcrumb = breadcrumb;
    $scope.selectedItem = {};
    $scope.selectedItem.title = "full";

    if(searchItems.length && searchItems.length > 0){
        $scope.selectedItem.title = "selected";
    }else{
        $scope.selectedItem.title = "full";
    }

    $scope.itemFormat = {};
})

.controller('ModalLegDownloadCtrl', function($scope, $modalInstance, searchItems, breadcrumb){
    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    $scope.searchItems = searchItems;
    $scope.breadcrumb = breadcrumb;
    $scope.selectedItem = {};
    $scope.itemFormat = {};
})

.controller('ModalLegShareCtrl', function($scope, $modalInstance, searchItems, breadcrumb){
    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    $scope.emailTargets = [
        {
            email: ""
        },
        {
            email: ""
        }
    ];

    $scope.addNewTarget = function(){
        $scope.emailTargets.push(
            {email: ""}
        );
    };

    $scope.searchItems = searchItems;
    $scope.breadcrumb = breadcrumb;
    $scope.selectedItem = {};
    $scope.itemFormat = {};
})

.controller('ModalSumProfileCtrl', function($scope, $modalInstance, breadcrumb, TbApi){
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    $scope.addToProfile = function(profile){
        console.log('add profile',profile);
        console.log('crumbs', breadcrumb);

        var existing = [];

        TbApi.one('profiles/'+profile['id']+'/legislation.json').get()
        .then(function(ret){
            console.log('load existing legs', ret);
            //make a list of existing legislation by item
            for(var i = 0, vlen = ret['data']['tracked-legislation'].length; i < vlen; ++i){
                existing.push({
                    'legislation-id': ret['data']['tracked-legislation'][i]['legislation-id'],
                    'tracked': (ret['data']['tracked-legislation'][i]['tracked'])
                });
            }

            //add the current legislation to the list
            TbApi.one('legislation/'+breadcrumb['legislation']['legislation-id']+'.json').get()
            .then(function(ret){

                existing.push({
                    'legislation-id': "" + ret['data']['legislation']['doc-id'],
                    'tracked': true
                });

                //push the list
                TbApi.one('profiles/' + profile['id'] + '/legislation/all.json').customPUT(existing).then(
                    function(ret){
                        if(ret['code'] == 200){
                            profile['processed'] = true;
                        }
                    }
                );
            });
        });
    };

    TbApi.all('profiles.json').getList().then(function(ret){$scope.profiles = ret['data'];});

    $scope.breadcrumb = breadcrumb;
    $scope.selectedItem = {};
    $scope.itemFormat = {};
    
    ////[LOWEB-204] start: Add new profile on alert modal
    $scope.profile = {
      "name": "",
      "description": "",
      "alert-no-activity": false,
      "report-type": "Standard",
      "frequency": [],
      "alert-events": {
        "progress": true,
        "modified": true,
        "commenced": true,
        "published": true,
        "assented": true,
        "amended": true,
        "repealed": true
      }
    };

    $scope.frequencyOptions = {
        'daily': true
    };

    $scope.reportOptions = [
        {
            'name': "Standard",
            'value': "Standard"
        },
        {
            'name': "Summary Only",
            'value': "Summary"
        }
    ];

    $scope.makeFrequencyArray = function(){
        var arr = [];
        if($scope.frequencyOptions['half-daily']){ arr.push('half-daily'); }
        if($scope.frequencyOptions['daily']){ arr.push('daily'); }
        if($scope.frequencyOptions['weekly']){ arr.push('weekly'); }
        if($scope.frequencyOptions['monthly']){ arr.push('monthly'); }
        return arr;
    };
    
    $scope.saveProfile = function(){
        if(!$scope.profile.name || $scope.profile.name.length <= 0){
            $scope.showErrorMessage = true;
        }else{
            //first check if this is a new or edit profile
            var putData = {};

            $scope.profile['frequency'] = $scope.makeFrequencyArray();

            if($scope.profile['alert-events']['amended']){
                $scope.profile['alert-events']['modified'] = true;
            }

            putData = {
              "name": $scope.profile['name'],
              "description": $scope.profile['description'],
              "alert-no-activity": $scope.profile['alert-no-activity'],
              "report-type": $scope.profile['report-type'],
              "frequency": $scope.profile['frequency'],
              "alert-events": $scope.profile['alert-events']
            };

            TbApi.one('profiles.json').customPOST(putData).then(function(ret){
                $scope.addToProfile(ret['data']);
                TbApi.all('profiles.json').getList().then(function(ret){
                    var tmpArr = [];
                    angular.forEach(ret['data'], function(item){
                        if(item['name'] == putData['name']){
                            item['processed'] = true;
                        }
                        tmpArr.push(item);
                    });
                    $scope.profiles = tmpArr;
                });
            });
            $scope.showErrorMessage = false;
            $scope.isShowProfDialog();
        }
    };

    $scope.isShowProfDialog = function(){
        $scope.filterCollapse = false;
    };

    $scope.isShowAlertDialog = function(){
        $scope.filterCollapse = true;
    };
    ////[LOWEB-204] end
})

.controller('ModalSumFavouritesCtrl', function($scope, $modalInstance, legsum, op, TbApi){
    $scope.legsum = legsum;
    $scope.op = op;

    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})

.controller('ModalSumPrintCtrl', function($scope, $modalInstance){
    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})

.controller('ModalSumDownloadCtrl', function($scope, $modalInstance){
    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    $scope.selectedItem = {};
    $scope.itemFormat = {};
})

.controller('ModalSumShareCtrl', function($scope, $modalInstance){
    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    $scope.emailTargets = [
        {
            email: ""
        },
        {
            email: ""
        }
    ];

    $scope.addNewTarget = function(){
        $scope.emailTargets.push(
            {email: ""}
        );
    };

    $scope.selectedItem = {};
    $scope.itemFormat = {};
})

;
