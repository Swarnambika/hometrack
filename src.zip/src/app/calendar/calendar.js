angular.module( 'tbLawOne.calendar', [
  'ui.router',
  'ui.bootstrap',
  'ui.calendar',
  'tbLawOne.services'
])

.config(function config( $stateProvider ) {
    $stateProvider
        .state( 'calendar', {
            url: '/calendar?juris',
            views: {
                "main": {
                    controller: 'CalendarCtrl',
                    templateUrl: 'calendar/calendar.tpl.html'
                }
            },
            data:{ pageTitle: 'Calendar' },
            params: {
                juris : { value: 'all'}
            }
        })
    ;//end stateProvider declarations
})

.controller( 'CalendarCtrl', function CalendarController( $scope, $stateParams ) {
    console.log('calendar controller loading', $stateParams);

    $scope.sparams = $stateParams;

    var date = new Date();
    var d = date.getDate();
    var m = date.getMonth();
    var y = date.getFullYear();

    $scope.calendarJuris = ['cth','act','nsw','nt','qld','sa','tas','vic','wa'];
    var calendarIDString = "timebase.com.au_6adf4l1gbp98pgptj4oiajkv6k@group.calendar.google.com";
    var calendarParams = {};

    if($stateParams['juris'] && $stateParams['juris'] !== 'all'){
        calendarParams['q'] = $stateParams['juris'];
    }

    $scope.generateCalendarPdfLink = function(){
        var jurisString = $stateParams['juris'];
        if(jurisString && jurisString !== 'all'){
            return 'http://downloads.lawone.com.au/' + jurisString + '/parliamentary-sitting-dates/' + jurisString.toUpperCase() + '_Parliamentary_Sittings_Current.pdf';
        }else{
            return null;
        }
    };
    $scope.calendarPdfLink = $scope.generateCalendarPdfLink();

    /* event source that pulls from google.com */
    $scope.allCalendar = {
        googleCalendarApiKey: 'AIzaSyBkmLbY_0nR8JVVugedm-lbudvztBwRwwQ',
        googleCalendarId: calendarIDString,
        className: 'gcal-event',
        currentTimezone: 'Australia/Sydney',
        data: calendarParams
    };

    /* event sources array*/
    $scope.eventSources = [$scope.allCalendar];
    $scope.selectJuris = $stateParams.juris;

    console.log('eventSources', $scope.eventSources);

    /* config object */
    $scope.uiConfig = {
      calendar:{
        height: 450,
        editable: true,
        header:{
          left: 'title',
          center: '',
          right: 'today prev,next'
        }
      }
    };

    /* Change View */
    $scope.changeView = function(view,calendar) {
      calendar.fullCalendar('changeView',view);
    };
    /* Change View */
    $scope.renderCalender = function(calendar) {
      calendar.fullCalendar('render');
    };
})

;
