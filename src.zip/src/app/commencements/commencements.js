angular.module( 'tbLawOne.commencements', [
  'ui.router',
  'ui.bootstrap',
  'restangular',
  'ngSanitize',
  'tbLawOne.directives',
  'tbLawOne.services'
])

.config(function config( $stateProvider ) {
    $stateProvider
        //browse master state, contains sub-views for sidebar frame and main frame
        .state( 'commencementmaster', {
            abstract: true,
            views: {
                "main": {
                    controller: 'CommencementsCtrl',
                    templateUrl: 'commencements/commencements.tpl.html'
                }
            },
            data:{ pageTitle: 'Commencements' }
        })
        .state ('commencement', {
            url: '/commencement?juris?doctype?year?sort?page',
            parent: 'commencementmaster',
            views: {
                "table": {
                    controller: 'CommencementsTableCtrl',
                    templateUrl: 'commencements/table.tpl.html'
                }
            },
            data:{ pageTitle: 'Commencements' }
        })
    ;//end stateProvider
})

.controller('CommencementsCtrl', function CommencementsController($scope, $state, $stateParams, CommencementsFactory){

})

.controller('CommencementsTableCtrl', function CommencementsTableController($scope, $state, $stateParams, CommencementsFactory){
    console.log('HELLO WORLD!');
    $scope.sparams = $stateParams;
    var itemsPerPage = 250;

    //PAGINATION
    if($scope.sparams['page']){
        $scope.currentPage = $scope.sparams['page'];
    }else{
        $scope.currentPage = 1;
    }
    
    $scope.initPagination = function(){
        if($scope.totalItems < itemsPerPage){
            $scope.itemsPerPage = $scope.totalItems;
        }else{
            $scope.itemsPerPage = itemsPerPage;
        }

        $scope.numPages = Math.ceil(($scope.totalItems / $scope.itemsPerPage));

        var xval = (($scope.currentPage - 1) * $scope.itemsPerPage) + 1;
        if(xval < $scope.totalItems){
            $scope.xval = xval;
        }

        var yval = ($scope.currentPage * $scope.itemsPerPage);
        if(yval <= $scope.totalItems){
            $scope.yval = yval;
        }else{
            ////WW fix the wrong display item number display of last page
            $scope.yval = $scope.totalItems;
        }
    };

    ////WW: LOWEB-195(LOWEB-197/LOWEB-198/LOWEB-199/LOWEB-200) start
    ////LOWEB-197
    $scope.displayDoctype = $stateParams['doctype'];
    if($stateParams['doctype'] && ($stateParams['doctype'].indexOf(',') > -1)){
        $scope.displayDoctype = $stateParams['doctype'].split(',')[0];
    }
    ////LOWEB-198
    $scope.currentYear = new Date().getFullYear().toString();
    $scope.yearsList = [];
    for(var i = $scope.currentYear;i>1997;i--){
        $scope.yearsList.push({'name':i.toString(), 'value':i.toString()});
    }
    if($scope.sparams['year']){
        $scope.currentYear = $scope.sparams['year'];
    }
    $scope.$watch('currentYear', function(newYear, oldYear){
        if(newYear != oldYear){
            $state.go('commencement', {year: newYear}, {inherit: true});
        }
    });
    ////LOWEB-199
    $scope.currentDoctype = "act,ord";
    $scope.doctypesList = [{'name':"Acts", 'value':"act,ord"},
                            {'name':"Regulations", 'value':"reg"}];
    if($scope.sparams['doctype']){
        $scope.currentDoctype = $scope.sparams['doctype'];
    }
    $scope.$watch('currentDoctype', function(newDoctype, oldDoctype){
        if(newDoctype != oldDoctype){
            $state.go('commencement', {doctype: newDoctype}, {inherit: true});
        }
    });
    //console.log('THIS YEAR IS: ', currentYear);
    ////LOWEB-200
    $scope.printPageOpen = function(){
        //console.log('Notification & Commencement tables print open!');

        var today = new Date();
        var sparams = {
            'juris' : ($stateParams['juris'] ? $stateParams['juris'] : 'cth'),
            'doctype' : ($stateParams['doctype'] ? $stateParams['doctype'] : 'act,ord'),
            //[LOWEB-205]'status' : ($stateParams['status'] ? $stateParams['status'] : 'cur,rep'),
            'year' : ($stateParams['year'] ? $stateParams['year'] : today.getFullYear()),
            'start' : 1,
            'count' : itemsPerPage,
            'sort' : ($stateParams['sort'] ? $stateParams['sort'] : 'date,title')
        };
        //console.log('COMMENCEPRINT CALL',sparams);
        var url = $state.href('commenceprint',sparams);
        window.open(url, '_blank');
    };
    ////WW: LOWEB-195(LOWEB-197/LOWEB-198/LOWEB-199/LOWEB-200) end

    //pagination change listener
    $scope.$watch('currentPage', function(newPage, oldPage){
        console.log('pagination listener fired ', newPage);
        if(newPage != oldPage){
            $state.go('commencement', {page: newPage}, {inherit: true});
        }
    });

    $scope.hasLoaded = false;
    $scope.populateCommencements = function(){
        var today = new Date();
        var start = 1;


        if($stateParams['page'] && $stateParams['page'] > 1){
            start = ($stateParams['page'] - 1) * itemsPerPage + 1;
        }

        var params = {
            'jurisdiction' : ($stateParams['juris'] ? $stateParams['juris'] : 'cth'),
            'doc-type' : ($stateParams['doctype'] ? $stateParams['doctype'] : 'act'),
            //[LOWEB-205]'status' : ($stateParams['status'] ? $stateParams['status'] : 'cur,rep'),
            'year' : ($stateParams['year'] ? $stateParams['year'] : today.getFullYear()),
            'start' : start,
            'count' : itemsPerPage,
            'sort' : ($stateParams['sort'] ? $stateParams['sort'] : 'date,title')
        };

        CommencementsFactory.getCommencements(params).then(function(ret){
            console.log('I GOT STUFF', ret);
            $scope.commencements = ret['legislation'];
            $scope.totalItems = ret['total'];
            $scope.initPagination();
            $scope.hasLoaded = true;
            
        });
    };
    $scope.populateCommencements();
})

;
