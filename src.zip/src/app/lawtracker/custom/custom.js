angular.module( 'tbLawOne.lawtracker.custom', [
  'ui.router',
  'ui.bootstrap',
  'restangular',
  'tbLawOne.services',
])

.config(function config( $stateProvider, $urlRouterProvider) {
    // LAWTRACKER: CUSTOM REPORTS
    $stateProvider
        .state( 'lawtracker.custom', {
            abstract: true,
            views: {
                "lawtracker":{
                    controller: 'CustomRepCtrl',
                    template: '<div ui-view="custom" class="hmax"></div>'
                }
            },
            data:{ pageTitle: 'LawTracker - Legislative activity reports'}
        })
        .state('lawtracker.custom.form',{
            url: '/reports/custom/form?sdate?edate?juris?doctype?subject?principal?eventtype?profile?legislation',
            views: {
                "custom":{
                    controller: 'CustomFormCtrl',
                    templateUrl: 'lawtracker/custom/custom.tpl.html'
                }
            }
        })
        .state('lawtracker.custom.result',{
            url: '/reports/custom/result?sdate?edate?juris?doctype?subject?principal?eventtype?profile?legislation?eventdate?from',
            views: {
                "custom":{
                    controller: 'CustomResultCtrl',
                    templateUrl: 'lawtracker/custom/customresults.tpl.html'
                }
            },
            onEnter: function($stateParams, trdoctypeFilter, trstatusFilter, $filter){
                console.log('ONENTER CUSTOM EVENT FIRED', $stateParams);
                var title = "Custom Report";

                if($stateParams['sdate'] && $stateParams['edate']){
                    title += " - Start " + $filter('date')($stateParams['sdate'], 'd MMM yyyy');
                    title += " to End " + $filter('date')($stateParams['edate'], 'd MMM yyyy');
                }

                if($stateParams['scope'] && $stateParams['scope'] !== ""){
                    title += (" | " + $stateParams['scope']);
                }

                var temp = "";
                var i = 0;
                var arr = [];

                if($stateParams['juris'] && $stateParams['juris'] !== ""){
                    if($stateParams['juris'] == 'all' || $stateParams['juris'] == 'All'){
                        title += (" | All");
                    }else{
                        arr = $stateParams['juris'].split(',');
                        for(i = 0;i<arr.length;i++){
                            temp = temp += arr[i] + ", ";
                        }
                        temp = temp.slice(0,-2);
                        title += (" | " + temp);
                        temp = "";
                    }

                }

                if($stateParams['doc-type'] && $stateParams['doc-type'] !== ""){
                    if($stateParams['doc-type'] == 'all' || $stateParams['doc-type'] == 'All'){
                        title += (" | All");
                    }else{
                        arr = $stateParams['doc-type'].split(',');
                        for(i = 0;i<arr.length;i++){
                            temp = temp += trdoctypeFilter(arr[i]) + ", ";
                        }
                        temp = temp.slice(0,-2);
                        title += (" | type: " + temp);
                        temp = "";
                    }
                }

                if($stateParams['principal']){
                    if($stateParams['principal'] == 'true'){
                        title += (" | " + "Principal");
                    }else if($stateParams['principal'] == 'false'){
                        title += (" | " + "Amending");
                    }
                }

                if($stateParams['subject'] && $stateParams['subject'] !== ""){
                    title += (" | subjects: " + $stateParams['subject'].split(',').length);
                }

                if($stateParams['within'] && $stateParams['department'] !== ""){
                    title += (" | within specific legislation");
                }
                this.data.pageTitle = title;
            }
        })
    ;
})


.controller('CustomRepCtrl', function CustomRepController( $scope ) {

})

.controller('CustomFormCtrl', function CustomFormController( $scope, $stateParams, $timeout, $state, TbApi, TbTestingApi, tbUserService, tbSubjectService, trdoctyperevFilter) {
    //startdate min = a year ago
    //startdate def = a week ago
    //enddate def = today
    //enddate max = six months ahead

    // console.log('Activity Factory dump', ActivityFactory);

    // ActivityFactory.getActivity({
    //     'sdate':'2014-03-15T17:30:18',
    //     'edate':'2014-03-26T17:30:10',
    //     'legislation':'cth0158106'
    // }).then(function(ret){
    //     console.log('Activity Factory test', ret);
    // });

            // {name: "Bill / Draft progress", isSelected: true},
            // {name: "Assent / Notification", isSelected: true},
            // {name: "Commenced", isSelected: true},
            // {name: "Amended",isSelected: true},
            // {name: "Repealed",isSelected: true}


    var reverseEventTypeSwitch = function(str){
        console.log('reverseEventType called', str);
        str = str.toLowerCase();
        switch(str){
            case 'commence':
                return 'Commenced';
            case 'assent':
                return 'Assent / Notification';
            case 'amend':
                return 'Amended';
            case 'repeal':
                return 'Repealed';
            case 'progress':
                return 'Bill / Draft progress';
            case 'all':
                break;
        }
    };

    var tempEventTypeSwitch = function(str){
        str = str.toLowerCase();
        switch(str){
            case 'commenced':
                return 'commence';
            case 'assent / notification':
                return 'assent';
            case 'amended':
                return 'amend';
            case 'repealed':
                return 'repeal';
            case 'bill / draft progress':
                return 'progress';
            case 'subordinate':
                return 'subordinate';
            case 'all':
                break;
        }
    };

    var tempEventFilter = function(str){
        str = str.toLowerCase();
        switch(str){
            case 'commenced':
                return 'commencement';
            case 'assent / notification':
                return 'assent,notification';
            case 'modified':
                return 'modifies';
            case 'amended':
                return 'amends';
            case 'repealed':
                return 'repeals';
            case 'bill / draft progress':
                return 'events';
            case 'subordinate':
                return 'subordinate';
        }
    };

    //SUBJECT WIDGET STUFF
    $scope.showSubjectWidget = false;
    $scope.showProfileWidget = false;
    $scope.showLegislationWidget = false;
    $scope.legislationItem = {};

    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            if(user['user'] && user.isIndividual()){
                $scope.showUserBlockWarning = false;
            }else{
                $scope.showUserBlockWarning = true;
            }
        },
        true
    );

    $scope.legislationAssign = function(input){
        console.log("typeahead selected object", input);
        $scope.legislationItem.title = input['title'];
        //$scope.legislationItem.title = input['text'];
        $scope.legislationItem.id = input['legislation-id'];
        //$scope.legislationItem.id = input['id'];
    };

    //grab titles for typeahead
    $scope.getTitles = function(input){
        $scope.loadingLocations = true;
        console.log('getTitles', input);
        var params = {
            'term' : input,
            'scope' : 'title',
            'count': 15
        };

        // return TbApi.all('search.json').getList(params).then(function(res){
        //     //console.log(res['data']['documents']);
        //     $scope.loadingLocations = false;
        //     console.log('returning typeahead',res['data']['documents']);
        //     return res['data']['documents'];
        // });
        return TbApi.all('lookup/legislation.json').getList(params).then(function(res){
            $scope.loadingLocations = false;
            console.log('returning typeahead',res['legislation']);

            var ret = [];

            for(var i = 0; i < res['legislation'].length - 1; i++){
                ret.push({
                    'legislation-id': res['legislation'][i]['id'],
                    'title': res['legislation'][i]['title'],
                    'content-id': res['legislation'][i]['content-id'],
                    'number' : res['legislation'][i]['number'],
                    'jurisdiction' : res['legislation'][i]['jurisdiction'],
                    'legislative-status' : res['legislation'][i]['legislative-status'],
                    'year' : res['legislation'][i] ['year']
                });
            }

            console.log('FFFFF', ret);
            return ret;
            //return res['legislation'];
        });
    };

    //$scope.subjectslist = listsubjects.getApiSubjects();
    //$scope.subjectslist = TbApi.all('subjects.json').getList().$object;
    $scope.subjectslist = tbSubjectService.get().$object;
    $scope.subjectCounter = 0;

    //END SUBJECT WIDGET STUFF


    //empty form object
    $scope.form = {};

    var popCheckboxes = function(string, target, filter){
        console.log('popCheckboxes called', string, target);
        var paramsArr = string.toLowerCase().split(',');

        for(var i = 0; i < target.length; i++){
            var proc = "";
            if(filter){
                proc = filter(target[i].name.toLowerCase());
            }else{
                proc = target[i].name.toLowerCase();
            }
            console.log('PROC', proc);

            if(paramsArr.indexOf(proc) > -1){
                target[i].isSelected = true;
            }else{
                target[i].isSelected = false;
            }
        }
        console.log('popCheckboxes result', target);
    };

    $scope.form.jurisdictions = {
        "allSelected" : true,
        "noneSelected" : false,
        "data" : [
            {name: "CTH", isSelected: true},
            {name: "ACT", isSelected: true},
            {name: "NSW", isSelected: true},
            {name: "NT", isSelected: true},
            {name: "QLD", isSelected: true},
            {name: "SA", isSelected: true},
            {name: "TAS", isSelected: true},
            {name: "VIC", isSelected: true},
            {name: "WA", isSelected: true}
        ]
    };


    $scope.form.doctypes = {
        "allSelected" : true,
        "noneSelected" : false,
        "data" : [
            {name: "Acts", isSelected: true},
            {name: "Regulations", isSelected: true},
            {name: "Bills", isSelected: true},
            {name: "Aged Care Principles", isSelected: false}
        ]
    };

    $scope.form.events = {
        "allSelected" : true,
        "noneSelected" : false,
        "data" : [
            {name: "Bill / Draft progress", isSelected: false},
            {name: "Assent / Notification", isSelected: true},
            {name: "Commenced", isSelected: true},
            {name: "Amended",isSelected: true},
            {name: "Repealed",isSelected: true},
            {name: "Subordinate",isSelected: false}
        ]
    };
    $scope.form.eventType = "All";

    $scope.form.principal = {
        'principal' : false,
        'amending' : false
    };

    $scope.form.subject = "";
    $scope.form.reportType = "all";

    $scope.showWeeks = false;

    $scope.clear = function () {
        console.log('form cleared');
        $scope.$broadcast('tbSubjectWidgetWipe');
        $scope.form.dStart = null;
        $scope.form.dEnd = null;
    };

    // Disable weekend selection
    $scope.disabled = function(date, mode) {
        return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
    };

    $scope.sopen = false;
    $scope.eopen = false;

    $scope.startOpen = function() {
        $scope.sopen = true;
    };

    $scope.endOpen = function() {
        $scope.eopen = true;
    };

    $scope.dateOptions = {
        'year-format': "'yyyy'",
        'starting-day': 1
    };

    $scope.format = 'dd MMM yyyy';

    //this picks up when the report type changes so we can do date stuff
    $scope.$watch('form.reportType', function(newRep, oldRep){
        if(newRep !== oldRep){
            console.log('report type changed to', newRep);

            $scope.showInvalidFormWarning = false;
            $scope.invalidFormWarning = "";

            //we have changed to a 6mo, so recalc maxDate and chop
            if(newRep == 'profile' || newRep == 'subject'){
                $scope.maxDateOffset = 6;
                $scope.syncDates();
            }

            //we have changed to a 3mo, so recalc maxDate and chop
            if(newRep == 'all'){
                $scope.maxDateOffset = 3;
                $scope.syncDates();
            }

            if(newRep == 'legislation'){
                $scope.maxDateOffset = 1200;
                $scope.syncDates();
            }
        }
    });

    $scope.syncDates = function(){
        console.log('datesync called');
        $scope.maxDate = new Date(Date.UTC($scope.form.dStart.getFullYear(), $scope.form.dStart.getMonth() + $scope.maxDateOffset, $scope.form.dStart.getDate()));
        if($scope.form.dEnd.getTime() > $scope.maxDate.getTime()){
            console.log('end date is beyond max date, cutting');
            $scope.form.dEnd = new Date($scope.maxDate);
        }

        if($scope.form.dStart.getTime() > $scope.form.dEnd.getTime()){
            console.log('end date is before start date, pushing');
            $scope.form.dEnd = new Date(Date.UTC($scope.form.dStart.getFullYear(), $scope.form.dStart.getMonth(), $scope.form.dStart.getDate() + 1));
        }
    };

    $scope.maxDateOffset = 3;

    //init dates assuming we're on 3mo
    $scope.initDates = function(){
        console.log('init dates');
        var today = new Date();

        //set minimum date to 1 January 1998
        $scope.minDate = new Date(Date.UTC(1998, 1, 1));

        //set maximum date to today + 3 months;
        $scope.maxDate = new Date(Date.UTC(today.getFullYear(), today.getMonth() + $scope.maxDateOffset, today.getDate()));

        //set starting date to today
        $scope.form.dStart = new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()));

        //set ending date to today + one day
        $scope.form.dEnd = new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()));

        //similarly set minimum date for dEnd to today + one day
        $scope.form.dStartPlusOne = new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate() + 1));
    };

    //call init dates function upon controller init
    $scope.initDates();

    //this function is called whenever startDate changes
    //and cuts off endDate if endDate is too far ahead
    //++ it is also called whenever endDate changes and is too far ahead

    var validateDate = function(d){
        if(d){
            if(Object.prototype.toString.call(d) === "[object Date]" ) {
                if( isNaN(d.getTime()) ){
                    return false;
                }else{
                    if(d.getFullYear() > 1997){
                        return true;
                    }else{
                        return false;
                    }
                }
            }else{
                return false;
            }
        }else{
            return false;
        }
    };

    $scope.$watch('form.dStart', function(newDate, oldDate){
        if(newDate !== oldDate){
            console.log('dStart watcher, changed', newDate, oldDate);
            if(validateDate(newDate)){
                console.log('dStart watcher, validate', validateDate(newDate));
                //the legislation widget is showing, which means no limit, so don't cut

                //set new minimum for dEnd picker
                $scope.form.dStartPlusOne = new Date(Date.UTC(newDate.getFullYear(), newDate.getMonth(), newDate.getDate() + 1));

                if($scope.form.reportType !== 'legislation'){
                    $scope.syncDates();
                }
            }
        }
    });

    $scope.$watch('form.dEnd', function(newDate, oldDate){
        if(newDate !== oldDate){
            console.log('dEnd watcher, changed', newDate, oldDate);
            var tempDateMinus = new Date(Date.UTC($scope.maxDate.getFullYear(), $scope.maxDate.getMonth(), $scope.maxDate.getDate() + 1));
            if(newDate.getTime() > tempDateMinus.getTime()){
                $scope.showDateRangeWarning = true;
            }else{
                $scope.showDateRangeWarning = false;
            }

            if(newDate.getTime() < $scope.form.dStart){
                $scope.showDateInversionWarning = true;
            }else{
                $scope.showDateInversionWarning = false;
            }
        }
    });

    var processStateParams = function(){
        if($stateParams['sdate'] && $stateParams['edate']){
            $scope.form.dStart = new Date($stateParams['sdate'] + "Z");

            var endstring = $stateParams['edate'].replace('23:59:59', '00:00:00');
            $scope.form.dEnd = new Date(endstring + "Z");
            console.log('changing dates', $stateParams['sdate'],$stateParams['edate']);
            console.log('after', $scope.form.dStart, $scope.form.dEnd);
        }
        if($stateParams['eventtype']){
            //use tempeventfilter like in form submission code
            //popCheckboxes($stateParams['eventtype'], $scope.form.events.data, tempEventFilter);
            console.log('RECEIVING EVENT TYPE PARAMETER');

            popCheckboxes($stateParams['eventtype'], $scope.form.events.data, tempEventTypeSwitch);
        }

        if($stateParams['legislation']){
            //go find whatever piece of legislation is in that ID and assign the title
            console.log('LEGISLATION INPUT', $stateParams['legislation']);

            TbApi.one('legislation/' + $stateParams['legislation'] + '.json').get().then(
                function(ret){
                    $scope.legislationAssign(ret['data']['legislation']);
                    $scope.form.reportType = 'legislation';
                }
            );
        }else if($stateParams['profile']){
            //set the profile by looking in existing profiles list and then assigning it

            console.log('PROFILE INPUT', $stateParams['profile']);

            angular.forEach($scope.alertsList, function(profile){
                if(profile.id == $stateParams['profile']){
                    $scope.form.profile = profile;
                }
            });

            $scope.form.reportType = 'profile';
        }else{
            if($stateParams['juris']){
                //jurisdictions needs no text filtering
                popCheckboxes($stateParams['juris'], $scope.form.jurisdictions.data);
            }
            if($stateParams['doctype']){
                //use doctyperevfilter like in form submission code
                popCheckboxes($stateParams['doctype'], $scope.form.doctypes.data, trdoctyperevFilter);
            }

            if($stateParams['principal']){
                if($stateParams['principal'] == 'true,false'){
                    $scope.form.principal.principal = true;
                    $scope.form.principal.amending = true;
                }else if($stateParams['principal'] == 'true' ){
                    $scope.form.principal.principal = true;
                }
            }

            if($stateParams['subject']){
                //turn on "subject" view option and set it'

                $timeout(function(){
                    $scope.$broadcast('tbSubjectWidgetPopulate', $stateParams['subject']);
                }, 200);
                $scope.form.reportType = 'subject';
                $scope.form.subject = $stateParams['subject'];
            }else{
                //default
                $scope.form.reportType = 'all';
            }
        }
    };

    var getFormStrings = function(target, filter){
        console.log('getFormStrings',target, filter);
        if(target['data']){
            var stringret = [];
            var working = target['data'];

            angular.forEach(working, function(item){
                if(item['isSelected']){
                    if(filter){
                        stringret.push(filter(item['name'].toLowerCase()));
                    }else{
                        stringret.push(item['name'].toLowerCase());
                    }
                }
            });

            return stringret.join(',');
        }else{
            return undefined;
        }
    };

    var zeroPad = function(n){
        return (n < 10) ? ("0" + n) : n;
    };
    var getRoundString = function(date){
        return date.getFullYear() + "-" + zeroPad(parseInt(date.getMonth() + 1, 10)) + "-" + zeroPad(date.getDate()) + "T" + "00:00:00";
    };

    var reportFormValidator = function(){
        console.log('validator', $scope.form.reportType);
        if($scope.form.reportType == 'subject'){
            console.log('rep subject',$scope.form.subject);
            if(!$scope.form.subject || $scope.form.subject.length < 1){
                //alert('For this report type, please select one of more Subjects.');
                $scope.showInvalidFormWarning = true;
                $scope.invalidFormWarning = "For this report type, please select one of more Subjects.";
                return false;
            }else{
                return true;
            }
        }

        else if($scope.form.reportType == 'profile'){
            console.log('rep profile',$scope.form.profile);
            if(!$scope.form.profile || $scope.form.profile.length < 1){
                //alert('For this report type, please select a Profile.');
                $scope.showInvalidFormWarning = true;
                $scope.invalidFormWarning = "For this report type, please select a Profile.";
                return false;
            }else{
                return true;
            }
        }

        else if($scope.form.reportType == 'legislation'){
            console.log('rep legislation',$scope.legislationItem);
            if(!$scope.legislationItem || !$scope.legislationItem.id || $scope.legislationItem.id.length < 1){
                //alert('For this report type, please select a legislation title.');
                $scope.showInvalidFormWarning = true;
                $scope.invalidFormWarning = "For this report type, please select a legislation title.";
                return false;
            }else{
                return true;
            }
        }

        else if($scope.form.reportType == 'all'){
            return true;
        }

        else{
            return false;
        }
    };

    $scope.generateReport = function(){
        if($scope.showDateRangeWarning || $scope.showDateInversionWarning){
            alert('Error: Report may not be submitted while form is invalid.');
        }else{
            if(reportFormValidator()){
                $scope.showInvalidFormWarning = false;
                $scope.invalidFormWarning = "";

                var params = {};

                //always present
                params['sdate'] = getRoundString($scope.form.dStart);

                //TEMPORARY FIX
                //var tempFixDate = new Date($scope.form.dEnd.getFullYear(), $scope.form.dEnd.getMonth(), $scope.form.dEnd.getDate()+1);
                //params['edate'] = getRoundString(tempFixDate);

                params['edate'] = getRoundString($scope.form.dEnd).replace('T00:00:00','T23:59:59');
                console.log('EDATE', params['edate']);

                params['eventtype'] = getFormStrings($scope.form.events, tempEventTypeSwitch);
                console.log('EVENT TYPE TEST', params['eventtype']);

                //params['eventtype'] = tempEventTypeSwitch();
                params['eventdate'] = 'real';

                //special cases, if either is present
                //params['profile'];
                //params['legislation'];

                if($scope.form.reportType == 'profile'){
                    if($scope.form.profile.id){
                        params['profile'] = $scope.form.profile.id;
                    }else{
                        params['profile'] = $stateParams['profile'];
                    }
                }else if($scope.form.reportType == 'legislation'){
                    params['legislation'] = $scope.legislationItem.id;
                    params['juris'] = getFormStrings($scope.form.jurisdictions);
                }else{
                    params['juris'] = getFormStrings($scope.form.jurisdictions);
                    params['doctype'] = getFormStrings($scope.form.doctypes, trdoctyperevFilter);

                    if($scope.form.principal){
                        if($scope.form.principal.principal && $scope.form.principal.amending){
                            params['principal'] = "true,false";
                        }else if($scope.form.principal.principal && !$scope.form.principal.amending){
                            params['principal'] = "true";
                        }else if(!$scope.form.principal.principal && $scope.form.principal.amending){
                            params['principal'] = "false";
                        }else if(!$scope.form.principal.principal && !$scope.form.principal.amending){
                            params['principal'] = undefined;
                        }
                    }else{
                        params['principal'] = undefined;
                    }

                    if($scope.form.reportType == 'subject'){
                        params['subject'] = $scope.form.subject;
                    }
                }

                //do none of these, but default to doing them

                //params['subject'];
                //params['principal'];

                console.log('generateReport',params);
                $state.go('lawtracker.custom.result',params);
            }
        }

    };

    TbApi.all('profiles.json').getList().then(function(ret){
        console.log('DUMPING USER PROFILES RETURN', ret);
        $scope.alertsList = ret['data'];
        processStateParams();
    });
})

.controller('CustomResultCtrl', function CustomResultController($scope, $state, $stateParams, $modal, tbUserService, tbFavouritesService, ActivityFactory, TbApi){
    $scope.sparams = $stateParams;
    $scope.hasLoaded = false;

    $scope.data = {};
    $scope.data.selected = [];

    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            if(user['user'] && user.isIndividual()){
                $scope.showUserButtons = true;
            }
        },
        true
    );

    //this tracks if we've come from alert list display
    if($stateParams.from == 'alert'){
        $scope.from = true;
    }

    if($stateParams['eventtype'].indexOf('amend') > -1 || $stateParams['eventtype'].indexOf('repeal') > -1 || $stateParams['eventtype'].indexOf('subordinate') > -1){
        console.log('REPORT RANGE WARNING!');
        $scope.showReportRangeWarning = true;
    }

    if($stateParams.legislation){
        TbApi.one('legislation/'+$stateParams.legislation+'.json').get().then(function(ret){
            console.log('LEGISLATION GET',ret);
            $scope.legtitle = ret['data']['legislation']['title'];
         });
    }

    if($stateParams.profile){
         TbApi.one('profiles/'+$stateParams.profile+'.json').get().then(function(ret){
            console.log('PROFILE GET',ret);
            $scope.profilename = ret['data']['name'];
         });
    }

    $scope.getSelectedItems = function(){
        return $scope.data.selected;
    };

    $scope.selectItem = function(item){
        if(item['isChecked']){
            item['isChecked'] = false;
            var index = _.findIndex($scope.data.selected, function(arrItem){
                return arrItem['legislation-id'] == item['legislation-id'];
            });

            if(index != -1){
                $scope.data.selected.splice(index, 1);
            }
        }else{
            item['isChecked'] = true;
            $scope.data.selected.push(item);
        }
        console.log('bucket dump',$scope.data.selected);
    };

    $scope.modalProfileOpen = function(){
        console.log('Modal add to profile called');
        var modalInstance = $modal.open({
            templateUrl: 'lawtracker/custom/modalcustomprofile.tpl.html',
            controller: 'ModalCustomProfileCtrl',
            resolve: {
                selected: function(){
                    return $scope.data.selected;
                }
            }
        });
    };

    $scope.modalFavouritesOpen = function(){
        if(tbUserService.getUserObject() && !tbUserService.isUserIndividual()){
            tbUserService.showShareBlockModal();
        }else{
            console.log('Modal add to favourites called');
            console.log($scope.data.selected);

            var modalInstance = $modal.open({
                templateUrl: 'lawtracker/custom/modalcustomfavourites.tpl.html',
                controller: 'ModalCustomFavouritesCtrl',
                resolve: {
                    selected: function(){
                        return $scope.data.selected;
                    }
                }
            });

            modalInstance.result.then(function(){
                if($scope.data.selected && $scope.data.selected.length > 0){
                    console.log('SELECTED FAVES',$scope.data.selected);
                    tbFavouritesService.addMultipleFavourites($scope.data.selected.map(function(item){
                        return item['doc-id'];
                    }));
                }
            });
        }
    };

    $scope.modalPrintOpen = function(){
        console.log('Modal print called');

        var modalInstance = $modal.open({
            templateUrl: 'lawtracker/custom/modalcustomprint.tpl.html',
            controller: 'ModalCustomPrintCtrl',
            resolve: {
                searchItems: function(){
                    return $scope.getSelectedItems();
                },
                fromalert: function(){
                    return $scope.from;
                }
            }
        });

        modalInstance.result.then(function(ret){
            console.log('Print modal dismissed!',ret);
            var params = {};
            switch(ret){
                case 'sections':
                    params.sections = true;
                    break;
                case 'selected':
                    var ids = $scope.data.selected.map(function(item){
                        return item['legislation-id'];
                    });
                    params.sections = true;
                    params.selected = ids.join(',');
                    break;
                case 'results':
                    break;
            }
            var sparams = $stateParams;
            sparams.sections = params.sections;
            sparams.selected = params.selected;
            delete sparams.page;

            sparams['fromcustom'] = true;

            if($scope.profilename){
                sparams['prep'] = $scope.profilename;
            }

            if($scope.legtitle){
                sparams['lti'] = $scope.legtitle;
            }

            console.log('SPARAMS',sparams);
            var url = $state.href('activityprint',sparams);
            window.open(url, '_blank');
            //$state.go('searchprint',params);
        });
    };

    $scope.getActivities = function(){
      var startDate, endDate, eventType, eventDate, detail;
      var legislation, jurisdiction, docType, principal;
      var subject, profile, department;
      var start, count, sort, selfInitiated;

      sort = 'title';

      var tempEventStringSwitch = function(input){
          console.log('tempEventStringSwitch', input);
          var str = input.toLowerCase();
          switch(str){
              case 'commence':
                  return 'Commenced';
              case 'assent':
                  return 'Assent/Notification';
              case 'amend':
                  return 'Amended';
              case 'repeal':
                  return 'Repealed';
              case 'progress':
                  return 'Bill/Draft Progress';
              case 'subordinate':
                  return 'Subordinate';
              case 'all':
                  break;
          }
      };

      var tempEventTypeSwitch = function(input){
          var str = input.toLowerCase();
          switch(str){
              case 'commence':
                  return 'commencement,commenced';
              case 'assent':
                  return 'assent,notification';
              case 'amend':
                  return 'amended,modified';
              case 'repeal':
                  return 'repealed,expiry,disallowed by';
              case 'progress':
                  return 'events';
              case 'subordinate':
                  return 'subordinate';
              case 'all':
                  return 'commencement,commenced,assent,notification,amended,modified,repealed,expiry,disallowed by,subordinate,events';
              default:
                  return input;
          }
      };

      //set the arguments from the $stateParams
      if($scope.sparams['sdate']){ startDate = $scope.sparams['sdate']; }
      if($scope.sparams['edate']){ endDate = $scope.sparams['edate']; }
      if($scope.sparams['juris']){ jurisdiction = $scope.sparams['juris']; }
      if($scope.sparams['doctype']){ docType = $scope.sparams['doctype']; }
      if($scope.sparams['principal']){ principal = $scope.sparams['principal']; }
      if($scope.sparams['subject']){ subject = $scope.sparams['subject']; }
      if($scope.sparams['profile'] && !$scope.sparams['legislation']){ profile = $scope.sparams['profile']; }
      if($scope.sparams['legislation'] && !$scope.sparams['profile']){ legislation = $scope.sparams['legislation']; }
      if($scope.sparams['sort']){ sort = $scope.sparams['sort']; }

      if($scope.sparams['eventtype']){
          var ts = "";
          var ttypes = $scope.sparams['eventtype'].split(',');
          for(var i = 0; i < ttypes.length; i++){
              ts += ","+tempEventTypeSwitch(ttypes[i]);
          }
          ts = ts.substring(1);
          console.log('TSTS',ts);
          eventType = ts;

          var tev = "";

          for(var j = 0; j < ttypes.length; j++){
              tev += ", "+ tempEventStringSwitch(ttypes[j]);
          }
          tev = tev.substring(2);
          $scope.tempEventString = tev;

      }else{
          eventType = 'commencement,commenced,assent,notification,amended,modified,repealed,expiry,disallowed by,subordinate,events';
      }

      eventDate = "occur,effective"; //real dates
      if($scope.sparams['eventdate'] && $scope.sparams['eventdate'].indexOf('editorial') > -1){
          eventDate += ',create,update,as-made'; //editorial dates
        if(($scope.sparams['eventtype'] && $scope.sparams['eventtype'].indexOf('progress') > -1) || ($scope.sparams['eventdate'].indexOf('progress') > -1)){
            eventDate += ',progress-update';
        }
      }else{
        if(($scope.sparams['eventtype'] && $scope.sparams['eventtype'].indexOf('progress') > -1) || ($scope.sparams['eventdate'] && $scope.sparams['eventdate'].indexOf('progress') > -1)){
            eventDate += ',progress';
        }
      }

      $scope.activityContainer = {};
      $scope.activityContainer.get = function(index, count, success){
            var result = [];
            for(var i = index; i <= index + count - 1; i++){
                if($scope.activityReturn && $scope.activityReturn.activity && $scope.activityReturn.activity[i]){
                    result.push($scope.activityReturn.activity[i]);
                }
            }
            success(result);
      };


      console.log('SORT PARAMETER', sort);
      ActivityFactory.getActivity(startDate, endDate, eventType, eventDate, detail,
       legislation, jurisdiction, docType, principal, subject, profile, department,
       start, count, sort, selfInitiated).then(function(ret){
          console.log('Activity Factory test', ret);
          $scope.activityReturn = ret;

          angular.forEach($scope.activityReturn.activity, function(activity){
              activity['legislation']['applicableEventNames'] = activity.applicableEventNames().join(', ');
          });

          $scope.hasLoaded = true;
      });
    };

    $scope.getActivities();

    $scope.selectAllOnPage = function (){
        console.log('selectAllOnPage', $scope.activityReturn.activity);
        for(var i = 0; i < $scope.activityReturn.activity.length; i++){
            if(!$scope.activityReturn.activity[i].legislation.isChecked){
                $scope.selectItem($scope.activityReturn.activity[i].legislation);
            }
        }
    };

    $scope.deselectAllOnPage = function(){
        console.log('deselectAllOnPage', $scope.activityReturn.activity);
        for(var i = 0; i < $scope.activityReturn.activity.length; i++){
            if($scope.activityReturn.activity[i].legislation.isChecked){
                $scope.selectItem($scope.activityReturn.activity[i].legislation);
            }
        }
    };

    $scope.expandAllOnPage = function(){
        $scope.$broadcast('tbExpandAllActivities');
    };

    $scope.collapseAllOnPage = function(){
        $scope.$broadcast('tbCollapseAllActivities');
    };

    $scope.changeSortBy = function(sort){
        if($scope.sparams['sort'] == sort){
            if($scope.sparams['sort'].charAt(0) == '-'){
                $scope.sparams['sort'] = sort.substring(1);
            }else{
                $scope.sparams['sort'] = '-' + sort;
            }

        }else if(!$scope.sparams['sort'] && (sort == 'title')){
            $scope.sparams['sort'] = '-title';
        }else{
            $scope.sparams['sort'] = sort;
        }

        $scope.hasLoaded = false;
        $scope.activityReturn = [];
        $scope.data.selected = [];
        $scope.getActivities();
    };
})

.controller('ModalCustomPrintCtrl', function($scope, $modalInstance, searchItems, fromalert){
    $scope.from = fromalert;

    $scope.ok = function () {
        $modalInstance.close($scope.selectedItem.res);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    $scope.searchItems = searchItems;
    $scope.selectedItem = {};
    $scope.selectedItem.res = "results";
})

.controller('ModalCustomFavouritesCtrl', function($scope, $modalInstance, selected, tbFavouritesService){
    console.log('SELECTED',selected);
    $scope.selectedItems = selected;

    $scope.ok = function () {
        $modalInstance.close(true);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})

.controller('ModalCustomProfileCtrl', function($scope, $modalInstance, selected, TbApi){
    console.log('SELECTED',selected);
    $scope.selectedItems = selected;

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    $scope.addToProfile = function(profile){
        console.log('add profile',profile);

        var existing = [];

        TbApi.one('profiles/'+profile['id']+'/legislation.json').get()
        .then(function(ret){
            console.log('load existing legs', ret);
            //make a list of existing legislation by item
            for(var i = 0, vlen = ret['data']['tracked-legislation'].length; i < vlen; ++i){
                existing.push({
                    'legislation-id': ret['data']['tracked-legislation'][i]['legislation-id'],
                    'tracked': (ret['data']['tracked-legislation'][i]['tracked'])
                });
            }

            //insert all the selected items
            for(var j = 0, elen = selected.length; j < elen; j++){
                console.log('le select',selected[j]);
                existing.push({
                    'legislation-id': selected[j]['doc-id'],
                    'tracked': true
                });
            }

            //push the list
            TbApi.one('profiles/' + profile['id'] + '/legislation/all.json').customPUT(existing).then(
                function(ret){
                    if(ret['code'] == 200){
                        profile['processed'] = true;
                    }
                }
            );
        });
    };

    if(selected && selected.length > 0){
        TbApi.all('profiles.json').getList().then(function(ret){$scope.profiles = ret['data'];});
    }

    ////[LOWEB-204] start: Add new profile on alert modal
    $scope.profile = {
      "name": "",
      "description": "",
      "alert-no-activity": false,
      "report-type": "Standard",
      "frequency": [],
      "alert-events": {
        "progress": true,
        "modified": true,
        "commenced": true,
        "published": true,
        "assented": true,
        "amended": true,
        "repealed": true
      }
    };

    $scope.frequencyOptions = {
        'daily': true
    };

    $scope.reportOptions = [
        {
            'name': "Standard",
            'value': "Standard"
        },
        {
            'name': "Summary Only",
            'value': "Summary"
        }
    ];

    $scope.makeFrequencyArray = function(){
        var arr = [];
        if($scope.frequencyOptions['half-daily']){ arr.push('half-daily'); }
        if($scope.frequencyOptions['daily']){ arr.push('daily'); }
        if($scope.frequencyOptions['weekly']){ arr.push('weekly'); }
        if($scope.frequencyOptions['monthly']){ arr.push('monthly'); }
        return arr;
    };
    
    $scope.saveProfile = function(){
        if(!$scope.profile.name || $scope.profile.name.length <= 0){
            $scope.showErrorMessage = true;
        }else{
            //first check if this is a new or edit profile
            var putData = {};

            $scope.profile['frequency'] = $scope.makeFrequencyArray();

            if($scope.profile['alert-events']['amended']){
                $scope.profile['alert-events']['modified'] = true;
            }

            putData = {
              "name": $scope.profile['name'],
              "description": $scope.profile['description'],
              "alert-no-activity": $scope.profile['alert-no-activity'],
              "report-type": $scope.profile['report-type'],
              "frequency": $scope.profile['frequency'],
              "alert-events": $scope.profile['alert-events']
            };

            TbApi.one('profiles.json').customPOST(putData).then(function(ret){
                $scope.addToProfile(ret['data']);
                TbApi.all('profiles.json').getList().then(function(ret){
                    var tmpArr = [];
                    angular.forEach(ret['data'], function(item){
                        if(item['name'] == putData['name']){
                            item['processed'] = true;
                        }
                        tmpArr.push(item);
                    });
                    $scope.profiles = tmpArr;
                });
            });
            $scope.showErrorMessage = false;
            $scope.isShowProfDialog();
        }
    };

    $scope.isShowProfDialog = function(){
        $scope.filterCollapse = false;
    };

    $scope.isShowAlertDialog = function(){
        $scope.filterCollapse = true;
    };
    ////[LOWEB-204] end
})

;
