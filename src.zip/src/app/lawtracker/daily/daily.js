angular.module( 'tbLawOne.lawtracker.daily', [
  'ui.router',
  'ui.bootstrap',
  'ui.utils',
  'restangular',
  'tbLawOne.services'
])

.config(function config( $stateProvider, $urlRouterProvider) {
    // LAWTRACKER: DAILY REPORTS
    $stateProvider
        .state( 'lawtracker.dailymaster', {
            abstract: true,
            views: {
                "lawtracker": {
                    controller: 'DailyRepCtrl',
                    templateUrl: 'lawtracker/daily/daily.tpl.html'
                },
                "col1@lawtracker.dailymaster" : {
                    controller: 'DailyRepSidebarCtrl',
                    templateUrl: 'lawtracker/daily/dailysidebar.tpl.html'
                },
                "col2@lawtracker.dailymaster" : {
                    controller: 'DailyRepHolderCtrl',
                    template: '<div ui-view="result"></div>'
                }
            },
            data:{ pageTitle: 'LawTracker - Daily Activity Reports' }
        })
        .state( 'lawtracker.daily', {
            url: '/reports/daily/?juris?period',
            parent: 'lawtracker.dailymaster',
            views: {
                "result" : {
                    controller: 'DailyRepFormCtrl',
                    templateUrl: 'lawtracker/daily/dailyform.tpl.html'
                }
            }
        })
        // .state( 'lawtracker.daily', {
        //     url: '/reports/daily/?juris?period',
        //     views: {
        //         "lawtracker":{
        //             controller: 'DailyRepCtrl',
        //             templateUrl: 'lawtracker/daily/daily.tpl.html'
        //         },
        //         "col1@lawtracker.daily":{
        //             controller: 'DailyRepSidebarCtrl',
        //             templateUrl: 'lawtracker/daily/dailysidebar.tpl.html'
        //         },
        //         "col2@lawtracker.daily":{
        //             controller: 'DailyRepFormCtrl',
        //             templateUrl: 'lawtracker/daily/dailyform.tpl.html'
        //         }
        //     },
        //     data:{ pageTitle: 'LawTracker - Daily Activity Reports'}
        // })
    ;
})


.controller('DailyRepCtrl', function DailyRepController( $scope, $stateParams, $state, $modal ) {
    console.log('DailyRepCtrl fired');
    $scope.data = {};
    $scope.data.selected = [];
    $scope.data.childLoaded = false;

    var zeroPad = function(n){
        return (n < 10) ? ("0" + n) : n;
    };
    var getRoundString = function(date){
        console.log('getRoundString date', date);
        var dateString = date.getFullYear() + "-" + zeroPad(parseInt(date.getMonth() + 1, 10)) + "-" + zeroPad(date.getDate()) + "T" + zeroPad(date.getHours()) + ":" + zeroPad(date.getMinutes()) + ":00";
        console.log('getRoundString dateString', dateString);
        return dateString;
    };

    $scope.getSelectedItems = function(){
        return $scope.data.selected;
    };

    $scope.modalPrintOpen = function(){
        console.log('Modal print called');

        var modalInstance = $modal.open({
            templateUrl: 'lawtracker/daily/modaldailyprint.tpl.html',
            controller: 'ModalDailyPrintCtrl',
            resolve: {
                searchItems: function(){
                    return $scope.getSelectedItems();
                }
            }
        });

        modalInstance.result.then(function(ret){
            console.log('Print modal dismissed!',ret);
            var sparams = {};
            switch(ret){
                case 'sections':
                    sparams.sections = true;
                    break;
                case 'selected':
                    var ids = $scope.data.selected.map(function(item){
                        return item['legislation-id'];
                    });

                    sparams.selected = ids.join(',');
                    sparams.sections = true;
                    break;
                case 'results':
                    break;
            }
            // var sparams = $stateParams;
            // sparams.sections = params.sections;
            // sparams.selected = params.selected;
            // delete sparams.page;

            console.log('SPARAMS',$scope.data);

            if($scope.data.sparams['period']){
                sparams['edate'] = getRoundString($scope.data.endDate);
                sparams['sdate'] = getRoundString($scope.data.startDate);
            }else{
                var tempDate = new Date();
                sparams['sdate'] = getRoundString(new Date(tempDate.setMonth(tempDate.getMonth() - 1)));
                sparams['edate'] = getRoundString(tempDate);
            }

            if($scope.data.sparams['juris']){
                sparams['juris'] = $scope.data.sparams['juris'];
            }


            sparams['fromdaily'] = true;

            var url = $state.href('activityprint',sparams);
            console.log('PRINT MODAL RESULTS',sparams);
            window.open(url, '_blank');
            //$state.go('searchprint',params);
        });
    };
})

.controller('DailyRepHolderCtrl', function DailyRepController( $scope, $stateParams, $state ) {
    console.log('DailyRepHolderCtrl fired', $scope, $scope.data);
})

.controller('DailyRepFormCtrl', function DailyRepFormController( $scope, $timeout, $stateParams, TbApi, ActivityFactory) {
    $scope.params = $stateParams;
    $scope.data.sparams = $stateParams;

    console.log('DailyRepFormCtrl SCOPE', $scope, $scope.data);

    var zeroPad = function(n){
        return (n < 10) ? ("0" + n) : n;
    };
    var getRoundString = function(date){
        console.log('getRoundString date', date);
        var dateString = date.getFullYear() + "-" + zeroPad(parseInt(date.getMonth() + 1, 10)) + "-" + zeroPad(date.getDate()) + "T" + zeroPad(date.getHours()) + ":" + zeroPad(date.getMinutes()) + ":00";
        console.log('getRoundString dateString', dateString);
        return dateString;
    };

    $scope.selectItem = function(item){
        if(item['isChecked']){
            item['isChecked'] = false;
            var index = _.findIndex($scope.data.selected, function(arrItem){
                return arrItem['legislation-id'] == item['legislation-id'];
            });

            if(index != -1){
                $scope.data.selected.splice(index, 1);
            }
        }else{
            item['isChecked'] = true;
            $scope.data.selected.push(item);
        }
        console.log('bucket dump',$scope.data.selected);
    };


    $scope.setToday = function() {
        //initialize dates
        $scope.data.startDate = new Date();
        $scope.data.endDate = new Date();
        $scope.today = new Date();

        $scope.today.setHours(0,0,0,0);
        $scope.data.startDate.setHours(0,0,0,0);
        $scope.data.endDate.setHours(0,0,0,0);
        //$scope.data.endDate.setHours(23, 59, 59, 999);

        //date range set by params
        switch($stateParams['period']){
            case 'next-month': //next month
                $scope.data.startDate.setDate($scope.today.getDate()+1);
                $scope.data.endDate.setMonth($scope.today.getMonth()+1);
                $scope.data.endDate.setDate($scope.today.getDate()+1);
                break;
            case 'next-week': //next week
                $scope.data.startDate.setDate($scope.today.getDate()+1);
                $scope.data.endDate.setDate($scope.today.getDate()+7);
                break;
            case 'last-week': //last week
                $scope.data.startDate.setDate($scope.today.getDate()-8);
                break;
            case 'last-month': //last month
                $scope.data.startDate.setMonth($scope.today.getMonth()-1);
                break;
            case 'last-day': //last day
                $scope.data.startDate.setDate($scope.today.getDate()-1);
                $scope.data.endDate.setDate($scope.today.getDate()+1);
                break;
        }
        console.log('CURRENT DATE OBJECTS',  $scope.data.startDate, $scope.data.endDate);

      $scope.printparams = {
        'sdate': getRoundString($scope.data.startDate),
        'edate': getRoundString($scope.data.endDate),
        'juris': $stateParams.juris
      };

    };
    $scope.setToday();

    $timeout(function(){
        $scope.loadActivities();
    });

    $scope.loadActivities = function(){
        $scope.hasLoaded = false;
        console.log('loadActivities called');
        var startDate, endDate, eventType, eventDate, detail;
        var legislation, jurisdiction, docType, principal;
        var subject, profile, department;
        var start, count, sort;

        var zeroPad = function(n){
            return (n < 10) ? ("0" + n) : n;
        };
        var getRoundString = function(date){
            return date.getFullYear() + "-" + zeroPad(parseInt(date.getMonth() + 1, 10)) + "-" + zeroPad(date.getDate()) + "T" + zeroPad(date.getHours()) + ":" + zeroPad(date.getMinutes()) + ":00";
        };

        eventType = "commencement,commenced,assent,notification,amended,modified,repealed,expiry,disallowed by,subordinate,events";
        eventDate = "occur,effective,progress,as-made";

        if($stateParams['period']){
            endDate = getRoundString($scope.data.endDate);
            startDate = getRoundString($scope.data.startDate);
        }else{
            endDate = getRoundString(new Date());
            var tempDate = new Date();
            startDate = getRoundString(new Date(tempDate.setMonth(tempDate.getMonth() - 1)));
        }

        if($stateParams['juris']){
            jurisdiction = $stateParams['juris'];
        }

        ActivityFactory.getActivity(startDate, endDate, eventType, eventDate, detail,
        legislation, jurisdiction, docType, principal, subject, profile, department,
        start, count, sort).then(function(ret){
            console.log('factory return', ret);
            $scope.activityReturn = ret;
            angular.forEach($scope.activityReturn.activity, function(activity){
                  activity['legislation']['applicableEventNames'] = activity.applicableEventNames().join(', ');
            });
            $scope.hasLoaded = true;
            $scope.data.childLoaded = true;
        });
    };
})

.controller('DailyRepSidebarCtrl', function DailyRepSidebarController( $scope) {

    $scope.dailyFilters = [
        {name: "cth"},
        {name: "act"},
        {name: "nsw"},
        {name: "nt"},
        {name: "qld"},
        {name: "sa"},
        {name: "tas"},
        {name: "vic"},
        {name: "wa"}
    ];

    $scope.checkOpen = function(){
        if(window.innerWidth <= 768){
            var elem = angular.element('.ui-layout-toggler-west');
            if(elem.hasClass('ui-layout-toggler-open')){
                elem.trigger('click');
            }
          }
    };
})

.controller('ModalDailyPrintCtrl', function($scope, $modalInstance, searchItems){
    $scope.ok = function () {
        $modalInstance.close($scope.selectedItem.res);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    $scope.searchItems = searchItems;
    $scope.selectedItem = {};
    $scope.selectedItem.res = "results";
})


;
