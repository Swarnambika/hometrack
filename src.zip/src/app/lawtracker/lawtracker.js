angular.module( 'tbLawOne.lawtracker', [
  'ui.router',
  'ui.bootstrap',
  'restangular',
  'tbLawOne.services',
  'tbLawOne.lawtracker.alerts',
  'tbLawOne.lawtracker.daily',
  'tbLawOne.lawtracker.custom',
  'tbLawOne.lawtracker.rss'
])

.config(function config( $stateProvider, $urlRouterProvider) {

    //redirect /daily to /daily/cth as default choice
    //define all the various LawTracker states and substates
    $stateProvider
        //LAWTRACKER: abstract parent state
        .state('lawtracker',{
            abstract: true,
            url: '/lawtracker',
            views: {
                "main" :{
                    controller: 'LawtrackerCtrl',
                    template: '<div ui-view="lawtracker" class="lawtracker"></div>'
                }
            }
        })
    ;//end stateProvider declarations
})

.controller( 'LawtrackerCtrl', function SearchController( $scope ) {

})

;
