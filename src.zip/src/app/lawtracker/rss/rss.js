angular.module( 'tbLawOne.lawtracker.rss', [
  'ui.router',
  'ui.bootstrap',
  'restangular',
  'tbLawOne.services'
])

.config(function config( $stateProvider, $urlRouterProvider) {
    // LAWTRACKER: RSS PAGE
    $stateProvider
        .state( 'lawtracker.rss', {
            url: '/rss/feeds',
            views: {
                "lawtracker":{
                    controller: 'RssCtrl',
                    templateUrl: 'lawtracker/rss/rss.tpl.html'
                }
            },
            data:{ pageTitle: 'LawTracker - RSS Feeds'}
        })
    ;
})

.controller('RssCtrl', function RssController( $scope, TbApi, tbSubjectService ) {
    $scope.rssbase = "https://www.lawone.com.au/activity-feed";

    $scope.jurisdictions = [
        "All Jurisdictions",
        "Commonwealth",
        "New South Wales",
        "Australian Capital Territory",
        "Northern Territory",
        "Queensland",
        "South Australia",
        "Tasmania",
        "Victoria",
        "Western Australia"
    ];

    $scope.daily = [
        {juris: 'all', report: 'all'},
        {juris: 'cth', report: 'all'},
        {juris: 'nsw', report: 'all'},
        {juris: 'act', report: 'all'},
        {juris: 'nt', report: 'all'},
        {juris: 'qld', report: 'all'},
        {juris: 'sa', report: 'all'},
        {juris: 'tas', report: 'all'},
        {juris: 'vic', report: 'all'},
        {juris: 'wa', report: 'all'}
    ];

    $scope.bill = [
        {juris: 'all', report: 'bill'},
        {juris: 'cth', report: 'bill'},
        {juris: 'nsw', report: 'bill'},
        {juris: 'act', report: 'bill'},
        {juris: 'nt', report: 'bill'},
        {juris: 'qld', report: 'bill'},
        {juris: 'sa', report: 'bill'},
        {juris: 'tas', report: 'bill'},
        {juris: 'vic', report: 'bill'},
        {juris: 'wa', report: 'bill'}
    ];

    $scope.new = [
        {juris: 'all', report: 'new'},
        {juris: 'cth', report: 'new'},
        {juris: 'nsw', report: 'new'},
        {juris: 'act', report: 'new'},
        {juris: 'nt', report: 'new'},
        {juris: 'qld', report: 'new'},
        {juris: 'sa', report: 'new'},
        {juris: 'tas', report: 'new'},
        {juris: 'vic', report: 'new'},
        {juris: 'wa', report: 'new'}
    ];

    $scope.rep = [
        {juris: 'all', report: 'repealed'},
        {juris: 'cth', report: 'repealed'},
        {juris: 'nsw', report: 'repealed'},
        {juris: 'act', report: 'repealed'},
        {juris: 'nt', report: 'repealed'},
        {juris: 'qld', report: 'repealed'},
        {juris: 'sa', report: 'repealed'},
        {juris: 'tas', report: 'repealed'},
        {juris: 'vic', report: 'repealed'},
        {juris: 'wa', report: 'repealed'}
    ];

    $scope.generateRSSUrl = function(report, juris, subject){
        var url = $scope.rssbase + "?report=" + report;

        // if(juris && juris.length > 0 && juris !== 'all'){
        //     url += ("&jurisdiction=" + juris);
        // }

        if(juris && juris.length > 0 && juris !== 'all'){
            if(Array.isArray(juris)){
                url += ("&jurisdiction=" + juris.join(','));
            }else{
                url += ("&jurisdiction=" + juris);
            }
        }

        if(subject){
            url += ("&subject=" + subject);
        }

        return url;
    };

    $scope.toggleJurisSubject = function(subject, juris){
        if(!subject.picked){
            subject.picked = [];
        }

        if(subject.picked.indexOf(juris) > -1){
            subject.picked.splice(subject.picked.indexOf(juris), 1);
        }else{
            subject.picked.push(juris);
        }
    };

    //TbApi.all('subjects.json').getList().then(function(ret){
    tbSubjectService.get().then(function(ret){
        $scope.subjectslist = ret['data']['subjects'];
    });
})

;
