angular.module( 'tbLawOne.lawtracker.alerts', [
  'ui.router',
  'ui.bootstrap',
  'restangular',
  'tbLawOne.services'
])

.config(function config( $stateProvider, $urlRouterProvider) {
    // LAWTRACKER: ALERTS
    $stateProvider
        .state( 'lawtracker.alerts', {
            abstract: true,
            views: {
                "lawtracker":{
                    controller: 'AlertsCtrl',
                    templateUrl: 'lawtracker/alerts/alerts.tpl.html'
                }
            },
            data:{ pageTitle: 'LawTracker - Alerts' }
            })
            //children of lawtracker.alerts
            .state( 'lawtracker.alerts.display', {
                url: '/alerts',
                views: {
                    "alert":{
                        controller: 'AlertsDisplayCtrl',
                        templateUrl: 'lawtracker/alerts/alertslist.tpl.html'
                    }
                }
            })
            .state('lawtracker.alerts.admin',{
                abstract: true,
                url: '/alerts/admin',
                views: {
                    "alert":{
                        controller: 'AlertsAdminCtrl',
                        templateUrl: 'lawtracker/alerts/alertsadmin.tpl.html'
                    }
                },
                data:{ pageTitle: 'LawTracker - Alerts Administration' }
            })
                .state('lawtracker.alerts.admin.profile',{
                    url: '/profiles',
                    views: {
                        "tab" :{
                            controller: 'AlertsAdminProfileCtrl',
                            templateUrl: 'lawtracker/alerts/alertsadminprofile.tpl.html'
                        }
                    }
                })
                .state('lawtracker.alerts.admin.users',{
                    url: '/users',
                    views: {
                        "tab" :{
                            controller: 'AlertsAdminUserCtrl',
                            templateUrl: 'lawtracker/alerts/alertsadminusers.tpl.html'
                        }
                    }
                })
            .state('lawtracker.alerts.summary',{
                url: '/alerts/profile/view/:id',
                views: {
                    "alert":{
                        controller: 'AlertsSummaryCtrl',
                        templateUrl: 'lawtracker/alerts/alertsummary.tpl.html'
                    }
                }
            })
            .state( 'lawtracker.alerts.profile', {
                abstract: true,
                url: '/alerts/profile/:edit?from',
                views: {
                    "alert":{
                        controller: 'AlertsProfileCtrl',
                        templateUrl: 'lawtracker/alerts/alertsprofile.tpl.html'
                    }
                },
                data:{ pageTitle: 'LawTracker - Edit tracked legislation' }
            })

                .state ('lawtracker.alerts.profile.subjects',{
                    parent: 'lawtracker.alerts.profile',
                    url: '/subjects',
                    views: {
                        "step":{
                            controller: 'AlertsProfileSubjectsCtrl',
                            //template: '<div>PROFILE SUBSTATE HO</div>'
                            templateUrl: 'lawtracker/alerts/alertssubject.tpl.html'
                        }
                    }
                })

                .state ('lawtracker.alerts.profile.legislation',{
                    parent: 'lawtracker.alerts.profile',
                    url: '/legislation',
                    views: {
                        "step":{
                            controller: 'AlertsProfileLegislationCtrl',
                            //template: '<div>PROFILE SUBSTATE HO</div>'
                            templateUrl: 'lawtracker/alerts/alertslegislation.tpl.html'
                        }
                    }
                })

                .state ('lawtracker.alerts.profile.review',{
                    parent: 'lawtracker.alerts.profile',
                    url: '/review',
                    views: {
                        "step":{
                            controller: 'AlertsProfileReviewCtrl',
                            //template: '<div>PROFILE SUBSTATE HO</div>'
                            templateUrl: 'lawtracker/alerts/alertsreview.tpl.html'
                        }
                    }
                })
    ;
})

.controller( 'AlertsCtrl', function AlertsController( $scope, $modal, tbUserService, TbApi) {

})

.controller('AlertsSummaryCtrl', function AlertsSummaryController($scope, $state, $stateParams, TbApi, $timeout){
    console.log('ALERTS SUMMARY CONTROLLER FIRED', $stateParams);

    $scope.profileId = $stateParams['id'];

    TbApi.one('profiles/'+$scope.profileId+'.json').get().then(function(ret){
        $scope.profile = ret['data'];

        if($scope.profile['membership']['role'] == 'Standard'){
            $scope.showUserBlock = true;
        }
    });

    //Pagination variables
    $scope.totalItemsReview = 0;
    $scope.currentPageReview = 1;
    $scope.itemsPerPageReview = 50;
    $scope.maxSizeReview = 5;
    $scope.numPagesReview = ($scope.totalItems / $scope.itemsPerPage);
    $scope.reviewHasLoaded = false;

    $scope.initForm = function(){
        $scope.jurisdictionsReview = {
            "allSelected" : false,
            "noneSelected" : true,
            "data" : [
                {name: "cth", isSelected: false},
                {name: "act", isSelected: false},
                {name: "nsw", isSelected: false},
                {name: "nt", isSelected: false},
                {name: "qld", isSelected: false},
                {name: "sa", isSelected: false},
                {name: "tas", isSelected: false},
                {name: "vic", isSelected: false},
                {name: "wa", isSelected: false}
            ]
        };

        $scope.doctypesReview = {
            "allSelected" : false,
            "noneSelected" : true,
            "data" : [
                {name: "act", isSelected: false},
                {name: "ord", isSelected: false},
                {name: "reg", isSelected: false},
                {name: "bill", isSelected: false},
                {name: "prn", isSelected: false},
                {name: "cpn", isSelected: false}
            ]
        };

        $scope.statusReview = {
            "allSelected" : false,
            "noneSelected" : true,
            "data" : [
                {name: "aws", isSelected: false},
                {name: "cur", isSelected: false},
                {name: "rep", isSelected: false},
                {name: "dra", isSelected: false},
                {name: "ass", isSelected: false},
                {name: "nis", isSelected: false},
                {name: "fail", isSelected: false}
            ]
        };

        $scope.principal = {
            'principal' : false,
            'amending' : false
        };
    };

    $scope.initForm();

    $scope.xvalReview = function(){
        var xval = (($scope.currentPageReview - 1) * $scope.itemsPerPageReview) + 1;
        if(xval < $scope.totalItemsReview){
            return xval;
        }else{
            return $scope.totalItemsReview;
        }
    };

    $scope.yvalReview = function(){
        var yval = ($scope.currentPageReview * $scope.itemsPerPageReview);
        if(yval < $scope.totalItemsReview){
            return yval;
        }else{
            return $scope.totalItemsReview;
        }
    };

    $scope.clearForm = function(){
        $scope.initForm();
        $scope.alphaLinkReview('');
    };

    $scope.applyFilters = function(){
        $scope.resetPagination();
        $scope.alertReviewSearch(1);
    };

    var getFormParams = function(page){

        //declare params object
        var params = {
            'scope': 'title',
            'profile': $stateParams['id']
        };

        if(page > 0){
            params['count'] = 50;
            params['sort'] = 'title';
            params['start'] = (((page - 1) * 50) + 1);
        }

        //grab alphabet
        if($scope.alphabetSelectedReview !== ""){
            params['starts-with'] = $scope.alphabetSelectedReview;
        }
        //grab jurisdictions
        console.log('jurischeck',$scope.jurisdictionsReview);
        if($scope.jurisdictionsReview.allSelected === true){
            params['jurisdiction'] = "cth,act,nsw,nt,qld,sa,tas,vic,wa";
        }else if($scope.jurisdictionsReview.allSelected === false && $scope.jurisdictionsReview.noneSelected === false){
            var ti = [];
            for(var i = 0;i<$scope.jurisdictionsReview.data.length;i++){
                if($scope.jurisdictionsReview.data[i].isSelected === true){
                    ti.push($scope.jurisdictionsReview.data[i]['name'].toLowerCase());
                }
            }
            params['jurisdiction'] = ti.toString();
        }else{
            console.log('no jurisdictions selected');
            params['jurisdiction'] = "";
        }

        //grab doctypes
        if($scope.doctypesReview.allSelected === true){
            params['doc-type'] = "act,ord,reg,bill,prn,cpn";
        }else if($scope.doctypesReview.allSelected !== true && $scope.doctypesReview.noneSelected !== true){
            var tj = [];
            for(var j = 0;j<$scope.doctypesReview.data.length;j++){
                if($scope.doctypesReview.data[j].isSelected === true){
                    tj.push($scope.doctypesReview.data[j]['name'].toLowerCase());
                }
            }
            params['doc-type'] = tj.toString();
        }else{
            params['doc-type'] = "";
        }

        //grab status
        if($scope.statusReview.allSelected === true){
            params['status'] = "aws,cur,rep,dra,ass,nis,fail";
        }else if($scope.statusReview.allSelected !== true && $scope.statusReview.noneSelected !== true){
            var tk = [];
            for(var k = 0;k<$scope.statusReview.data.length;k++){
                if($scope.statusReview.data[k].isSelected === true){
                    tk.push($scope.statusReview.data[k]['name'].toLowerCase());
                }
            }
            params['status'] = tk.toString();
        }else{
            params['status'] = "";
        }

        //grab principal
        if($scope.principal){
            if($scope.principal.principal && $scope.principal.amending){
                params['principal'] = "true,false";
            }else if($scope.principal.principal && !$scope.principal.amending){
                params['principal'] = "true";
            }else if(!$scope.principal.principal && $scope.principal.amending){
                params['principal'] = "false";
            }else if(!$scope.principal.principal && !$scope.principal.amending){
                params['principal'] = null;
            }
        }

        return params;
    };

    $scope.alertReviewSearch = function(page, disableAlpha, popInitialCounter){
        console.log('alertReviewSearch called',page);

        disableAlpha = (typeof disableAlpha === "undefined") ? false : disableAlpha;
        if($scope.cleanSlate){
            $scope.cleanSlate = false;
        }

        var params = getFormParams(page);

        //fire search request
        console.log('searching with', params);
        $scope.step3Loading = true;

        params['_'] = Date.now();

        TbApi.all('search.json').getList(params).then(function(res){
            console.log('returning', res);
            //process this first

            $scope.legResultsReview = res['data']['documents'];
            $scope.totalItemsReview = res['data']['hits'];
            $scope.numPagesReview = ($scope.totalItemsReview / $scope.itemsPerPageReview);
            $scope.reviewHasLoaded = true;

            if(popInitialCounter){
                $scope.trackedLegislationCounter = $scope.totalItemsReview;
            }

            //WARNING: HERESY
            //SUPER HERETICAL
            var elem = $('.resultsbox');
            elem.scrollTop(0);
        });
        if(!disableAlpha){
            console.log('alphabet repop');
            $scope.populateAlphabetReview(params);
        }
    };

    $scope.trackPagination = true;

    $scope.resetPagination = function(){
        $scope.trackPagination = false;
        $scope.currentPage = 1;
        $scope.trackPagination = true;
    };

    //pagination change listener
    $scope.$watch('currentPageReview', function(newPage, oldPage){
       console.log(newPage, oldPage);
       if($scope.trackPagination && (newPage != oldPage)){
            $scope.alertReviewSearch(newPage);
       }
    });

    function sortObject(o) {
        var sorted = {},
        key, a = [];

        for (key in o) {
            if (o.hasOwnProperty(key)) {
                a.push(key);
            }
        }

        a.sort();

        for (key = 0; key < a.length; key++) {
            sorted[a[key]] = o[a[key]];
        }
        return sorted;
    }

    $scope.alphabetReviewLoaded = false;
    $scope.populateAlphabetReview = function(params){
        //populate starts-with selection widget
        if(!params){params={};}
        var aparams = {
            'term':params['term'],
            'scope':params['scope'],
            'jurisdiction':params['jurisdiction'],
            'doc-type':params['doc-type'],
            'status':params['status'],
            'principal':params['principal'],
            'year':params['year'],
            'profile':params['profile']
        };
        TbApi.all('search/facets/starts-with.json').getList(aparams).then(function(ret){
            //console.log('original return',ret);
            //
            $scope.alphabetReviewLoaded = true;
            $scope.alphabetReview = _.groupBy(ret[2]['filters'],function(input){
                return input['name'].charAt(0);
            });

            var alpha=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
            for(var i=0;i<alpha.length;i++){
                if(!$scope.alphabetReview[alpha[i]]){
                    $scope.alphabetReview[alpha[i]] = [];
                }
            }

            $scope.alphabetReview = sortObject($scope.alphabetReview);

            if(params['starts-with']){
                $scope.toggleAlphabetReview(params['starts-with'][0]);
            }
        });
    };

    $scope.toggleAlphabetReview = function(topletter){
        _.forEach($scope.alphabetReview, function(item){
            item['selected'] = false;
        });
        if($scope.alphabetReview[topletter]){
            $scope.alphabetReview[topletter]['selected'] = true;
        }
    };

    $scope.alphabetSelectedReview = "";

    $scope.alphaLinkReview = function(string){
        console.log('startswith transition called', string);
        $scope.alphabetSelectedReview = string;

        if(string === ''){
            _.forEach($scope.alphabetReview, function(item){
                item['selected'] = false;
            });
        }
        $scope.alertReviewSearch(1, true);
    };

    //fire on state load
    $scope.alertReviewSearch(1, false, true);

    //ui-sref="searchprint({profile: profileId, prep: profile['name']})
    $scope.summaryPrint = function(){
        var printparams = getFormParams(0);
        printparams['profile'] = $scope.profileId;
        printparams['prep'] = $scope.profile['name'];
        printparams['juris'] = printparams['jurisdiction'];
        window.open($state.href('searchprint', printparams), '_blank');
    };

    $scope.statuscheck = function(str){
        switch(str){
            case 'Repealed legislation' : return "*** REPEALED"; //error
            case 'Repealed' : return "*** REPEALED";
            case 'Inoperative legislation': return "*** INOPERATIVE"; //error
            case 'Inoperative': return "*** INOPERATIVE";
            case 'Failed bill': return "*** FAILED"; //error
            case 'Failed': return "*** FAILED";
            case 'Assented bill': return "*** ASSENTED"; //error
            case 'Assented': return "*** ASSENTED";
            case 'Awaiting Assent': return "*** AWAITING ASSENT";
            case 'Spent legislation': return "*** SPENT"; //error
            case 'Spent': return "*** SPENT";
            case 'Draft': return '*** DRAFT';
            case 'Not in current session': return "*** NICS";
            default: return "";
        }
    };

})

.controller('AlertsAdminProfileCtrl', function AlertsAdminProfileController($scope){

})

.controller('AlertsAdminUserCtrl', function AlertsAdminUserController($scope, $state, tbUserService, TbApi, TbDrmApi, $modal){

    $scope.stashProfiles = [];

    $scope.loadOrgUsers = function(){
      TbDrmApi.all('users.json').getList({'organisation': tbUserService.getOrgID()}).then(function(ret){
        console.log('loadorgusers',ret);
        $scope.orgUserList = ret['users'];
      });
    };

    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            if(user['user']){
                //$scope.loadOrgProfiles();
                $scope.loadOrgUsers();
            }
        },
        true
    );

    $scope.loadUsers = function(profile){
        console.log('loadUsers', profile);
        if(!profile['extras'] || !profile['extras']['users']){
            profile['loading'] = true;
            TbApi.all('profiles/' + profile['id'] + '/members.json').getList().then(function(ret){
                console.log('loading members list',ret);
                profile['extras'] = {};
                profile['extras']['users'] = ret['data']['members'];

                profile['loading'] = false;
            });
        }
    };

    $scope.loadUserProfiles = function(user){
        console.log('loadUserProfiles called', user);

        if(!user['extras'] || !user['extras']['profiles']){
            user.isCollapsed = !user.isCollapsed;
            user['loading'] = true;
            TbApi.all('profiles.json').getList({ 'user': user.id }).then(function(ret){
                console.log('loading users profiles', ret);

                if(!user['extras'] || !user['extras']['profiles']){
                    user['extras'] = {};
                    user['extras']['profiles'] = [];
                }

                user['extras']['profiles'] = ret['data'];
                user['loading'] = false;
            });
        }else{
            delete user['extras'];
            user.isCollapsed = !user.isCollapsed;
        }
    };

    $scope.resetExtras = function(){
        for(var i = 0; i < $scope.orgUserList.length; i++){
            delete $scope.orgUserList[i]['extras'];
            $scope.orgUserList[i].isCollapsed = false;
        }
    };

    $scope.alertsShareModal = function(item, user){
        console.log('alertsShareModal called with', item);
        var modalInstance = $modal.open({
           templateUrl: 'user/sharealert.tpl.html',
           controller:  'AlertsShareModalCtrl',
           windowClass: 'alert-share-modal',
           resolve: {
                resItem: function(){
                    return item;
                }
           }
        });

        modalInstance.result['finally'](function(){
            $scope.resetExtras();
            $scope.loadUserProfiles(user);
        });
    };

    $scope.alertsDeleteModal = function(item, user){
        console.log('alertsDeleteModal FROM ADMIN called with', item);
        var modalInstance = $modal.open({
           templateUrl: 'user/deletealert.tpl.html',
           controller:  'AlertsAdminDeleteModalCtrl',
           windowClass: 'alert-delete-modal',
           resolve: {
                resItem: function(){
                    return item;
                },
                members: function(TbApi){
                    return TbApi.one('profiles/'+item['id']+'/members.json').get();
                }
           }
        });

        modalInstance.result.then(function(ret){
            if(ret){
                $scope.resetExtras();
                $scope.loadUserProfiles(user);
            }
        });
    };

    $scope.deleteProfileUser = function(profile, user){
        console.log('deleteProfileUser', profile, user);
        if(window.confirm('Are you sure you want to remove this user?')){
            TbApi.one('profiles/'+profile['id']+'/members/'+user['id']+'.json').customDELETE().then(function(ret){
                console.log('Delete return TEST',ret);
                //$scope.loadOrgUsers();
                //
                //SLICE THIS OUT OF THE USER'S ARRAY
                $scope.resetExtras();
                $scope.loadUserProfiles(user);
            });
        }
    };
})

.controller('AlertsAdminCtrl', function AlertsAdminController($scope, $state, $filter, tbUserService, TbApi, $modal){
    //for PROFILE ADMINISTRATORS ONLY


    $scope.loadProfiles = function(item){

        if(!$scope.loading){
            $scope.loading = true;
        }

        TbApi.all('profiles.json').getList({'organisation': tbUserService.getOrgID()}).then(function(ret){
            console.log('LOAD PROFILES!', ret);
            $scope.profiles = ret['data'];

            $scope.loading = false;

            if(item){
                var open = _.find($scope.profiles, function(sub){
                    return sub['id'] == item['id'];
                });
                console.log('target to open', open);
                if(open){
                    $scope.toggleAlert(open);
                }
            }
        });
    };

    $scope.toggleAlert = function(profile){
        profile['isCollapsed'] = !profile['isCollapsed'];
        $scope.loadUsers(profile);
        $scope.processSummaryStrings(profile);
    };

    $scope.loadUsers = function(profile){
        console.log('loadUsers', profile);
        if(!profile['extras'] || !profile['extras']['users']){
            profile['loading'] = true;
            TbApi.all('profiles/' + profile['id'] + '/members.json').getList().then(function(ret){
                console.log('loading members list',ret);
                profile['extras'] = {};
                profile['extras']['users'] = ret['data']['members'];

                profile['loading'] = false;
            });
        }
    };

    $scope.processSummaryStrings = function(alert){
        if(!alert['alert-events-strings']){
            console.log('SUMMARY STRING PROCESSOR CALLED', alert);
            var evts = [];
            var working = [];

            evts = _.map(alert['alert-events'], function(value, key){
                if(value){ return key; }
            });

            for(var i = 0; i < evts.length; i++){
                working.push($filter('activityNameFilter')(evts[i]));
            }

            working = _.compact(_.uniq(working));
            alert['alert-events-strings'] = working;
        }
    };

    $scope.saveProfile = function(item){
        console.log('save profile', item);

        //first check if this is a new or edit profile
        var putData = {
          "name": item['name'],
          "description": item['description'],
          "alert-no-activity": item['alert-no-activity'],
          "report-type": item['report-type'],
          "frequency": item['frequency'],
          "alert-events": item['alert-events']
        };

        TbApi.one('profiles/'+item['id']+'.json').customPUT(putData).then(function(ret){
            console.log('Edit existing profile return object',ret);
            $scope.loadProfiles(item);
        });
    };

    $scope.editProfileModal = function(item){
        console.log('editProfileModal called',item);
        var modalInstance = $modal.open({
           templateUrl: 'lawtracker/admineditprofilesummary.tpl.html',
           controller:  'EditProfileSummaryModalCtrl',
           windowClass: 'alert-create-modal',
           resolve: {
                profile: function(){return item;}
           }
        });

        modalInstance.result.then(function(ret){
            console.log('Edit modal closed, returning',ret);
            $scope.saveProfile(ret);
        });
    };


    $scope.modUserLevel = function(profile, user){
        console.log('modUserLevel', profile, user);

        var newUserRole = user['role'];
        var putData = {
            "role" : newUserRole
        };

        //check if user is the only profile manager by counting profile managers
        var counter = 0;
        for(var i = 0; i < profile['extras']['users'].length; i++){
            if(profile['extras']['users'][i]['role'].indexOf('Profile Manager') > -1){
                counter++;
            }
        }

        var execModUser = function(){
            console.log('execModUser fired');
            return TbApi.one('profiles/'+profile['id']+'/members/'+user['user']['id']+'.json').customPUT(putData).then(function(ret){
                console.log('Toggle user return object',ret);
                $scope.loadUsers(profile);

                //check if we just took ourselves off the admin list, if so hide admin features
                // if(newUserRole == 'Standard' && $scope.item['membership']['user']['email'] == ret['data']['membership']['user']['email']){
                //     $scope.adminVisible = false;
                // }
            });
        };
        //only allow the 'remove' operation if the number of profile managers is greater than one
        //if it's an 'add' operation we don't care about numbers, so let it through in that case

        switch(newUserRole){
            case 'Profile Manager': //check if we are making a profile manager
                console.log('Changing Standard to Manager');
                execModUser();
                break;
            case 'Standard': //we are demoting a profile manager
                console.log('Changing Manager to Standard');

                //first check to see if there are any managers left
                //if not, do nothing
                if(counter > 0){
                    //now check if we are a profile manager ourselves
                    if(profile['membership']['user']['email'] == user['user']['email']){
                        if(window.confirm('Are you sure you want to remove your own profile manager status?')){
                            console.log('we are not the only manager and we are OK with demoting ourselves');
                            execModUser();
                        }else{
                            console.log('aborting, we dont want to demote ourselves');
                            user['role'] = 'Profile Manager';
                        }
                    }else{
                        console.log('we are not the only manager and we arent dealing with ourselves');
                        execModUser();
                    }
                }else{
                    alert('You cannot remove the final profile manager from a profile!');
                    user['role'] = 'Profile Manager';
                }
                break;
        }
    };

    $scope.deleteUser = function(profile, user){
        console.log('deleteUser', profile, user);
        if(window.confirm('Are you sure you want to remove this user?')){
            TbApi.one('profiles/'+profile['id']+'/members/'+user['user']['id']+'.json').customDELETE().then(function(ret){
                console.log('Delete return TEST',ret);
                $scope.loadUsers(profile);
            });
        }
    };

    $scope.addUser = function(profile){
        console.log('Profile test',profile);

        var putData = {
            invitation: true
        };

        TbApi.one('profiles/'+profile['id']+'/members/'+encodeURIComponent(profile.extras.newuser)+'.json').customPUT(putData).then(function(ret){
            console.log('Add user return object',ret);
            //$scope.users[index] = ret['data']['membership'];
            profile.extras.newuser = "";
            $scope.loadUsers(profile);
        });
    };

    //modals
    var alertsModSwitch = function(input){
        var str = input.toLowerCase();
        switch(str){
            case 'progress':
                return 'progress';
            case 'commenced':
                return 'commence';
            case 'assented':
                return 'assent';
            case 'amended':
                return 'amend';
            case 'repealed':
                return 'repeal';
            case 'modified':
                return false;
            case 'published':
                return false;
            default:
                return null;
        }
    };
    var zeroPad = function(n){
        return (n < 10) ? ("0" + n) : n;
    };
    var getRoundString = function(date){
        return date.getFullYear() + "-" + zeroPad(parseInt(date.getMonth() + 1, 10)) + "-" + zeroPad(date.getDate()) + "T" + "00:00:00";
    };

    $scope.alertsReportModal = function(item){
        console.log('alertsReportModal called with', item);

        var modalInstance = $modal.open({
            templateUrl: 'user/reportalert.tpl.html',
            controller:  'AlertsReportModalCtrl',
            windowClass: 'alert-report-modal',
            resolve: {
                resItem: function(){
                    return item;
                }
            }
        });

        modalInstance.result.then(function(ret){
            if(ret){
                var estring = [];
                angular.forEach(item['alert-events'], function(v,k){
                    console.log(v, k);
                    if(v && alertsModSwitch(k)){
                        estring.push(alertsModSwitch(k));
                    }
                });
                estring.push('subordinate');

                console.log('alertsReportModal finished with', ret);

                //IF 'editorial', THEN add 'as-made'
                //IF 'editorial' AND (profile tracks OR report tracks bill/draft progress), THEN add 'progress-update'
                //IF 'real' AND (profile tracks OR report tracks bill/draft progress), THEN add 'progress'

                var edatestring = "real,editorial";
                if(item['alert-events']['progress']){
                    edatestring += ",progress";
                }

                var url = $state.href('lawtracker.custom.result', {
                    sdate: getRoundString(ret['dStart']),
                    edate: getRoundString(ret['dEnd']),
                    profile: item.id,
                    eventtype: estring.join(','),
                    eventdate: edatestring,
                    from: 'alert'
                });
                window.open(url, '_blank');
            }
        });
    };

    $scope.alertsPrintModal = function(){
        var modalInstance = $modal.open({
            templateUrl: 'user/printalert.tpl.html',
            controller: 'AlertsPrintModalCtrl',
            windowClass: 'alert-print-modal',
            resolve: {
                isAdmin: function(){
                    return true;
                }
            }
        });

        modalInstance.result.then(function(ret){
            if(ret){
                var params = {};
                switch(ret){
                    case 'titles':
                        params.admin = true;
                        break;
                    case 'details':
                        params.admin = true;
                        params.sections = true;
                        break;
                    case 'users':
                        params.users = true;
                        break;
                    case 'userdetails':
                        params.users = true;
                        params.details = true;
                        break;

                }

                var url = "";
                if(params.users){
                    url = $state.href('alertsusersprint', params);
                }else{
                    url = $state.href('alertsprint', params);
                }

                window.open(url, '_blank');
            }
        });
    };

    $scope.alertsShareModal = function(item){
        console.log('alertsShareModal called with', item);
        var modalInstance = $modal.open({
           templateUrl: 'user/sharealert.tpl.html',
           controller:  'AlertsShareModalCtrl',
           windowClass: 'alert-share-modal',
           resolve: {
                resItem: function(){
                    return item;
                }
           }
        });

        modalInstance.result['finally'](function(){
            console.log('Alerts share modal DISMISSED');
            $scope.loadProfiles(item);
        });
    };

    $scope.alertsDeleteModal = function(item){
        console.log('alertsDeleteModal FROM ADMIN called with', item);
        var modalInstance = $modal.open({
           templateUrl: 'user/deletealert.tpl.html',
           controller:  'AlertsAdminDeleteModalCtrl',
           windowClass: 'alert-delete-modal',
           resolve: {
                resItem: function(){
                    return item;
                },
                members: function(TbApi){
                    return TbApi.one('profiles/'+item['id']+'/members.json').get();
                }
           }
        });

        modalInstance.result.then(function(ret){
            if(ret){
                $scope.loadProfiles();
            }
        });
    };

    $scope.alertsList = [];
    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            $scope.userInfo = user;
            if(user['user']){
                console.log('Alerts List User Load', user);
                $scope.loadProfiles();
            }
        },
        true
    );
})

.controller( 'AlertsProfileCtrl', function AlertsProfileController( $scope,$state,$stateParams,$filter,tbUserService,TbApi, $modal, $timeout){
    //SUMMARY PORTION AND FULL PAGE
    $scope.showSummary = false;
    $scope.showSummaryEdit = false;

    $scope.tab = {
        subjects: true,
        legislation: false,
        review: false
    };

    $scope.defaultProfile = {
      "name": "",
      "description": "",
      "alert-no-activity": false,
      "report-type": "Standard",
      "frequency": [
        "daily"
      ],
      "alert-events": {
        "progress": true,
        "modified": false,
        "commenced": true,
        "published": false,
        "assented": true,
        "amended": true,
        "repealed": true
      }
    };

    $scope.databox = {};
    $scope.legForm = {};

    $scope.clearInput = function(type){
        switch(type){
            case 'title':
                $scope.legForm.legislationTitle = "";
                break;
            case 'year':
                $scope.legForm.year = "";
                break;
            case 'number':
                $scope.legForm.legnum = "";
                break;
        }

    };

    $scope.processSummaryStrings = function(alert){
        console.log('SUMMARY STRING PROCESSOR CALLED', alert);
        var evts = [];
        var working = [];

        evts = _.map(alert['alert-events'], function(value, key){
            if(value){ return key; }
        });

        for(var i = 0; i < evts.length; i++){
            working.push($filter('activityNameFilter')(evts[i]));
        }

        working = _.compact(_.uniq(working));
        alert['alert-events-strings'] = working;
    };

    $scope.loadEditableProfile = function(id){
        TbApi.one('profiles/'+id+'.json').get()
        .then(function(ret){
            console.log('HERP, get single profile:',ret['data']);
            $scope.profile = ret['data'];
            $scope.processSummaryStrings($scope.profile);
            console.log('DERP, assign single profile:',$scope.profile);

            if($scope.profile){
                $scope.frequencyOptions = {
                    'half-daily': _.contains($scope.profile['frequency'], 'half-daily'),
                    'daily': _.contains($scope.profile['frequency'], 'daily'),
                    'weekly': _.contains($scope.profile['frequency'], 'weekly'),
                    'monthly': _.contains($scope.profile['frequency'], 'monthly')
                };
            }
            $scope.loadExistingLegislation(id);
            $scope.loadInitialSearches(id);
        });
    };

    $scope.loadInitialSearches = function(id){
        console.log('LOADING INITIAL SEARCH NUMBERS');
        TbApi.all('search.json').getList({'profile':id, '_':Date.now()})
        .then(function(ret){
            //$scope.databox.legResultsReview = ret['data']['documents'];
            $scope.databox.legCounter = ret['data']['hits'];
            $scope.databox.legReviewCounter = ret['data']['hits'];
        });
    };

    //INIT
    console.log('profile controller init state params',$stateParams);
    $scope.returnToAdmin = $stateParams['from'];
    if($stateParams['edit']){
        $scope.editProfile = $stateParams['edit'];
        $scope.loadEditableProfile($scope.editProfile);
    }else{
        $scope.profile = JSON.parse(JSON.stringify($scope.defaultProfile));
        $scope.frequencyOptions = {
            'daily': true
        };
    }
    $scope.databox.subjectCounter = 0;

    $scope.existingLegList = [];
    $scope.loadExistingLegislation = function(id){
        TbApi.one('profiles/'+id+'/legislation.json').get()
        .then(function(ret){
            console.log('load existing legs', ret);
            //make a list of existing legislation by item
            for(var i = 0, vlen = ret['data']['tracked-legislation'].length; i < vlen; ++i){
                $scope.existingLegList.push(
                    {
                        'legislation-id': ret['data']['tracked-legislation'][i]['legislation-id'],
                        'tracked': (ret['data']['tracked-legislation'][i]['tracked'])
                    }
                );
            }
        });
    };

    $scope.reportOptions = [
        {
            'name': "Standard",
            'value': "Standard"
        },
        {
            'name': "Summary Only",
            'value': "Summary"
        }
    ];

    $scope.makeFrequencyArray = function(){
        var arr = [];
        if($scope.frequencyOptions['half-daily']){ arr.push('half-daily'); }
        if($scope.frequencyOptions['daily']){ arr.push('daily'); }
        if($scope.frequencyOptions['weekly']){ arr.push('weekly'); }
        if($scope.frequencyOptions['monthly']){ arr.push('monthly'); }
        return arr;
    };

    $scope.saveProfile = function(){
        //first check if this is a new or edit profile
        var putData = {};

        if($stateParams['edit']){

            $scope.profile['frequency'] = $scope.makeFrequencyArray();
            putData = $scope.profile;

            TbApi.one('profiles/'+$stateParams['edit']+'.json').customPUT(putData).then(function(ret){
                console.log('Edit existing profile return object',ret);
                //$state.go('lawtracker.alerts.display');
                $scope.loadEditableProfile($scope.editProfile);
                $scope.showSummaryEdit = false;
            });
        }else{
            $scope.profile['frequency'] = $scope.makeFrequencyArray();
            putData = $scope.profile;

            TbApi.one('profiles.json').customPOST(putData).then(function(ret){
                console.log('Add new profile return object',ret);
                //$state.go('lawtracker.alerts.display');
                $scope.loadEditableProfile($scope.editProfile);
                $scope.showSummaryEdit = false;
            });
        }
    };

    $scope.omniSubmit = function(){
        console.log('omniSubmit!');
        $scope.$broadcast('profileOmniSubmit');
        $scope.subStateChanged = false;
    };

    $scope.$on('reloadNumbers', function(){
        $scope.loadInitialSearches($scope.editProfile);
    });

    $scope.$on('$stateChangeSuccess', function(){
        $scope.loadInitialSearches($scope.editProfile);
    });

    $scope.subStateChanged = false;

    //this is for catching the transition out
    $scope.$watch('subStateChanged', function(newValue, oldValue){
        console.log('SUBSTATE CHANGED FLAG', $state);
        $state.current.data.subStateChanged = newValue;
    });

    //handling transitions
    $scope.changeSubState = function(input){
        console.log(input);
        switch(input){
            case 'subjects':
                $state.go('lawtracker.alerts.profile.subjects');
                break;
            case 'legislation':
                $state.go('lawtracker.alerts.profile.legislation');
                break;
            case 'review':
                $state.go('lawtracker.alerts.profile.review');
                break;
        }
    };

    $scope.$on('subStateChanged', function(event){
        event.preventDefault();
        event.stopPropagation();
        if(!$scope.subStateChanged){
            $scope.subStateChanged = true;
        }
    });

    $scope.$on('subStateReset',function(event){
        event.preventDefault();
        event.stopPropagation();
        if($scope.subStateChanged){
            $scope.subStateChanged = false;
        }
    });

    $scope.statuscheck = function(str){
        switch(str){
            case 'Repealed legislation' : return "*** REPEALED"; //error
            case 'Repealed' : return "*** REPEALED";
            case 'Inoperative legislation': return "*** INOPERATIVE"; //error
            case 'Inoperative': return "*** INOPERATIVE";
            case 'Failed bill': return "*** FAILED"; //error
            case 'Failed': return "*** FAILED";
            case 'Assented bill': return "*** ASSENTED"; //error
            case 'Assented': return "*** ASSENTED";
            case 'Awaiting Assent': return "*** AWAITING ASSENT";
            case 'Spent legislation': return "*** SPENT"; //error
            case 'Spent': return "*** SPENT";
            case 'Draft': return '*** DRAFT';
            case 'Not in current session': return "*** NICS";
            default: return "";
        }
    };
})

.controller( 'AlertsProfileSubjectsCtrl', function AlertsProfileSubjectController( $scope, $state, TbApi, $timeout, tbSubjectService) {

    $scope.legForm.subjects = "";
    $scope.showSubExtras = false;

    $scope.defaultSubObject = {
        'juris':{
            'cth':true,
            'act':true,
            'nsw':true,
            'nt':true,
            'qld':true,
            'sa':true,
            'tas':true,
            'vic':true,
            'wa':true
        },
        'type':{
            'act':true,
            'bill':true,
            'reg':true,
            'ord':true,
            'cpn':true,
            'prn': true
        }
    };

    function initSubjectsForEdit(list){
        console.log("initializing subjects", list);
        $scope.databox.subjectCounter = 0;
        $scope.step2Loading = false;

        //go through the whole subject list
        var mlist = $scope.subjectslist['data']['subjects'];
        for(var i = 0, mlen = mlist.length;i<mlen;++i){
            //check if the current node we are at exists inside the list of selected subjects
            var mfd = _.find(list, {'subject-id': mlist[i]['doc-id']});
            if(mfd){
                console.log('MFD', mfd);
                mlist[i]['ischecked'] = true;
                mlist[i]['sobj'] = {
                    'juris':{
                        'cth': (mfd['jurisdictions'].indexOf('cth') > -1),
                        'act': (mfd['jurisdictions'].indexOf('act') > -1),
                        'nsw': (mfd['jurisdictions'].indexOf('nsw') > -1),
                        'nt': (mfd['jurisdictions'].indexOf('nt') > -1),
                        'qld': (mfd['jurisdictions'].indexOf('qld') > -1),
                        'sa': (mfd['jurisdictions'].indexOf('sa') > -1),
                        'tas': (mfd['jurisdictions'].indexOf('tas') > -1),
                        'vic': (mfd['jurisdictions'].indexOf('vic') > -1),
                        'wa': (mfd['jurisdictions'].indexOf('wa') > -1)
                    },
                    'type':{
                        'act':(mfd['document-types'].indexOf('act') > -1),
                        'ord':(mfd['document-types'].indexOf('act') > -1),
                        'bill':(mfd['document-types'].indexOf('bill') > -1),
                        'reg':(mfd['document-types'].indexOf('reg') > -1),
                        'prn':(mfd['document-types'].indexOf('reg') > -1),
                        'cpn':(mfd['document-types'].indexOf('reg') > -1)
                    }
                };
                $scope.selectMainSubject(mlist[i]['id']);
            }

            var slist = mlist[i]['_embedded']['sub-subjects'];
            for(var j = 0, slen = slist.length; j < slen;++j){
                var smd = _.find(list, {'subject-id': slist[j]['doc-id']});

                if(smd){
                    slist[j]['ischecked'] = true;
                    slist[j]['sobj'] = {
                        'juris':{
                            'cth': (smd['jurisdictions'].indexOf('cth') > -1),
                            'act': (smd['jurisdictions'].indexOf('act') > -1),
                            'nsw': (smd['jurisdictions'].indexOf('nsw') > -1),
                            'nt': (smd['jurisdictions'].indexOf('nt') > -1),
                            'qld': (smd['jurisdictions'].indexOf('qld') > -1),
                            'sa': (smd['jurisdictions'].indexOf('sa') > -1),
                            'tas': (smd['jurisdictions'].indexOf('tas') > -1),
                            'vic': (smd['jurisdictions'].indexOf('vic') > -1),
                            'wa': (smd['jurisdictions'].indexOf('wa') > -1)
                        },
                        'type':{
                            'act':(smd['document-types'].indexOf('act') > -1),
                            'ord':(smd['document-types'].indexOf('act') > -1),
                            'bill':(smd['document-types'].indexOf('bill') > -1),
                            'reg':(smd['document-types'].indexOf('reg') > -1),
                            'prn':(smd['document-types'].indexOf('reg') > -1),
                            'cpn':(smd['document-types'].indexOf('reg') > -1)
                        }
                    };

                    $scope.databox.subjectCounter += 1;
                    $scope.selectSubSubject(mlist[i]['id'], slist[j]['id']);
                }
            }
        }
        //turn off the loading icon
    }

    //trawls through subjectlist to submit all selected subjects
    $scope.trawl = function(){
        var list = $scope.subjectslist['data']['subjects'];
        console.log('TRAWLING THE SEA',list);

        var output = [];
        for(var i=0;i<list.length;i++){
            if(list[i]['ischecked']){
                var iob = {
                    "subject-id": list[i]['doc-id'],
                    "jurisdictions": [],
                    "document-types": []
                };

                if(!list[i]['sobj']){
                    list[i]['sobj'] = JSON.parse(JSON.stringify($scope.defaultSubObject));
                }

                for(var k1 in list[i]['sobj']['juris']){
                    if(list[i]['sobj']['juris'][k1]){
                        iob['jurisdictions'].push(k1);
                    }
                }

                for(var k2 in list[i]['sobj']['type']){
                    if(list[i]['sobj']['type'][k2]){
                        iob['document-types'].push(k2);
                    }
                }

                output.push(iob);
            }else{
                var sub = list[i]['_embedded']['sub-subjects'];
                for(var j=0;j<sub.length;j++){
                    if(sub[j]['ischecked']){

                        var sob = {
                            "subject-id": sub[j]['doc-id'],
                            "jurisdictions": [],
                            "document-types": []
                        };

                        if(!sub[j]['sobj']){
                            sub[j]['sobj'] = JSON.parse(JSON.stringify($scope.defaultSubObject));
                        }

                        for(var k3 in sub[j]['sobj']['juris']){
                            if(sub[j]['sobj']['juris'][k3]){
                                sob['jurisdictions'].push(k3);
                            }
                        }

                        for(var k4 in sub[j]['sobj']['type']){
                            if(sub[j]['sobj']['type'][k4]){
                                sob['document-types'].push(k4);
                            }
                        }

                        output.push(sob);
                    }
                }
            }
        }
        if(output.length > 0){
            $scope.showSubExtras = true;
        }else{
            $scope.showSubExtras = false;
        }

        return output;
    };

    $scope.selectMainSubject = function(id){
        $scope.$emit('subStateChanged');
        var subject = _.find($scope.subjectslist['data']['subjects'],{'id': id});
        var counter = 0;

        console.log('selectMainSubject called', id, subject);

        if(!subject['sobj']){
            subject['sobj'] = JSON.parse(JSON.stringify($scope.defaultSubObject));
        }

        if(subject['ischecked'] === true){
            //$scope.databox.subjectCounter += subject['_embedded']['sub-subjects'].length;
           // subject['sobj'] = JSON.parse(JSON.stringify($scope.defaultSubObject));

            for(var k=0;k<subject['_embedded']['sub-subjects'].length;k++){
                if(_.isEqual(subject['sobj'], $scope.defaultSubObject)){
                    subject['_embedded']['sub-subjects'][k]['sobj'] = JSON.parse(JSON.stringify($scope.defaultSubObject));
                }else{
                    subject['_embedded']['sub-subjects'][k]['sobj'] = JSON.parse(JSON.stringify(subject['sobj']));
                }

                if(!subject['_embedded']['sub-subjects'][k]['ischecked']){
                    subject['_embedded']['sub-subjects'][k]['ischecked'] = true;
                    $scope.databox.subjectCounter++;
                }
                counter++;
            }
        }else{
            subject['sobj'] = null;
            //$scope.databox.subjectCounter -= subject['_embedded']['sub-subjects'].length;
            for(var l=0;l<subject['_embedded']['sub-subjects'].length;l++){
                subject['_embedded']['sub-subjects'][l]['ischecked'] = false;
                subject['_embedded']['sub-subjects'][l]['sobj'] = null;
                $scope.databox.subjectCounter--;
            }
            counter = 0;
        }
        subject['childCheckedCount'] = counter;
        //$scope.legForm.subjects = $scope.trawl();
    };

    $scope.selectSubSubject = function(pid, id){
        $scope.$emit('subStateChanged');
        //get parent
        var subject = _.find($scope.subjectslist['data']['subjects'],{'id': pid});
        var counter = 0;

        //change this logic
        var mysobj = [];
        for(var m=0;m<subject['_embedded']['sub-subjects'].length;m++){
            mysobj.push(subject['_embedded']['sub-subjects'][m]['sobj']);
            if(subject['_embedded']['sub-subjects'][m].ischecked){
                counter++;
            }
        }

        //now also test if all the sobjs are the same, if not we DO NOT tag the parent!
        var allthesame = !!mysobj.reduce(function(a, b){
            return (_.isEqual(a, b)) ? a : NaN;
        });

        if(counter >= subject['_embedded']['sub-subjects'].length && allthesame){
            subject['ischecked'] = true;
        }else{
            subject['ischecked'] = false;
        }

        console.log(counter);
        //$scope.legForm.subjects  = $scope.trawl();
        subject['childCheckedCount'] = counter;
    };

    $scope.toggleSubSubject = function(sub){
        sub['ischecked'] = !sub['ischecked'];
        if(sub['ischecked']){
            if(!sub['sobj']){
                sub['sobj'] = JSON.parse(JSON.stringify($scope.defaultSubObject));
            }
            $scope.databox.subjectCounter += 1;
        }else{
            $scope.databox.subjectCounter -= 1;
            sub['sobj'] = null;
        }
    };

    $scope.toggleSubExtra = function(item, string1, string2, parent){
        $scope.$emit('subStateChanged');

        if(string1 && string2){
            item['sobj'][string1][string2] = !item['sobj'][string1][string2];

            if(item['_embedded']){
                var subs = item['_embedded']['sub-subjects'];
                for(var i=0;i<subs.length;i++){
                    if(item['sobj'][string1][string2] === true){
                        subs[i]['sobj'][string1][string2] = true;
                    }else{
                        subs[i]['sobj'][string1][string2] = false;
                    }
                }
            }else{
                //now we need to check if we have siblings
                //if we're different from siblings, we untick the parent
                if(parent){
                    console.log('toggleSubExtra',item, parent);
                    var cur = item['sobj'];
                    var sibs = parent['_embedded']['sub-subjects'];
                    var counter = 0;

                    for(var j=0;j<sibs.length; j++){
                        if(!_.isEqual(cur, sibs[j]['sobj'])){
                            parent['ischecked'] = false;
                            break;
                        }else{
                            counter++;
                        }
                    }

                    if(counter >= sibs.length){
                        parent['ischecked'] = true;
                        if(!_.isEqual(parent['sobj'], cur)){
                            parent['sobj'] = JSON.parse(JSON.stringify(cur));
                        }
                    }
                }
            }
        }
    };

    $scope.saveSubjects = function(stateInfo){
        var putData = $scope.trawl();
        console.log('FISH',putData);

        if(putData && putData.length < 1){
            TbApi.one('profiles/'+$scope.editProfile+'/subjects/all.json').customDELETE().then(
                function(ret){
                    alert('Your profile is successfully saved!');
                    console.log('Delete return TEST',ret);
                    $scope.$emit('reloadNumbers');
                    $scope.$emit('subStateReset');

                    if(stateInfo){
                        $state.go(stateInfo.toState, stateInfo.toParams);
                    }
                }
            );
        }else{
            TbApi.one('profiles/' + $scope.editProfile + '/subjects/all.json').customPUT(putData).then(
                function(ret){
                    console.log('Add tracked subjects', ret);
                    alert('Your profile is successfully saved!');
                    $scope.$emit('reloadNumbers');
                    $scope.$emit('subStateReset');

                    if(stateInfo){
                        $state.go(stateInfo.toState, stateInfo.toParams);
                    }
                }
            );
        }
    };

    if(!$scope.subjectslist){
        $scope.step2Loading = true;
        //TbApi.all('subjects.json').getList().then(function(res){
        tbSubjectService.get().then(function(res){
            console.log('returning list of subjects', res);
            $scope.subjectslist = res;
        }).then(function(){
            TbApi.all('profiles/'+$scope.editProfile+'/subjects.json').getList().then(function(res){
                console.log('SUBJECTS OWNED BY PROFILE',res['data']);
                initSubjectsForEdit(res['data']['tracked-subjects']);
                $scope.$emit('subStateReset');
            });
        });
    }

    $scope.$on('profileOmniSubmit', function(event, stateInfo){
        event.preventDefault();
        console.log('I OBEY THE OMNI BUTTON! SUBJECT SAVE!', event);
        $scope.saveSubjects(stateInfo);
    });
})

.controller( 'AlertsProfileLegislationCtrl', function AlertsProfileLegislationController( $scope, $state, TbApi, $timeout ) {

    var initCheckboxes = function(){
        $scope.jurisdictions = {
            "allSelected" : false,
            "noneSelected" : true,
            "data" : [
                {name: "cth", isSelected: false},
                {name: "act", isSelected: false},
                {name: "nsw", isSelected: false},
                {name: "nt", isSelected: false},
                {name: "qld", isSelected: false},
                {name: "sa", isSelected: false},
                {name: "tas", isSelected: false},
                {name: "vic", isSelected: false},
                {name: "wa", isSelected: false}
            ]
        };

        $scope.doctypes = {
            "allSelected" : false,
            "noneSelected" : true,
            "data" : [
                {name: "act", isSelected: false},
                {name: "ord", isSelected: false},
                {name: "reg", isSelected: false},
                {name: "bill", isSelected: false},
                {name: "prn", isSelected: false},
                {name: "cpn", isSelected: false}
            ]
        };

        $scope.status = {
            "allSelected" : false,
            "noneSelected" : true,
            "data" : [
                {name: "aws", isSelected: false},
                {name: "cur", isSelected: false},
                {name: "rep", isSelected: false},
                {name: "dra", isSelected: false},
                {name: "ass", isSelected: false},
                {name: "nis", isSelected: false},
                {name: "fail", isSelected: false}
            ]
        };

        $scope.principal = {
            'principal' : false,
            'amending' : false
        };
    };

    $scope.tempMemory = {
        'forceTrack' : [],
        'forceUntrack' : []
    };

    //Results document array
    //$scope.databox.legResults = [];
    $scope.cleanSlate = true;

    //Pagination variables
    $scope.totalItems = 0;
    $scope.currentPage = 1;
    $scope.itemsPerPage = 50;
    $scope.maxSize = 5;
    $scope.numPages = ($scope.totalItems / $scope.itemsPerPage);
    $scope.legislationCart = [];
    $scope.legislationRemovalCart = [];
    $scope.legHasLoaded = false;

    //$scope.databox.legCounter = 0;

    // $scope.$watch('legCounter', function(newVal, oldVal){
    //     //$scope.$parent.topLegCounter = $scope.databox.legCounter;
    //     console.log('parentLegCounter', $scope.$parent.topLegCounter);
    //     console.log('legCounter', $scope.databox.legCounter);
    //     console.log('newVal oldVal', newVal, oldVal);

    //     $scope.$parent.topLegCounter = $scope.databox.legCounter;
    // });

    $scope.initForm = function(){
        $scope.legForm.legislationTitle = "";
        $scope.legForm.year = "";
        $scope.legForm.legnum = "";
        initCheckboxes();
    };

    $scope.clearForm = function(){
        $scope.initForm();
        $scope.alphaLink('');
    };
    $scope.initForm();

    $scope.saveLegislation = function(stateInfo){
        //go through the current list of legislation stuff we have stored
        //make them into the objects the PUT request expects
        var putData = $scope.existingLegList;

        if(putData && putData.length < 1){
            TbApi.one('profiles/'+$scope.editProfile+'/legislation/all.json').customDELETE().then(
                function(ret){
                    alert('Your profile is successfully saved!');
                    console.log('Delete return TEST',ret);
                    $scope.$emit('reloadNumbers');

                    $scope.tempMemory = {
                        'forceTrack' : [],
                        'forceUntrack' : []
                    };

                    if(stateInfo){
                        $state.go(stateInfo.toState, stateInfo.toParams);
                    }
                }
            );
        }else{
            TbApi.one('profiles/' + $scope.editProfile + '/legislation/all.json').customPUT(putData).then(
                function(ret){
                    alert('Your profile is successfully saved!');
                    console.log('Add tracked subjects', ret);
                    $scope.$emit('reloadNumbers');

                    $scope.tempMemory = {
                        'forceTrack' : [],
                        'forceUntrack' : []
                    };

                    if(stateInfo){
                        $state.go(stateInfo.toState, stateInfo.toParams);
                    }
                }
            );
        }
    };

    var isLegInList = function(id){
        for(var i = 0, len = $scope.existingLegList.length; i < len; i++){
            if($scope.existingLegList[i]['legislation-id'] == id){
                return i;
            }
        }
        return -1;
    };

    $scope.toggleCheckedItem = function(item){
        console.log('Toggle Checked Item', item);
        console.log('CURRENT List of Tracked Legs', $scope.existingLegList);
        console.log('Checking List Index', isLegInList(item['doc-id']));

        $scope.$emit('subStateChanged');
        var listIndex = isLegInList(item['doc-id']);

        //are we toggling off or on
        if(item['tracked']){ //item is being untracked
            console.log('ITEM IS BEING UNTRACKED');
            //check if this thing is in the list
            if(listIndex != -1){ //yes it is, remove it
                //first add its doc-id to the temporary list of things that we must always remove
                console.log('putting in forceUntrack', item['doc-id']);
                $scope.tempMemory.forceUntrack.push(item['doc-id']);
                $scope.existingLegList.splice(listIndex, 1);

            }else{ //no it's not, add it to the list with tracked = false
                $scope.existingLegList.push({
                    'legislation-id': item['doc-id'],
                    'tracked': false
                });
            }
            //and take one off the counter
            $scope.databox.legCounter -= 1;
            //trip the global counter
        }else{ //item is being tracked
            console.log('ITEM IS BEING TRACKED');
            //check if this thing is in the list
            if(listIndex != -1){ //yes it is, make false true by removing it
                console.log('putting in forceTrack', item['doc-id']);
                $scope.tempMemory.forceTrack.push(item['doc-id']);
                $scope.existingLegList.splice(listIndex, 1);
            }else{ //no it's not, add it to the list with tracked = true
                $scope.existingLegList.push({
                    'legislation-id': item['doc-id'],
                    'tracked': true
                });
            }
            //and add one to the counter
            $scope.databox.legCounter += 1;
        }

        //now we flip the bit for UI
        item['tracked'] = !item['tracked'];

         console.log('AFTER', $scope.existingLegList);
         console.log('List of Tracked Legs', $scope.existingLegList);
         console.log('Toggle Checked Item', item);
         console.log('Checking List Index', isLegInList(item['doc-id']));
    };

    $scope.selectAllItems = function(){
        for(var i = 0; i < $scope.databox.legResults.length; i++){
            if(!$scope.databox.legResults[i].tracked){
                $scope.toggleCheckedItem($scope.databox.legResults[i]);
            }
        }
    };

    $scope.deselectAllItems = function(){
        for(var i = 0; i < $scope.databox.legResults.length; i++){
            if($scope.databox.legResults[i].tracked){
                $scope.toggleCheckedItem($scope.databox.legResults[i]);
            }
        }
    };

    $scope.xval = function(){
        var xval = (($scope.currentPage - 1) * $scope.itemsPerPage) + 1;
        if(xval < $scope.totalItems){
            return xval;
        }else{
            return $scope.totalItems;
        }
    };

    $scope.yval = function(){
        var yval = ($scope.currentPage * $scope.itemsPerPage);
        if(yval < $scope.totalItems){
            return yval;
        }else{
            return $scope.totalItems;
        }
    };

    //Search function
    $scope.alertLegSearch = function(page, disableAlpha){
        console.log('step 3 leg search submission function called');
        disableAlpha = (typeof disableAlpha === "undefined") ? false : disableAlpha;
        if($scope.cleanSlate){
            $scope.cleanSlate = false;
        }

        console.log($scope.currentPage);
        if(page == 1){
            $scope.resetPagination();
        }

        //declare params object
        var params = {
            'scope': 'title',
            'count': 50,
            'sort': 'title',
            'start': (((page - 1) * 50) + 1),
            'indicate-tracking': $scope.editProfile
        };

        //if they typed anything or chose an item in the words box, use it
        if($scope.legForm.legislationTitle){
            params['term'] = $scope.legForm.legislationTitle;
        }

        //grab year, number
        if($scope.legForm.year){
            params['year'] = $scope.legForm.year;
        }
        //there is no number parameter in the search, dummy this out
        if($scope.legForm.legnum){
            params['number'] = $scope.legForm.legnum;
        }

        //grab alphabet
        if($scope.alphabetSelected !== ""){
            params['starts-with'] = $scope.alphabetSelected;
        }

        //grab jurisdictions
        if($scope.jurisdictions.allSelected === true){
            params['jurisdiction'] = "cth,act,nsw,nt,qld,sa,tas,vic,wa";
        }else if($scope.jurisdictions.allSelected === false && $scope.jurisdictions.noneSelected === false){
            var ti = [];
            for(var i = 0;i<$scope.jurisdictions.data.length;i++){
                if($scope.jurisdictions.data[i].isSelected === true){
                    ti.push($scope.jurisdictions.data[i]['name'].toLowerCase());
                }
            }
            params['jurisdiction'] = ti.toString();
        }

        //grab doctypes
        if($scope.doctypes.allSelected === true){
            params['doc-type'] = "act,ord,reg,bill,prn,cpn";
        }else if($scope.doctypes.allSelected !== true && $scope.doctypes.noneSelected !== true){
            var tj = [];
            for(var j = 0;j<$scope.doctypes.data.length;j++){
                if($scope.doctypes.data[j].isSelected === true){
                    tj.push($scope.doctypes.data[j]['name'].toLowerCase());
                }
            }
            params['doc-type'] = tj.toString();
        }

        console.log('STATUS OBJECT',$scope.status);
        //grab status
        if($scope.status.allSelected === true){
            params['status'] = "";
        }else if($scope.status.allSelected !== true && $scope.status.noneSelected !== true){
            var tk = [];
            for(var k = 0;k<$scope.status.data.length;k++){
                if($scope.status.data[k].isSelected === true){
                    tk.push($scope.status.data[k]['name'].toLowerCase());
                }
            }
            params['status'] = tk.toString();
        }

        //grab principal
        if($scope.principal){
            if($scope.principal.principal && $scope.principal.amending){
                params['principal'] = "true,false";
            }else if($scope.principal.principal && !$scope.principal.amending){
                params['principal'] = "true";
            }else if(!$scope.principal.principal && $scope.principal.amending){
                params['principal'] = "false";
            }else if(!$scope.principal.principal && !$scope.principal.amending){
                params['principal'] = undefined;
            }
        }

        //fire search request
        console.log('searching with', params);
        $scope.step3Loading = true;
        params['_'] = Date.now();
        TbApi.all('search.json').getList(params).then(function(res){
            console.log('returning legislation search request', res['data']['documents']);
            console.log('current drawer contents', $scope.existingLegList);
            console.log('current force memory contents', $scope.tempMemory);

            //we now need to check if any of the things coming back are in our list of already-selected legislation
            var reviewHolder = res['data']['documents'];

            //for each item in the list we've just got from the server
            for(var i = 0, holderLength = reviewHolder.length; i<holderLength; i++){

                //let's pre-emptively get the list index of the current item's doc-id in the existingLegList
                var cur = isLegInList(reviewHolder[i]['doc-id']);

                //and check whether this is present - it is
                if(cur > -1){
                    //and it's marked as tracked = true in the list, so let's mark it tracked
                    if($scope.existingLegList[cur] && $scope.existingLegList[cur]['tracked']){
                        reviewHolder[i]['tracked'] = true;
                    }

                    //it is in the list and as tracked = false, so let's mark it untracked
                    else if($scope.existingLegList[cur] && !$scope.existingLegList[cur]['tracked']){
                        reviewHolder[i]['tracked'] = false;
                    }
                }

                //it is not, which means it is either untracked entirely or the user has untracked it, let's check if they have
                else{
                    //is it in the force-tracked list?
                    if($scope.tempMemory.forceTrack.indexOf(reviewHolder[i]['doc-id']) > -1){
                        reviewHolder[i]['tracked'] = true;
                    }

                    //is it in the force-UNtracked list? If so, set false
                    else if($scope.tempMemory.forceUntrack.indexOf(reviewHolder[i]['doc-id']) > -1){
                        reviewHolder[i]['tracked'] = false;
                    }
                }
            }

            $scope.databox.legResults = reviewHolder;

            //current counter
            $scope.currentCounter = $scope.databox.legResults.length;

            $scope.totalItems = res['data']['hits'];
            $scope.numPages = ($scope.totalItems / $scope.itemsPerPage);
            $scope.legHasLoaded = true;

            //WARNING: HERESY
            //SUPER HERETICAL
            var elem = $('.resultsbox');
            elem.scrollTop(0);
        });

        if(!disableAlpha){
            console.log('alphabet repop');
            $scope.populateAlphabet(params);
        }
    };

    $scope.trackPagination = true;

    $scope.resetPagination = function(){
        $scope.trackPagination = false;
        $scope.currentPage = 1;
        $scope.trackPagination = true;
    };

    //pagination change listener
    $scope.$watch('currentPage', function(newPage, oldPage){
       console.log(newPage, oldPage);
       if($scope.trackPagination && (newPage != oldPage)){
            $scope.alertLegSearch(newPage);
       }
    });

    $scope.applyFilters = function(){
        $scope.resetPagination();
        $scope.alertLegSearch(1);
    };

    function sortObject(o) {
        var sorted = {},
        key, a = [];

        for (key in o) {
            if (o.hasOwnProperty(key)) {
                a.push(key);
            }
        }

        a.sort();

        for (key = 0; key < a.length; key++) {
            sorted[a[key]] = o[a[key]];
        }
        return sorted;
    }

    $scope.alphabetLoaded = false;
    $scope.populateAlphabet = function(params){
        //populate starts-with selection widget
        if(!params){params={};}

        var aparams = {
            'term':params['term'],
            'scope':params['scope'],
            'jurisdiction':params['jurisdiction'],
            'doc-type':params['doc-type'],
            'status':params['status'],
            'principal':params['principal'],
            'year':params['year']
        };

        TbApi.all('search/facets/starts-with.json').getList(aparams).then(function(ret){
            $scope.alphabetLoaded = true;
            //console.log('original return',ret);
            $scope.alphabet = _.groupBy(ret[2]['filters'],function(input){
                return input['name'].charAt(0);
            });

            var alpha=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
            for(var i=0;i<alpha.length;i++){
                if(!$scope.alphabet[alpha[i]]){
                    $scope.alphabet[alpha[i]] = [];
                }
            }

            $scope.alphabet = sortObject($scope.alphabet);
            if(params['starts-with']){
                $scope.toggleAlphabet(params['starts-with'][0]);
            }
        });
    };
    $scope.populateAlphabet();

    $scope.toggleAlphabet = function(topletter){
        _.forEach($scope.alphabet, function(item){
            item['selected'] = false;
        });
        if($scope.alphabet[topletter]){
            $scope.alphabet[topletter]['selected'] = true;
        }
    };

    $scope.alphabetSelected = "";
    $scope.alphaLink = function(string){
        console.log('startswith transition called', string);
        $scope.alphabetSelected = string;

        if(string === ''){
            _.forEach($scope.alphabet, function(item){
                item['selected'] = false;
            });
        }
        $scope.alertLegSearch(1, true);
    };

    //fire on load
    $scope.alertLegSearch(1);
    $scope.$emit('subStateReset');

    $scope.$on('profileOmniSubmit', function(event, stateInfo){
        event.preventDefault();
        console.log('I OBEY THE OMNI BUTTON! LEGISLATION SAVE!', event);
        $scope.saveLegislation(stateInfo);
    });
})

.controller( 'AlertsProfileReviewCtrl', function AlertsProfileReviewController( $scope, $state, TbApi, $timeout ) {
    //Results document array
    //$scope.databox.legResultsReview = [];

    //Pagination variables
    $scope.totalItemsReview = 0;
    $scope.currentPageReview = 1;
    $scope.itemsPerPageReview = 50;
    $scope.maxSizeReview = 5;
    $scope.numPagesReview = ($scope.totalItems / $scope.itemsPerPage);
    $scope.reviewHasLoaded = false;

    $scope.initForm = function(){
        $scope.jurisdictionsReview = {
            "allSelected" : false,
            "noneSelected" : true,
            "data" : [
                {name: "cth", isSelected: false},
                {name: "act", isSelected: false},
                {name: "nsw", isSelected: false},
                {name: "nt", isSelected: false},
                {name: "qld", isSelected: false},
                {name: "sa", isSelected: false},
                {name: "tas", isSelected: false},
                {name: "vic", isSelected: false},
                {name: "wa", isSelected: false}
            ]
        };

        $scope.doctypesReview = {
            "allSelected" : false,
            "noneSelected" : true,
            "data" : [
                {name: "act", isSelected: false},
                {name: "ord", isSelected: false},
                {name: "reg", isSelected: false},
                {name: "bill", isSelected: false},
                {name: "prn", isSelected: false},
                {name: "cpn", isSelected: false}
            ]
        };

        $scope.statusReview = {
            "allSelected" : false,
            "noneSelected" : true,
            "data" : [
                {name: "aws", isSelected: false},
                {name: "cur", isSelected: false},
                {name: "rep", isSelected: false},
                {name: "dra", isSelected: false},
                {name: "ass", isSelected: false},
                {name: "nis", isSelected: false},
                {name: "fail", isSelected: false}
            ]
        };

        $scope.principal = {
            'principal' : false,
            'amending' : false
        };
    };
    $scope.initForm();

    $scope.tempMemory = {
        'forceTrack' : [],
        'forceUntrack' : []
    };

    $scope.xvalReview = function(){
        var xval = (($scope.currentPageReview - 1) * $scope.itemsPerPageReview) + 1;
        if(xval < $scope.totalItemsReview){
            return xval;
        }else{
            return $scope.totalItemsReview;
        }
    };

    $scope.yvalReview = function(){
        var yval = ($scope.currentPageReview * $scope.itemsPerPageReview);
        if(yval < $scope.totalItemsReview){
            return yval;
        }else{
            return $scope.totalItemsReview;
        }
    };

    $scope.saveReview = function(stateInfo){
        //go through the current list of legislation stuff we have stored
        //make them into the objects the PUT request expects
        var putData = $scope.existingLegList;

        if(putData && putData.length < 1){
            TbApi.one('profiles/'+$scope.editProfile+'/legislation/all.json').customDELETE().then(
                function(ret){
                    alert('Your profile is successfully saved!');
                    console.log('Delete return TEST',ret);
                    $scope.$emit('reloadNumbers');
                    $scope.alertReviewSearch(1);

                    $scope.tempMemory = {
                        'forceTrack' : [],
                        'forceUntrack' : []
                    };

                    if(stateInfo){
                        $state.go(stateInfo.toState, stateInfo.toParams);
                    }
                }
            );
        }else{
            TbApi.one('profiles/' + $scope.editProfile + '/legislation/all.json').customPUT(putData).then(
                function(ret){
                    alert('Your profile is successfully saved!');
                    console.log('Add tracked subjects', ret);
                    $scope.$emit('reloadNumbers');
                    $scope.alertReviewSearch(1);

                    $scope.tempMemory = {
                        'forceTrack' : [],
                        'forceUntrack' : []
                    };

                    if(stateInfo){
                        $state.go(stateInfo.toState, stateInfo.toParams);
                    }
                }
            );
        }
    };

    var isLegInList = function(id){
        for(var i = 0, len = $scope.existingLegList.length; i < len; i++){
            if($scope.existingLegList[i]['legislation-id'] == id){
                return i;
            }
        }
        return -1;
    };

    $scope.toggleCheckedItem = function(item){
        console.log('BEFORE', $scope.existingLegList);
        console.log('List of Tracked Legs', $scope.existingLegList);
        console.log('Toggle Checked Item', item);
        console.log('Checking List Index', isLegInList(item['doc-id']));
        $scope.$emit('subStateChanged');
        var listIndex = isLegInList(item['doc-id']);

        //are we toggling off or on
        if(item['tracked']){ //item is tracked
            //check if this thing is in the list
            if(listIndex != -1){ //yes it is, remove it
                console.log('putting in forceUntrack', item['doc-id']);
                $scope.tempMemory.forceUntrack.push(item['doc-id']);
                $scope.existingLegList.splice(listIndex, 1);
            }else{ //no it's not, add it to the list with tracked = false
                $scope.existingLegList.push({
                    'legislation-id': item['doc-id'],
                    'tracked': false
                });
            }
            //now we flip the bit for UI
            item['tracked'] = false;
            //and take one off the counter
            $scope.databox.legReviewCounter -= 1;
        }else{ //item is not tracked
            //check if this thing is in the list
            if(listIndex != -1){ //yes it is, make false true
                console.log('putting in forceTrack', item['doc-id']);
                $scope.tempMemory.forceTrack.push(item['doc-id']);
                $scope.existingLegList.splice(listIndex, 1);
            }else{ //no it's not, add it to the list with tracked = true
                $scope.existingLegList.push({
                    'legislation-id': item['doc-id'],
                    'tracked': true
                });
            }
            //now we flip the bit for UI
            item['tracked'] = true;
            //and add one to the counter
            $scope.databox.legReviewCounter += 1;
        }

        console.log('AFTER', $scope.existingLegList);
        console.log('List of Tracked Legs', $scope.existingLegList);
        console.log('Toggle Checked Item', item);
        console.log('Checking List Index', isLegInList(item['doc-id']));
    };

    $scope.$on('profileOmniSubmit', function(event, stateInfo){
        event.preventDefault();
        console.log('I OBEY THE OMNI BUTTON! REVIEW SAVE!', event);
        $scope.saveReview(stateInfo);
    });

    $scope.selectAllItems = function(){
        for(var i = 0; i < $scope.databox.legResultsReview.length; i++){
            if(!$scope.databox.legResultsReview[i].tracked){
                console.log(i, $scope.databox.legResultsReview[i].tracked);
                $scope.toggleCheckedItem($scope.databox.legResultsReview[i]);
            }
        }
    };

    $scope.deselectAllItems = function(){
        for(var i = 0; i < $scope.databox.legResultsReview.length; i++){
            if($scope.databox.legResultsReview[i].tracked){
                console.log(i, $scope.databox.legResultsReview[i].tracked);
                $scope.toggleCheckedItem($scope.databox.legResultsReview[i]);
            }
        }
    };

    $scope.alertReviewSearch = function(page, disableAlpha){
        console.log('alertReviewSearch called',page);

        disableAlpha = (typeof disableAlpha === "undefined") ? false : disableAlpha;
        if($scope.cleanSlate){
            $scope.cleanSlate = false;
        }

        //declare params object
        var params = {
            'scope': 'title',
            'count': 50,
            'sort': 'title',
            'start': (((page - 1) * 50) + 1),
            'profile': $scope.editProfile
        };

        console.log('herp',$scope.currentPage);
        if(page == 1){
            $scope.resetPagination();
        }

        //grab alphabet
        if($scope.alphabetSelectedReview !== ""){
            params['starts-with'] = $scope.alphabetSelectedReview;
        }
        //grab jurisdictions
        if($scope.jurisdictionsReview.allSelected === true){
            params['jurisdiction'] = "cth,act,nsw,nt,qld,sa,tas,vic,wa";
        }else if($scope.jurisdictionsReview.allSelected === false && $scope.jurisdictionsReview.noneSelected === false){
            var ti = [];
            for(var i = 0;i<$scope.jurisdictionsReview.data.length;i++){
                if($scope.jurisdictionsReview.data[i].isSelected === true){
                    ti.push($scope.jurisdictionsReview.data[i]['name'].toLowerCase());
                }
            }
            params['jurisdiction'] = ti.toString();
        }else{
            console.log('no jurisdictions selected');
            params['jurisdiction'] = "";
        }

        //grab doctypes
        if($scope.doctypesReview.allSelected === true){
            params['doc-type'] = "act,ord,reg,bill,prn,cpn";
        }else if($scope.doctypesReview.allSelected !== true && $scope.doctypesReview.noneSelected !== true){
            var tj = [];
            for(var j = 0;j<$scope.doctypesReview.data.length;j++){
                if($scope.doctypesReview.data[j].isSelected === true){
                    tj.push($scope.doctypesReview.data[j]['name'].toLowerCase());
                }
            }
            params['doc-type'] = tj.toString();
        }else{
            params['doc-type'] = "";
        }

        //grab status
        if($scope.statusReview.allSelected === true){
            params['status'] = "aws,cur,rep,dra,ass,nis,fail";
        }else if($scope.statusReview.allSelected !== true && $scope.statusReview.noneSelected !== true){
            var tk = [];
            for(var k = 0;k<$scope.statusReview.data.length;k++){
                if($scope.statusReview.data[k].isSelected === true){
                    tk.push($scope.statusReview.data[k]['name'].toLowerCase());
                }
            }
            params['status'] = tk.toString();
        }else{
            params['status'] = "";
        }

        //grab principal
        if($scope.principal){
            if($scope.principal.principal && $scope.principal.amending){
                params['principal'] = "true,false";
            }else if($scope.principal.principal && !$scope.principal.amending){
                params['principal'] = "true";
            }else if(!$scope.principal.principal && $scope.principal.amending){
                params['principal'] = "false";
            }else if(!$scope.principal.principal && !$scope.principal.amending){
                params['principal'] = null;
            }
        }

        //fire search request
        console.log('searching with', params);
        $scope.step3Loading = true;

        params['_'] = Date.now();

        TbApi.all('search.json').getList(params).then(function(res){
            console.log('returning', res);
            //process this first
            var reviewHolder = res['data']['documents'];

            for(var i = 0, holderLength = reviewHolder.length; i<holderLength; i++){

                //let's pre-emptively get the list index of the current item's doc-id in the existingLegList
                var cur = isLegInList(reviewHolder[i]['doc-id']);

                //and check whether this is present - it is
                if(cur > -1){
                    //and it's marked as tracked = true in the list, so let's mark it tracked
                    if($scope.existingLegList[cur] && $scope.existingLegList[cur]['tracked']){
                        reviewHolder[i]['tracked'] = true;
                    }

                    //it is in the list and as tracked = false, so let's mark it untracked
                    else if($scope.existingLegList[cur] && !$scope.existingLegList[cur]['tracked']){
                        reviewHolder[i]['tracked'] = false;
                    }
                }

                //it is not, which means it is either untracked entirely or the user has untracked it, let's check if they have
                else{
                    //is it in the force-tracked list?
                    if($scope.tempMemory.forceTrack.indexOf(reviewHolder[i]['doc-id']) > -1){
                        reviewHolder[i]['tracked'] = true;
                    }

                    //is it in the force-UNtracked list? If so, set false
                    else if($scope.tempMemory.forceUntrack.indexOf(reviewHolder[i]['doc-id']) > -1){
                        reviewHolder[i]['tracked'] = false;
                    }

                    else{
                        reviewHolder[i]['tracked'] = true;
                    }
                }
            }

            $scope.databox.legResultsReview = reviewHolder;
            $scope.totalItemsReview = res['data']['hits'];
            $scope.numPagesReview = ($scope.totalItemsReview / $scope.itemsPerPageReview);
            $scope.reviewHasLoaded = true;

            //WARNING: HERESY
            //SUPER HERETICAL
            var elem = $('.resultsbox');
            elem.scrollTop(0);
        });
        if(!disableAlpha){
            console.log('alphabet repop');
            $scope.populateAlphabetReview(params);
        }
    };


    $scope.trackPagination = true;

    $scope.resetPagination = function(){
        $scope.trackPagination = false;
        $scope.currentPageReview = 1;
        $scope.trackPagination = true;
    };

    $scope.clearForm = function(){
        $scope.initForm();
        $scope.alphaLinkReview('');
    };

    $scope.applyFilters = function(){
        $scope.resetPagination();
        $scope.alertReviewSearch(1);
    };

    //pagination change listener
    $scope.$watch('currentPageReview', function(newPage, oldPage){
       console.log(newPage, oldPage);
       if($scope.trackPagination && (newPage != oldPage)){
            $scope.alertReviewSearch(newPage);
       }
    });

    function sortObject(o) {
        var sorted = {},
        key, a = [];

        for (key in o) {
            if (o.hasOwnProperty(key)) {
                a.push(key);
            }
        }

        a.sort();

        for (key = 0; key < a.length; key++) {
            sorted[a[key]] = o[a[key]];
        }
        return sorted;
    }

    $scope.alphabetReviewLoaded = false;
    $scope.populateAlphabetReview = function(params){
        //populate starts-with selection widget
        if(!params){params={};}

        var aparams = {
            'term':params['term'],
            'scope':params['scope'],
            'jurisdiction':params['jurisdiction'],
            'doc-type':params['doc-type'],
            'status':params['status'],
            'principal':params['principal'],
            'year':params['year'],
            'profile':params['profile']
        };

        TbApi.all('search/facets/starts-with.json').getList(aparams).then(function(ret){
            $scope.alphabetReviewLoaded = true;
            //console.log('original return',ret);
            $scope.alphabetReview = _.groupBy(ret[2]['filters'],function(input){
                return input['name'].charAt(0);
            });

            var alpha=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
            for(var i=0;i<alpha.length;i++){
                if(!$scope.alphabetReview[alpha[i]]){
                    $scope.alphabetReview[alpha[i]] = [];
                }
            }

            $scope.alphabetReview = sortObject($scope.alphabetReview);
            if(params['starts-with']){
                $scope.toggleAlphabet(params['starts-with'][0]);
            }
        });
    };
    $scope.populateAlphabetReview();

    $scope.toggleAlphabetReview = function(topletter){
        _.forEach($scope.alphabetReview, function(item){
            item['selected'] = false;
        });
        if($scope.alphabetReview[topletter]){
            $scope.alphabetReview[topletter]['selected'] = true;
        }
    };

    $scope.alphabetSelectedReview = "";

    $scope.alphaLinkReview = function(string){
        console.log('startswith transition called', string);
        $scope.alphabetSelectedReview = string;

        if(string === ''){
            _.forEach($scope.alphabetReview, function(item){
                item['selected'] = false;
            });
        }
        $scope.alertReviewSearch(1, true);
    };

    //fire on state load
    $scope.alertReviewSearch(1);
    $scope.populateAlphabetReview();
    $scope.$emit('subStateReset');
})

.controller( 'AlertsDisplayCtrl', function AlertsDisplayController( $scope, $state, $modal, $filter, tbUserService, TbApi) {
    $scope.loading = true;

    $scope.jurisdictions = [
        {name: "CTH", isSelected: false},
        {name: "ACT", isSelected: false},
        {name: "NSW", isSelected: false},
        {name: "NT", isSelected: false},
        {name: "QLD", isSelected: false},
        {name: "SA", isSelected: false},
        {name: "TAS", isSelected: false},
        {name: "VIC", isSelected: false},
        {name: "WA", isSelected: false}
    ];

    var zeroPad = function(n){
        return (n < 10) ? ("0" + n) : n;
    };
    var getRoundString = function(date){
        return date.getFullYear() + "-" + zeroPad(parseInt(date.getMonth() + 1, 10)) + "-" + zeroPad(date.getDate()) + "T" + "00:00:00";
    };

    var alertsModSwitch = function(input){
        var str = input.toLowerCase();
        switch(str){
            case 'progress':
                return 'progress';
            case 'commenced':
                return 'commence';
            case 'assented':
                return 'assent';
            case 'amended':
                return 'amend';
            case 'repealed':
                return 'repeal';
            case 'modified':
                return false;
            case 'published':
                return false;
            default:
                return null;
        }
    };

    $scope.toggleAlert = function(alert){
        alert.isCollapsed = !alert.isCollapsed;
        $scope.loadUsers(alert);
        $scope.processSummaryStrings(alert);
    };

    $scope.showError = function(){
        alert('Only a Profile Manger or Administrator can edit tracked legislation.');
    };

    $scope.loadUsers = function(alert){
        console.log('loadUsers', alert);
        if(!alert['extras'] || !alert['extras']['users']){
            TbApi.all('profiles/' + alert['id'] + '/members.json').getList().then(function(ret){
                console.log('loading members list',ret);
                alert['extras'] = {};
                alert['extras']['users'] = ret['data']['members'];
            });
        }
    };

    $scope.processSummaryStrings = function(alert){
        if(!alert['alert-events-strings']){
            console.log('SUMMARY STRING PROCESSOR CALLED', alert);
            var evts = [];
            var working = [];

            evts = _.map(alert['alert-events'], function(value, key){
                if(value){ return key; }
            });

            for(var i = 0; i < evts.length; i++){
                working.push($filter('activityNameFilter')(evts[i]));
            }

            working = _.compact(_.uniq(working));
            alert['alert-events-strings'] = working;
        }
    };

    $scope.alertsPrintModal = function(){
        var modalInstance = $modal.open({
            templateUrl: 'lawtracker/printalert.tpl.html',
            controller: 'AlertsPrintModalCtrl',
            windowClass: 'alert-print-modal',
            resolve: {
                isAdmin: function(){
                    return false;
                }
            }
        });
        modalInstance.result.then(function(ret){
            if(ret){
                var params = {};
                switch(ret){
                    case 'titles':

                        break;
                    case 'details':
                        params.sections = true;
                        break;
                }

                var url = $state.href('alertsprint', params);
                window.open(url, '_blank');
            }
        });
    };

    $scope.alertsReportModal = function(item){
        console.log('alertsReportModal called with', item);

        var modalInstance = $modal.open({
            templateUrl: 'lawtracker/reportalert.tpl.html',
            controller:  'AlertsReportModalCtrl',
            windowClass: 'alert-report-modal',
            resolve: {
                resItem: function(){
                    return item;
                }
            }
        });

        modalInstance.result.then(function(ret){
            if(ret){
                var estring = [];
                angular.forEach(item['alert-events'], function(v,k){
                    console.log(v, k);
                    if(v && alertsModSwitch(k)){
                        estring.push(alertsModSwitch(k));
                    }
                });
                estring.push('subordinate');

                console.log('alertsReportModal finished with', ret);

                //IF 'editorial', THEN add 'as-made'
                //IF 'editorial' AND (profile tracks OR report tracks bill/draft progress), THEN add 'progress-update'
                //IF 'real' AND (profile tracks OR report tracks bill/draft progress), THEN add 'progress'

                var edatestring = "real,editorial";
                if(item['alert-events']['progress']){
                    edatestring += ",progress";
                }

                var url = $state.href('lawtracker.custom.result', {
                    sdate: getRoundString(ret['dStart']),
                    edate: getRoundString(ret['dEnd']),
                    profile: item.id,
                    eventtype: estring.join(','),
                    eventdate: edatestring,
                    from: 'alert'
                });
                window.open(url, '_blank');
            }
        });
    };

    $scope.alertsCreateModal = function(){
        console.log('alertsCreateModal called');
        var modalInstance = $modal.open({
           templateUrl: 'lawtracker/createalert.tpl.html',
           controller:  'AlertsCreateModalCtrl',
           windowClass: 'alert-create-modal'
        });

        modalInstance.result.then(function(ret){
            if(ret){
                console.log('Create modal closed, returning',ret);
                $state.go('lawtracker.alerts.profile.subjects',{edit: ret['id']});
                $scope.loadProfiles();
            }
        });
    };

    $scope.saveProfile = function(item){
        console.log('save profile', item);

        //first check if this is a new or edit profile
        var putData = {
          "name": item['name'],
          "description": item['description'],
          "alert-no-activity": item['alert-no-activity'],
          "report-type": item['report-type'],
          "frequency": item['frequency'],
          "alert-events": item['alert-events']
        };

        TbApi.one('profiles/'+item['id']+'.json').customPUT(putData).then(function(ret){
            console.log('Edit existing profile return object',ret);
            $scope.loadProfiles(item);
        });
    };

    $scope.editProfileModal = function(item){
        console.log('editProfileModal called',item);
        var modalInstance = $modal.open({
           templateUrl: 'lawtracker/editprofilesummary.tpl.html',
           controller:  'EditProfileSummaryModalCtrl',
           windowClass: 'alert-create-modal',
           resolve: {
                profile: function(){return item;}
           }
        });

        modalInstance.result.then(function(ret){
            console.log('Edit modal closed, returning',ret);
            $scope.saveProfile(ret);
        });
    };

    $scope.alertsShareModal = function(item){
        console.log('alertsShareModal called with', item);
        var modalInstance = $modal.open({
           templateUrl: 'lawtracker/sharealert.tpl.html',
           controller:  'AlertsShareModalCtrl',
           windowClass: 'alert-share-modal',
           resolve: {
                resItem: function(){
                    return item;
                }
           }
        });

        modalInstance.result['finally'](function(){
            console.log('Alerts share modal DISMISSED');
            $scope.loadProfiles(item);
        });
    };

    $scope.alertsDeleteModal = function(item){
        console.log('alertsDeleteModal called with', item);
        var modalInstance = $modal.open({
           templateUrl: 'lawtracker/deletealert.tpl.html',
           controller:  'AlertsDeleteModalCtrl',
           windowClass: 'alert-delete-modal',
           resolve: {
                resItem: function(){
                    return item;
                },
                members: function(TbApi){
                    return TbApi.one('profiles/'+item['id']+'/members.json').get();
                }
           }
        });

        modalInstance.result.then(function(ret){
            console.log('modal delete closed', ret);
            if(ret){
                $scope.loadProfiles(item);
            }else{
                $scope.alertsShareModal(item);
            }
        });
    };

    $scope.alertsList = [];
    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            $scope.userInfo = user;
            if(user['user']){
                console.log('Alerts List User Load', user);
                $scope.loadProfiles();
            }
        },
        true
    );

    $scope.loadProfiles = function(item){
        console.log('loadProfiles called', item);
        if(!$scope.loading){
            $scope.loading = true;
        }

        TbApi.all('profiles.json').getList().then(function(ret){
            console.log('LOAD PROFILES!', ret);
            $scope.alertsList = ret['data'];
            console.log('alertsList',$scope.alertsList);

            $scope.loading = false;

            if(item){
                var open = _.find($scope.alertsList, function(sub){
                    return sub['id'] == item['id'];
                });
                console.log('target to open', open);
                if (open){
                    $scope.toggleAlert(open);
                }
            }
        });
    };

    $scope.deleteProfile = function(profile){
        // console.log('DELETING', profile);
        // TbApi.one('profiles/'+profile['id']+'.json').customDELETE().then(function(ret){
        //     console.log('Delete return TEST',ret);
        //     $scope.loadProfiles();
        // });
    };

    $scope.toggleSuspension = function(profile){
        console.log('toggleSuspension',profile);

        var alertStatus = "";
        if(profile['membership']['alert-status'] == "suspended"){
            alertStatus = "active";
        }else if(profile['membership']['alert-status'] == "active"){
            alertStatus = "suspended";
        }

        var putData = {
            "alert-status" : alertStatus
        };


        ///0.1/profiles/{profile}/members/{user}/alert-status

        //TbApi.one('profiles/'+profile['id']+'/members/'+profile['membership']['user']['id']+'.json').customPUT(putData).then(function(ret){
        TbApi.one('profiles/'+profile['id']+'/members/'+profile['membership']['user']['id']+'/alert-status.json').customPUT(putData).then(function(ret){
            console.log('Toggle suspension return object',ret);
            //$scope.loadProfiles();
            //
            profile['membership']['alert-status'] = alertStatus;
        });
    };
})

.controller('AlertsPrintModalCtrl', function($scope, $modalInstance, isAdmin){
    $scope.ok = function () {
        $modalInstance.close($scope.selectedItem.res);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };

    $scope.admin = isAdmin;

    console.log('alerts print modal ADMIN CHECK', $scope.admin);

    $scope.selectedItem = {};
    $scope.selectedItem.res = "titles";
})

.controller( 'EditProfileSummaryModalCtrl' ,function EditProfileSummaryModalController($scope,$state,$modalInstance, TbApi, profile){
    $scope.profile = profile;
    console.log('EditProfileSummaryModalCtrl', profile);

    if($scope.profile.membership && $scope.profile.membership.role == 'Standard'){
        $scope.showUserBlock = true;
    }

    if($scope.profile){
        $scope.frequencyOptions = {
            'half-daily': _.contains($scope.profile['frequency'], 'half-daily'),
            'daily': _.contains($scope.profile['frequency'], 'daily'),
            'weekly': _.contains($scope.profile['frequency'], 'weekly'),
            'monthly': _.contains($scope.profile['frequency'], 'monthly')
        };
        $scope.reportOptions = [
            {
                'name': "Standard",
                'value': "Standard"
            },
            {
                'name': "Summary Only",
                'value': "Summary"
            }
        ];
    }

    $scope.makeFrequencyArray = function(){
        var arr = [];
        if($scope.frequencyOptions['half-daily']){ arr.push('half-daily'); }
        if($scope.frequencyOptions['daily']){ arr.push('daily'); }
        if($scope.frequencyOptions['weekly']){ arr.push('weekly'); }
        if($scope.frequencyOptions['monthly']){ arr.push('monthly'); }
        return arr;
    };

    $scope.ok = function () {
        $scope.profile['frequency'] = $scope.makeFrequencyArray();
        $modalInstance.close($scope.profile);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})

.controller( 'AlertsCreateModalCtrl',function AlertsCreateModalController($scope,$state,$modalInstance, TbApi){
    console.log('create modal spawned');

    $scope.profile = {
      "name": "",
      "description": "",
      "alert-no-activity": false,
      "report-type": "Standard",
      "frequency": [],
      "alert-events": {
        "progress": true,
        "modified": true,
        "commenced": true,
        "published": true,
        "assented": true,
        "amended": true,
        "repealed": true
      }
    };

    $scope.frequencyOptions = {
        'daily': true
    };

    $scope.reportOptions = [
        {
            'name': "Standard",
            'value': "Standard"
        },
        {
            'name': "Summary Only",
            'value': "Summary"
        }
    ];

    $scope.makeFrequencyArray = function(){
        var arr = [];
        if($scope.frequencyOptions['half-daily']){ arr.push('half-daily'); }
        if($scope.frequencyOptions['daily']){ arr.push('daily'); }
        if($scope.frequencyOptions['weekly']){ arr.push('weekly'); }
        if($scope.frequencyOptions['monthly']){ arr.push('monthly'); }
        return arr;
    };

    $scope.saveProfile = function(){

        if(!$scope.profile.name || $scope.profile.name.length <= 0){
            $scope.showErrorMessage = true;
        }else{
            //first check if this is a new or edit profile
            var putData = {};

            $scope.profile['frequency'] = $scope.makeFrequencyArray();

            if($scope.profile['alert-events']['amended']){
                $scope.profile['alert-events']['modified'] = true;
            }

            putData = {
              "name": $scope.profile['name'],
              "description": $scope.profile['description'],
              "alert-no-activity": $scope.profile['alert-no-activity'],
              "report-type": $scope.profile['report-type'],
              "frequency": $scope.profile['frequency'],
              "alert-events": $scope.profile['alert-events']
            };

            TbApi.one('profiles.json').customPOST(putData).then(function(ret){
                console.log('Add new profile return object',ret['data']);
                $modalInstance.close(ret['data']);
            });
        }
    };

    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})

.controller('AlertsReportModalCtrl',function AlertsReportModalController($scope,$state,$modalInstance,$timeout,resItem,TbApi){
    console.log('alerts report modal controller spawned');

    $scope.item = resItem;
    $scope.dates = {};

    $scope.sopen = false;
    $scope.eopen = false;

    $scope.dateOptions = {
        'year-format': "'yyyy'",
        'starting-day': 1
    };

    $scope.format = 'dd MMM yyyy';

    $scope.initDates = function(){
        var today = new Date();
        $scope.minDate = new Date(Date.UTC(1998, 1, 1));
        $scope.maxDate = new Date(Date.UTC(today.getFullYear(), today.getMonth() + 3, today.getDate()));
        $scope.dates.dStart = new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate() -1));
        $scope.dates.dEnd = new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()));
    };
    $scope.initDates();

    $scope.$watch('dates.dStart', function(newDate, oldDate){
        if(newDate !== oldDate){
            if($scope.dates.dStart > $scope.dates.dEnd){
                //$scope.dates.dEnd = new Date(Date.UTC(newDate.getFullYear(), newDate.getMonth(), newDate.getDate() + 1));
                $scope.dates.dEnd = new Date(Date.UTC(newDate.getFullYear(), newDate.getMonth(), newDate.getDate()));
            }
        }
    });


    $scope.disabled = function(date, mode) {
        return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
    };

    $scope.ok = function () {
        $modalInstance.close($scope.dates);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})

.controller( 'AlertsAdminDeleteModalCtrl',function AlertsAdminDeleteModalController($scope,$state,$modalInstance, resItem, members, TbApi, tbUserService){
    console.log('admin delete modal called');
    var loadProfile = function(){
        TbApi.one('profiles/'+resItem['id']+'.json').get().then(function(ret){
            console.log('new profile lawl', ret['data']);
            $scope.item = resItem;
            $scope.loadMembers();
        });
    };
    loadProfile();

    $scope.managers = 0;
    $scope.loadMembers = function(){
        TbApi.one('profiles/'+resItem['id']+'/members.json').get().then(function(ret){
            $scope.members = ret['data']['members'];

            console.log('tbUserService call roles',tbUserService.getUserRoles());
            console.log('resItem', resItem);
            console.log('members', ret['data']['members']);

            if(resItem){
                if(resItem['membership'] && resItem['membership']['role'] && resItem['membership']['role'].indexOf('Profile Manager') > -1){
                    $scope.isManager = true;
                }else{
                    $scope.isManager = false;
                }
            }

            if(members){
                for(var i = 0; i < members['data']['members'].length ;i++){
                    if(members['data']['members'][i].role.indexOf('Profile Manager') > -1){
                        $scope.managers++;
                    }
                }
            }

            console.log('isManager', $scope.isManager);
            console.log('managers', $scope.managers);

            $scope.loading = false;
        });
    };

    $scope.deleteProfile = function(profile){
        TbApi.one('profiles/'+profile['id']+'.json').customDELETE().then(function(ret){
            $modalInstance.close(true);
        });
    };

    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})

.controller( 'AlertsDeleteModalCtrl',function AlertsDeleteModalController($scope,$state,$modalInstance, resItem, members, TbApi, tbUserService){
    console.log('delete modal spawned', resItem);

    var loadProfile = function(){
        console.log('new profile', resItem);
        TbApi.one('profiles/'+resItem['id']+'.json').get().then(function(ret){
            console.log('new profile lawl', ret['data']);
            $scope.item = resItem;
            $scope.loadMembers();
        });
    };
    loadProfile();

    $scope.managers = 0;
    $scope.loading = true;

    $scope.loadMembers = function(){
        TbApi.one('profiles/'+resItem['id']+'/members.json').get().then(function(ret){
            $scope.members = ret['data']['members'];

            console.log('tbUserService call roles',tbUserService.getUserRoles());
            console.log('resItem', resItem);
            console.log('members', ret['data']);

            if(resItem){
                if(resItem['membership'] && resItem['membership']['role'] && resItem['membership']['role'].indexOf('Profile Manager') > -1){
                    $scope.isManager = true;
                }else{
                    $scope.isManager = false;
                }
            }

            if(members){
                for(var i = 0; i < members['data']['members'].length ;i++){
                    if(members['data']['members'][i].role.indexOf('Profile Manager') > -1){
                        $scope.managers++;
                    }
                }
            }

            console.log('isManager', $scope.isManager);
            console.log('members', $scope.managers);

            $scope.loading = false;
        });
    };

    $scope.deleteProfile = function(profile){
        console.log('MANAGER NUMBER CHECK', $scope.managers);
        if(($scope.isManager && $scope.managers > 1) || (!$scope.isManager) ){
            TbApi.one('profiles/'+profile['id']+'/members/'+profile['membership']['user']['id']+'.json').customDELETE().then(function(ret){
                $modalInstance.close(ret);
            });
        }else if($scope.isManager){
            TbApi.one('profiles/'+profile['id']+'.json').customDELETE().then(function(ret){
                $modalInstance.close(true);
            });
        }
    };

    $scope.ok = function () {
        $modalInstance.close(false);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})

.controller( 'AlertsShareModalCtrl', function AlertsShareModalController($scope, $modalInstance, resItem, tbUserService, TbApi){
    $scope.showInviteForm = false;
    $scope.form = {
        email: ''
    };
    $scope.adminVisible = false;

    $scope.orgName = "Enter a valid email address.";

    $scope.loading = true;

    //get a new copy of the thing
    var loadProfile = function(){
        console.log('new profile', resItem);
        TbApi.one('profiles/'+resItem['id']+'.json').get().then(function(ret){
            console.log('new profile lawl', ret['data']);
            $scope.item = resItem;
            console.log('profile return details',$scope.item);

            if(tbUserService.isUserProfileAdmin() || ($scope.item['membership'] && $scope.item['membership'] != 'null' && $scope.item['membership']['role'].indexOf('Profile Manager') > -1)){
                $scope.adminVisible = true;
            }
            if($scope.item['membership'] && $scope.item['membership'] != 'null' && $scope.item['membership']['user']['organisation']){
                $scope.orgName = "Enter a valid "+$scope.item['membership']['user']['organisation'] + " email address.";
            }
            if($scope.item['membership'] && $scope.item['membership']['role'] == 'Standard'){
                $scope.showUserBlock = true;
            }

            $scope.loadMembers();
        });
    };
    loadProfile();

    $scope.toggleUserLevel = function(user, index){
        console.log('toggleUserLevel', user, index);

        var newUserRole = user['role'];
        var putData = {
            "role" : newUserRole
        };

        //check if user is the only profile manager by counting profile managers
        var counter = 0;
        for(var i = 0; i < $scope.users.length; i++){
            console.log($scope.users[i]);
            if($scope.users[i]['role'].indexOf('Profile Manager') > -1){
                counter++;
            }
        }

        console.log('toggleUserLevel check if I\'m a profile manager', $scope.item);

        var modUser = function(){
            console.log('modUser fired');
            return TbApi.one('profiles/'+resItem['id']+'/members/'+user['user']['id']+'.json').customPUT(putData).then(function(ret){
                console.log('Toggle user return object',ret);
                $scope.loadMembers();

                //check if we just took ourselves off the admin list, if so hide admin features
                if(newUserRole == 'Standard' && $scope.item['membership']['user']['email'] == ret['data']['membership']['user']['email']){
                    $scope.adminVisible = false;
                }
            });
        };
        //only allow the 'remove' operation if the number of profile managers is greater than one
        //if it's an 'add' operation we don't care about numbers, so let it through in that case

        switch(newUserRole){
            case 'Profile Manager': //check if we are making a profile manager
                console.log('Changing Standard to Manager');
                modUser();
                break;
            case 'Standard': //we are demoting a profile manager
                console.log('Changing Manager to Standard');

                //first check to see if there are any managers left
                //if not, do nothing
                if(counter > 0){
                    //now check if we are a profile manager ourselves
                    if($scope.item['membership']['user']['email'] == user['user']['email']){
                        if(window.confirm('Are you sure you want to remove your own profile manager status?')){
                            console.log('we are not the only manager and we are OK with demoting ourselves');
                            modUser();
                        }else{
                            console.log('aborting, we dont want to demote ourselves');
                            user['role'] = 'Profile Manager';
                        }
                    }else{
                        console.log('we are not the only manager and we arent dealing with ourselves');
                        modUser();
                    }
                }else{
                    alert('You cannot remove the final profile manager from a profile!');
                    user['role'] = 'Profile Manager';
                }
                break;
        }
    };

    $scope.loadMembers = function(){
        TbApi.all('profiles/' + resItem['id'] + '/members.json').getList().then(function(ret){
            console.log('loading members list',ret);
            $scope.users = ret['data']['members'];
            $scope.loading = false;
        });
    };

    $scope.addUser = function(form){
        //if(form.$valid && (tbUserService.getOrgDomain() == $scope.form.email.split('@')[1])){
        if(form.$valid){
            var putData = {
                invitation: true
            };
            TbApi.one('profiles/'+resItem['id']+'/members/'+encodeURIComponent($scope.form.email)+'.json').customPUT(putData).then(function(ret){
                console.log('Add user return object',ret);
                $scope.form.email = "";
                $scope.loadMembers();
            });
        }else{
            alert('Please enter a valid email address.');
        }
    };

    $scope.deleteUser = function(user){
        console.log('deleteUser', user);

        // var userRole = "";
        // if(user['role'] == "Standard"){
        //     userRole = "Profile Manager";
        // }else if(user['role'] = "Profile Manager"){
        //     userRole = "Standard";
        // }

        if($scope.adminVisible){
            if(window.confirm('Are you sure you want to remove this user?')){
                TbApi.one('profiles/'+resItem['id']+'/members/'+user['user']['id']+'.json').customDELETE().then(function(ret){
                    console.log('Delete return TEST',ret);
                    $scope.loadMembers();
                });
            }
        }else{
            console.log('You are not a profile manager. I\'m sorry, Dave.');
        }
    };

    $scope.ok = function () {
        $modalInstance.close(true);
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
})

.controller( 'AlertsTransitionModalCtrl', function AlertsTransitionModalController($scope, $modalInstance){

    $scope.ok = function () {
        $modalInstance.close("dismiss");
    };

    $scope.save = function(){

        $modalInstance.close("save");
    };

    $scope.cancel = function () {
        $modalInstance.dismiss(false);
    };
})

;//eof
