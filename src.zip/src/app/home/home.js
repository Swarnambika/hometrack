/**
 * Each section of the site has its own module. It probably also has
 * submodules, though this boilerplate is too simple to demonstrate it. Within
 * `src/app/home`, however, could exist several additional folders representing
 * additional modules that would then be listed as dependencies of this one.
 * For example, a `note` section could have the submodules `note.create`,
 * `note.delete`, `note.edit`, etc.
 *
 * Regardless, so long as dependencies are managed correctly, the build process
 * will automatically take take of the rest.
 *
 * The dependencies block here is also where component dependencies should be
 * specified, as shown below.
 */
angular.module( 'tbLawOne.home', [
  'ui.router',
  'ui.bootstrap',
  'restangular',
  'tbLawOne.directives'
])

/**
 * Each section or module of the site can also have its own routes. AngularJS
 * will handle ensuring they are all available at run-time, but splitting it
 * this way makes each module more "self-contained".
 */
.config(function config( $stateProvider ) {
  $stateProvider
    .state( 'home', {
        url: '/home',
        views: {
          "main": {
            controller: 'HomeCtrl',
            templateUrl: 'home/home.tpl.html'
          }
        },
        data:{ pageTitle: 'Home' }
    });
})

/**
 * And of course we define a controller (or controllers) for our route.
 */
.controller( 'HomeCtrl', function HomeController($scope, $state, tbUtil, TbApi, Restangular, tbSearchServiceAlt, TbTestingApi) {
    console.log('LOADING HOME CONTROLLER');

    $scope.today = new Date();
    $scope.loadingLocations = false;

    $scope.searchHome = {};
    $scope.deleteInput = function(){
        $scope.searchHome.term = "";
    };
    $scope.submitSearch = function(){
        var homeSearch = {}; //construct the object submitted to the state transition
        //bind the stuff that's common to both form complexity levels
        //params['term'] = $scope.searchHome.term;

        if($scope.searchHome.term){
            tbSearchServiceAlt.newSearchObject();
            homeSearch = tbSearchServiceAlt.searchObject;
            homeSearch['term'] = $scope.searchHome.term;
            tbSearchServiceAlt.setSearchObject(homeSearch);
            tbSearchServiceAlt.executeSearch();
        }else{
            $scope.searchHome.error = true;
            alert('You need to enter some search terms.');
        }
    };

    //selection handler
    $scope.typeaheadSelect = function(input){
        if(input['icon'] !== 'fa fa-info-circle'){
            if(input['icon'] == 'fa fa-search'){
                $scope.searchHome.term = input['text'];
                $scope.submitSearch();
            }else{
                console.log("typeahead selected object", input);
                $scope.searchHome.term = input['text'];

                if(input['content-id']){
                    $state.go('legislation', {
                        'legId': input['legislation-id'],
                        'contId': input['content-id']
                    },{inherit: false});
                }else{
                    $state.go('legdisplay', {
                        'id': input['legislation-id']
                    },{inherit: false});
                }

            }
        }else{
            $scope.searchHome.term = "";
        }
    };

    //parses a legislation link and calls state transitions
    //$scope.legLink = tbUtil.legLink;

    $scope.homeLegLink = function(input){
        console.log('home leg link', input);
    };

    //grab titles for typeahead
    $scope.getTitles = function(input){
        console.log('getTitles input',input);
        $scope.loadingLocations = true;
        var params = {
            'term' : input,
            'scope' : 'title',
            'count': 15
        };
        var ret = [{
            "legislation-id": null,
            "content-id": null,
            "text": input,
            "icon": 'fa fa-search',
            'hover': ('Search LawOne for ' + input)
        }];

        return TbApi.all('lookup/legislation.json').getList(params).then(function(res){
            $scope.loadingLocations = false;
            _.forEach(res['legislation'], function(item){

                var obj = {
                    'legislation-id': item['id'],
                    'text': item['title'],
                    'hover' : ('Navigate to ' + item['title']),
                    'icon' : '',
                    'number' : item['number'],
                    'jurisdiction' : item['jurisdiction'],
                    'year' : item ['year']
                };

                if(item['_links'] && item['_links']['content'] && item['_links']['content']['href']){
                    obj['content-id'] = item['_links']['content']['href'].split('?')[0].split('/')[6].replace('.json','');
                }

                ret.push(obj);
            });
            ret.splice(-1,1);

            if(ret.length == 16){
                ret.push({
                    "legislation-id": null,
                    "content-id": null,
                    "text": '- Top 15 title matches - for better results type short jurisdiction or year before the title eg vic retail, cth invest, 2001 corp.',
                    "icon": '',
                    'hover': '',
                    'special': true
                });
            }

            console.log('final getTitles return', ret);
            return ret;
        });
    };
})

//controller for the tabbed set of legislation boxes
.controller( 'HomeLegislationCtrl' , function HomeLegislationController ($scope, $state, ActivityFactory, tbUserService, $localStorage) {
    $scope.storage = $localStorage;
    $scope.limitNum = 5;

    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            if(user && user['user']){
                if(user.isIndividual()){
                    $scope.limitNum = 5;
                }else{
                    $scope.limitNum = 10;
                }
            }
        },
        true
    );

    $scope.tabs = [
        {
            title: "New legislation",
            hover: "Lists new legislation",
            active: true
        },
        {
            title: "Amended",
            hover: "Lists recently amended legislation"
        },
        {
            title: "Commenced",
            hover: "Lists recently commenced legislation"
        },
        {
            title: "Bill / Draft progress",
            hover: "Lists recent bill/draft progress"
        },
        {
            title: "Repealed",
            hover: "Lists recently repealed legislation"
        }
    ];

    if($scope.storage && $scope.storage.homejuris && $scope.storage.homejuris != 'ALL'){
        $scope.overJuris = $scope.storage.homejuris;
    }else{
        $scope.overJuris = "ALL";
        $scope.storage.homejuris = 'ALL';
    }

    $scope.setOverJuris = function(juris){
        $scope.overJuris = juris;
        $scope.homeJurisSelect = !$scope.homeJurisSelect;

        if($scope.storage){
            $scope.storage.homejuris = juris;
        }

        $scope.loadActivities($scope.currentTab);
    };

    $scope.loading = true;


    var zeroPad = function(n){
        return (n < 10) ? ("0" + n) : n;
    };
    var getRoundString = function(date){
        return date.getFullYear() + "-" + zeroPad(parseInt(date.getMonth() + 1, 10)) + "-" + zeroPad(date.getDate()) + "T" + zeroPad(date.getHours()) + ":" + zeroPad(date.getMinutes()) + ":" + zeroPad(date.getSeconds());
    };

    $scope.loadCustomReport = function(targetType){

        startDate = new Date();
        startDate.setHours(0,0,0,0);
        startDate.setMonth(startDate.getMonth() - 1);
        startDate = getRoundString(new Date(startDate));

        endDate = new Date();        
        endDate.setHours(23,59,59,999);
        endDate = getRoundString(new Date(endDate));

        //?sdate?edate?juris?doctype?subject?principal?eventtype?profile?legislation?eventdate
        var params = {
            'sdate': startDate,
            'edate': endDate
        };

        if($scope.overJuris != "ALL"){
            params['juris'] = $scope.overJuris;
        }

        switch(targetType){
            case 'new':
                params['eventtype'] = 'assent';
                break;
            case 'updated':
                params['eventtype'] = 'amend';
                break;
            case 'commenced':
                params['eventtype'] = 'commence';
                break;
            case 'bill':
                params['doctype'] = 'bill';
                params['eventtype'] = 'progress';
                break;
            case 'repealed':
                params['eventtype'] = 'repeal';
                break;
        }
        console.log('LOADCUSTOM',params);
        $state.go('lawtracker.custom.result', params);
    };

    $scope.loadActivities = function(targetType){
        $scope.loading = true;
        console.log('loadActivities called', targetType);

        var startDate, endDate, eventType, eventDate, detail;
        var legislation, jurisdiction, docType, principal;
        var subject, profile, department;
        var start, count, sort;


        startDate = new Date();
        startDate.setHours(0,0,0,0);
        startDate.setMonth(startDate.getMonth() - 1);
        startDate = getRoundString(new Date(startDate));

        endDate = new Date();        
        endDate.setHours(23,59,59,999);
        endDate = getRoundString(new Date(endDate));

        count = 5;
        sort = '-date';

        if($scope.overJuris !== 'ALL'){
            jurisdiction = $scope.overJuris;
        }

        switch(targetType){
            case 'updated':
                eventType = 'amended,modified';
                eventDate = "effective,occur";

                ActivityFactory.getActivity(startDate, endDate, eventType, eventDate, detail,
                legislation, jurisdiction, docType, principal, subject, profile, department,
                start, count, sort).then(function(ret){
                    console.log('factory return', ret);
                    $scope.updatedActivities = ret;
                    $scope.loading = false;
                });
                break;
            case 'new':
                eventType = 'notification,assent';
                eventDate = "effective,occur";

                ActivityFactory.getActivity(startDate, endDate, eventType, eventDate, detail,
                legislation, jurisdiction, docType, principal, subject, profile, department,
                start, count, sort).then(function(ret){
                    console.log('factory return', ret);
                    $scope.newActivities = ret;
                    $scope.loading = false;
                });
                break;
            case 'commenced':
                eventType = 'commencement,commenced';
                eventDate = "effective,occur";

                ActivityFactory.getActivity(startDate, endDate, eventType, eventDate, detail,
                legislation, jurisdiction, docType, principal, subject, profile, department,
                start, count, sort).then(function(ret){
                    console.log('factory return', ret);
                    $scope.commencedActivities = ret;
                    $scope.loading = false;
                });
                break;
            case 'bill':
                docType = 'bill';
                eventType = 'events';
                eventDate = "effective,occur";

                ActivityFactory.getActivity(startDate, endDate, eventType, eventDate, detail,
                legislation, jurisdiction, docType, principal, subject, profile, department,
                start, count, sort).then(function(ret){
                    console.log('factory return', ret);
                    $scope.billActivities = ret;
                    $scope.loading = false;
                });
                break;
            case 'repealed':
                eventType = 'repealed,expiry,disallowed by';
                eventDate = "effective,occur";

                ActivityFactory.getActivity(startDate, endDate, eventType, eventDate, detail,
                legislation, jurisdiction, docType, principal, subject, profile, department,
                start, count, sort).then(function(ret){
                    console.log('factory return', ret);
                    $scope.repealedActivities = ret;
                    $scope.loading = false;
                });
                break;
            default:
                alert('INVALID TARGET');
        }
    };

    $scope.tabSelected = function(tab){
        $scope.currentTab = tab;
        console.log('tab selected',tab);
        $scope.loadActivities(tab);
    };
})

//controller for recently viewed collapse
.controller( 'HomeRecentlyCtrl' , function HomeRecentlyController ($scope, tbTrailService) {
    var rawTrail = tbTrailService.getTrailItems();
    $scope.posts = [];
    $scope.showRecently = false;

    if(rawTrail['recently'] && rawTrail['recently'].length > 0){
        $scope.posts = rawTrail['recently'].slice().reverse();
        $scope.showRecently = true;
    }

    $scope.isCollapsed = true;
    if($scope.posts.length > 0){
        $scope.isCollapsed = false;
    }

    //variables for recently viewed
    $scope.limitNum = 5;
    $scope.limitStep = 5;

    $scope.resetLimit = function(){
        $scope.limitNum = 5;
    };

    $scope.parseDate = function(date){
        var tempDate = new Date(date);
        return tempDate;
    };

   $scope.loadmore = function(){
      if($scope.limitNum <= $scope.posts.length){
       $scope.limitNum = $scope.limitNum += $scope.limitStep;
      }
   };
})

//controller for favourites collapse
.controller( 'HomeFavouritesCtrl' , function HomeFavouritesController ($scope, Restangular, tbFavouritesService, tbUserService) {
    $scope.isCollapsed = false;
    //$scope.posts = $scope.mainFav;
    $scope.showLoad = true;
    $scope.posts = [];
    $scope.starter = 0;

    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            if(user['user'] && $scope.posts.length === 0){
                if(user.isIndividual()){
                    $scope.showManage = true;
                    getFaves(6);
                }else{
                    getMassFaves();
                }

            }
        },
        true
    );

    var getFaves = function(num){
        //first parameter is number, second parameter is where we start

        tbFavouritesService.getFavourites(num, $scope.starter + 1).then(function(ret){
            console.log('FAVESTEST', ret);
            var working = ret.data.favourites;
            for(var i = 0; i < working.length; i++){
                $scope.posts.push(working[i]['_embedded']['legislation']);
            }
            $scope.starter += num;
        });
    };

    var getMassFaves = function(){

        tbFavouritesService.getFavourites(50, 0, 'title').then(function(ret){
            console.log('FAVESTEST MASS', ret);
            var working = ret.data.favourites;
            for(var i = 0; i < working.length; i++){
                $scope.posts.push(working[i]['_embedded']['legislation']);
            }
            $scope.starter = 50;
        });
    };

    //variables for recently viewed
    $scope.limitNum = 5;
    $scope.limitStep = 5;

    $scope.resetLimit = function(){
        $scope.limitNum = 5;
    };

    $scope.loadmore = function(){
        $scope.limitNum += 5;
        getFaves(5);

      // if($scope.limitNum <= $scope.posts.length){
      //  $scope.limitNum = $scope.limitNum += $scope.limitStep;
      // }
   };
})

//controller for notifications collapse
.controller( 'HomeNotificationsCtrl' , function HomeNotificationsController ($scope, Restangular, $http) {

    $http.get('/updates.json').then(function(ret){
        console.log('notifications', ret);
        if(ret){
           $scope.posts = ret['data']['items'];
        }
    });

    $scope.transformDate = function(date){
        var mDate = new Date(date);
        return mDate;
    };

    // Restangular.one('updates.json').get().then(function(ret){
    //     console.log('ret', ret);
    //     $scope.posts = ret['responseData']['feed']['entries'];
    // });

    // Restangular.one('updates.json').get().then(function(ret){
    //     console.log('JSON', ret);
    // });

    // $http.get(
    //     'http://www.timebase.com.au/blog/lawone/feed.xml',
    //     {transformResponse: function(data) {
    //         var x2js = new X2JS();
    //         var json = x2js.xml_str2json (data);
    //         return json;
    //     }}
    // ).success(function(data, status){
    //     console.log('XML', data);
    // });

    $scope.isCollapsed = false;
    //$scope.posts = $scope.mainNotes;
    $scope.showLoad = true;

    //variables for recently viewed
    $scope.limitNum = 6;
    $scope.limitStep = 6;

    $scope.resetLimit = function(){
        $scope.limitNum = 6;
        //[ww on 12/21/2016] Display "Load more" button again after click the collapse title
        //$scope.showLoad = true;
    };

    $scope.loadmore = function(){
      if($scope.limitNum < $scope.posts.length){
        $scope.limitNum = $scope.limitNum += $scope.limitStep;
        //$scope.showLoad = false;
        /*[ww on 12/22/2016] Since limitNum still get values left, no need to stop load more action.
        console.log("limitNum is :" + $scope.limitNum);
        */
      }
    };
})

;//end module declaration
