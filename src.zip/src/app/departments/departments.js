angular.module( 'tbLawOne.departments', [
  'ui.router',
  'ui.bootstrap',
  'tbLawOne.services'
])

.config(function config( $stateProvider ) {
    $stateProvider
        //about page
        .state( 'departments', {
            url: '/departments/:juris?dept',
            views: {
                "main": {
                    controller: 'DepartmentsCtrl',
                    templateUrl: 'departments/departments.tpl.html'
                }
            },
            data:{ pageTitle: 'Departments' }
        })
    ;//end stateProvider declarations
})

.controller( 'DepartmentsCtrl', function DepartmentsController( $scope, $state, $stateParams, TbApi,trjurisFilter ) {
    console.log($stateParams);
    $scope.params = $stateParams;
    //$scope.depts = {};

    $scope.predicate = 'legislation.title';
    $scope.pageTitle = "";

    $scope.setPredicate = function(input){
        switch(input){
            case 'title':
                if($scope.predicate == 'legislation.title'){
                    $scope.predicate = '-legislation.title';
                }else{
                    $scope.predicate = 'legislation.title';
                }
                break;
            case 'year':
                if($scope.predicate && $scope.predicate[0] && $scope.predicate[0] == '-legislation.year'){
                    $scope.predicate = ['legislation.year','legislation.number'];
                }else{
                    $scope.predicate = ['-legislation.year','-legislation.number'];
                }
                break;
        }
    };

    TbApi.all(
        'jurisdictions/' + $scope.params['juris'] + '/departments' + (($scope.params['dept'])?'/'+$scope.params['dept']:'') + '.json'
    ).getList().then(function(ret){
        console.log(ret['data']);
        $scope.depts = ret['data'];
        $scope.updatePageTitle();
    });

    $scope.updatePageTitle = function(){
        if($scope.depts['departments']){
            $scope.pageTitle = trjurisFilter($stateParams['juris']) + ' Departments';
        }else{
            $scope.pageTitle = $scope.depts['department']['title'];
        }
        $scope.$emit('PageTitleChanged', $scope.pageTitle);
    };

    $scope.tempLink = function(item){
        console.log(item);
        $state.go('legislation', {'legId': item['legislation-id'], 'contId': item['content-id']}, {inherit: false});
    };

    $scope.deptLink = function(input){
        console.log(input);
        if(input){
            var arr = input.split('/');
            var juris = arr[4];
            var dept = arr[6].substr(0,arr[6].indexOf('.'));
            $state.go('departments',{
                'juris': juris,
                'dept': dept
            });
        }
    };
})

;
