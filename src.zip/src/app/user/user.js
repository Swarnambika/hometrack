angular.module( 'tbLawOne.user', [
  'ui.router',
  'ui.bootstrap',
  'tbLawOne.services'
])

.config(function config( $stateProvider ) {
    $stateProvider
        //about page
        .state('user',{
            abstract: true,
            url: '/user',
            views: {
                "main" :{
                    controller: 'UserCtrl',
                    template: '<div ui-view="accountport" class="account"></div>'
                }
            }
        })
        // Accounts: User
        .state( 'user.account', {
            url: '/account',
            views: {
                "accountport":{
                    controller: 'UserAccountCtrl',
                    templateUrl: 'user/user-account.tpl.html'
                },
                "main@user.account":{
                    controller: 'UserAccountFormCtrl',
                    templateUrl: 'user/user-account-form.tpl.html'
                }
            },
            data:{ pageTitle: 'User Account' }
        })
        // Accounts: Faves
        .state( 'user.favourites', {
            url: '/favourites',
            views: {
                "accountport":{
                    controller: 'UserAccountCtrl',
                    templateUrl: 'user/user-account.tpl.html'
                },
                "main@user.favourites":{
                    controller: 'UserAccountFavouritesCtrl',
                    templateUrl: 'user/user-account-favourites.tpl.html'
                }
            },
            data:{ pageTitle: 'User Account - Favourites' }
        })
        // Accounts: Saved
        .state( 'user.searches', {
            url: '/searches',
            views: {
                "accountport":{
                    controller: 'UserAccountCtrl',
                    templateUrl: 'user/user-account.tpl.html'
                },
                "main@user.searches":{
                    controller: 'UserAccountSearchesCtrl',
                    templateUrl: 'user/user-account-searches.tpl.html'
                }
            },
            data:{ pageTitle: 'User Account - Saved Searches' }
        })
        .state( 'user.admin', {
            url: '/admin/profiles',
            views: {
                "accountport":{
                    controller: 'UserAccountCtrl',
                    templateUrl: 'user/user-account.tpl.html'
                },
                "main@user.admin":{
                    controller: 'UserAccountAdminCtrl',
                    //template: '<div class="container-fluid">HELLO WORLD</div>'
                    templateUrl: 'user/user-admin-profiles.tpl.html'
                }
            },
            data:{ pageTitle: 'User Account - Administration' }
        })
    ;//end stateProvider declarations
})

.controller( 'UserCtrl', function UserController( $scope, tbUserService) {
    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            $scope.userInfo = user;
            console.log('USERCTRL HERE', $scope.userInfo);
        },
        true
    );
})

.controller( 'UserAccountCtrl', function UserAccountController( $scope ) {
    //need to have a mirroring variable for each actually editable variable
    //we populate these with the actual user's properties when we load the page
    //we edit these as we wish inside the little boxes
    //we only save to the model when save is clicked
    //canceling reverts to the original and does not retain changes
    //so the 'lifespan' of one of these temp vars is ONLY AS LONG AS THE EDIT WINDOW IS OPEN

})

.controller( 'UserAccountAdminCtrl', function UserAccountAdminController($scope, tbUserService, TbApi, $modal){
    //for PROFILE ADMINISTRATORS ONLY

    console.log('UserAccountAdminCtrl hello world');
    $scope.loadProfiles = function(){

        if(!$scope.loading){
            $scope.loading = true;
        }

        TbApi.all('profiles.json').getList().then(function(ret){
            console.log('LOAD PROFILES!', ret);
            $scope.profiles = ret['data'];

            $scope.loading = false;
        });
    };

    $scope.loadProfiles();

    $scope.loadUsers = function(profile){
        console.log('loadUsers', profile);

        profile['isCollapsed'] = !profile['isCollapsed'];
        profile['loading'] = true;
        TbApi.all('profiles/' + profile['id'] + '/members.json').getList().then(function(ret){
            console.log('loading members list',ret);
            profile['extras'] = {};
            profile['extras']['users'] = ret['data']['members'];

            profile['loading'] = false;
        });
    };

    $scope.modUserLevel = function(profile, user){
        console.log('modUserLevel', profile, user);

        var newUserRole = user['role'];
        var putData = {
            "role" : newUserRole
        };

        //check if user is the only profile manager by counting profile managers
        var counter = 0;
        for(var i = 0; i < profile['extras']['users'].length; i++){
            if(profile['extras']['users'][i]['role'].indexOf('Profile Manager') > -1){
                counter++;
            }
        }

        var execModUser = function(){
            console.log('execModUser fired');
            return TbApi.one('profiles/'+profile['id']+'/members/'+user['user']['id']+'.json').customPUT(putData).then(function(ret){
                console.log('Toggle user return object',ret);
                $scope.loadUsers(profile);

                //check if we just took ourselves off the admin list, if so hide admin features
                // if(newUserRole == 'Standard' && $scope.item['membership']['user']['email'] == ret['data']['membership']['user']['email']){
                //     $scope.adminVisible = false;
                // }
            });
        };
        //only allow the 'remove' operation if the number of profile managers is greater than one
        //if it's an 'add' operation we don't care about numbers, so let it through in that case

        switch(newUserRole){
            case 'Profile Manager': //check if we are making a profile manager
                console.log('Changing Standard to Manager');
                execModUser();
                break;
            case 'Standard': //we are demoting a profile manager
                console.log('Changing Manager to Standard');

                //first check to see if there are any managers left
                //if not, do nothing
                if(counter > 0){
                    //now check if we are a profile manager ourselves
                    if(profile['membership']['user']['email'] == user['user']['email']){
                        if(window.confirm('Are you sure you want to remove your own profile manager status?')){
                            console.log('we are not the only manager and we are OK with demoting ourselves');
                            execModUser();
                        }else{
                            console.log('aborting, we dont want to demote ourselves');
                            user['role'] = 'Profile Manager';
                        }
                    }else{
                        console.log('we are not the only manager and we arent dealing with ourselves');
                        execModUser();
                    }
                }else{
                    alert('You cannot remove the final profile manager from a profile!');
                    user['role'] = 'Profile Manager';
                }
                break;
        }
    };

    $scope.deleteUser = function(profile, user){
        console.log('deleteUser', profile, user);
        TbApi.one('profiles/'+profile['id']+'/members/'+user['user']['id']+'.json').customDELETE().then(function(ret){
            console.log('Delete return TEST',ret);
            $scope.loadUsers(profile);
        });
    };

    $scope.addUser = function(profile){
        console.log('Profile test',profile);

        var putData = {
            invitation: true
        };

        TbApi.one('profiles/'+profile['id']+'/members/'+encodeURIComponent(profile.extras.newuser)+'.json').customPUT(putData).then(function(ret){
            console.log('Add user return object',ret);
            //$scope.users[index] = ret['data']['membership'];
            profile.extras.newuser = "";
            $scope.loadUsers(profile);
        });
    };

    //modals
    $scope.alertsShareModal = function(item){
        console.log('alertsShareModal called with', item);
        var modalInstance = $modal.open({
           templateUrl: 'user/sharealert.tpl.html',
           controller:  'AlertsShareModalCtrl',
           windowClass: 'alert-share-modal',
           resolve: {
                resItem: function(){
                    return item;
                }
           }
        });

        modalInstance.result['finally'](function(){
            console.log('Alerts share modal DISMISSED');
            $scope.loadProfiles();
        });
    };

    $scope.alertsDeleteModal = function(item){
        console.log('alertsDeleteModal called with', item);
        var modalInstance = $modal.open({
           templateUrl: 'user/deletealert.tpl.html',
           controller:  'AlertsDeleteModalCtrl',
           windowClass: 'alert-delete-modal',
           resolve: {
                resItem: function(){
                    return item;
                },
                members: function(TbApi){
                    return TbApi.one('profiles/'+item['id']+'/members.json').get();
                }
           }
        });

        modalInstance.result.then(function(ret){
            if(ret){
                $scope.loadProfiles();
            }
        });
    };

    $scope.alertsList = {};
    $scope.$watch(
        function(){
            return tbUserService.getUserObject();
        },
        function (user){
            //$scope.userInfo = user
            if(user['user']){
                console.log('Alerts List User Load', user);
                $scope.loadProfiles();
            }
        },
        true
    );
})

    .controller( 'AlertsDeleteModalCtrl',function AlertsDeleteModalController($scope,$state,$modalInstance, resItem, members, TbApi){
        console.log('delete modal spawned', resItem);

        var loadProfile = function(){
            console.log('new profile', resItem);
            TbApi.one('profiles/'+resItem['id']+'.json').get().then(function(ret){
                console.log('new profile lawl', ret['data']);
                $scope.item = resItem;
                $scope.loadMembers();
            });
        };
        loadProfile();

        $scope.managers = 0;
        $scope.loading = true;

        $scope.loadMembers = function(){
            TbApi.one('profiles/'+resItem['id']+'/members.json').get().then(function(ret){
                $scope.members = ret['data']['members'];

                if(resItem){
                    if(resItem['membership']['role'].indexOf('Profile Manager') > -1){
                        $scope.isAdmin = true;
                    }else{
                        $scope.isAdmin = false;
                    }
                }

                if(members){
                    for(var i = 0; i < members['data']['members'].length ;i++){
                        if(members['data']['members'][i].role.indexOf('Profile Manager') > -1){
                            $scope.managers++;
                        }
                    }
                }

                $scope.loading = false;
            });
        };

        $scope.deleteProfile = function(profile){

            //case 3: is admin, you are the only admin - DELETE ENTIRE PROFILE
            if($scope.isAdmin === true && $scope.managers == 1){
                TbApi.one('profiles/'+profile['id']+'.json').customDELETE().then(function(ret){
                    $modalInstance.close(true);
                });
            }
            //case: is admin, other admins exist - DELETE MEMBER
            //case: is not admin - DELETE MEMBER
            else{
                TbApi.one('profiles/'+profile['id']+'/members/'+profile['membership']['user']['id']+'.json').customDELETE().then(function(ret){
                    $modalInstance.close(ret);
                });
            }
        };

        $scope.ok = function () {
            $modalInstance.close();
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    })

.controller( 'UserAccountFavouritesCtrl', function UserAccountFavouritesController( $scope, $state, $modal, tbFavouritesService ) {
    $scope.loadFaves = function(){
        $scope.faves = {};
        tbFavouritesService.getFavourites(50).then(function(ret){
            console.log('RET',ret);
            $scope.faves = ret['data']['favourites'].map(function(item){return item['_embedded']['legislation'];});
        });
    };
    $scope.loadFaves();

    $scope.deleteFav = function(item){
        var modalInstance = $modal.open({
            templateUrl: 'user/modalDeleteFavourite.html',
            controller: 'ModalDeleteFavouriteCtrl',
            resolve: {
                item: function(){
                    return item;
                }
            }
        });

        modalInstance.result.then(function(ret){
            if(ret){
                tbFavouritesService.deleteFavourite(item['doc-id']).then(function(){
                    $state.reload();
                });
            }
        });
    };
})
    .controller( 'ModalDeleteFavouriteCtrl', function ModalDeleteFavouriteCtrl($scope, $modalInstance, item){
        $scope.item = item;

        $scope.ok = function () {
            $modalInstance.close(true);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    })

.controller( 'UserAccountSearchesCtrl', function UserAccountFavouritesController( $scope, $state, $modal, tbSavedSearchService ) {
    $scope.loadSearches = function(){
        $scope.searches = {};
        tbSavedSearchService.getSavedSearches().then(function(ret){
            $scope.searches = ret['data']['searches'];
        });
    };
    $scope.loadSearches();

    $scope.deleteSearch = function(item){

        var modalInstance = $modal.open({
            templateUrl: 'user/modalDeleteSave.html',
            controller: 'ModalDeleteSaveCtrl',
            resolve: {
                item: function(){
                    return item;
                }
            }
        });

        modalInstance.result.then(function(ret){
            if(ret){
                tbSavedSearchService.deleteSavedSearch(item.id).then(function(){
                    $state.reload();
                });
            }
        });
    };
})

    .controller( 'ModalDeleteSaveCtrl', function ModalDeleteFavouriteCtrl($scope, $modalInstance, item){
        $scope.item = item;

        $scope.ok = function () {
            $modalInstance.close(true);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    })

.controller( 'UserAccountFormCtrl', function UserAccountFormController( $scope ) {
    $scope.userForm = {};
    $scope.initNameEdit = function(){
        $scope.editName = !$scope.editName;
        $scope.userForm.firstname = angular.copy($scope.userInfo.user.firstname);
        $scope.userForm.surname = angular.copy($scope.userInfo.user.surname);
    };
    $scope.saveNameEdit = function(){
        $scope.editName = !$scope.editName;
        $scope.userInfo.user.firstname = angular.copy($scope.userForm.firstname);
        $scope.userInfo.user.surname = angular.copy($scope.userForm.surname);
    };
    $scope.initEmailEdit = function(){
        $scope.editEmail = !$scope.editEmail;
        $scope.userForm.email = angular.copy($scope.userInfo.user.email);
    };
    $scope.saveEmailEdit = function(){
        $scope.editEmail = !$scope.editEmail;
        $scope.userInfo.user.email = angular.copy($scope.userForm.email);
    };
})

;
