angular.module( 'tbLawOne.about', [
  'ui.router',
  'ui.bootstrap',
  'tbLawOne.services'
])

.config(function config( $stateProvider ) {
    $stateProvider
        //about page
        .state( 'about', {
            url: '/about',
            views: {
                "main": {
                    controller: 'AboutCtrl',
                    templateUrl: 'about/about.tpl.html'
                }
            },
            data:{ pageTitle: 'About' }
        })
        //copyright page
        .state( 'copyright', {
            url: '/copyright',
            views: {
                "main": {
                    controller: 'CopyrightCtrl',
                    templateUrl: 'about/copyright.tpl.html'
                }
            },
            data:{ pageTitle: 'Guide' }
        })
        //help abstract state
        .state( 'help', {
            abstract: true,
            views: {
                "main": {
                    controller: 'HelpCtrl',
                    template: '<div ui-view="help"></div>'
                }
            }
        })
            //help pages list
            .state('help.helplist',{
                url: '/help',
                views: {
                    "help" :{
                        controller: 'HelpCtrl',
                        templateUrl: 'about/help.tpl.html'
                    }
                },
                data:{ pageTitle: 'Help' }
            })
            //help search
            .state('help.helpsearch',{
                url: '/help/search',
                views: {
                    "help": {
                        controller: 'HelpSearchCtrl',
                        templateUrl: 'about/helpsearch.tpl.html'
                    }
                },
                data:{ pageTitle: 'Help - Search' }
            })
    ;//end stateProvider declarations
})

.controller( 'AboutCtrl', function AboutController( $scope ) {

})

.controller( 'CoverageCtrl', function GuideController( $scope ) {

})

.controller( 'CopyrightCtrl', function CopyrightController( $scope ) {

})

.controller( 'HelpCtrl', function HelpController( $scope ) {

})

.controller( 'HelpSearchCtrl', function HelpSearchController( $scope ) {

})

;
