FlatStrap
=============

for Flatstrap 3 [click here](https://github.com/littlesparkvt/Flatstrap-for-Bootstrap-3)

Sometimes a project doesn't need rounded corners or drop shadows. That's why we ripped all of them out of Bootstrap.

For a demonstration go to http://littlesparkvt.com/flatstrap/

APACHE LICENSE

USE AND SHARE!
